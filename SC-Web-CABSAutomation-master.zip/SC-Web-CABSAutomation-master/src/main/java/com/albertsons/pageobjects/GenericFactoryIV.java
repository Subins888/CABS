package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GenericFactoryIV {
	

	/**
	 *  
	 * 
	 * @author akuma58
	 *
	 */
	
WebDriver Driver;


@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
WebElement createBillrcrd;
 
@FindBy(xpath="//*[@id='performanceCode1']/div/span")
WebElement perfCode;

@FindBy(xpath="//*[@id='performanceCode2']/div/span")
WebElement perfCode2;
 
//@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/allowinc-header-flat/div/div[1]/div[1]/cabs-checkbox/label/span")
@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/allowinc-header-flat/div/div[1]/div[1]/cabs-checkbox")
WebElement headerChckbox;

//@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[1]/div/div[1]/cabs-checkbox/label/span")
@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[1]/div/div[1]/cabs-checkbox")
WebElement itemChckbox;

//@FindBy(id="undefined")
@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-textbox/div/input")
WebElement qty;

@FindBy(xpath="//*[@id='flatAmount']/input")
WebElement fltAmnt;

@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
WebElement incSave;
				 
//@FindBy(xpath="//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[4]/cabs-amount/div/div/input")
//@FindBy(xpath="//*[@id='flatAmount']/div/input")
@FindBy(id="flatAmount")
public WebElement flatAmt;

@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[1]")
WebElement incSave2;

@FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
WebElement warngYes;

@FindBy(id="deductInvoiceNumber")
WebElement deductInv;

@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
WebElement invARPR;

@FindBy(xpath="//*[@id='arId']")
WebElement ARRadio;

@FindBy(xpath = "//*[@id='undefined']")
public WebElement txtDescr;

@FindBy(id="notesId")
public WebElement notesComment;

public GenericFactoryIV(WebDriver Driver) {
	this.Driver = Driver;
	PageFactory.initElements(Driver, this);
}
   
public String perfCodee(WebDriver Driver) {

	perfCode.click();
	return null;
}

public String perfCode2Drp(WebDriver Driver) {

	perfCode2.click();
	return null;
}
 
public String qtyy(WebDriver Driver){
	 
	
	//qty.findElement(By.className("form-control")).sendKeys("20");
	qty.sendKeys("10");
	qty.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,"20");	
	return null;
}

public String incSave22(WebDriver Driver){
	
	incSave2.click();
	return null;
}

public String notesTabFlatAmt(WebDriver Driver){
	
	notesComment.sendKeys("Test Notes Automation");
	notesComment.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,"1");	
	
	return null;
}

public String flatAmtt(WebDriver Driver) {
	//flatAmt.sendKeys("1");
	
	flatAmt.findElement(By.className("form-control")).sendKeys("1");	
	return null;
}
 

public String incSubmt(WebDriver Driver){
	
	incSave.click();
	return null;
}

public String warngYess(WebDriver Driver){
	
	warngYes.click();
	return null;
}

public String deductInvv(WebDriver Driver) {
	deductInv.findElement(By.className("form-control")).sendKeys("4114211122334");
	return null;
}


public String deductInvVal(WebDriver Driver) {
	deductInv.findElement(By.className("form-control")).sendKeys("15");
	return null;
}


public String invARPRr(WebDriver Driver) {
	return 	invARPR.getText();
	 
}

public String txtAreaa(WebDriver Driver) {
	txtDescr.sendKeys(" Test Automation II");
	return null;
}

public String ARRadioo(WebDriver Driver){
	
//	ARRadio.click();
	Actions actions = new Actions(Driver);
	actions.moveToElement(ARRadio).click().perform();
	return null;
}



}
