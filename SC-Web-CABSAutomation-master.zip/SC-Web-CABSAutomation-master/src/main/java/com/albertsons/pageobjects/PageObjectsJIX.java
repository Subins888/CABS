package com.albertsons.pageobjects;

import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

public class PageObjectsJIX extends ExtendBaseClass {
	WebDriver Driver;
	GenericFactoryJIX pageFactS10;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact;
	GenericFactoryJSprint3 pageFactS3;
	String date1,date2, notfdUser, assgndUser, sub;
	
	public PageObjectsJIX(WebDriver Driver) {
		this.Driver = Driver;

	}

	public String AlwnceBR(WebDriver Driver) throws IOException, InterruptedException, ParseException, BiffException {
        pageFact.waitForSpinnerToBeGone();
        Thread.sleep(1500);
        wait_forBlngbtn(Driver);
        Thread.sleep(15000);
        pageFactS10.analysis_wrklist.click();
        Thread.sleep(60000);
        pageFact.creatBillng();
		 Thread.sleep(60000);
       // Thread.sleep(15000);
	// pageFact.waitForSpinnerToBeGone();
        //Thread.sleep(2500);
        pageFact.blngrcrdDrp();
        Thread.sleep(4500);
        pageFact.retailalw();
        Thread.sleep(4500);

        pageFact.bRTypeRetailFieldAccValue();
        Thread.sleep(2500);
        pageFact.bRTypeRetailFieldOffNo();
        Thread.sleep(2500);
         pageFact.bRTypeRetailFieldLeadCIC();
        Thread.sleep(2500);
        pageFact.bRTypeRetailFieldStartDt();
        Thread.sleep(2500);
        pageFact.bRTypeRetailFieldEndDt();
        Thread.sleep(2500);
        pageFact.headerFlatAmtGrtZero();
        Thread.sleep(2500);
        pageFact.itemAlwType();
        Thread.sleep(2500);
        pageFact.allwtype();
        pageFactS10.allwTP1P2();
        Thread.sleep(2500);
        pageFact.brSubmit.click();
        Thread.sleep(4000);

        return null;

  }


	public String wait_forBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactS10.createBillrcrd));
		return null;
	}

	public String bRHeader(WebDriver Driver) throws InterruptedException {
        Thread.sleep(2000);
        pageFactS10.dedInv.findElement(By.className("form-control")).sendKeys(Keys.ENTER, "45375");
        Thread.sleep(3000);
        pageFactS10.fAmt.clear();
        pageFactS10.amt.sendKeys("10");
        // pageFactS10.amt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
        Thread.sleep(2000);
        pageFactS10.save.click();
  //     Thread.sleep(15000);
        //pageFact.waitForSpinnerToBeGone();
        Thread.sleep(55000);
        String brID = pageFactS10.BillingID();
        return brID;

  }


	public String OvrlapItemBillDt(WebDriver Driver, String BillId) throws InterruptedException, IOException {

		Thread.sleep(30000);
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);
		String Itm = pageFactS10.ovrlpItem();
		String Date = pageFactS10.ovrlpDate();
		System.out.println("Overalpped Items Before edit is : " + Itm);
		System.out.println("Overalpped Dates Before edit is : " + Date);
		pageFactS10.item.click();
		pageFactS10.EditDate();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);
		System.out.println("Overalpped Items After edit is : " + pageFactS10.ovrlpItem());
		System.out.println("Overalpped Dates After edit is : " + pageFactS10.ovrlpDate());

		int x = Integer.parseInt(Date) - 2;
		int Dt = Integer.parseInt(pageFactS10.ovrlpDate());
		if (Dt == x) {
			System.out.println("Overlap re-calculation is happening while changing the 'Item Bill Date'");
			extentTest.log(LogStatus.INFO, "Overlap re-calculation is happening while changing the 'Item Bill Date'");
		} else {
			System.out.println("Overlap re-calculation is not happening while changing the 'Item Bill Date'");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "Overlap re-calculation is not happening while changing the 'Item Bill Date'"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		return null;
	}

	public String AllwTypChange(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		String Itm = pageFactS10.ovrlpItem();
		String Date = pageFactS10.ovrlpDate();
		System.out.println("Overalpped Items Before edit is : " + Itm);
		System.out.println("Overalpped Dates Before edit is : " + Date);

		pageFactS10.alwTyp.click();
		pageFactS10.alwTypC.click();
		Thread.sleep(3000);
		pageFactS10.changePerfDt();
		Thread.sleep(3000);
		pageFactS10.save.click();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);

		System.out.println("Overalpped Items After edit is : " + pageFactS10.ovrlpItem());
		System.out.println("Overalpped Dates After edit is : " + pageFactS10.ovrlpDate());

		int x = Integer.parseInt(Date) - 2;
		int Dt = Integer.parseInt(pageFactS10.ovrlpDate());
		if (Dt == x) {
			System.out.println("Overlap re-calculation is happening while changing the 'Allowance Type'");
			extentTest.log(LogStatus.INFO, "Overlap re-calculation is happening while changing the 'Allowance Type'");
		} else {
			System.out.println("Overlap re-calculation is not happening while changing the 'Allowance Type'");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "Overlap re-calculation is not happening while changing the 'Allowance Type'"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		return null;
	}

	public String PerfChange(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		String Itm = pageFactS10.ovrlpItem();
		String Date = pageFactS10.ovrlpDate();
		System.out.println("Overalpped Items Before edit is : " + Itm);
		System.out.println("Overalpped Dates Before edit is : " + Date);

		pageFactS10.changePerfDtII();
		Thread.sleep(3000);
		pageFactS10.save.click();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);

		System.out.println("Overalpped Items After edit is : " + pageFactS10.ovrlpItem());
		System.out.println("Overalpped Dates After edit is : " + pageFactS10.ovrlpDate());

		int x = Integer.parseInt(Date) - 2;
		int Dt = Integer.parseInt(pageFactS10.ovrlpDate());
		if (Dt == x) {
			System.out.println("Overlap re-calculation is happening while changing the 'Performance Date'");
			extentTest.log(LogStatus.INFO, "Overlap re-calculation is happening while changing the 'Performance Date'");
		} else {
			System.out.println("Overlap re-calculation is not happening while changing the 'Performance Date'");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Overlap re-calculation is not happening while changing the 'Performance Date'"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		return null;
	}

	public String itemDel(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		String Itm = pageFactS10.ovrlpItem();
		String Date = pageFactS10.ovrlpDate();
		System.out.println("Overalpped Items Before edit is : " + Itm);
		System.out.println("Overalpped Dates Before edit is : " + Date);

		pageFactS10.DelItm();
		Thread.sleep(2000);

		pageFactS10.amt.click();
		pageFactS10.amt.sendKeys(Keys.TAB, Keys.ENTER);
		// pageFactS10.save.click();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);

		System.out.println("Overalpped Items After edit is : " + pageFactS10.ovrlpItem());
		System.out.println("Overalpped Dates After edit is : " + pageFactS10.ovrlpDate());

		int x = Integer.parseInt(Itm) - 1;
		int tm = Integer.parseInt(pageFactS10.ovrlpItem());
		if (tm == x) {
			System.out.println("Overlap re-calculation is happening while deleting an item (UPC)");
			extentTest.log(LogStatus.INFO, "Overlap re-calculation is happening while deleting an item (UPC)");
		} else {
			System.out.println("Overlap re-calculation is not happening while deleting an item (UPC)");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "Overlap re-calculation is not happening while deleting an item (UPC)"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		return null;
	}

	public String itemAdd(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		String Itm = pageFactS10.ovrlpItem();
		String Date = pageFactS10.ovrlpDate();
		System.out.println("Overalpped Items Before edit is : " + Itm);
		System.out.println("Overalpped Dates Before edit is : " + Date);

		pageFactS10.AddItm();

		Thread.sleep(15000);
		pageFactS10.save.click();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
		Thread.sleep(5000);
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);

		System.out.println("Overalpped Items After edit is : " + pageFactS10.ovrlpItem());
		System.out.println("Overalpped Dates After edit is : " + pageFactS10.ovrlpDate());

		int x = Integer.parseInt(Itm);
		int tm = Integer.parseInt(pageFactS10.ovrlpItem());
		if (tm == x) {
			System.out.println("Overlap re-calculation is happening while adding an item (CIC)");
			extentTest.log(LogStatus.INFO, "Overlap re-calculation is happening while adding an item (CIC)");
		} else {
			System.out.println("Overlap re-calculation is not happening while adding an item (CIC)");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "Overlap re-calculation is not happening while deleting an item (CIC)"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		return null;
	}

	public String itemDelCIC(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		String Itm = pageFactS10.ovrlpItem();
		String Date = pageFactS10.ovrlpDate();
		System.out.println("Overalpped Items Before edit is : " + Itm);
		System.out.println("Overalpped Dates Before edit is : " + Date);

		pageFactS10.DelItmCIC();
		Thread.sleep(2000);

		pageFactS10.amt.click();
		pageFactS10.amt.sendKeys(Keys.TAB, Keys.ENTER);
		// pageFactS10.save.click();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);

		System.out.println("Overalpped Items After edit is : " + pageFactS10.ovrlpItem());
		System.out.println("Overalpped Dates After edit is : " + pageFactS10.ovrlpDate());

		int x = Integer.parseInt(Itm);
		int tm = Integer.parseInt(pageFactS10.ovrlpItem());
		if (tm == x) {
			System.out.println("Overlap re-calculation is happening while deleting an item (CIC)");
			extentTest.log(LogStatus.INFO, "Overlap re-calculation is happening while deleting an item (CIC)");
		} else {
			System.out.println("Overlap re-calculation is not happening while deleting an item (CIC)");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "Overlap re-calculation is not happening while deleting an item (CIC)"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		return null;
	}

	public String BrEnd(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		WebElement ovpCnt = pageFactS10.overlapCnt.findElement(By.className("ng-value-label"));

		System.out.println("Overalp count before changing status is " + ovpCnt.getText());
		pageFactS10.chgStus();
		pageFactS10.save.click();
		Thread.sleep(55000);
		pageFactS10.allowTab.click();
        System.out.println("Overalp count after changing status is " + pageFactS10.overlapCntEnd.getText());

        if (pageFactS10.overlapCntEnd.getText().contains("0/0")) {

			System.out.println("There is no billing when BR status is Ended");
			extentTest.log(LogStatus.INFO, "There is no billing when BR status is Ended");
		} else {
			System.out.println("There are billings when BR status is Ended");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "There are billings when BR status is Ended"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		return null;
	}

	public String OvrlapDtlModal(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		Thread.sleep(30000);
		pageFactS10.item.click();
		
		 date1 =pageFactS10.ItmDt1();
		 date2 =pageFactS10.ItmDt2();
			
		pageFactS10.allowTab.click();
		pageFactS10.overlap.click();
		pageFactS10.ovrlp(BillId);
		pageFactS10.ovpItem.click();
		if (pageFactS10.ovpdtlmodal.getText().contentEquals("Overlap details by UPC")) {
			System.out.println(
					"Overlap Detail modal is opened by clicking on the hyperlink on item count row on overlap");
			extentTest.log(LogStatus.INFO,
					"Overlap Detail modal is opened by clicking on the hyperlink on item count row on overlap");
		} else {
			System.out.println(
					"Overlap Detail modal is opened by clicking on the hyperlink on item count row on overlap");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Overlap Detail modal is opened by clicking on the hyperlink on item count row on overlap"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		return null;
	}

	public String OvrlapDtlModalHdr(WebDriver Driver, String BillId,String BillIDNxt) throws InterruptedException, IOException {
		if (pageFactS10.ovpdtlmodal.getText().contentEquals("Overlap details by UPC")) {
			System.out.println("Overlap Detail modal heading is 'Overlap details by UPC'");
			extentTest.log(LogStatus.INFO, "Overlap Detail modal heading is 'Overlap details by UPC'");
		} else {
			System.out.println("Overlap Detail modal heading is not as expected");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, "Overlap Detail modal heading is not as expected"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		System.out.println("Overlap Detail modal header is showing");
		extentTest.log(LogStatus.INFO, "Overlap Detail modal header is showing");

		if (pageFactS10.ovpHdrItm().contentEquals("Items")) {
			System.out.println("'Items'");
			extentTest.log(LogStatus.INFO, "'Items'");
		} else {

			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, " " + extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		System.out.println(pageFactS10.ovpHdrBR1());
		if (pageFactS10.ovpHdrBR1().contentEquals("BR "+BillIDNxt+"\n" + 
				"Scan")) {
			System.out.println("'Current BR's Billing Record ID along with Allowance type group description'");
			extentTest.log(LogStatus.INFO, "'Current BR's Billing Record ID along with Allowance type group description'");
		} else {

			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, " " + extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		System.out.println(pageFactS10.ovpHdrBR2());
		if (pageFactS10.ovpHdrBR2().contentEquals("BR "+BillId+"\n" + 
				"Scan")) {
			System.out.println("'Overlapping BR's Billing Record ID along with Allowance type group description'");
			extentTest.log(LogStatus.INFO, "'Overlapping BR's Billing Record ID along with Allowance type group description'");
		} else {

			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, " " + extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if (pageFactS10.ovpHdrDays().contentEquals("Overlap Days")) {
			System.out.println("'Overlap Days'");
			extentTest.log(LogStatus.INFO, "'Overlap Days'");
		} else {

			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL, " " + extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		return null;
	}

	public String OvrlapDtlModalBody(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		
		if(pageFactS10.ovpBdyItm().contentEquals("1200017186")) {
			System.out.println(
					"First column in the table body is showing UPC");
			extentTest.log(LogStatus.INFO,
					"First column in the table body is showing UPC");
		} else {
			System.out.println(
					"First column in the table body is not showing UPC");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"First column in the table body is not showing UPC"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
	
		if(pageFactS10.ovpBdyCurrntBRDt1().contentEquals(date1)) {
			if(pageFactS10.ovpBdyCurrntBRDt2().contentEquals(date2)) {
			System.out.println(
					"Second column in the table body is showing Item Bill from and to dates for current BR");
			extentTest.log(LogStatus.INFO,
					"Second column in the table body is showing Item Bill from and to dates for current BR");
		} else {
			System.out.println(
					"Second column in the table body is not showing Item Bill from and to dates for current BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Second column in the table body is not showing Item Bill from and to dates for current BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		}else {
			System.out.println(
					"Second column in the table body is not showing Item Bill from and to dates for current BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Second column in the table body is not showing Item Bill from and to dates for current BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if(pageFactS10.ovpBdyOldBRDt1().contentEquals(date1)) {
			if(pageFactS10.ovpBdyOldBRDt2().contentEquals(date2)) {
			System.out.println(
					"Third column in the table body is showing Item Bill from and to dates for Overlapping BR");
			extentTest.log(LogStatus.INFO,
					"Third column in the table body is showing Item Bill from and to dates for Overlapping BR");
		} else {
			System.out.println(
					"Third column in the table body is not showing Item Bill from and to dates for Overlapping BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Third column in the table body is not showing Item Bill from and to dates for Overlapping BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		}else {
			System.out.println(
					"Third column in the table body is not showing Item Bill from and to dates for Overlapping BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Third column in the table body is not showing Item Bill from and to dates for Overlapping BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if(pageFactS10.ovpBdyovpdays().contentEquals("14")) {
			System.out.println(
					"Fourth column in the table body is showing number of days overlapping between item bill dates");
			extentTest.log(LogStatus.INFO,
					"Fourth column in the table body is showing number of days overlapping between item bill dates");
		} else {
			System.out.println(
					"Fourth column in the table body is not showing number of days overlapping between item bill dates");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,
					"Fourth column in the table body is not showing number of days overlapping between item bill dates"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
				return null;
	}
	
	
	public String OvrlapDtlModalBottm(WebDriver Driver, String BillId) throws InterruptedException, IOException {
		if(pageFactS10.ovpBdyMaxdays().contentEquals("Max Overlap    14 Day(s)")) {
			System.out.println(
					"Modal is showing Max Overlap days in bottom section, which is the count of unique overlapping dates");
			extentTest.log(LogStatus.INFO,
					"Modal is showing Max Overlap days in bottom section, which is the count of unique overlapping dates");
		} else {
			System.out.println(
					"Modal is not showing Max Overlap days in bottom section");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Modal is not showing Max Overlap days in bottom section"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		
		return null;
	}
	
	public String WarnMsg(WebDriver Driver) throws InterruptedException, IOException {
	
		Thread.sleep(30000);
		WebElement elm = pageFactS10.iNotes.findElement(By.className("form-control"));
		elm.sendKeys("Test");
		
		pageFactS10.searchBR.click();
		pageFactS10.warnMsgNo.click();
		
		pageFactS10.searchBR.click();
		pageFactS10.warnMsgYs.click();
	
		Thread.sleep(20000);
		
		if(pageFactS10.srchBRlabl.getText().contains("Home   >   Search Billing Record")) {
			System.out.println(
					"Not Saved warning message is showing for BR");
			extentTest.log(LogStatus.INFO,
					"Not Saved warning message is showing for BR");
		} else {
			System.out.println(
					"Not Saved warning message is not showing for BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Not Saved warning message is not showing for BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		
		return null;
	}
	
	public String nonAlwnceNew(WebDriver Driver) throws InterruptedException {

		wait_forBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		pageFact.BrTyp();
		Thread.sleep(2500);
		pageFact.nonAllwdrp();
		pageFact.submitClk();
		
		return null;
	} 
	
	public String brSavNonAlw(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		pageFactS10.retDivDrp.click();
		Thread.sleep(3000);
		pageFactS10.retDiv.click();
		Thread.sleep(2000);
		pageFactS10.retDivVal.click();
		Thread.sleep(2000);
		pageFactS10.retValu.click();
		pageFactS10.deductnum.findElement(By.className("form-control")).sendKeys("45375");
		Thread.sleep(2000);
		pageFactS10.txtDescr.sendKeys(" Test Automation II");
		Thread.sleep(2000);
		pageFactS10.brSavebtn.click();
		Thread.sleep(55000);
		String brID = pageFactS10.BillingID();
		return brID;
	}
	
	public String addDialog(WebDriver Driver) {
		pageFactS10.addDialog.click();
		pageFactS10.subjectDrpMisc.click();
		sub=pageFactS10.subjectVal.getText();
		pageFactS10.subjectVal.click();
		pageFactS10.assignToDrpMisc.click();
		assgndUser = pageFactS10.assignedUser.getText();
		pageFactS10.assignedUser.click();
		pageFactS10.notifyDrp.click();
		notfdUser = pageFactS10.notifiedUser.getText();
		pageFactS10.notifiedUser.click();
		pageFactS10.reason.sendKeys("Test");
		pageFactS10.dialogSave.click();
		
		return null;
	}
	public String dialogWklst(WebDriver Driver,String s) throws IOException {
		
		System.out.println(pageFactS10.dialogWrklst.getText());
		
		String s1 = pageFactS10.dialogWrklst.getText().substring(pageFactS10.dialogWrklst.getText().indexOf("(")+1,pageFactS10.dialogWrklst.getText().indexOf(")"));
		
		if(pageFactS10.dialogWrklst.getText().contains("DIALOG WORKLIST ("+s1+")")) {
			System.out.println(
					"The 'Dialog worklist' menu on side bar is showing the count of active dialogs for the "+s+" user in 'Worklist for' drop down for the selected team");
			extentTest.log(LogStatus.INFO,
					"The 'Dialog worklist' menu on side bar is showing the count of active dialogs for the "+s+" user in 'Worklist for' drop down for the selected team");
		} else {
			System.out.println(
					"The 'Dialog worklist' menu on side bar is not showing the count of active dialogs for the "+s+" user in 'Worklist for' drop down for the selected team");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"The 'Dialog worklist' menu on side bar is not showing the count of active dialogs for the "+s+" user in 'Worklist for' drop down for the selected team"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		return null;
	}
	
	public String dialogWklstwklstFrNotfdUsr(WebDriver Driver) throws IOException, InterruptedException {
		
		String s2 = notfdUser.substring(notfdUser.indexOf("-")+2,notfdUser.length());
		
		pageFactS10.wrklstFr.sendKeys(s2,Keys.ENTER);
	//	pageFactS10.warngYs.click();
		Thread.sleep(15000);
		return null;
	}
	
	public String dialogWklstwklstFrAsgUsr(WebDriver Driver) throws IOException, InterruptedException {
		
		String s2 = assgndUser.substring(assgndUser.indexOf("-")+2,assgndUser.length());
		pageFactS10.wrklstFr.sendKeys(s2,Keys.ENTER);
		Thread.sleep(55000);
		return null;
	}
	
public String dialogWklstField(WebDriver Driver,String Billid) throws IOException, InterruptedException {
		
		pageFactS10.dialogWrklst.click();
		Thread.sleep(46000);
		pageFactS10.parntBr.click();
		Thread.sleep(25000);
		
		if(pageFactS10.parntBr.getText().contains("Parent BR")) {
			System.out.println(
					"First field is Parent BR");
			extentTest.log(LogStatus.INFO,
					"First field is Parent BR");
		}
		else {
			System.out.println(
					"First field is not Parent BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"First field is not Parent BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		
		
			if(pageFactS10.parntBrid.getText().equals(Billid)) {
				System.out.println(
						"Parent BR field is showing BR from which the dialog originated");
				extentTest.log(LogStatus.INFO,
						"Parent BR field is showing BR from which the dialog originated");
			}
			else {
				System.out.println(
						"Parent BR field is not showing BR from which the dialog originated");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Parent BR field is not showing BR from which the dialog originated"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}	
		
			
			if(pageFactS10.Br.getText().contains("BR")) {
				System.out.println(
						"Second field is BR");
				extentTest.log(LogStatus.INFO,
						"Second field is BR");
			}
			else {
				System.out.println(
						"Second field is not BR");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Second field is not BR"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}	
			
			if(pageFactS10.area.getText().contains("Area")) {
				System.out.println(
						"Third field is Area");
				extentTest.log(LogStatus.INFO,
						"Third field is Area");
			}
			else {
				System.out.println(
						"Third field is not Area");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Third field is not Area"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}	
			
			if(pageFactS10.areaval1.getText().contains("Retail Div")) {
				if(pageFactS10.areaval2.getText().contains("15"))
				System.out.println(
						"Area is showing Acct Lkup Type & Val in double decker format");
				extentTest.log(LogStatus.INFO,
						"Area is showing Acct Lkup Type & Val in double decker format");
			}
			else {
				System.out.println(
						"Area is not showing Acct Lkup Type & Val in double decker format");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Area is not showing Acct Lkup Type & Val in double decker format"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}	
			
			if(pageFactS10.catgry.getText().contains("Category")) {
				System.out.println(
						"Fourth field is Category");
				extentTest.log(LogStatus.INFO,
						"Fourth field is Category");
			}
			else {
				System.out.println(
						"Fourth field is not Category");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Fourth field is not Category"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}
			

			if(pageFactS10.subj.getText().contains(sub)) {
				System.out.println(
						"Category field is showing the Subject of the dialog");
				extentTest.log(LogStatus.INFO,
						"Category field is showing the Subject of the dialog");
			}
			else {
				System.out.println(
						"Category field is not showing the Subject of the dialog");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Category field is not showing the Subject of the dialog"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}
			
			if(pageFactS10.asgnTo.getText().contains("Assign To")) {
				System.out.println(
						"Fifth field is Assign To");
				extentTest.log(LogStatus.INFO,
						"Fifth field is Assign To");
			}
			else {
				System.out.println(
						"Fifth field is not Assign To");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Fifth field is not Assign To"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}
			
			if(pageFactS10.ntfy.getText().contains("Notify To")) {
				System.out.println(
						"Sixth field is Notify To");
				extentTest.log(LogStatus.INFO,
						"Sixth field is Notify To");
			}
			else {
				System.out.println(
						"Sixth field is not Notify To");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Sixth field is not Notify To"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}
			
			if(pageFactS10.initBy.getText().contains("Initiated By")) {
				System.out.println(
						"Seventh field is Initiated By");
				extentTest.log(LogStatus.INFO,
						"Seventh field is Initiated By");
			}
			else {
				System.out.println(
						"Seventh field is not Initiated By");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Seventh field is not Initiated By"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}
			
			if(pageFactS10.rcntCmt.getText().contains("Recent Comment")) {
				System.out.println(
						"Eighth field is Recent Comment");
				extentTest.log(LogStatus.INFO,
						"Eighth field is Recent Comment");
			}
			else {
				System.out.println(
						"Eighth field is not Recent Comment");
				String source = aftermthd(Driver);

				extentTest.log(LogStatus.FAIL,"Eighth field is not Recent Comment"
								+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}
		return null;
	}


public String dialogWklstFieldRtl(WebDriver Driver,String Billid) throws IOException, InterruptedException {
	
	pageFactS10.dialogWrklst.click();
	//pageFactS10.warngYs.click();
	Thread.sleep(46000);
	pageFactS10.parntBr.click();
	Thread.sleep(25000);
	
	if(pageFactS10.parntBr.getText().contains("Parent BR")) {
		System.out.println(
				"First field is Parent BR");
		extentTest.log(LogStatus.INFO,
				"First field is Parent BR");
	}
	else {
		System.out.println(
				"First field is not Parent BR");
		String source = aftermthd(Driver);

		extentTest.log(LogStatus.FAIL,"First field is not Parent BR"
						+ extentTest.addScreenCapture("data:image/png;base64," + source));
	}	
	
		if(pageFactS10.parntBrid.getText().equals(Billid)) {
			System.out.println(
					"Parent BR field is showing BR from which the dialog originated");
			extentTest.log(LogStatus.INFO,
					"Parent BR field is showing BR from which the dialog originated");
		}
		else {
			System.out.println(
					"Parent BR field is not showing BR from which the dialog originated");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Parent BR field is not showing BR from which the dialog originated"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
	
		
		if(pageFactS10.Br.getText().contains("BR")) {
			System.out.println(
					"Second field is BR");
			extentTest.log(LogStatus.INFO,
					"Second field is BR");
		}
		else {
			System.out.println(
					"Second field is not BR");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Second field is not BR"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		
		if(pageFactS10.area.getText().contains("Area")) {
			System.out.println(
					"Third field is Area");
			extentTest.log(LogStatus.INFO,
					"Third field is Area");
		}
		else {
			System.out.println(
					"Third field is not Area");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Third field is not Area"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		
		if(pageFactS10.areaval1.getText().contains("Retail Div")) {
			if(pageFactS10.areaval2.getText().contains("15"))
			System.out.println(
					"Area is showing Acct Lkup Type & Val in double decker format");
			extentTest.log(LogStatus.INFO,
					"Area is showing Acct Lkup Type & Val in double decker format");
		}
		else {
			System.out.println(
					"Area is not showing Acct Lkup Type & Val in double decker format");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Area is not showing Acct Lkup Type & Val in double decker format"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}	
		
		if(pageFactS10.catgry.getText().contains("Category")) {
			System.out.println(
					"Fourth field is Category");
			extentTest.log(LogStatus.INFO,
					"Fourth field is Category");
		}
		else {
			System.out.println(
					"Fourth field is not Category");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Fourth field is not Category"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		

		if(pageFactS10.subj.getText().contains(sub)) {
			System.out.println(
					"Category field is showing the Subject of the dialog");
			extentTest.log(LogStatus.INFO,
					"Category field is showing the Subject of the dialog");
		}
		else {
			System.out.println(
					"Category field is not showing the Subject of the dialog");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Category field is not showing the Subject of the dialog"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if(pageFactS10.asgnTo.getText().contains("Assign To")) {
			System.out.println(
					"Fifth field is Assign To");
			extentTest.log(LogStatus.INFO,
					"Fifth field is Assign To");
		}
		else {
			System.out.println(
					"Fifth field is not Assign To");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Fifth field is not Assign To"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if(pageFactS10.ntfy.getText().contains("Notify To")) {
			System.out.println(
					"Sixth field is Notify To");
			extentTest.log(LogStatus.INFO,
					"Sixth field is Notify To");
		}
		else {
			System.out.println(
					"Sixth field is not Notify To");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Sixth field is not Notify To"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if(pageFactS10.initBy.getText().contains("Initiated By")) {
			System.out.println(
					"Seventh field is Initiated By");
			extentTest.log(LogStatus.INFO,
					"Seventh field is Initiated By");
		}
		else {
			System.out.println(
					"Seventh field is not Initiated By");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Seventh field is not Initiated By"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
		
		if(pageFactS10.rcntCmt.getText().contains("Recent Comment")) {
			System.out.println(
					"Eighth field is Recent Comment");
			extentTest.log(LogStatus.INFO,
					"Eighth field is Recent Comment");
		}
		else {
			System.out.println(
					"Eighth field is not Recent Comment");
			String source = aftermthd(Driver);

			extentTest.log(LogStatus.FAIL,"Eighth field is not Recent Comment"
							+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}
	return null;
}
	
	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) throws InterruptedException {

		pageFactS10 = new GenericFactoryJIX(Driver);
		pageFact = new GenericFactory(Driver);
		// pageFactS3 = new GenericFactoryJSprint3(Driver);

	}
}
