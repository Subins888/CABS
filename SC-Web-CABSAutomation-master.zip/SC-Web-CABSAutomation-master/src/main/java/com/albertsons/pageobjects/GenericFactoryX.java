package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

public class GenericFactoryX {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;
	public WebElement LCIC;

	@FindBy(id = "accountLookupValue")
	WebElement COGSval;

	@FindBy(xpath = "//*[@id=\"leadCIC\"]")
	public WebElement leadCIC;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
	public WebElement errMsg;

	@FindBy(xpath = "//*[@id=\"accountLookupValue\"]")
	public WebElement accLkUpVal;

	@FindBy(id = "ta-accountLookupValue-1")
	public WebElement selAccLkUpVal;

	@FindBy(id = "ta-accountLookupValue-2")
	public WebElement selAccLkUpVal2;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement warningYes;

	@FindBy(id = "section")
	public WebElement sectionNum;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement ready;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[4]/button")
	public WebElement addIncomeRetail;

	@FindBy(id = "notesId")
	public WebElement notes;

	@FindBy(xpath = "//*[@id='flatAmount']/input")
	public WebElement flatAmount;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
	public WebElement incomeSubmit;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	public WebElement invoice;

	@FindBy(id = "offsetAccountNumber")
	public WebElement AccountNum;

	@FindBy(id = "offsetFacilityNumber")
	public WebElement FacilityNum;

	@FindBy(id = "offsetSectionNumber")
	public WebElement SectionNum;

	@FindBy(xpath = "//*[@id='teamDropdown']/span[2]/fa/i")
	public WebElement teamDrp;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[2]/a")
	public WebElement xternal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement searchFirstItem;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement cic;

	@FindBy(xpath = "//*[@id='item-tab']/div[1]/i-feather")
	public WebElement itemdetailsPlus;

	// @FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span")
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span/i-feather")
	public WebElement CloseBtn;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span/span")
	public WebElement errMsgBrSave;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
	public WebElement errMsgBrSaveII;
	
	
	@FindBy(xpath = "//*[@id='undefined']/input")
	public WebElement itemDetailsAmnt;
	
	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;
	
	@FindBy(xpath="//*[@id='allowanceType']/div/div/div[2]/input")
	public WebElement alwTypDrp;
	
	@FindBy(xpath="//*[@id='allowanceType']/div/div/div[3]/input")
	public WebElement alwTypDrpII;
	
	@FindBy(xpath="//*[@id='performanceCode1']/div/span")
	public WebElement perf1Drp;
	
	@FindBy(xpath="//*[@id='performanceCode1']/div/div/div[2]/input")
	public WebElement perf1DrpII;
	
	@FindBy(xpath="//*[@id='performanceCode1']/div/div/div[3]/input")
	public WebElement perf1Val;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[1]/a")
	public WebElement analysisWorklist;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")
	public WebElement pagination;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement brNumSearch;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
	public WebElement brstatusSearch;
	
	@FindBy(xpath="//*[@id='brStatus']/div/div/div[3]/input")
	public WebElement brStatusDrp;
	
	@FindBy(id="ta-brStatus-1")
	public WebElement brStatusDrpVal;
	
	@FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[2]/label")
	public WebElement warning;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[1]/div/div[3]/cabs-checkbox/label/span")
	public WebElement accountOverride;
	
	@FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	public WebElement overrideNO;
	
	public String sectionN(WebDriver Driver) {

		sectionNum.findElement(By.className("form-control")).getText();

		return null;
	}
	
	public String itemDetailsAmntt(WebDriver Driver)
			throws InterruptedException {
		itemDetailsAmnt.sendKeys("1");
		itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		save.click();
		Thread.sleep(5000);
	 
		System.out.println("Clicked on Save button");
		 
		return null;
	}
	
	public String itemDetailsAmnttII(WebDriver Driver)
			throws InterruptedException {
//		itemDetailsAmnt.sendKeys("1");
//		itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		save.click();
		Thread.sleep(5000);
	 
		System.out.println("Clicked on Save button");
		 
		return null;
	}
	
	public String itemDetailsAmnttNoSave(WebDriver Driver)
			throws InterruptedException {
		itemDetailsAmnt.sendKeys("1");
		itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		 
		Thread.sleep(5000);
 
		 
		return null;
	}

	public boolean bRTypeRetailFieldLeadCIC() throws BiffException, IOException {
		// public boolean bRTypeRetailFieldLeadCIC() throws BiffException,
		// IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(20, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
		// LCIC.sendKeys("15200143");
		// return null;
	}

	public boolean bRTypeRetailFieldLeadCICCOGS() throws BiffException, IOException {
		// public boolean bRTypeRetailFieldLeadCIC() throws BiffException,
		// IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(7, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
		// LCIC.sendKeys("15200143");
		// return null;
	}
	 

	public boolean bRTypeRetailFieldAccValue(WebDriver Driver)
			throws InterruptedException {

		Thread.sleep(2500);
		accLkUpVal.click();
		Thread.sleep(2500);
		// selAccLkUpVal.click();
		selAccLkUpVal.click();

		if (accLkUpVal.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public boolean bRTypeRetailFieldAccValueII(WebDriver Driver)
			throws InterruptedException {

		Thread.sleep(2500);
		accLkUpVal.click();
		Thread.sleep(2500);
		// selAccLkUpVal.click();
		selAccLkUpVal2.click();

		if (accLkUpVal.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public GenericFactoryX(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}
}
