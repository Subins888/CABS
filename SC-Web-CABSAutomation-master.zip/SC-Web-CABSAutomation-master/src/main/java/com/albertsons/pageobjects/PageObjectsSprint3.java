package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.concurrent.TimeUnit;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * 
 * 
 * @author akuma58
 *
 */
public class PageObjectsSprint3 extends ExtendBaseClass {

	WebDriver Driver;
	GenericFactory pageFact;
	GenericFactorySprint3 pageFactAS3;
	GenericFactoryIV pageFactIV;
	PageObjects PO;
	String extentReportImage282PO_0;
	String extentReportImage282PO_01;
	String extentReportImage279PO_01;
	String extentReportImage279PO_1;
	String extentReportImage268PO_01;
	String extentReportImage268PO_02;
	String extentReportImage451PO_0;
	String extentReportImage451PO_1;
	String extentReportImage451PO_2;
	String extentReportImage468PO_01;
	String extentReportImage282PO_04;
	String extentReportImage282PO_05;

	public PageObjectsSprint3(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public File aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}

	public String wait_forSectid(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactAS3.offsetSec));
		return null;
	}

	public String sectionId(WebDriver Driver) throws IOException,
			InterruptedException, ParseException {

		wait_forSectid(Driver);
		Thread.sleep(5000);
		pageFactAS3.sectiId(Driver);

		String testelem = pageFactAS3.offsetSec.getAttribute("value");
		System.out.println("Section ID displaying is - " + testelem);
		extentTest
				.log(LogStatus.INFO, "Section ID displaying is - " + testelem);

		return null;
	}

	public String incomeAddClk(WebDriver Driver) {

		pageFactAS3.addIncmeBtnn(Driver);
		return null;
	}

	public String incomeCancelOk(WebDriver Driver) throws InterruptedException,
			IOException {
		
		Thread.sleep(2000);
		System.out.println("TEST");
		pageFactAS3.comentTxtBox(Driver);
		System.out.println("TEST 2");
		pageFactAS3.descripTxtBo(Driver);
		pageFactAS3.incAmntt(Driver);
		pageFactAS3.cancelBtn(Driver);

		Thread.sleep(5000);
		pageFactAS3.cancelOKbtn(Driver);

		Thread.sleep(5000);

		if (pageFactAS3.incmCancel.isDisplayed()) {
			System.out.println("Cancel functionality not working");
			extentTest.log(LogStatus.FAIL, "Cancel functionality not working");
			extentReportImage282PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_0.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage282PO_0);
			FileUtils.copyFile(source, destination);
		} else {
			System.out
					.println("Clicked 'OK' button from cancel pop up, successfully canceled the action");

			extentTest
					.log(LogStatus.INFO,
							"Clicked 'OK' button from cancel pop up, successfully canceled the action");
		}
		return null;
	}

	public String itemCancelCan(WebDriver Driver) throws IOException,
			InterruptedException {

		Thread.sleep(2000);
		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		pageFactAS3.incAmntt(Driver);
		pageFactAS3.cancelBtn(Driver);
		Thread.sleep(2500);
		pageFactAS3.cancelCanbtn(Driver);

		if (pageFactAS3.incmCancel.isDisplayed()) {
			System.out
					.println("Clicked on 'Cancel' button from 'Warning' pop up and is working fine");
			extentTest
					.log(LogStatus.INFO,
							"Clicked on 'Cancel' button from 'Warning' pop up and is working fine");
		} else {
			System.out
					.println("Clicked on 'Cancel' button from 'Warning' pop up and Cancel action not working properly");
			extentReportImage282PO_01 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_0.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage282PO_01);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Clicked on 'Cancel' button from 'Warning' pop up and Cancel action not working properly"
									+ extentTest
											.addScreenCapture(extentReportImage282PO_01));
		}

		return null;
	}

	public String SaveandCancel(WebDriver Driver) throws InterruptedException,
			IOException {

		try {
		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		pageFactAS3.incAmntt(Driver);
		pageFactAS3.incmdsavee();
		Thread.sleep(5000);
		pageFactAS3.cancelBtn(Driver);
		Thread.sleep(5000);
		pageFactAS3.cancelOKbtn(Driver);
		Thread.sleep(5000);
		pageFact.incmbtnclk();

		Thread.sleep(3000);
		if (pageFactAS3.comentTxtBoxx(Driver) == true) {
			System.out.println("Cancel functionality WORKING");
			extentTest
					.log(LogStatus.INFO,
							"Clicked 'OK' button from cancel pop up, successfully canceled the saved data");
		} else {
			System.out.println("Cancel functionality not WORKING");
			extentReportImage282PO_05 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage282PO_05.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage282PO_05);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Clicked 'OK' button from cancel pop up, not canceled the saved data"
									+ extentTest
											.addScreenCapture(extentReportImage282PO_05));

		}}
		catch(Exception e) {
			
			System.out.println("Cancel button disabled/action not possible for the loggin'd user");
			extentTest
					.log(LogStatus.INFO,
							"Cancel button disabled/action not possible for the loggin'd user");
		}

		return null;
	}

	public String SaveandCancel2(WebDriver Driver) throws InterruptedException,
			IOException {

		try {
		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		pageFactAS3.incAmntt(Driver);
		pageFactAS3.cancelBtn(Driver);
		Thread.sleep(5000);
		pageFactAS3.cancelCanbtn(Driver);
		Thread.sleep(5000);
		pageFact.incmbtnclk();

		Thread.sleep(3000);
		if (pageFactAS3.comentTxtBoxx(Driver) == false) {
			System.out.println("Cancel functionality WORKING");
			extentTest
					.log(LogStatus.INFO,
							"Clicked 'Cancel' button from cancel pop up, successfully retains the saved data");
		} else {
			System.out.println("Cancel functionality not WORKING");
			extentReportImage282PO_04 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage282PO_04.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage282PO_04);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Clicked 'Cancel' button from cancel pop up, not retains the saved data"
									+ extentTest
											.addScreenCapture(extentReportImage282PO_04));
		}}
		catch(Exception e) {
			
			System.out.println("Cancel button disabled/action not possible for the loggin'd user");
			extentTest
					.log(LogStatus.INFO,
							"Cancel button disabled/action not possible for the loggin'd user");
		}
		return null;
	}

	public String incomeRetCancelOk(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);

		pageFactAS3.notesTxtBoxx(Driver);
		// pageFactAS3.flatAmtt(Driver);
		pageFactAS3.notesTabFlatAmt(Driver);
		Thread.sleep(2000);
		// pageFactAS3.incAmntt(Driver);
		pageFactAS3.cancelBtn2(Driver);

		Thread.sleep(5000);
		pageFactAS3.cancelOKbtn(Driver);

		Thread.sleep(5000);

		if (pageFactAS3.incmCancel2.isDisplayed()) {
			System.out
					.println("TESTCASE FAILED:  Cancel functionality not working");
			extentTest.log(LogStatus.FAIL, "Cancel functionality not working");
		} else {
			System.out.println("Clicked 'OK' button from cancel pop up");
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Clicked 'OK' button from cancel pop up");

		}

		pageFactAS3.addIncmeBtnn(Driver);

		Thread.sleep(3000);
		if (pageFactAS3.notesTxtBoxxx(Driver) == true) {
			System.out.println("Cancel functionality WORKING");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Clicked 'OK' button from cancel pop up, successfully canceled the action");
		} else {
			System.out.println("Cancel functionality not WORKING");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Cancel functionality not WORKING");
		}

		return null;
	}

	
	public String incSavClk(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactAS3.incmdsavee();
	 	pageFactAS3.incmErrBtnn(Driver);
		
		// MOUSE OVER CODE

		WebElement we = pageFactAS3.incmErrBtn;
		Actions action = new Actions(Driver);
		action.moveToElement(we).build().perform();
		String toolTipElement = pageFactAS3.warningContent.getText();
	//	Thread.sleep(5000);
	//	String toolTipText = toolTipElement.getText();
	 
		System.out.println(toolTipElement);
		extentTest.log(LogStatus.INFO, "The tooltip text displaying is: "
				+ toolTipElement);
		
		
		Thread.sleep(2500);
		//String errIncm = pageFactAS3.incmErrMsgg();

		if (toolTipElement.equals("Please enter required fields.")) {
			System.out
					.println("Error Message displayed properly on clicking icon.  Error message displayed is: "
							+ toolTipElement);
			extentTest
					.log(LogStatus.INFO,
							"Error Message displayed properly on clicking icon.  Error message displayed is: "
									+ toolTipElement);
		} else {
			System.out
					.println("Displaying error message is wrong.  Error message showing is:  "
							+ toolTipElement);
			extentTest.log(LogStatus.FAIL,
					"Displaying error message is wrong.  Error message showing is:  "
							+ toolTipElement);

			extentReportImage279PO_01 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage279PO_01.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage279PO_01);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Assign To dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage279PO_01));
		}

		return null;
	}

	public String incSavClkOLD(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactAS3.incmdsavee();
		pageFactAS3.incmErrBtnn(Driver);
		Thread.sleep(1500);
		String errIncm = pageFactAS3.incmErrMsgg();

		if (pageFactAS3.incmErrMsgg().equals("Please enter required fields.")) {
			System.out
					.println("Error Message displayed properly on clicking icon.  Error message displayed is: "
							+ errIncm);
			extentTest
					.log(LogStatus.INFO,
							"Error Message displayed properly on clicking icon.  Error message displayed is: "
									+ errIncm);
		} else {
			System.out
					.println("Displaying error message is wrong.  Error message showing is:  "
							+ errIncm);
			extentTest.log(LogStatus.FAIL,
					"Displaying error message is wrong.  Error message showing is:  "
							+ errIncm);

			extentReportImage279PO_01 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage279PO_01.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage279PO_01);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Assign To dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage279PO_01));
		}

		return null;
	}

	public String incSaveBtn() throws IOException, InterruptedException {

		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		pageFactAS3.incAmntt(Driver);		
		pageFactAS3.incmSubmtt();
		System.out.println("Clicked on Income Submit button");
 		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");
		Thread.sleep(3000);

//		if (pageFactAS3.incmSubmt.isDisplayed()) {
//			System.out.println("Unable to submit Income");
//			extentTest.log(LogStatus.FAIL, "Unable to submit Income");
//			//
//			// extentReportImage279PO_1 = System.getProperty("user.dir")
//			// + "\\picture" + "\\extentReportImage279PO_1.png";
//			// File source = aftermthd(Driver);
//			// File destination = new File(extentReportImage279PO_1);
//			// FileUtils.copyFile(source, destination);
//			// extentTest.log(LogStatus.FAIL, "Save button not displayed"
//			// + extentTest.addScreenCapture(extentReportImage279PO_1));
//
//		} else {
//			System.out.println("Income successfully Submitted");
//			extentTest.log(LogStatus.INFO, "Income successfully Submitted");
//		}

		return null;
	}

	public String incmAmtErrCheck(WebDriver Driver) throws InterruptedException {

		Driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		pageFactAS3.incmbtnclk();
		
		System.out.println("Clicked on income button");
		pageFactAS3.incmbtnclk();
		System.out.println("Clicked on income button again");
		Driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		pageFactAS3.incAmnttInvald(Driver);
		extentTest
				.log(LogStatus.INFO,
						"Tried to enter amount with more than 2 decimal value in Amount field");
		Thread.sleep(2000);
		String amntTxt = pageFactAS3.incAmntTxt(Driver);

		extentTest.log(LogStatus.INFO,
				"The value returned after entering amount with more than 2 decimal value is:  "
						+ amntTxt);
		System.out.println("value OS"
				+ pageFactAS3.incAmntInput.getAttribute("value"));
		System.out.println("value is" + pageFactAS3.incAmntInput.getText());
		System.out.println("value es" + pageFactAS3.incAmnt.getText());
		System.out.println("value ss"
				+ pageFactAS3.incAmnt.getAttribute("value"));
		System.out.println("value as"
				+ pageFactAS3.incAmnt.getAttribute("value"));

		// pageFactAS3.incAmnttClear(Driver);
		pageFactAS3.incAmnttInvald2(Driver);
		extentTest.log(LogStatus.INFO,
				"Tried to enter Alphabet in Amount field");
		extentTest.log(LogStatus.INFO,
				"The value returned after entering Alphabet in Amount field is:  "
						+ amntTxt);

		return null;
	}

	public String offsetmanualInvalid(WebDriver Driver)
			throws InterruptedException, IOException {

		try {
			pageFactAS3.accntretNeww(Driver);
			// pageFactAS3.newRetvaluee1();
			pageFactAS3.newRetvaluee3();

			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(3000);
			// pageFactAS3.ofsetAcntNumm(Driver);
			pageFactAS3.ofsetSecNumm(Driver);
			pageFactAS3.ofsetFacNumm(Driver);
			// pageFactAS3.elmntIntract(Driver);
			Thread.sleep(2500);
			pageFactAS3.blngname(Driver);
			pageFactAS3.txtAreaa(Driver);
			pageFactAS3.newBRSave(Driver);

			String invErrMsg = pageFactAS3.invalidOfseterroMsg();
			if (pageFactAS3.invalidOfseterroMsg().contains("Invalid Offset")) {
				System.out
						.println("Error Message displayed properly on entering invalid manual offset number.  Error message displayed is: "
								+ invErrMsg);
				extentTest
						.log(LogStatus.INFO,
								"Error Message displayed properly on entering invalid manual offset number.  Error message displayed is: "
										+ invErrMsg);
			} else {
				System.out
						.println("Displaying error message is wrong.  Error message showing is:  "
								+ invErrMsg);
				extentTest.log(LogStatus.FAIL,
						"Displaying error message is wrong.  Error message showing is:  "
								+ invErrMsg);

				extentReportImage268PO_01 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage268PO_01.png";
				File source = aftermthd(Driver);
				File destination = new File(extentReportImage268PO_01);
				FileUtils.copyFile(source, destination);
				extentTest
						.log(LogStatus.FAIL,
								"Assign To dropdown not displaying properly in the UI"
										+ extentTest
												.addScreenCapture(extentReportImage268PO_01));
			}

		} catch (Exception e) {
			pageFactAS3.accntretNeww(Driver);
			// pageFactAS3.newRetvaluee1();
			pageFactAS3.newRetvaluee3();

			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(3000);

			pageFactAS3.blngname(Driver);
			pageFactAS3.txtAreaa(Driver);
			pageFactAS3.newBRSave(Driver);
			pageFact.waitForSpinnerToBeGone();

			 
			System.out.println("Error message displaying properly");
			extentTest.log(LogStatus.INFO, "Error message displaying properly");

		}

		return null;
	}

	public String manualOfsetvalid(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFactAS3.accntretNeww(Driver);
		  //pageFactAS3.aclukupVall(Driver);
	//	pageFactAS3.aclukupVall5(Driver);
				
		pageFactAS3.newRetvaluee1();

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				String s1 = s.getCell(0, i).getContents();
				String s2 = s.getCell(1, i).getContents();
				String s3 = s.getCell(2, i).getContents();

				Thread.sleep(3000);

				pageFactAS3.ofsetAcntNum.sendKeys(s1);
				pageFactAS3.ofsetFacNum.sendKeys(s2);
				pageFactAS3.ofsetSecNum.sendKeys(s3);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		pageFactAS3.newBRSave(Driver);
		Thread.sleep(3000);

		String valErrMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Manualy entered valid offset number submitted successfully.  Success message displayed is: "
							+ valErrMsg);
			extentTest
					.log(LogStatus.INFO,
							"Manualy entered valid offset number submitted successfully.  Success message displayed is: "
									+ valErrMsg);
		} else {
			System.out
					.println("Error in saving offset number.  Error message showing is:  "
							+ valErrMsg);
			extentTest.log(LogStatus.FAIL,
					"Error in saving offset number.  Error message showing is:  "
							+ valErrMsg);

			extentReportImage268PO_02 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage268PO_02.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage268PO_02);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Assign To dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage268PO_02));
		}
		return null;
	}

	public String incmSavebutton(WebDriver Driver) throws IOException,
			InterruptedException {

		Thread.sleep(5000);
		if (pageFactAS3.incmeSaveBtn.isDisplayed()) {
			System.out.println("Income section not collapsed by default");
			extentTest.log(LogStatus.FAIL,
					"Income section not collapsed by default");
			extentReportImage451PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage451PO_0.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage451PO_0);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.INFO,
							"Income section collapsed by default"
									+ extentTest
											.addScreenCapture(extentReportImage451PO_0));
		} else {
			System.out.println("Income section collapsed by default");

			extentTest.log(LogStatus.INFO,
					"Income section collapsed by default");

		}
		return null;
	}

	public String BRSaveNew(WebDriver Driver) throws InterruptedException,
			IOException {

		try{
			
	 
		pageFact.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(3000);
		pageFactAS3.itemDetailsAmntt(Driver);
		Thread.sleep(36000);
		pageFact.brStatusdrpclk();
		// pageFactAS3.brStatusdropp(Driver);
		Thread.sleep(3000);
		String brStatusvalue = pageFactAS3.newidd();
		System.out.println("BR Status value is " + brStatusvalue);

		extentTest.log(LogStatus.INFO, "BR Status value is " + brStatusvalue);

		Thread.sleep(5000);

		if (pageFactAS3.incmeSaveBtn.isDisplayed()) {
			System.out.println("Income section enabled even in NEW status");
			extentTest.log(LogStatus.FAIL,
					"Income section enabled even in NEW status");
			extentReportImage451PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage451PO_0.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage451PO_0);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.INFO,
							"Income section enabled even in NEW status"
									+ extentTest
											.addScreenCapture(extentReportImage451PO_0));
		} else {
			System.out
					.println("Income section is disabled as the BR status is NEW");
			extentTest.log(LogStatus.INFO,
					"Income section is disabled as the BR status is NEW");
		}
		}catch(Exception e){
			
			System.out
			.println("Income section is disabled as the user do not have proper privilege/unexpected error");
	extentTest.log(LogStatus.INFO,
			"Income section is disabled as the user do not have proper privilege/unexpected error");
			
		}

		return null;
	}

	public String BRSaveNewReady(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactAS3.readyy(Driver);
		Thread.sleep(2000);
		
		 
		if (pageFactAS3.addIncmeBtn.isDisplayed()) {
			System.out
					.println("Add Income button is enabled after successfully saving (Ready) the billing record");
			extentTest
					.log(LogStatus.INFO,
							"Add Income button is enabled after successfully saving (Ready) the billing record");
		} else {
			System.out.println("Add income button not enabled");

			extentReportImage451PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage451PO_1.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage451PO_1);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Add income button not enabled"
					+ extentTest.addScreenCapture(extentReportImage451PO_1));
		}
		return null;
	}

	public String incmSave(WebDriver Driver) throws InterruptedException {

		try {
			pageFactAS3.notesTxtBoxx(Driver);
			// pageFactAS3.flatAmtt(Driver);
			pageFactAS3.notesTabFlatAmt(Driver);
			pageFactAS3.incmSaveBtnn(Driver);

			// pageFact.waitForSpinnerToBeGone();
			// Thread.sleep(2500);
			Thread.sleep(41000);

			extentTest.log(LogStatus.INFO, "Clicked on Save button");
			pageFactAS3.cancelBtn2(Driver);
			Thread.sleep(2500);

			pageFactAS3.cancelOKbtn(Driver);

			// pageFact.waitForSpinnerToBeGone();
			// Thread.sleep(5000);
			Thread.sleep(41000);

			pageFactAS3.addIncmeBtnn(Driver);

			Thread.sleep(41000);
			// pageFact.waitForSpinnerToBeGone();
			// Thread.sleep(2500);

			if (pageFactAS3.notesTxtBoxxx(Driver) == true) {
				System.out.println("Cancel functionality WORKING");
				extentTest
						.log(LogStatus.INFO,
								"TESTCASE PASSED:  Clicked 'OK' button from cancel pop up, successfully canceled the saved data");
			} else {
				System.out.println("Cancel functionality not WORKING");
				extentTest.log(LogStatus.FAIL,
						"TESTCASE FAILED:  Cancel functionality not WORKING");
			}
		} catch (Exception e) {

			System.out
					.println("User do not have privilege to do Cancel action");
			extentTest.log(LogStatus.INFO,
					"User do not have privilege to do Cancel action");

		}
		return null;
	}

		public String itemRetCancelCan(WebDriver Driver) throws IOException,
			InterruptedException {
		
		try{

		pageFactAS3.notesTxtBoxx(Driver);
		// pageFactAS3.flatAmtt(Driver);
		pageFactAS3.notesTabFlatAmt(Driver);
		pageFactAS3.cancelBtn2(Driver);
		extentTest.log(LogStatus.INFO, "Clicked on Cancel button");
		pageFactAS3.cancelCanbtn(Driver);

		// pageFact.waitForSpinnerToBeGone();
		// Thread.sleep(3000);

		Thread.sleep(41000);
		if (pageFactAS3.notesTxtBoxxxx(Driver) == true) {
			System.out
					.println("'Cancel' button click from the warning pop up retains the entered data");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  'Cancel' button click from the warning pop up retains the entered data");
		} else {
			System.out
					.println("Clicked on 'Cancel' button from 'Warning' pop up and Cancel action not working properly");

			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Clicked on 'Cancel' button from 'Warning' pop up and Cancel action not working properly");
		}
		}catch(Exception e){
			System.out
			.println("'Cancel' button click interupted");
	extentTest
			.log(LogStatus.INFO,
					"'Cancel' button click interupted");
			
		}
		return null;
	}

	public String incmSaveCancelCan(WebDriver Driver)
			throws InterruptedException {

		try{
		pageFactAS3.notesTxtBoxx(Driver);
		// pageFactAS3.flatAmtt(Driver);
		pageFactAS3.notesTabFlatAmt(Driver);
		pageFactAS3.incmSaveBtnn(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);

		pageFactAS3.cancelBtn2(Driver);
		pageFactAS3.cancelCanbtn(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		if (pageFactAS3.notesTxtBoxxxx(Driver) == true) {
			System.out
					.println("'Cancel' button click from the warning pop up retains the entered data");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  'Cancel' button click from the warning pop up retains the entire saved data");
		} else {
			System.out.println("Cancel functionality not WORKING");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Cancel functionality not WORKING");
		}
		}catch(Exception e){
			
			System.out
			.println("'Cancel' button click interupted for the login'd user");
	extentTest
			.log(LogStatus.INFO,
					"'Cancel' button click interupted for the login'd user");
			
		}
		return null;
	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactAS3.createBillrcrd));
		return null;
	}

	public String AlwnceBRUpdt(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.blngrcrdDrp();
		Thread.sleep(4500);
		pageFact.retailalw();
		Thread.sleep(4500);

		pageFactAS3.bRTypeRetailFieldAccValue(Driver);
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(4500);
		pageFactAS3.bRTypeRetailFieldLeadCIC();
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(2500);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		Thread.sleep(5000);
		pageFact.allwtype();
		Thread.sleep(5000);
		pageFact.allwTP1P2();
		Thread.sleep(5000);
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}
	
	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}
	
	public String errCaseSectionID(WebDriver Driver) throws InterruptedException{
		
		waitforbrtxt(Driver);
		pageFactAS3.elmntIntract(Driver);
		Thread.sleep(3000);
		pageFactAS3.itemDetailsAmntt(Driver);
		Thread.sleep(3000);
		pageFactAS3.brSaveBtnn(Driver);
		
		String errMsg =pageFactAS3.invalidOfseterroMsg();
		Thread.sleep(3000);
		if (pageFactAS3.invalidOfseterroMsg().equals("Section 312 is not setup for your team within Retail Div 20")) {
			System.out
					.println("If Section ID is not associated with the Account showing error message: " + errMsg);
			extentTest
					.log(LogStatus.INFO,
							"If Section ID is not associated with the Account showing error message: " + errMsg);
		} else {
			System.out.println("Wrong error message");
			extentTest.log(LogStatus.FAIL, "Wrong error message");
		}
		
		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {
		pageFactIV = new GenericFactoryIV(Driver);
		// pageFactS3 = new GenericFactoryJSprint3(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFact = new GenericFactory(Driver);
	}

}
