package com.albertsons.pageobjects;

import org.openqa.selenium.Dimension;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

public class GenericFactorySJVII {

	WebDriver Driver;

	GenericFactorySJVII POJS7;

	public GenericFactorySJVII(WebDriver Driver) {

		this.Driver = Driver;

		PageFactory.initElements(Driver, this);

	}

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[5]/a")

	WebElement paybackWorkListMenu;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]")

	WebElement paybackWorkListData;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")

	WebElement paybackWorkListDataBR;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")

	WebElement paybackWorkListDataBRVal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")

	WebElement paybackWorkListDataBRVal2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[3]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")

	WebElement paybackWorkListDataBRVal3;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[3]/div/span[1]/label")

	WebElement paybackWorkListDataInv;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")

	WebElement paybackWorkListDataInvVal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")

	WebElement paybackWorkListDataInvVal2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[3]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")

	WebElement paybackWorkListDataInvVal3;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[4]/div/span[1]/label")

	WebElement paybackWorkListDataBillName;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")

	WebElement paybackWorkListDataBillNameVal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[5]/div/span[1]/label")

	WebElement paybackWorkListDataArea;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span[1]")

	WebElement paybackWorkListDataAreaVal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span[2]")

	WebElement paybackWorkListDataAreaVal2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[6]/div/span[1]/label")

	WebElement paybackWorkListDataOffer;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/span")

	WebElement paybackWorkListDataOfferValRt;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[3]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div")

	WebElement paybackWorkListDataOfferValMisc;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[7]/div/span[1]/label")

	WebElement paybackWorkListDataBillBy;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/span")

	WebElement paybackWorkListDataBillByVal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[8]/div/span[1]/label")

	WebElement paybackWorkListDataInvDetails;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/div/span[1]")

	WebElement paybackWorkListDataInvDetails1;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/div/span[2]")

	WebElement paybackWorkListDataInvDetails2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[9]/div/span[1]/label")

	WebElement paybackWorkListDataInvReason;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/div/span[1]")

	WebElement paybackWorkListDataInvReason1;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/div/span[2]")

	WebElement paybackWorkListDataInvReason2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[1]/nav/ol/li")

	WebElement newBRPage;

	public String paybackWorkListMenu(WebDriver Driver) {

		paybackWorkListMenu.click();

		return null;

	}

	public String newBRPage(WebDriver Driver) {

		return newBRPage.getText();

	}

	public String BRclick(WebDriver Driver) {

		paybackWorkListDataBRVal.click();

		return null;

	}

	public String paybackWorkListCount(WebDriver Driver) {

		return paybackWorkListMenu.getText();

	}

	public String paybackWorkListDataBR(WebDriver Driver) {

		return paybackWorkListDataBR.getText();

	}

	public String paybackWorkListDataBRVal(WebDriver Driver) {

		return paybackWorkListDataBRVal.getText();

	}

	public String paybackWorkListDataBRVal2(WebDriver Driver) {

		return paybackWorkListDataBRVal2.getText();

	}

	public String paybackWorkListDataBRVal3(WebDriver Driver) {

		return paybackWorkListDataBRVal3.getText();

	}

	public String paybackWorkListDataInv(WebDriver Driver) {

		return paybackWorkListDataInv.getText();

	}

	public String paybackWorkListDataInvVal(WebDriver Driver) {

		return paybackWorkListDataInvVal.getText();

	}

	public String paybackWorkListDataInvVal2(WebDriver Driver) {

		return paybackWorkListDataInvVal2.getText();

	}

	public String paybackWorkListDataInvVal3(WebDriver Driver) {

		return paybackWorkListDataInvVal3.getText();

	}

	public String paybackWorkListDataBillName(WebDriver Driver) {

		return paybackWorkListDataBillName.getText();

	}

	public String paybackWorkListDataBillNameVal(WebDriver Driver) {

		return paybackWorkListDataBillNameVal.getText();

	}

	public String paybackWorkListDataArea(WebDriver Driver) {

		return paybackWorkListDataArea.getText();

	}

	public String paybackWorkListDataAreaVal(WebDriver Driver) {

		return paybackWorkListDataAreaVal.getText();

	}

	public String paybackWorkListDataAreaVal2(WebDriver Driver) {

		return paybackWorkListDataAreaVal2.getText();

	}

	public String paybackWorkListDataOffer(WebDriver Driver) {

		return paybackWorkListDataOffer.getText();

	}

	public String paybackWorkListDataOfferValRt(WebDriver Driver) {

		return paybackWorkListDataOfferValRt.getText();

	}

	public String paybackWorkListDataOfferValMisc(WebDriver Driver) {

		return paybackWorkListDataOfferValMisc.getText();

	}

	public String paybackWorkListDataBillBy(WebDriver Driver) {

		return paybackWorkListDataBillBy.getText();

	}

	public String paybackWorkListDataBillByVal(WebDriver Driver) {

		return paybackWorkListDataBillByVal.getText();

	}

	public String paybackWorkListDataInvDetails(WebDriver Driver) {

		return paybackWorkListDataInvDetails.getText();

	}

	public String paybackWorkListDataInvDetails1(WebDriver Driver) {

		return paybackWorkListDataInvDetails1.getText();

	}

	public String paybackWorkListDataInvReason(WebDriver Driver) {

		return paybackWorkListDataInvReason.getText();

	}

	public String paybackWorkListDataInvDetails2(WebDriver Driver) {

		return paybackWorkListDataInvDetails2.getText();

	}

	public String paybackWorkListDataInvReason1(WebDriver Driver) {

		return paybackWorkListDataInvReason1.getText();

	}

	public String paybackWorkListDataInvReason2(WebDriver Driver) {

		return paybackWorkListDataInvReason2.getText();

	}

}
