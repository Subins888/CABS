package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsX extends ExtendBaseClass {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactoryVI pageFactVI;
	GenericFactoryVII pageFactVII;
	GenericFactoryVIII pageFactVIII;
	GenericFactoryV pageFactV;
	GenericFactorySprint3 pageFactAS3;
	GenericFactoryJSprint3 pageFactJS3;
	GenericFactoryIX pageFactIX;
	GenericFactoryX pageFactX;
	PageObjectsVIII POVIII;

	public WebElement LCIC;
	static String billingId;

	public PageObjectsX(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactV.createBillrcrd));
		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String waitforAlwncType(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVI.cogsType));
		return null;
	}

	public String COGSAlwnceBRLukupVal(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		Thread.sleep(20000);
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");

		} else {

			String source = aftermthd(Driver);

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			extentTest.log(
					LogStatus.FAIL,
					"Not able to see Allowance type in the Billing Record Type Dropdown"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(7500);

		return null;

	}

	public String readyBtnClk(WebDriver Driver) {

		pageFactVIII.readyClk(Driver);
		System.out.println("Clicked on Ready Button");
		extentTest.log(LogStatus.INFO, "Clicked on Ready Button");
		return null;
	}

	public String BRSave(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);
		Thread.sleep(5000);
		pageFactVIII.elmntIntract();
		Thread.sleep(30000);

		readyBtnClk(Driver);
		Thread.sleep(30000);

		pageFactX.addIncomeRetail.click();
		Thread.sleep(5000);
		scroldown(Driver);
		Thread.sleep(2500);
		pageFactX.notes.sendKeys("Test Automation");

		pageFactX.notes.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				Keys.TAB, "1");
		Thread.sleep(2500);

		// pageFactX.flatAmount.sendKeys("1");
		pageFactX.incomeSubmit.click();
		Thread.sleep(20000);

		pageFactVIII.incHist.click();
		Thread.sleep(1500);

		String invoice = pageFactX.invoice.getText();

		if (pageFactX.invoice.isDisplayed()) {

			System.out
					.println("Income successfully submitted and the invoice number from the Income History section is:  "
							+ invoice);
			extentTest
					.log(LogStatus.INFO,
							"Income successfully submitted and the invoice number from the Income History section is:  "
									+ invoice);

		} else {

			String source = aftermthd(Driver);

			System.out.println("Income submission failed");

			extentTest.log(
					LogStatus.FAIL,
					"Income submission failed"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		return null;
	}

	public String BRSaveII(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactVIII.elmntIntract();

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactVIII.itemDetailsAmntt(Driver);

		// Spinner wait not working
		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(36000);

		return null;
	}

	public String BRSaveIII(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactVIII.elmntIntract();

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactVIII.save.click();

		// Spinner wait not working
		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(36000);

		return null;
	}

	public String brSavMisc(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactV.retDivDrpp(Driver);
		Thread.sleep(3000);
		pageFactV.retDivv(Driver);
		Thread.sleep(4500);
		pageFactV.retDivVall(Driver);
		Thread.sleep(2000);
		pageFactV.retValuu(Driver);
		pageFactV.elmntIntract(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		pageFactV.txtAreaa(Driver);
		Thread.sleep(2500);
		pageFactV.brSavebtnn(Driver);

	//	pageFact.waitForSpinnerToBeGone();
		Thread.sleep(32000);

		return null;
	}

	public String offsetValidation(WebDriver Driver) {

		String acount = pageFactX.AccountNum.getAttribute("value");

		extentTest.log(LogStatus.INFO, "COGS Offset Account number is :  "
				+ acount);

		String Facility = pageFactX.FacilityNum.getAttribute("value");

		extentTest.log(LogStatus.INFO, "COGS Offset Facility number is :  "
				+ Facility);

		String Section = pageFactX.SectionNum.getAttribute("value");

		extentTest.log(LogStatus.INFO, "COGS Offset Section number is :  "
				+ Section);

		return null;
	}

	public String CICValidation(WebDriver Driver) throws InterruptedException {

		String cic = pageFactX.cic.getText();
		String cicII = pageFactX.cic.getAttribute("value");
		System.out.println(cic);
		System.out.println(cicII);

		pageFactX.itemdetailsPlus.click();
		Thread.sleep(2500);

		if (pageFactX.cic.isDisplayed()) {

			extentTest.log(LogStatus.INFO,
					"Valid CIC corresponding to the given date displaying in the Item Details :  "
							+ cic);

		} else {

			extentTest.log(LogStatus.FAIL,
					"CIC not displaying in the item details section");
		}

		return null;
	}

	public boolean bRTypeRetailFieldLeadCIC(WebDriver Driver, String valu)
			throws BiffException, IOException {

		LCIC = pageFactX.leadCIC.findElement(By.className("form-control"));
		LCIC.click();

		LCIC.sendKeys(valu);

		if (LCIC.getAttribute("value").equals(valu)) {
			return true;
		} else {
			return false;
		}

	}

	public String COGSAlwnceBRInvalid(WebDriver Driver, String valu)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		pageFactX.bRTypeRetailFieldAccValue(Driver);
		pageFact.bRTypeRetailFieldOffNo();
		bRTypeRetailFieldLeadCIC(Driver, valu);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();

		Thread.sleep(3500);

		pageFact.brSubmit.click();

		return null;

	}

	public String COGSAlwnceBR(WebDriver Driver, String valu)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		//Thread.sleep(20000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		Thread.sleep(7500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");

		} else {

			String source = aftermthd(Driver);

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			extentTest.log(
					LogStatus.FAIL,
					"Not able to see Allowance type in the Billing Record Type Dropdown"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(7500);

		pageFactX.bRTypeRetailFieldAccValueII(Driver);
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(4500);
		bRTypeRetailFieldLeadCIC(Driver, valu);
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();

		Thread.sleep(3500);

		pageFact.brSubmit.click();

		return null;

	}

	public boolean brSubmitInvalidCOGS(WebDriver Driver)
			throws InterruptedException {

		waitforbrtxt(Driver);
				//Thread.sleep(20000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);

		pageFactVIII.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(5000);
		pageFactX.itemDetailsAmnttII(Driver);
		Thread.sleep(36000);

		String ErrMsg = pageFactX.errMsg.getText();
		if (ErrMsg
				.equals("No Account or Facility has been setup for your team within COGS Facilities WAUB")) {

			System.out
					.println("Error message displaying properly.  The error message showing is : "
							+ ErrMsg);
			extentTest.log(LogStatus.INFO,
					"Error message displaying properly.  The error message showing is : "
							+ ErrMsg);
			return true;

		} else {
			System.out
					.println("Error message NOT displaying properly.  The error message showing is : "
							+ ErrMsg);
			extentTest.log(LogStatus.FAIL,
					"Error message NOT displaying properly.  The error message showing is : "
							+ ErrMsg);
			return false;
		}

	}

	public String COGSDrpValue(WebDriver Driver) throws InterruptedException {

		pageFactX.COGSval.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues = pageFactX.COGSval.findElements(By
				.className("ng-dropdown-panel"));

		ArrayList<String> listValues = new ArrayList<String>();
		for (WebElement value : dropDownvalues) {

			listValues.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues);

		extentTest.log(LogStatus.INFO,
				"COGS Account lookup type Values obtained from UI are "
						+ listValues);

		// if(listValues.contains("WANC
		// WAUB
		// WBRE
		// WCOL
		// WDAL
		// WDEN
		// WEAS
		// WHAW
		// WIRV
		// WLAN
		// WLAS
		// WMEL
		// WMET
		// WNCA
		// WPHA
		// WPHX
		// WPOA
		// WPON
		// WSLC
		// WSPK
		// WSUN
		// WWEL"))

		return null;
	}

	public String WarningYES(WebDriver Driver) {

		pageFactX.warningYes.click();
		return null;
	}

	public String searchBtn(WebDriver Driver) {

		pageFactVII.searchh(Driver);
		return null;
	}

	public String scroldown(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactX.incomeSubmit).perform();
		return null;
	}

	public boolean sectionIDValidation(WebDriver Driver, String valu)
			throws InterruptedException, BiffException, IOException,
			ParseException {

		// COMMENT THE BELOW 2 LINE
		// waitforBlngbtn(Driver);
		// Thread.sleep(20000);

		searchBtn(Driver);
		Thread.sleep(7500);
		// UNCOMMENT THE BELOW LINE
		WarningYES(Driver);
		Thread.sleep(5000);

		COGSAlwnceBR(Driver, valu);

		waitforbrtxt(Driver);
		Thread.sleep(20000);

		String val = pageFactX.sectionNum.getText();
		String val2 = pageFactX.sectionNum.getAttribute("value");
		String val3 = pageFactX.sectionNum.findElement(
				By.className("form-control")).getText();
		String val4 = pageFactX.sectionNum.findElement(
				By.className("form-control")).getAttribute("value");

		System.out.println(val4);
		if (val4.equals("203")) {

			System.out.println("Section ID associated with Lead CIC is valid");
			extentTest.log(LogStatus.INFO,
					"Section ID associated with Lead CIC is valid");
			return true;
		} else {
			System.out
					.println("Section ID associated with Lead CIC is NOT valid");
			extentTest.log(LogStatus.FAIL,
					"Section ID associated with Lead CIC is NOT valid");
			return false;

		}

	}

	public String teamChange(WebDriver Driver) throws InterruptedException {

		pageFactX.teamDrp.click();
		Thread.sleep(1500);
		pageFactX.xternal.click();
		Thread.sleep(7000);

		return null;
	}

	public String COGSAlwnceBRNoItemized(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		// Thread.sleep(20000);
		pageFact.creatBillng();
		Thread.sleep(5500);

		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			extentTest.log(
					LogStatus.FAIL,
					"Not able to see Allowance type in the Billing Record Type Dropdown"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactX.bRTypeRetailFieldLeadCICCOGS();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(5000);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		Thread.sleep(3000);

		pageFact.brSubmit.click();

		return null;

	}

	public String RetailAlwnceBRwithItemized(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		//Thread.sleep(20000);
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");

		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFact.blngRcrdType0.click();
		Thread.sleep(2500);

		pageFactVI.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		Thread.sleep(2500);

		// ONE
		pageFactX.alwTypDrp.click();
		Thread.sleep(4500);
		pageFact.allwType0.click();
		Thread.sleep(4500);
		pageFactX.perf1Drp.click();
		Thread.sleep(2500);
		pageFactVI.p1AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();
		Thread.sleep(4500);

		String errMsg = pageFact.errMsg.getText();

		if (pageFact.errMsg.getText()
				.contains("Performance Code 2 is required")) {

			System.out
					.println("Valid message showing, error message displaying is : "
							+ errMsg);
			extentTest
					.log(LogStatus.INFO,
							"Valid message showing, error message displaying is [Allowance Type T, Perf value 20] : "
									+ errMsg);

		} else {

			System.out.println("Error message showing is wrong : " + errMsg);
			extentTest.log(LogStatus.FAIL, "Error message showing is wrong : "
					+ errMsg);
		}

		// TWO
		pageFactX.alwTypDrpII.click();
		Thread.sleep(4500);
		pageFact.allwType3.click();
		Thread.sleep(4500);

		pageFact.brSubmit.click();
		Thread.sleep(3500);

		String errMsg2 = pageFact.errMsg.getText();

		if (pageFact.errMsg.getText()
				.contains("Performance Code 2 is required")) {

			System.out
					.println("Valid message showing, error message displaying is : "
							+ errMsg2);
			extentTest
					.log(LogStatus.INFO,
							"Valid message showing, error message displaying is [Allowance Type A, Perf value A] : "
									+ errMsg2);

		} else {

			System.out.println("Error message showing is wrong : " + errMsg2);
			extentTest.log(LogStatus.FAIL, "Error message showing is wrong : "
					+ errMsg2);
		}

		// THREE
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(5500);

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactX.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(5000);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		Thread.sleep(3000);

		pageFactX.alwTypDrp.click();
		Thread.sleep(4500);
		pageFact.allwType0.click();
		Thread.sleep(4500);
		pageFactX.perf1DrpII.click();
		Thread.sleep(1500);
		pageFact.p1AlwT1.click();
		Thread.sleep(4500);

		pageFact.brSubmit.click();
		Thread.sleep(3500);

		String errMsg3 = pageFact.errMsg.getText();

		if (pageFact.errMsg.getText()
				.contains("Performance Code 2 is required")) {

			System.out
					.println("Valid message showing, error message displaying is : "
							+ errMsg3);
			extentTest
					.log(LogStatus.INFO,
							"Valid message showing, error message displaying is [Allowance Type C, Perf value 48] : "
									+ errMsg3);

		} else {

			System.out.println("Error message showing is wrong : " + errMsg3);
			extentTest.log(LogStatus.FAIL, "Error message showing is wrong : "
					+ errMsg3);
		}

		// FOUR
		pageFactX.alwTypDrpII.click();
		Thread.sleep(4500);
		pageFact.allwType1.click();
		Thread.sleep(4500);

		String val1 = pageFactX.perf1Val.getText();
		String val2 = pageFactX.perf1Val.getAttribute("value");
		// String val3 =
		// pageFactX.perf1Val.findElement(By.className("dropdown")).getAttribute("value");
		// String val4 =
		// pageFactX.perf1Val.findElement(By.className("dropdown")).getText();

		System.out.println(val1);
		System.out.println(val2);

		if (val2.equals("A")) {

			String source = aftermthd(Driver);

			System.out.println("Performance 1 value not displaying by default");
			extentTest.log(
					LogStatus.FAIL,
					"Performance 1 value not displaying by default"

							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		} else {

			System.out
					.println("Performance 1 value displaying properly by default");
			extentTest.log(LogStatus.INFO,
					"Performance 1 value displaying properly by default");

		}

		return null;

	}

	public String invalidCOGSCIC(WebDriver Driver) throws InterruptedException,
			IOException {

		// COMMENT THE BELOW 2 LINE
		// waitforBlngbtn(Driver);
		// Thread.sleep(20000);

		String ErrMsg = pageFactVI.errMsgg(Driver);

		if (pageFactVI
				.errMsgg(Driver)
				.equals("This item is not valid in this billing record's location and time frame ")) {

			System.out
					.println("Proper error message showing properly in case of Invalid CIC : "
							+ ErrMsg);

			extentTest.log(LogStatus.INFO,
					"Proper error message showing properly in case of Invalid CIC : "
							+ ErrMsg);
		} else {

			String source = aftermthd(Driver);

			System.out
					.println("Error message showing is not proper in case of Invalid CIC : "
							+ ErrMsg);
			extentTest.log(
					LogStatus.FAIL,
					"Error message showing is not proper in case of Invalid CIC : "
							+ ErrMsg

							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}
		pageFactX.CloseBtn.click();
		System.out.println("Clicked on Close Button");
		Thread.sleep(2500);

		return null;

	}

	public String otherUser(WebDriver Driver) throws InterruptedException {

		// COMMENT THE BELOW 2 LINE
		// waitforBlngbtn(Driver);
		// Thread.sleep(20000);

		// UNCOMMENT THE BELOW LINE

		// searchBtn(Driver);
		// WarningYES(Driver);
		Thread.sleep(3000);

		teamChange(Driver);
		searchBtn(Driver);
		Thread.sleep(7000);
		pageFactVIII.brStatusDrpInput.sendKeys("Ready");
		pageFactVIII.brStatusDrpInput.sendKeys(Keys.ENTER);
		pageFactVIII.searchApply.click();
		Thread.sleep(7000);
		pageFactX.searchFirstItem.click();
		waitforbrtxt(Driver);
		Thread.sleep(20000);

		try {

			if (pageFactX.AccountNum.isEnabled()
					&& pageFactX.FacilityNum.isEnabled()
					&& pageFactX.SectionNum.isEnabled()) {

				String source = aftermthd(Driver);

				System.out
						.println("Offset number displaying for a user with 'View Only' privilege");
				extentTest
						.log(LogStatus.FAIL,
								"Offset number displaying for a user with 'View Only' privilege"

										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			} else {

				System.out
						.println("Offset number field disabled for a user with 'View Only' privilege");

				extentTest
						.log(LogStatus.INFO,
								"Offset number field disabled for a user with 'View Only' privilege");

			}

		} catch (Exception e) {

			System.out
					.println("Offset number field disabled for a user with 'View Only' privilege");
			extentTest
					.log(LogStatus.INFO,
							"Offset number field disabled for a user with 'View Only' privilege");

		}

		return null;
	}

	public boolean brSubmit(WebDriver Driver, String valu)
			throws InterruptedException, IOException {

		waitforbrtxt(Driver);
		Thread.sleep(20000);

		if (pageFactX.ready.isEnabled()) {

			System.out.println("'Ready Button' enabled by default");
			extentTest.log(LogStatus.INFO, "'Ready Button' enabled by default");

		} else {
			System.out.println("'Ready Button' NOT enabled by default");
			extentTest.log(LogStatus.FAIL,
					"'Ready Button' NOT enabled by default");

		}

		readyBtnClk(Driver);
		Thread.sleep(30000);

		String errMsg = pageFactX.errMsgBrSave.getText();

		if (pageFactX.errMsgBrSave.isDisplayed()) {

			System.out
					.println("Validation success, error message displaying is : "
							+ errMsg);
			extentTest.log(LogStatus.INFO,
					"Validation success, error message displaying is : "
							+ errMsg);

		} else {
			System.out.println("Validation failed no error messages showing");
			extentTest.log(LogStatus.FAIL,
					"Validation failed no error messages showing");

		}

		pageFactVIII.elmntIntract();
		Thread.sleep(5000);

		readyBtnClk(Driver);
		Thread.sleep(30000);

		pageFact.brStatuclk();
		Thread.sleep(5000);
		if (pageFact.brStatustxt().contains("Ready for Income")) {
			System.out
					.println("BR Status enabled with Status Ready For Income");
			extentTest.log(LogStatus.INFO,
					"BR Status enabled with Status Ready For Income");
			return true;
		} else {

			String source = aftermthd(Driver);

			System.out
					.println("BR Status not enabled or status showing is wrong");

			extentTest.log(
					LogStatus.FAIL,
					"BR Status not enabled or status showing is wrong"

							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			return false;
		}

	}

	public String incomeBtn(WebDriver Driver) throws IOException {

		if (pageFactX.addIncomeRetail.isEnabled()) {

			System.out
					.println("Add Income button is enabled for the user with all privileges");
			extentTest
					.log(LogStatus.INFO,
							"Add Income button is enabled for the user with all privileges");

		} else {

			String source = aftermthd(Driver);

			System.out
					.println("Add Income button is NOT enabled even the user have all privileges");

			extentTest.log(
					LogStatus.FAIL,
					"Add Income button is NOT enabled even the user have all privileges"

							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		return null;
	}

	public String readyOtherRights(WebDriver Driver)
			throws InterruptedException {

		searchBtn(Driver);
		Thread.sleep(1500);

		WarningYES(Driver);
		Thread.sleep(7500);
		pageFactVIII.brStatusDrpInput.sendKeys("New");
		Thread.sleep(1500);
		pageFactVIII.brStatusDrpInput.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFactVIII.assignTodrp.sendKeys("Ajith");
		Thread.sleep(1500);
		pageFactVIII.assignTodrp.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFactVIII.searchApply.click();
		Thread.sleep(7000);

		pageFactX.searchFirstItem.click();
		waitforbrtxt(Driver);
		Thread.sleep(20000);

		if (pageFactX.ready.isEnabled()) {

			System.out
					.println("'Ready Button' enabled by default for user with edit Others right");
			extentTest
					.log(LogStatus.INFO,
							"'Ready Button' enabled by default for user with edit Others right");

		} else {
			System.out
					.println("'Ready Button' NOT enabled by default for user with edit Others right");
			extentTest
					.log(LogStatus.FAIL,
							"'Ready Button' NOT enabled by default for user with edit Others right");

		}

		readyBtnClk(Driver);
		Thread.sleep(30000);

		String errMsg = pageFactX.errMsgBrSaveII.getText();

		if (pageFactX.errMsgBrSaveII.isDisplayed()) {

			System.out
					.println("Validation success (Edit Others user), error message displaying is : "
							+ errMsg);
			extentTest.log(LogStatus.INFO,
					"Validation success (Edit Others user), error message displaying is : "
							+ errMsg);

		} else {
			System.out.println("Validation failed no error messages showing");
			extentTest.log(LogStatus.FAIL,
					"Validation failed no error messages showing");

		}

		return null;
	}

	public String analysisWorklistNew(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFactX.analysisWorklist.click();

		// Thread.sleep(1500);
		// WarningYES(Driver);

		// Wait for spinner not working here
		// pageFact.waitForSpinnerToBeGone();
		// Thread.sleep(2500);

		Thread.sleep(36000);

		pageFactX.pagination.click();

		// Wait for spinner not working here
		// pageFact.waitForSpinnerToBeGone();
		// Thread.sleep(2500);
		Thread.sleep(36000);

		String brNum = pageFactX.brNumSearch.getText();

		if (pageFactX.brNumSearch.isDisplayed()) {

			System.out
					.println("The newly created BR displaying properly in the Analysis worklist: "
							+ brNum);
			extentTest.log(LogStatus.INFO,
					"The newly created BR displaying properly in the Analysis worklist: "
							+ brNum);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("The created BR not showing in the Analysis worklist");

			extentTest.log(
					LogStatus.FAIL,
					"The created BR not showing in the Analysis worklist"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		if (pageFactX.brstatusSearch.getText().equals("New")) {

			System.out
					.println("The BR Status displaying is 'NEW' for the newly created BR");
			extentTest
					.log(LogStatus.INFO,
							"The BR Status displaying is 'NEW' for the newly created BR");
		} else {

			String source = aftermthd(Driver);
			System.out
					.println("The BR Status displaying is wrong for the newly created BR");

			extentTest.log(
					LogStatus.FAIL,
					"The BR Status displaying is wrong for the newly created BR"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		return null;
	}

	public String analysisWorklistLater(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFactX.brNumSearch.click();

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactX.brStatusDrp.click();
		Thread.sleep(2500);

		pageFactX.brStatusDrpVal.click();
		pageFactV.save.click();
		// pageFact.waitForSpinnerToBeGone();
		// Thread.sleep(2500);
		Thread.sleep(46000);

		pageFactX.analysisWorklist.click();
		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(36000);

		pageFactX.pagination.click();
		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(36000);

		if (pageFactX.brstatusSearch.getText().equals("Analyze Later")) {

			System.out
					.println("The BR with status 'Analyze Later' displaying properly in the Analysis Worklist section");
			extentTest
					.log(LogStatus.INFO,
							"The BR with status 'Analyze Later' displaying properly in the Analysis Worklist section");
		} else {

			String source = aftermthd(Driver);
			System.out
					.println("The BR with status 'Analyze Later' NOT displaying properly in the Analysis Worklist section");

			extentTest
					.log(LogStatus.FAIL,
							"The BR with status 'Analyze Later' NOT displaying properly in the Analysis Worklist section"
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
		}

		return null;
	}

	public String incomeCheckMisc(WebDriver Driver)
			throws InterruptedException, IOException {

		try {
			pageFactV.incomeBtnNonAlw.click();
			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(2500);

			pageFactVII.fltAmntt(Driver);
			Thread.sleep(3000);

			pageFactVII.incmSbmtBtnII.click();
			// pageFact.waitForSpinnerToBeGone();
			// Thread.sleep(2500);
			Thread.sleep(25000);

			// -----------
			pageFactV.incomeBtnNonAlw.click();
			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(2500);

			pageFactVII.fltAmntt(Driver);
			Thread.sleep(3000);

			pageFactVII.incmSbmtBtnII.click();
			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(2500);

			if (pageFactX.warning
					.getText()
					.contains(
							"Income already exists for this billing record. Are you sure you want to proceed")) {

				System.out
						.println("'Income Already Exists' warning pop up displaying properly");
				extentTest
						.log(LogStatus.INFO,
								"'Income Already Exists' warning pop up displaying properly");

			} else {

				String source = aftermthd(Driver);
				System.out
						.println("'Income Already Exists' warning pop up NOT displaying properly");

				extentTest
						.log(LogStatus.FAIL,
								"'Income Already Exists' warning pop up NOT displaying properly"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));
			}
		} catch (Exception e) {

			System.out
					.println("'Income Already Exists' warning pop up not displaying because of some privilege issues");
			extentTest
					.log(LogStatus.INFO,
							"'Income Already Exists' warning pop up not displaying because of some privilege issues");

		}
		return null;
	}

	public String accountOverride(WebDriver Driver) throws IOException,
			InterruptedException {

		if (pageFactX.accountOverride.isEnabled()) {

			System.out
					.println("'Account Override' checkbox enabled for the log in'd user");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  'Account Override' checkbox enabled for the log in'd user");

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("'Account Override' checkbox NOT enabled for the log in'd user, as he have no privilege");

			extentTest
					.log(LogStatus.INFO,
							"'Account Override' checkbox NOT enabled for the log in'd user, as he have no privilege"
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
		}

		Thread.sleep(3000);
		pageFactX.accountOverride.click();
		System.out.println("Clicked on 'Account Override' check box");
		extentTest.log(LogStatus.INFO,
				"Clicked on 'Account Override' check box");

		if (pageFactX.AccountNum.isEnabled()
				&& pageFactX.FacilityNum.isEnabled()
				&& pageFactX.SectionNum.isEnabled()) {
			System.out
					.println("Able to edit the Offset value fields successfully after checking on the 'Account Override' check box");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Able to edit the Offset value fields successfully after checking on the 'Account Override' check box");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Unable to modify the Offset field values, even after checking the 'Account Override' checkbox");

			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Unable to modify the Offset field values, even after checking the 'Account Override' checkbox"
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
		}

		pageFactX.accountOverride.click();
		System.out.println("Uncheck 'Account Override' check box");
		extentTest.log(LogStatus.INFO, "Uncheck 'Account Override' check box");

		Thread.sleep(1500);

		String warningmsg = pageFactX.warning.getText();

		if (pageFactX.warning
				.getText()
				.contains(
						"Are you sure you want to revert back to auto-derived default Offset Account Number")) {
			System.out
					.println("Warning message displaying properly with text: -  "
							+ warningmsg);
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Warning message displaying properly with text: -  "
							+ warningmsg);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Warning message not properly displayed or message showing is wrong "
							+ warningmsg);

			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Warning message not properly displayed or message showing is wrong "
									+ warningmsg
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}
		
		pageFactX.overrideNO.click();
		Thread.sleep(1500);

		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactV = new GenericFactoryV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFactJS3 = new GenericFactoryJSprint3(Driver);
		pageFact = new GenericFactory(Driver);
		pageFactVI = new GenericFactoryVI(Driver);
		pageFactVII = new GenericFactoryVII(Driver);
		pageFactVIII = new GenericFactoryVIII(Driver);
		pageFactIX = new GenericFactoryIX(Driver);
		pageFactX = new GenericFactoryX(Driver);
		POVIII = new PageObjectsVIII(Driver);

	}

}
