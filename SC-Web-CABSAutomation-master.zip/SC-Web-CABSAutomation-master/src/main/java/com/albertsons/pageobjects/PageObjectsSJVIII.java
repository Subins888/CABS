package com.albertsons.pageobjects;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

import jxl.common.Assert;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsSJVIII extends ExtendBaseClass {
              WebDriver Driver;
              GenericFactory pageFact;
              Properties prop;
              HSSFWorkbook workbook;
              HSSFSheet sheet;
              HSSFCell cell;
              GenericFactoryIV pageFactIV;
              GenericFactorySprint3 pageFactAS3;
              GenericFactorySJVI pageFactSJVI;
              GenericFactorySJVII pageFactSJVII;
              GenericFactorySJVIII pageFactSJVIII;
              GenericFactoryV pageFactV;
  
  public  PageObjectsSJVIII(WebDriver Driver) {
                             this.Driver = Driver;
                             PageFactory.initElements(Driver, this);
  }
  
  public String aftermthd(WebDriver Driver) throws IOException {

      TakesScreenshot ts = (TakesScreenshot) Driver;
      // File source = ts.getScreenshotAs(OutputType.FILE);
      String source1 = ts.getScreenshotAs(OutputType.BASE64);
      return source1;

}
  @Test
  
  public String SearchBRClick(WebDriver Driver) throws InterruptedException {
                Thread.sleep(3000);
                pageFactSJVIII.SearchBRMenu(Driver);
                pageFact.waitForSpinnerToBeGone();
                Thread.sleep(7000);
                System.out.println("Clicked on Search BR");
                extentTest.log(LogStatus.INFO,"Clicked on Search BR");
                Thread.sleep(3000);
                pageFactSJVIII.advSearch.click();
                System.out.println("Clicked on Advanced Search");
                extentTest.log(LogStatus.INFO,"Clicked on Advanced Search");
                Thread.sleep(3000);
                return null;
  }
  
              
              public String wait_forBlngbtn(WebDriver Driver) throws InterruptedException {

                             WebDriverWait wait = new WebDriverWait(Driver, 60);
                             wait.until(ExpectedConditions
                                                         .elementToBeClickable(pageFact.createBillrcrd));
                             pageFact.waitForSpinnerToBeGone();
                      Thread.sleep(3000);
                      System.out.println("Added wait for spinner");
                             return null;
              }
  
  public String EnterBRValue(WebDriver Driver) throws InterruptedException, IOException {
                pageFactSJVIII.EnterBRVal();
                Thread.sleep(3000);
                pageFactSJVIII.SearchBRApply(Driver);
                Thread.sleep(5000);
                pageFactSJVIII.SelectBRVal(Driver);
                Thread.sleep(3000);
                IncomeHistscroldown(Driver);
                Thread.sleep(5000);
                pageFactSJVIII.nonAlwIncomeHistClick(Driver);
                Thread.sleep(5000);
                String Income1=pageFactSJVIII.FirstIncomeVal(Driver);
                System.out.println("First Income in Income History is :" +Income1);
                extentTest.log(LogStatus.INFO, "First Income in Income History is :" +Income1);
                String PaybkIncome=pageFactSJVIII.PaybkIncomeVal(Driver);
                System.out.println("Second Income in Income History is :" +PaybkIncome);
                extentTest.log(LogStatus.INFO, "Second Income in Income History is :" +PaybkIncome);            
                String Pbk=Income1+'P';
                System.out.println("Payback Income is:" +Pbk);
                if (Pbk.equals(PaybkIncome))
                {
                                           System.out.println("In Income History section, Payback  associated with a bill income is shown below the bill income .");
                                           extentTest.log(LogStatus.INFO, "In Income History section, Payback  associated with a bill income is shown below the bill income . ");
              
                             }
                             else {
                                           
                             String source = aftermthd(Driver);          
         System.out.println("Payback  associated with a bill income is  not shown below the bill income");
         extentTest.log(LogStatus.FAIL, "Payback  associated with a bill income is  not shown below the bill income"
                              + extentTest.addScreenCapture("data:image/png;base64,"+ source));
         
                             }
                
                return null;
  }
  
  public String IncomeHistscroldown(WebDriver Driver) {
                //pageFactSJVI.nonAlwIncomeClick(Driver);

                             // pageFactJS3.allwTab(Driver);

                             Actions act = new Actions(Driver);
                             act.moveToElement(pageFactSJVIII.miscHistory).perform();
                             return null;
              } 
  public String AddIncomescroldown(WebDriver Driver) throws InterruptedException {

                             // pageFactJS3.allwTab(Driver);
                pageFactSJVI.nonAlwIncomeClick(Driver);

                             Actions act = new Actions(Driver);
                            act.moveToElement(pageFactSJVIII.NonAlwAddrow).perform();
                             
                             pageFactSJVI.nonAlwAddIncomeComment(Driver);
                               System.out.println("Income Comments Added");
                               extentTest.log(LogStatus.INFO,
                                                                        "Income Comments Added");
                               
                               pageFactSJVI.nonAlwAddDesc(Driver);
                               System.out.println("Description Added");
                               extentTest.log(LogStatus.INFO,
                                                                        "Description Added");
                               
                               pageFactSJVI.nonAlwAddAmt(Driver);
                               System.out.println("Allowance Amount Added");
                               extentTest.log(LogStatus.INFO,
                                                                        "Allowance Amount Added");
                               
                               
                               //scroldown(Driver);
                               Thread.sleep(3000);
                               pageFactSJVI.nonAlwIncomeSubmitClick(Driver);           
                               pageFact.waitForSpinnerToBeGone();
                               Thread.sleep(3000);
                               Thread.sleep(5000);
                               System.out.println("Misc-Income Submitted");
                               extentTest.log(LogStatus.INFO,
                                                                        "Misc-Income Submitted");
                               pageFact.waitForSpinnerToBeGone();
                               Thread.sleep(7000);
                               pageFactSJVI.nonAlwIncomeHistClick(Driver);
                               System.out.println("Misc-Income History Expanded");
                               extentTest.log(LogStatus.INFO,
                                                                        "Misc-Income History Expanded");
                               
                               
                               pageFact.waitForSpinnerToBeGone();
                               Thread.sleep(7000);
                               
                             return null;
                             

  }
  

              
              public String waitforBR(WebDriver Driver) {

                             WebDriverWait wait = new WebDriverWait(Driver, 60);
              wait.until(ExpectedConditions.elementToBeClickable(pageFactSJVIII.createBR));
                             return null;
              }
              
              public String waitforAddIncome(WebDriver Driver) {

                             WebDriverWait wait = new WebDriverWait(Driver, 60);
              wait.until(ExpectedConditions.elementToBeClickable(pageFactSJVIII.nonAlwAddIncome));
                             return null;
              }
  
              public String nonAlwnceNew(WebDriver Driver) throws InterruptedException {
                             waitforBR(Driver);
                             pageFactSJVIII.creatBillng2();
                             Thread.sleep(3000);
                             System.out.println("BR clicked");
                             pageFactSJVIII.BrTypClick();
                             System.out.println("BR Type clicked");
                             pageFactSJVIII.BrTypeNonAlwClick();
                             Thread.sleep(3000);                     
                             pageFact.submitClk();
                             return null;
              }
  
  public String SortIncomeVal(WebDriver Driver) throws InterruptedException, IOException {
                
      String InvVal1=pageFactSJVIII.FirstInv(Driver);
      String InvVal2=pageFactSJVIII.SecondInv(Driver);
                String InvVal3=pageFactSJVIII.ThirdInv(Driver);
                
                //Invoice nbr nbr sorting
                             ArrayList<String> sortList = new ArrayList<String>(); //arrayList taken for sorting
                             ArrayList<String> ObtList = new ArrayList<String>();//ArrayList for obtained value from UI
                             sortList.add(InvVal1);
                             sortList.add(InvVal2);
                             sortList.add(InvVal3);
                             ObtList.add(InvVal1);
                             ObtList.add(InvVal2);
                             ObtList.add(InvVal3);
                             
                             System.out.println("Obtained List from UI :" +ObtList);
                             extentTest.log(LogStatus.INFO, "Obtained List from UI :" +ObtList);
                             
                             Collections.sort(sortList);//Sort the list in ascending order
                             System.out.println("Sorted List is :" +sortList);
                             extentTest.log(LogStatus.INFO, "Sorted List is :" +sortList);
                             Collections.reverse(sortList);//Sort the list to descending order
                             System.out.println("Sorted List in descending :" +sortList);
                             extentTest.log(LogStatus.INFO,"Sorted List in descending :" +sortList);
                             
                             if (sortList.equals(ObtList)){
                                           System.out.println("All incomes in Income History section is sorted by submitted date & time in descending order( Most recent income first).");
                                           extentTest.log(LogStatus.INFO, "All incomes in Income History section is sorted by submitted date & time in descending order( Most recent income first).");
              
                             }
                             else {
                                           
                                           String source = aftermthd(Driver);
            System.out.println("Income History section is not sorted by submitted date & time in descending order.");
            extentTest.log(LogStatus.FAIL, "Income History section is not sorted by submitted date & time in descending order."
                              + extentTest.addScreenCapture("data:image/png;base64,"+ source));
            
                             }
                
                
                
                return null;
                
  }
  
  public String BillnAccrueVal(WebDriver Driver) throws InterruptedException, IOException {
                String AccrNbr=pageFactSJVI.nonAlwIncmHistryAccrue();
                String InvNbr = pageFactSJVI.nonAlwIncmHistryInvNbr();
                if(!AccrNbr.isEmpty() && !InvNbr.isEmpty())
                {
                               System.out.println("Both Accrual and Bill Invoice is created for same date");
          extentTest.log(LogStatus.INFO, "Both Accrual and Bill Invoice are created for same date"); 
                }             
                else {
                               String source = aftermthd(Driver);
          System.out.println("Both Accrual and Bill Invoice are not created for same date ");
          extentTest.log(LogStatus.FAIL, "Both Accrual and Bill Invoice are not created for same date"
                               + extentTest.addScreenCapture("data:image/png;base64,"+ source));  
                             }

                if (pageFactSJVI.nonAlwIncmHistryAccrue().equals("Accrual")) {
          System.out.println("PASS:  First Invoice  value is : "+AccrNbr);
          extentTest.log(LogStatus.INFO, "First Invoice value is :" +AccrNbr);
                System.out.println("Second Invoice Value is : "
                                                          + InvNbr);
                extentTest.log(LogStatus.INFO,
                                             "Second Invoice Value is: "
                                                                                      + InvNbr);                                            
                
    } else {
              String source = aftermthd(Driver);
          System.out.println("FAIL:  First Invoice value is not Accrue  ");
          extentTest.log(LogStatus.FAIL, "First Invoice value  is not Accrue"
                               + extentTest.addScreenCapture("data:image/png;base64,"+ source));               
                             }
              

                System.out
                                           .println("For Bill & Accrue records associated with a billing record with same date & time,Accrue record is on top followed by Billing income record shown on top in the income history section.");
                               extentTest.log(LogStatus.INFO,
                                                            "Bill & Accrue records associated with a billing record with same date & time ,Accrue record is on top followed by Billing income record shown on top in the income history section. ");
                             return null;

  }
  @BeforeTest
  public void beforeTest(WebDriver Driver) {
                             pageFactIV = new GenericFactoryIV(Driver);
                             pageFactV = new GenericFactoryV(Driver);
                             pageFactAS3 = new GenericFactorySprint3(Driver);
                             pageFact = new GenericFactory(Driver);
                             pageFactSJVI=new GenericFactorySJVI(Driver);
                             pageFactSJVII=new GenericFactorySJVII(Driver);
                             pageFactSJVIII=new GenericFactorySJVIII(Driver);
  }

}
