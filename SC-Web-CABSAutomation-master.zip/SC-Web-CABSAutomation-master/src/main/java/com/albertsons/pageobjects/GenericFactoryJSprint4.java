package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.PageObjects;

public class GenericFactoryJSprint4 {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	GenericFactoryJSprint3 pageFactS3;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement ready;
	
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement ready1;
	
	@FindBy(xpath = "//*[@id=\"allow-income-tab\"]/div[1]/i-feather")
	public WebElement incmExp;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[1]/div[1]/cabs-checkbox")
	public WebElement incChk;

	@FindBy(xpath = "//*[@id=\"allow-tab\"]/div[1]/i-feather")
	public WebElement allwTb;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[1]/cabs-datepicker/form/div/div/input")
	public WebElement pDtFm;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[2]/cabs-datepicker/form/div/div/input")
	public WebElement pDtTo;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[1]/div/div[1]/cabs-checkbox")
	public WebElement itemized;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[4]/cabs-amount/div/div/input")
	public WebElement billFlatAmt;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/div[2]/div/div[2]/div/button[2]")
	public WebElement incSub;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[3]/cabs-amount/div/div/input")
	public WebElement fltRemVal;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[3]/cabs-checkbox/label")
	public WebElement useRemChk;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/div[2]/div/div[2]/div/button[1]")
	public WebElement save;

	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/div[2]/div/div[2]/div/plain-button/button")
	public WebElement cancel;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	public WebElement incPopNo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement incPopYes;
	
	@FindBy(xpath = "//*[@id=\"allow-income-tab\"]/div[3]/div[2]/label")
	public WebElement accrue;
	
	@FindBy(xpath = "//*[@id=\"allow-income-tab\"]/div[3]/div[3]/label")
	public WebElement billAccrue;
	
	@FindBy(xpath = "//*[@id=\"allow-income-tab\"]/div[4]/span/button/span")
	public WebElement incWarning;
	
	@FindBy(xpath = "//*[@id=\"ngb-popover-10\"]/div[2]")
	public WebElement incWarningTxt;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement itemizedCIC1;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement itemizedCIC2;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement itemCIC;
	
	@FindBy(xpath = "//*[@id=\"item-tab\"]/div[1]/i-feather")
	public WebElement itemTab;
	
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement itemizedUPC1;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement itemizedUPC2;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
	public WebElement itemUPC1;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
	public WebElement itemUPC2;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement dtFrm1;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement dtTo1;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement dtFrm2;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement dtTo2;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement itemDtFrm1;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement itemDtTo1;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement itemDtFrm2;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement itemDtTo2;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-amount/div/div/input")
	public WebElement alwAmt1;
	
	@FindBy(xpath = "//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-amount/div/div/input")
	public WebElement alwAmt2;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-amount/div/div/input")
	public WebElement itemAlwAmt1;
	
	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-amount/div/div/input")
	public WebElement itemAlwAmt2;
	
	@FindBy(xpath ="//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-textbox/div/input")
	public WebElement qty1;
	
	@FindBy(xpath ="//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-textbox/div/input")
	public WebElement qty2;
	
	@FindBy(xpath ="//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/cabs-amount/div/div/input")
	public WebElement tot1;
	
	@FindBy(xpath ="//*[@id=\"allowIncomeCollapse\"]/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/cabs-amount/div/div/input")
	public WebElement tot2;
	
	//@FindBy(xpath="//*[@id='undefined']")
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-textbox/div/input")	
	public WebElement qnty;
	
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/cabs-amount")
	public WebElement total1;
	
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/cabs-amount")
	public WebElement total2;
		
	@FindBy(xpath="//*[@id='grandTotalRow']/div/div[2]/div[1]/cabs-amount")
	public WebElement grandTotal;
	
	@FindBy(xpath="//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[4]/cabs-amount/div/div/input")	 	
	//@FindBy(xpath="//*[@id='flatAmount']/input")
	public WebElement fltAmnt;	
	
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
	public WebElement incmSbmtBtn;
	
	@FindBy(id="notesId")
	public WebElement notes;
	
	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement brSaveBtn;
	
	@FindBy(xpath="//*[@id='allow-income-tab']/div[4]/button")
	public WebElement addIncmeBtn;
	
	
	@FindBy(id="allow-inc-accure")
	public WebElement accruee;
	
	@FindBy(id="allow-inc-bill-accure")
	public WebElement billNaccrue;
	
	@FindBy(xpath="//*[@id='incomeCollapse']/div/div[2]/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/span")
	public WebElement clckable;
	
	public GenericFactoryJSprint4(WebDriver Driver) {

		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public Boolean headrChkBox(WebDriver Driver) throws InterruptedException {
		Thread.sleep(2000);

		pageFactS3.dedInv.findElement(By.className("form-control")).sendKeys(Keys.ENTER, "5");
		Thread.sleep(5000);
		pageFactS3.fAmt.sendKeys("1");
		pageFactS3.amt.sendKeys("10");
		pageFactS3.amt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		Thread.sleep(1000);
		pageFactS3.save.click();
		Thread.sleep(2000);
		ready.click();
		Thread.sleep(2000);
		ready.click();
		Thread.sleep(2000);
		ready.click();
		Thread.sleep(2000);
		
		incmExp.click();

		Thread.sleep(2000);

		WebElement incChkBox = incChk.findElement(By.tagName("input"));

		if (incChkBox.isSelected() == true) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean headrLbl(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		allwTb.click();
		WebElement element = pageFactS3.fCode.findElement(By.className("ng-value-label"));

		Actions act = new Actions(Driver);
		act.moveToElement(itemized).perform();

		if (incChk.getText().contentEquals("Header Flat Income (" + element.getText() + ")")) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean perfDtFrmToDflt(WebDriver Driver) throws InterruptedException {

		Thread.sleep(5000);

		if ((pageFactS3.pDateFm.getAttribute("value").contentEquals(pDtFm.getAttribute("value")))
				&& (pageFactS3.pDateTo.getAttribute("value").contentEquals(pDtTo.getAttribute("value")))) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean FltRemain(WebDriver Driver) throws InterruptedException {
		String flatPrev = fltRemVal.getAttribute("value");

		Double flatPrevInt = Double.parseDouble(flatPrev);

		billFlatAmt.sendKeys("0.5");
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(2000);
		incmExp.click();

		Double flatCur = flatPrevInt - 0.5;

		if ((Double.parseDouble(fltRemVal.getAttribute("value"))) == flatCur) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean flatRemainLssZero(WebDriver Driver) throws InterruptedException {
		String flatPrev = fltRemVal.getAttribute("value");
		
		Double flatPrevInt = Double.parseDouble(flatPrev);
		Double flatCur = flatPrevInt + 1;
		String faltcur1 = flatCur.toString();
		System.out.println(faltcur1);
		billFlatAmt.sendKeys(flatCur.toString());
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(2000);
		incPopYes.click();
		Thread.sleep(1000);
		incmExp.click();

		if (fltRemVal.getAttribute("value").contentEquals("0.00")) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean flatAmtVerify(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("25");
		if (billFlatAmt.getAttribute("value").contentEquals("25")) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean useRemBalance(WebDriver Driver) throws InterruptedException {

		useRemChk.click();
		if (fltRemVal.getAttribute("value").contentEquals(billFlatAmt.getAttribute("value"))) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean buttonsEnable(WebDriver Driver) throws InterruptedException {

		WebElement incChkBox = incChk.findElement(By.tagName("input"));
		WebElement itemChkBox = itemized.findElement(By.tagName("input"));
		if (incChkBox.isSelected() || itemChkBox.isSelected()) {
			if (save.isEnabled() && incSub.isEnabled() && cancel.isEnabled()) {
				return true;
			} else {
				return false;
			}
		} else {
			if (save.isEnabled() && incSub.isEnabled() && cancel.isEnabled()) {
				return false;
			} else {

				return true;
			}
		}

	}

	public Boolean FlatAmtGRemSaveSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("2");
		Thread.sleep(2000);
		save.click();
		Thread.sleep(1000);
		incPopNo.click();
		Thread.sleep(1000);
		save.click();
		Thread.sleep(1000);
		incPopYes.click();
		Thread.sleep(1000);
		incSub.click();
		Thread.sleep(1000);
		incPopYes.click();
		Thread.sleep(2000);
		if (save.isDisplayed() || incSub.isDisplayed() || cancel.isDisplayed()) {
			return false;
		}

		else {
			return true;
		}

	}

	public Boolean FlatAmtGRemSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("2");
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(1000);
		incPopYes.click();
		Thread.sleep(2000);
		if (save.isDisplayed() || incSub.isDisplayed() || cancel.isDisplayed()) {
			return false;
		}

		else {
			return true;
		}

	}

	public Boolean FlatAmtLRemSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("0.5");
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(2000);
		if (save.isDisplayed() || incSub.isDisplayed() || cancel.isDisplayed()) {
			return false;
		}

		else {
			return true;
		}

	}

	public Boolean FlatAmtERemSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("1");
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(2000);
		if (save.isDisplayed() || incSub.isDisplayed() || cancel.isDisplayed()) {
			return false;
		}

		else {
			return true;
		}

	}

	public Boolean FlatARSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("0.5");
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(2000);
		if (save.isDisplayed() || incSub.isDisplayed() || cancel.isDisplayed()) {
			return false;
		}

		else {
			return true;
		}

	}
	
	public Boolean headrChkBoxFlatRemzero(WebDriver Driver) throws InterruptedException {
		Thread.sleep(2000);

		pageFactS3.dedInv.findElement(By.className("form-control")).sendKeys(Keys.ENTER, "5");
		Thread.sleep(5000);
		pageFactS3.fAmt.clear();
		pageFactS3.amt.sendKeys("10");
		pageFactS3.amt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		Thread.sleep(1000);
		pageFactS3.save.click();
		Thread.sleep(2000);
		ready.click();
		Thread.sleep(2000);
		incmExp.click();

		Thread.sleep(2000);

		WebElement incChkBox = incChk.findElement(By.tagName("input"));

		if (incChkBox.isSelected() == true) {
			return false;
		} else {
			return true;
		}
	}
	public Boolean TotFlatEqualBill(WebDriver Driver) throws InterruptedException {

		String flatPrev = fltRemVal.getAttribute("value");
		
		billFlatAmt.sendKeys(flatPrev);
		Thread.sleep(2000);
		incSub.click();
		Thread.sleep(2000);
		incmExp.click();

		if (fltRemVal.getAttribute("value").contentEquals("0.00")) {
			return true;
		} else {
			return false;
		}
	}
	
	public Boolean FlatzeroSaveSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.clear();
		Thread.sleep(1000);
		save.click();
		Thread.sleep(1000);
		incWarning.click();
		Thread.sleep(1000);
		if(incWarningTxt.getText().contentEquals("Please enter required fields - Header flat income section")) {
			incSub.click();
			incWarning.click();
			if(incWarningTxt.getText().contentEquals("Please enter required fields - Header flat income section")) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
		
	}
	
	public Boolean FlatAmtRemSaveSub(WebDriver Driver) throws InterruptedException {

		billFlatAmt.sendKeys("0.5");
		Thread.sleep(2000);
		save.click();
		Thread.sleep(1000);
		incSub.click();
		Thread.sleep(1000);
		if (save.isDisplayed() || incSub.isDisplayed() || cancel.isDisplayed()) {
			return false;
		}

		else {
			return true;
		}

	}
	
	public Boolean itemChkBox(WebDriver Driver) throws InterruptedException {
		Thread.sleep(2000);

		pageFactS3.dedInv.findElement(By.className("form-control")).sendKeys(Keys.ENTER, "5");
		Thread.sleep(5000);
		pageFactS3.fAmt.clear();;
		pageFactS3.amt.sendKeys("10");
		pageFactS3.amt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		Thread.sleep(1000);
		pageFactS3.save.click();
		Thread.sleep(2000);
		ready.click();
		System.out.println("Ready1 clicked");
		Thread.sleep(2000);
		ready.click();
		System.out.println("Ready2 clicked");
		Thread.sleep(2000);
		ready.click();
		System.out.println("Ready3 clicked");
		incmExp.click();

		Thread.sleep(2000);

		WebElement itemChkBox = itemized.findElement(By.tagName("input"));
		
		if (itemChkBox.isSelected() == true) {
			return true;
			
		} else {
			return false;
		}
	}

	public Boolean itemChkBoxLbl(WebDriver Driver) throws InterruptedException {
		if (itemized.getText().contentEquals("Itemized Income (" +PO.allwTyp + "-" +PO.perf1+ "-" +PO.perf2+")")) {
			return true;
			}
			else {
				return false;
			}
	}
	
	public Boolean itemFieldsCIC(WebDriver Driver) throws InterruptedException {
		Thread.sleep(2000);
		itemTab.click();
		Thread.sleep(2000);
		Actions act = new Actions(Driver);
		act.moveToElement(save).perform();
		
		Thread.sleep(5000);
		if (itemizedCIC1.getText().contentEquals(itemCIC.getText())) {
			if (itemizedCIC2.getText().contentEquals(itemCIC.getText())){
			return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
public Boolean itemFieldsUPC(WebDriver Driver) throws InterruptedException {
		
		
		if (itemizedUPC1.getText().contentEquals(itemUPC1.getText())) {
			if (itemizedUPC2.getText().contentEquals(itemUPC2.getText())){
			return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}

public Boolean itemFieldsDtFrm(WebDriver Driver) throws InterruptedException {
	

	if (dtFrm1.getAttribute("value").contentEquals(itemDtFrm1.getAttribute("value"))) {
		if (dtFrm2.getAttribute("value").contentEquals(itemDtFrm2.getAttribute("value"))) {
		return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
	
}

public Boolean itemFieldsDtTo(WebDriver Driver) throws InterruptedException {
	
	
	if (dtTo1.getAttribute("value").contentEquals(itemDtTo1.getAttribute("value"))) {
		if (dtTo2.getAttribute("value").contentEquals(itemDtTo2.getAttribute("value"))) {
		return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
	
}
	
public Boolean itemFieldsAlwAmt(WebDriver Driver) throws InterruptedException {
	System.out.println(alwAmt1.getAttribute("value"));
	System.out.println(itemAlwAmt1.getAttribute("value"));
	System.out.println(alwAmt2.getAttribute("value"));
	System.out.println(itemAlwAmt2.getAttribute("value"));
	
	if (alwAmt1.getAttribute("value").contentEquals(itemAlwAmt1.getAttribute("value"))) {
		if (alwAmt2.getAttribute("value").contentEquals(itemAlwAmt2.getAttribute("value"))) {
		return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
	
}

public Boolean itemFieldsQty(WebDriver Driver) throws InterruptedException {
	System.out.println(qty1.getAttribute("value"));
	
	System.out.println(qty2.getAttribute("value"));
	if (qty1.getAttribute("value").isEmpty()) {
		if (qty2.getAttribute("value").isEmpty()) {
		return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
	
}

public String qtyfield(WebDriver Driver){
	
	
	qnty.sendKeys("3");
	qnty.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "20");
	
	return null;
}

public String qtyfield0(WebDriver Driver){
	
	
	qnty.sendKeys("0");
	qnty.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "0");
	
	return null;
}


public String totalSum(WebDriver Driver){
	
	
	String total1Val1 = total1.getAttribute("value");
	String totalVal2 = total2.getAttribute("value");
	System.out.println("total val1" +total1Val1);
	
	System.out.println("total val1" +totalVal2);
	 int value1 = Integer.parseInt(total1Val1);
     int value2 = Integer.parseInt(totalVal2);
     System.out.println("total valuu1" +value1);
     System.out.println("total valuu1" +value2);
  
	
	int sum = value1 + value2;
	System.out.println("Sum is " +sum);
	
	if(grandTotal.equals(sum)){
		System.out.println("Getting sum properly");
		
	}else{
		
		System.out.println("sum is wrong");
	}
	return null;
}


public String flatAmnt(WebDriver Driver){
	fltAmnt.sendKeys("3");
	return null;
}


public String notess(WebDriver Driver){
	
	notes.sendKeys("Test Automation Notes");
	return null;
}

public String elmntIntract(WebDriver Driver) throws InterruptedException {
	deductnum.findElement(By.className("form-control")).clear();
	Thread.sleep(3000);
	deductnum.findElement(By.className("form-control")).sendKeys("5");
	
	
	return null;
}

public String brSaveBtnn(WebDriver Driver) {

	brSaveBtn.click();
	return null;
}

public String readyy(WebDriver Driver){
	
	ready1.click();
	return null;
}


public String addIncmeBtnn(WebDriver Driver){
	
	addIncmeBtn.click();
	return null;
}

public String accrueee(WebDriver Driver){
	accrue.click();
//	accruee.click();
	return null;
}

public String billNaccruee(WebDriver Driver){
	
	billAccrue.click();
	//billNaccrue.click();
	return null;
}
 





//public Boolean itemFieldsTot(WebDriver Driver) throws InterruptedException {
//	
//	qty1.sendKeys("2");
//	System.out.println("A is "+tot1.getAttribute("value"));
//	System.out.println("B is "+tot1.getText());
//	
//	
//	System.out.println(tot2.getAttribute("value"));
//	
//	if (tot1.getAttribute("value").contentEquals((alwAmt1.getAttribute("value"))*(qty1.getAttribute("value")))) {
//		if (tot2.getAttribute("value").contentEquals("0.00")) {
//		return true;
//		}
//		else {
//			return false;
//		}
//	}
//	else {
//		return false;
//	}
//	
//}
//
//public Boolean itemizedItmInc(WebDriver Driver) throws InterruptedException {
//	
//	qty1.sendKeys("2");
//	qty2.sendKeys("3");
//	
//	if (tot1.getAttribute("value").contentEquals((alwAmt1.getAttribute("value")))) {
//		if (tot2.getAttribute("value").contentEquals("0.00")) {
//		return true;
//		}
//		else {
//			return false;
//		}
//	}
//	else {
//		return false;
//	}
//	
//}
	@BeforeTest
	public void beforeTest(WebDriver Driver) throws InterruptedException {

		pageFactS3 = new GenericFactoryJSprint3(Driver);

	}

}
