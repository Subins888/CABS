package com.albertsons.pageobjects;

import java.io.IOException;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsSJIX extends ExtendBaseClass {
	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactorySJIX pageFactSJIX;
	GenericFactorySJX pageFactSJX;
	GenericFactoryV pageFactV;

	public PageObjectsSJIX(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		// File source = ts.getScreenshotAs(OutputType.FILE);
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	@Test
	public String BRCreateHistVal(WebDriver Driver, String EditType)
			throws InterruptedException, IOException {
		Thread.sleep(3000);
		scrollUp(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		pageFactSJIX.clickLastUpdate(Driver);
		Thread.sleep(3000);
		String BRCreateHistVal = pageFactSJIX.createBRHist(Driver);
		String BRCreateHistDate = pageFactSJIX.createBRHistdate(Driver);
		String createBRHistCurrent = pageFactSJIX.createBRHistCurrent(Driver);

		if (EditType.equals("Billing")) {

			System.out.println("BR create " + BRCreateHistVal);
			if (BRCreateHistVal.contains("Billing record created")) {
				System.out
						.println("Historical view of BR shows date time - Billing Record Created:"
								+ BRCreateHistDate
								+ BRCreateHistVal
								+ createBRHistCurrent);
				extentTest.log(LogStatus.INFO,
						"Historical view of BR shows date time - Billing Record Created:"
								+ BRCreateHistDate + "" + "-" + BRCreateHistVal
								+ createBRHistCurrent);

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Historical view of BR doesnt show- Billing Record Created");
				extentTest
						.log(LogStatus.FAIL,
								"Historical view of BR doesnt show -Billing Record Created"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}
			Thread.sleep(3000);
		}

		if (EditType.equals("Allowance")) {

			System.out.println("Allowance history " + BRCreateHistVal);
			// Allowance Information updated

			if (BRCreateHistVal.contains("Allowance Information updated")) {
				System.out
						.println("Historical view of BR shows date time -Allowance Information updated:"
								+ BRCreateHistDate
								+ BRCreateHistVal
								+ createBRHistCurrent);
				extentTest.log(LogStatus.INFO,
						"Historical view of BR shows date time - Allowance Information updated:"
								+ BRCreateHistDate + "" + "-" + BRCreateHistVal
								+ createBRHistCurrent);

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Historical view of BR doesnt show- Allowance Information updated");
				extentTest
						.log(LogStatus.FAIL,
								"Historical view of BR doesnt show -Allowance Information updated"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}
			Thread.sleep(3000);
		}

		if (EditType.equals("ItemDetails")) {

			System.out.println("ItemDetails history " + BRCreateHistVal);
			// Allowance Information updated

			if (BRCreateHistVal.contains("Item details updated")) {
				System.out
						.println("Historical view of BR shows date time -Item details updated:"
								+ BRCreateHistDate
								+ BRCreateHistVal
								+ createBRHistCurrent);
				extentTest.log(LogStatus.INFO,
						"Historical view of BR shows date time - Item details updated:"
								+ BRCreateHistDate + "" + "-" + BRCreateHistVal
								+ createBRHistCurrent);

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Historical view of BR doesnt show- Item details updated");
				extentTest
						.log(LogStatus.FAIL,
								"Historical view of BR doesnt show -Item details updated"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}
			Thread.sleep(3000);
		}

		if (EditType.equals("Header")) {

			System.out.println("Billing record header history "
					+ BRCreateHistVal);
			// Allowance Information updated

			if (BRCreateHistVal.contains("Billing record header updated")) {
				System.out
						.println("Historical view of BR shows date time -Billing record header updated:"
								+ BRCreateHistDate
								+ BRCreateHistVal
								+ createBRHistCurrent);
				extentTest.log(LogStatus.INFO,
						"Historical view of BR shows date time - Billing record header updated:"
								+ BRCreateHistDate + "" + "-" + BRCreateHistVal
								+ createBRHistCurrent);

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Historical view of BR doesnt show- Billing record header updated");
				extentTest
						.log(LogStatus.FAIL,
								"Historical view of BR doesnt show -Billing record header updated"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}
			Thread.sleep(3000);
		}
		if (EditType.equals("Multiple")) {

			System.out.println("Multiple updates history " + BRCreateHistVal);
			// Allowance Information updated

			if (BRCreateHistVal.contains("Multiple updates")) {
				System.out
						.println("Historical view of BR shows date time -Multiple updates:"
								+ BRCreateHistDate
								+ BRCreateHistVal
								+ createBRHistCurrent);
				extentTest.log(LogStatus.INFO,
						"Historical view of BR shows date time - Multiple updates:"
								+ BRCreateHistDate + "" + "-" + BRCreateHistVal
								+ createBRHistCurrent);

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Historical view of BR doesnt show- Multiple updates");
				extentTest
						.log(LogStatus.FAIL,
								"Historical view of BR doesnt show -Multiple updates"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}
			Thread.sleep(3000);
		}

		if (EditType.equals("Income")) {

			System.out.println("Income submit history " + BRCreateHistVal);
			// Allowance Information updated

			if (BRCreateHistVal.contains("Income submitted")) {
				System.out
						.println("Historical view of BR shows date time -Income submitted:"
								+ BRCreateHistDate
								+ BRCreateHistVal
								+ createBRHistCurrent);
				extentTest.log(LogStatus.INFO,
						"Historical view of BR shows date time - Income submitted:"
								+ BRCreateHistDate + "" + "-" + BRCreateHistVal
								+ createBRHistCurrent);

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Historical view of BR doesnt show- Income submitted");
				extentTest
						.log(LogStatus.FAIL,
								"Historical view of BR doesnt show -Income submitted"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}
			Thread.sleep(3000);
		}

		return null;
	}

	public String EditItem(WebDriver Driver) throws InterruptedException {

		Thread.sleep(55000);
		pageFactSJIX.Itemtab.click();
		Thread.sleep(2000);
		pageFactSJIX.itemDetailsAmnt.sendKeys(Keys.CONTROL + "a");
		pageFactSJIX.itemDetailsAmnt.sendKeys("15.99");
		Thread.sleep(4000);
		pageFactSJIX.save.click();
		System.out.println("Edited Item details-Allow amount to 15.99");
		extentTest.log(LogStatus.INFO,
				"Edited Item details-Allow amount to 15.99");
		Thread.sleep(2000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);

		return null;
	}

	public String EditHeader(WebDriver Driver) throws InterruptedException {
		// pageFactSJIX.EditHeaderBillName(Driver);
		// pageFactSJIX.save.click();
		Thread.sleep(2000);
		pageFactSJIX.ready.click();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		System.out
				.println("Clicked Ready which will update BR status in Header section");
		extentTest.log(LogStatus.INFO,
				"Clicked Ready which will update BR status in Header section");
		Thread.sleep(2000);

		return null;
	}

	public String MultipleUpdates(WebDriver Driver) throws InterruptedException {
		pageFactSJX.alwTab.click();
		scrollDownReady(Driver);
		pageFactSJIX.itemAlTypeClick.click();
		Thread.sleep(2000);
		pageFactSJIX.itemAlPerf1.click();
		Thread.sleep(2000);
		pageFactSJIX.itemAlPerf2Click.click();
		Thread.sleep(2000);
		pageFactSJIX.itemAlPerf2.click();
		Thread.sleep(2000);
		pageFactSJIX.itemAlPerf3Click.click();
		Thread.sleep(2000);
		pageFactSJIX.itemAlPerf3.click();
		Thread.sleep(2500);
		pageFactSJIX.Itemtab.click();
		scrollDownIncome(Driver);
		Thread.sleep(2500);
		pageFactSJIX.itemDetailsAmnt.sendKeys("9.99");
		pageFactSJIX.itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB,
				"9.99");
		Thread.sleep(3000);
		pageFactSJIX.save.click();
		Thread.sleep(55000);
		// pageFactSJIX.EditMultiple(Driver);
		System.out
				.println("Edited Allowance Type and Item allow amount to 9.99  -Multiple updates");
		extentTest
				.log(LogStatus.INFO,
						"Edited Allowance Type and Item allow amount to 9.99  -Multiple updates");

		return null;
	}

		public String BRCreateHistClick(WebDriver Driver)
			throws InterruptedException {
		pageFactSJIX.createBRHistdateClick(Driver);
		pageFact.waitForSpinnerToBeGone();
		System.out.println("Clicked on Historical view of BR ");
		extentTest.log(LogStatus.INFO, "Clicked on Historical view of BR");
		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		return null;

	}

	public String BRCreateHistClickFieldsVal(WebDriver Driver)
			throws InterruptedException, IOException {
		// BillingNameClick(Driver);
		String BillName = pageFactSJIX.BillingNameVal(Driver);
		System.out.println("AP/AR number first saved is " + BillName);
		String IntNotes = pageFactSJIX.NonAlwNotesVal(Driver);
		System.out.println("Internal Notes first saved is  " + IntNotes);

		if (BillName.equals("510") && (IntNotes.equals("Test Automation"))) {
			System.out
					.println("User is able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.INFO,
							"Useris able to see the data on various fields in various sections, as it was during that snapshot of time.");

		}

		else {
			String source = aftermthd(Driver);
			System.out
					.println("User is not able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to see the data on various fields in various sections, as it was during that snapshot of time."
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		return null;

	}

	public String BRCreateHistClickFieldsValwithMulipleUpd(WebDriver Driver)
			throws InterruptedException, IOException {
		// BillingNameClick(Driver);
		String BillName = pageFactSJIX.BillingNameVal(Driver);
		System.out.println("AP/AR number last saved is " + BillName);
		String IntNotes = pageFactSJIX.NonAlwNotesVal(Driver);
		System.out.println("Internal Notes last saved is  " + IntNotes);

		if (BillName.equals("510") && (IntNotes.contains("Test Automation"))) {
			System.out
					.println("User is able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.INFO,
							"Useris able to see the data on various fields in various sections, as it was during that snapshot of time.");

		}

		else {
			String source = aftermthd(Driver);
			System.out
					.println("User is not able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to see the data on various fields in various sections, as it was during that snapshot of time."
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		return null;

	}

	public String BRCreateHistClickFieldsValwithHeader(WebDriver Driver)
			throws InterruptedException, IOException {
		// BillingNameClick(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		String BillName = pageFactSJIX.BillingNameVal(Driver);
		System.out.println("AP/AR number last saved is " + BillName);
		String IntNotes = pageFactSJIX.NonAlwNotesVal(Driver);
		System.out.println("Internal Notes last saved is  " + IntNotes);

		if (BillName.equals("510") && (IntNotes.equals("Test Automation"))) {
			System.out
					.println("User is able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.INFO,
							"Useris able to see the data on various fields in various sections, as it was during that snapshot of time.");

		}

		else {
			String source = aftermthd(Driver);
			System.out
					.println("User is not able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to see the data on various fields in various sections, as it was during that snapshot of time."
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		return null;

	}

	public String BRCreateHistFieldsValwithAllowFields(WebDriver Driver)
			throws InterruptedException, IOException {
		// BillingNameClick(Driver);
		String BillName = pageFactSJIX.BillingNameVal(Driver);
		System.out.println("AP/AR number last saved is " + BillName);
		String IntNotes = pageFactSJIX.NonAlwNotesVal(Driver);
		System.out.println("Internal Notes last saved is  " + IntNotes);
		String AllowCode = pageFactSJIX.FlatAmtVal(Driver);
		System.out.println("Flat amount last saved is  " + AllowCode);

		if (BillName.equals("510") && (IntNotes.equals("Test Automation"))
				&& (AllowCode.equals("10.99"))) {
			System.out
					.println("User is able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.INFO,
							"Useris able to see the data on various fields in various sections, as it was during that snapshot of time.");

		}

		else {
			String source = aftermthd(Driver);
			System.out
					.println("User is not able to see the data on various fields in various sections, as it was during that snapshot of time.");
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to see the data on various fields in various sections, as it was during that snapshot of time."
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		return null;

	}

	public String EditAllowInfo(WebDriver Driver) throws InterruptedException {
		Thread.sleep(4000);
		pageFactSJIX.FlatAmtChange(Driver);
		pageFactSJIX.Save(Driver);
		Thread.sleep(30000);
		System.out
				.println("Edited Allowance information section-Flat code to 10.99");
		extentTest.log(LogStatus.INFO,
				"Edited Allowance information section-Flat code to 10.99");

		return null;

	}

	public String AllwncBRSave(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		Thread.sleep(3000);
		pageFactSJIX.BillingName(Driver);
		Thread.sleep(3000);
		pageFactSJIX.txtArea(Driver);
		Thread.sleep(3000);
		pageFactSJIX.itemDetailsAmnt(Driver);
		Thread.sleep(5000);
		return null;
	}

	public String AddAllowIncome(WebDriver Driver) throws InterruptedException {
		// pageFactSJIX.ready.click();
		// System.out.println("Clicked Ready");
		// Thread.sleep(20000);
		Thread.sleep(3000);
		scrollDownIncome(Driver);
		waitforAddIncome(Driver);
		Thread.sleep(3000);
		System.out.println("Add income is enabled");
		pageFactSJIX.AddIncome.click();
		System.out.println("Clicked Add Income");
		Thread.sleep(3000);
		pageFactSJIX.AddIncomeComments.sendKeys("Test Automation-Income");
		System.out.println("Added income comments");
		Thread.sleep(1000);
		pageFactSJIX.AddIncomeComments.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB,
				Keys.TAB, Keys.TAB, "1.78");
		Thread.sleep(1000);
		scrollDownIncomeSubmit(Driver);
		Thread.sleep(2000);
		System.out.println("Added income amount");
		Thread.sleep(1000);
		pageFactSJIX.AddIncomeSubmit.click();
		System.out.println("Income Submitted for amount 1.78");
		extentTest.log(LogStatus.INFO, "Income Submitted for amount 1.78");
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);
		scrollUp(Driver);
		Thread.sleep(2000);
		return null;

	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactSJIX.BRtxt));
		return null;
	}

	public String waitforAddIncome(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactSJIX.AddIncome));
		return null;
	}

	public String scrollUp(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactSJIX.clickLastUpdate).perform();
		return null;
	}

	public String scrollDown(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactSJIX.FlatAmt).perform();
		return null;
	}

	public String scrollDownReady(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactSJIX.ready).perform();
		return null;
	}

	public String scrollDownIncome(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactSJIX.AddIncome).perform();
		return null;
	}

	public String scrollDownIncomeSubmit(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactSJIX.AddIncomeSubmit).perform();
		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {
		pageFact = new GenericFactory(Driver);
		pageFactSJIX = new GenericFactorySJIX(Driver);
		pageFactSJX = new GenericFactorySJX(Driver);
	}

}
