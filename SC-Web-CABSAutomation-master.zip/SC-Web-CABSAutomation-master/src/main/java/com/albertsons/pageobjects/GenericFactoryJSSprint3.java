package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.albertsons.reportGeneration.ExtendBaseClass;

public class GenericFactoryJSSprint3 extends ExtendBaseClass{
	
	WebDriver Driver;	
	
    public GenericFactoryJSSprint3(WebDriver Driver) {
        this.Driver = Driver;
        PageFactory.initElements(Driver, this);
  }
   
    @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
        public WebElement AlwSaveBtn;
    
    @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
       public WebElement AlwReadyBtn;
    
    @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/plain-button/button")
        public WebElement AlwCnclBtn;
    
    @FindBy(xpath = "//*[@id='allow-income-tab']/div[2]")
                    public WebElement AlwIncBtn;
    
    @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div")
        public WebElement AlwActBr;

    //--------------------------------------------------------------
    @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span/span")
      public WebElement SaveErrMsg;
    @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[1]/div/div[3]/div")
            public WebElement RtOffset;   
    @FindBy(xpath="//*[@id='assignTo']/div/div/div[2]/span[2]")
    //driver.Findelement(By.partialLinkText("Jenny Jolly - Billing"))
    public WebElement AssignedToUsr;
    
      @FindBy(id = "deductInvoiceNumber")
      public WebElement deductnum;
      
      @FindBy(xpath="//*[@id='ta-assignTo-1']")
      public WebElement SelectAssignTo;
      //*[@id="ta-assignTo-1"]
      
  @FindBy(xpath="//*[@id='assignTo']/div/div/div[3]/input")
      public WebElement SelectAssig;
    
    @FindBy(xpath="//*[@id='assignTo']/div/span")
    public WebElement AssignedToDropDwn;
    
    @FindBy(xpath="//*[@id='undefined']/input")
    public WebElement itemDetailsAmnt;
    
    @FindBy(id="ta-brStatus-0")
	public WebElement newid;

@FindBy(id="ta-assignTo-0")
public WebElement asgnto0;    


@FindBy(id="ta-assignTo-2")
public WebElement asgnto2; 

@FindBy(id="offsetSectionNumber")
public WebElement sectNum;

@FindBy(xpath = "//*[@id='brStatus']/div/span")
public WebElement brStatusdrp;

@FindBy(xpath ="//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
public WebElement save;


@FindBy(id = "billingRecordId")
public WebElement blngRcrdid;

@FindBy(id="offsetFacilityNumber")
public WebElement offsetAccountNumber;

@FindBy(id="offsetAccountNumber")
public WebElement offsetFacilityNumber;


@FindBy(id="offsetSectionNumber")
public WebElement offsetSectionNumber;


    //Method2
    
    public String AlwSavebtntxt(WebDriver Driver) {
        Actions action = new Actions(Driver);
        action.moveToElement(AlwIncBtn).perform();;
              return AlwSaveBtn.getText();
        }
        public String AlwReadybtntxt(WebDriver Driver) {
              return AlwReadyBtn.getText();
        }
        public String AlwCnclbtntxt(WebDriver Driver) {
              return AlwCnclBtn.getText();
        }

    //--------------------------------------------------------------
         
     public String RtSaveError(WebDriver Driver){
                   return SaveErrMsg.getText();
     }
     
     
     public String RtSave(WebDriver Driver){
       AlwSaveBtn.click();
       return null;
              
 }   
     
     //public String AssignedToDropDwn(WebDriver Driver){
       //    AssignedToDropDwn.click();
       //    return null;
 //}
     public String AssignedToVal(WebDriver Driver){
       //AssignedToDropDwn.click();
             return AssignedToUsr.getText();
 }
     
     public String elmntIntract() {
             deductnum.findElement(By.className("form-control")).sendKeys("5");
             return null;
       }
     
     public String SelectAssinTo(WebDriver Driver)
     {       
       AssignedToDropDwn.click();   
       return null;
     }
     
     public String SelectAsignToo(WebDriver Driver){
       
       SelectAssignTo.click();
       return null;
     }

     
     public String RtAssignedToVal2(WebDriver Driver){
       //AssignedToDropDwn.click();
             return SelectAssignTo.getText();
 }
     
     public String itemDetailsAmnt2(WebDriver Driver) {
         itemDetailsAmnt.sendKeys("1");
   itemDetailsAmnt.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,"20");           
         return null;
   }
     
     
     
     public String asgntoo(WebDriver Driver){
         
    	 return asgnto0.getText();
           
       }  
     
 public String asgntoo2(WebDriver Driver){
         
    	 return asgnto2.getText();
           
       } 
     
     public String sectNumm(WebDriver Driver) {
    	 sectNum.sendKeys("11111");
         return null;
   } 
     
     
     public String brStatusdrpclk(WebDriver Driver) {

 		brStatusdrp.click();
 		return null;
 	}

     
     public String newidd(WebDriver Driver) {

    	 return newid.getText();   
    }
     
     public String itemDetailsAmntt(WebDriver Driver) {
    		itemDetailsAmnt.sendKeys("1");
    		itemDetailsAmnt.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,"20");	
    		save.click();
    		return null;
    	}
     public String ofsetNumAcnt(WebDriver Driver) {

    	 		
    		//	WebElement elem = offsetAccountNumber.findElement(By.className("AcctNbr"));
	     WebElement elem = offsetAccountNumber;
    			return	elem.getAttribute("value");	
		 
    		}
     public String ofsetNumFac(WebDriver Driver) {

	 		
    	// WebElement elem2 = offsetFacilityNumber.findElement(By.className("FactNbr"));		
	     WebElement elem2 = offsetFacilityNumber;
			return	elem2.getAttribute("value");	
			 
		}
     public String ofsetNumSec(WebDriver Driver) {
    	 
		//WebElement elem3 = offsetSectionNumber.findElement(By.className("SectNbr"));		
	            WebElement elem3 = offsetSectionNumber;
			return	elem3.getAttribute("value");	
			 
		}
     
     

 	public String blngRcrdidd() {

 		WebElement elem = blngRcrdid.findElement(By.className("form-control"));		
 		return	elem.getAttribute("value");	
 
 	}
     }

