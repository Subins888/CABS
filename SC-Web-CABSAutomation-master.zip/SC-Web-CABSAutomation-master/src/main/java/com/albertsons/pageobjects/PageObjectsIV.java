package com.albertsons.pageobjects;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Properties;

import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * 
 * 
 * @author akuma58
 *
 */

public class PageObjectsIV extends ExtendBaseClass {

	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactorySprint3 pageFactAS3;
	String extentReportImage467PO_0;
	String extentReportImage467PO_1;
	String extentReportImage467PO_2;
	String extentReportImage467PO_3;
	String extentReportImage467PO_4;
	String extentReportImage450PO_1;
	String extentReportImage205PO_0;
	String extentReportImage205PO_1;

	public PageObjectsIV(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public File aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactIV.createBillrcrd));
		return null;
	}

	public String AlwnceBRNoItemizd(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		//Thread.sleep(30000);
		//wait for spinner not working in linux		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5500);

		pageFact.blngrcrdDrp();

		Thread.sleep(5000);

		pageFact.retailalw();
		Thread.sleep(10000);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldLeadCIC();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(3000);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(3000);
		pageFact.itemAlwType();
		Thread.sleep(3000);
		pageFact.brSubmit.click();

		return null;

	}
	
	public String AlwnceBRIV(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		//Thread.sleep(20000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		Thread.sleep(7500);
		pageFact.retailalw();
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(3000);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(3000);
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(3000);
		pageFact.itemAlwType();
		Thread.sleep(3000);
		pageFact.allwtype();
		Thread.sleep(3000);
		pageFact.allwTP1P2();
		Thread.sleep(3000);
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBR2(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {
		waitforBlngbtn(Driver);
		Thread.sleep(2500);
		pageFact.analysisWrklstt(Driver);
		Thread.sleep(2500);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();

		Thread.sleep(2000);
		pageFact.billDateTo.sendKeys(Keys.TAB, "1");

		Thread.sleep(3000);
		WebElement FC = Driver.findElement(By
				.xpath("//*[@id=\"flatCode\"]/div/div/div[2]/input"));

		FC.click();
		Thread.sleep(3000);
		pageFact.flatCode1.click();
		pageFact.brSubmit.click();

		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}
	public String scrolUp(WebDriver Driver) {
 
		Actions act = new Actions(Driver);
		act.moveToElement(pageFact.BRtxt).perform();
		return null;
	}
	
		public String BRSave(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);
		Thread.sleep(3000);
		pageFact.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(3000);
		pageFactAS3.itemDetailsAmntt(Driver);
		Thread.sleep(5000);
		scrolUp(Driver);
		// Thread.sleep(15000);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact.brStatusdrpclk();
		// pageFactAS3.brStatusdropp(Driver);
		Thread.sleep(5000);
//		String brStatusvalue = pageFactAS3.newidd();
//		System.out.println("BR Status value is " + brStatusvalue);
//
//		extentTest.log(LogStatus.INFO, "BR Status value is " + brStatusvalue);

	//	Thread.sleep(5000);

		if (pageFactAS3.incmeSaveBtn.isDisplayed()) {
			System.out.println("Income section enabled even in NEW status");
			extentTest.log(LogStatus.FAIL,
					"Income section enabled even in NEW status");
			extentReportImage467PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage467PO_0.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage467PO_0);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.INFO,
							"Income section enabled even in NEW status"
									+ extentTest
											.addScreenCapture(extentReportImage467PO_0));
		} else {
			System.out
					.println("Income section is disabled as the BR status is NEW");
			extentTest.log(LogStatus.INFO,
					"Income section is disabled as the BR status is NEW");
		}

		return null;
	}

	public String BRSaveNewReady(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactAS3.readyy(Driver);
		Thread.sleep(2000);
		if (pageFactAS3.addIncmeBtn.isDisplayed()) {
			System.out
					.println("Add Income button is enabled after successfully saving (Ready) the billing record");
			extentTest
					.log(LogStatus.INFO,
							"TEST CASE PASSED:  Add Income button is enabled after successfully saving (Ready) the billing record");
		} else {
			System.out.println("Add income button not enabled");
			extentTest
					.log(LogStatus.FAIL,
							"TEST CASE FAILED:  Add income button not enabled");
		}

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		return null;
	}

	public String BRReadyenabled(WebDriver Driver) throws InterruptedException,
			IOException {
		Thread.sleep(2000);
		if (pageFactAS3.ready.isDisplayed()) {
			System.out.println("Ready button is enabled");
			extentTest.log(LogStatus.INFO, "Ready button is enabled");
		} else {
			System.out.println("Ready button not enabled");

			extentReportImage450PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage450PO_1.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage450PO_1);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Ready button not enabled"
					+ extentTest.addScreenCapture(extentReportImage450PO_1));
		}

		pageFactAS3.readyy(Driver);
		Thread.sleep(2500);
		pageFact.brStatusdrpclk();
		// pageFactAS3.brStatusdropp(Driver);
		Thread.sleep(3000);
		String brStatusvalue = pageFactAS3.newidd();
		System.out.println("BR Status value is " + brStatusvalue);

		extentTest.log(LogStatus.INFO, "BR Status value is " + brStatusvalue);

		return null;
	}

	public String incomeAddClk(WebDriver Driver) throws InterruptedException {

		Thread.sleep(55000);
		pageFactAS3.addIncmeBtnn(Driver);
		return null;
	}

	public String chckBox(WebDriver Driver) throws IOException,
			InterruptedException {

		Thread.sleep(2500);
		Actions scroll = new Actions(Driver);
		scroll.moveToElement(pageFactIV.incSave).perform();
		WebElement checkbox1 = pageFactIV.headerChckbox.findElement(By
				.tagName("input"));
		WebElement checkbox2 = pageFactIV.itemChckbox.findElement(By
				.tagName("input"));

		if (checkbox1.isSelected()) {

			System.out.println("Header flat income checkbox selected");
			extentTest.log(LogStatus.INFO,
					"Header flat income checkbox selected");
		} else {

			System.out.println("Header flat income checkbox not selected");
			extentReportImage467PO_2 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage467PO_2.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage467PO_2);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Header flat income checkbox not selected"
									+ extentTest
											.addScreenCapture(extentReportImage467PO_2));
		}

		if (checkbox2.isSelected()) {

			System.out.println("Itemized income checkbox selected");
			extentTest.log(LogStatus.INFO, "Itemized income checkbox selected");
		} else {

			System.out.println("Itemized income checkbox not selected");
			extentReportImage467PO_3 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage467PO_3.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage467PO_3);
			FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Itemized income checkbox not selected"
									+ extentTest
											.addScreenCapture(extentReportImage467PO_3));
		}

		return null;
	}

	public String waitforSaveIncome(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactIV.incSave2));
		return null;
	}

	public String itemQtyAmnt(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		System.out.println("1");
		pageFactIV.notesTabFlatAmt(Driver);
	//	pageFactIV.flatAmtt(Driver);
		System.out.println("2");
		pageFactIV.qtyy(Driver);
		System.out.println("3");
		return null;
	}
	
	public String itemQtyAmntII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		System.out.println("1");
		pageFactIV.notesTabFlatAmt(Driver);

		return null;
	}

	public String incomeSave(WebDriver Driver) throws IOException,
			InterruptedException {
		// waitforSaveIncome(Driver);
		pageFactIV.incSave22(Driver);
		extentTest.log(LogStatus.INFO, "Clicked on Save button");
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactIV.incSubmt(Driver);
		Thread.sleep(3000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		if (pageFactIV.incSave2.isDisplayed()) {
			System.out.println("Submit functionality not working");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Submit functionality not working");

		} else {
			System.out
					.println("Clicked on Submit button, Submit functionality working properly");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Clicked on Submit button, Submit functionality working properly");

		}

		return null;
	}

	public String incomeSubmit(WebDriver Driver) throws IOException,
			InterruptedException {
		incomeAddClk(Driver);
		itemQtyAmntII(Driver);

		waitforSaveIncome(Driver);
		pageFactIV.incSubmt(Driver);
		Thread.sleep(1500);
		pageFactIV.warngYess(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		if (pageFactIV.incSave2.isDisplayed()) {
			System.out.println("Submit functionality not working");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Submit functionality not working");
		 
		} else {
			System.out
					.println("Clicked on Submit button alone, Submit functionality working properly");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Clicked on Submit button alone, Submit functionality working properly");
		}
		return null;
	}

	public String incomeSubmit2(WebDriver Driver) throws IOException,
			InterruptedException {
		Thread.sleep(2000);

		pageFactIV.incSubmt(Driver);
		Thread.sleep(2000);
		// pageFactIV.warngYess(Driver);
		Thread.sleep(3000);
		if (pageFactIV.incSave2.isDisplayed()) {
			System.out.println("Submit functionality not working");
			extentTest.log(LogStatus.FAIL, "Submit functionality not working");
			
		} else {
			System.out
					.println("Clicked on Income Submit button, Submit functionality working properly");
			extentTest
					.log(LogStatus.INFO,
							"Clicked on Income Submit button, Submit functionality working properly");
		}
		return null;
	}

	public String incomeSubmit3(WebDriver Driver) throws IOException,
			InterruptedException {
		Thread.sleep(2000);

		pageFactIV.incSubmt(Driver);
		Thread.sleep(2000);
		pageFactIV.warngYess(Driver);
		Thread.sleep(3000);
		if (pageFactIV.incSave2.isDisplayed()) {
			System.out.println("Submit functionality not working");
			extentTest.log(LogStatus.FAIL, "Submit functionality not working");
			
		} else {
			System.out
					.println("Clicked on Income Submit button, Submit functionality working properly");
			extentTest
					.log(LogStatus.INFO,
							"Clicked on Income Submit button, Submit functionality working properly");
		}
		return null;
	}

	public String deductInvoice(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);
		pageFactIV.deductInvv(Driver);
		Thread.sleep(2000);

		String err = pageFactIV.invARPRr(Driver);

		if (pageFactIV.invARPRr(Driver).equals("Invalid AP/AR number")) {
			System.out
					.println("Invalid AP number case, error message displaying properly.  Error message showing is:  "
							+ err);
			extentTest
					.log(LogStatus.INFO,
							"Invalid AP number case, error message displaying properly.  Error message showing is:  "
									+ err);

		} else {
			System.out
					.println("Invalid AP number case, error message not displaying properly.  Error message showing is:  "
							+ err);
			extentTest
					.log(LogStatus.FAIL,
							"Invalid AP number case, error message not displaying properly.  Error message showing is:  "
									+ err);
			extentReportImage205PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage205PO_0.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage205PO_0);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.INFO, "Submit functionality not working"
					+ extentTest.addScreenCapture(extentReportImage205PO_0));
		}

		pageFactIV.ARRadioo(Driver);
		Thread.sleep(2000);
		pageFactIV.deductInvv(Driver);
		Thread.sleep(2000);

		if (pageFactIV.invARPRr(Driver).equals("Invalid AP/AR number")) {
			System.out
					.println("Invalid AR number case, error message displaying properly.  Error message showing is:  "
							+ err);
			extentTest
					.log(LogStatus.INFO,
							"Invalid AR number case, error message displaying properly.  Error message showing is:  "
									+ err);

		} else {
			System.out
					.println("Invalid AR number case, error message not displaying properly.  Error message showing is:  "
							+ err);
			extentTest
					.log(LogStatus.FAIL,
							"Invalid AR number case, error message not displaying properly.  Error message showing is:  "
									+ err);
			extentReportImage205PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage205PO_1.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage205PO_1);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.INFO, "Submit functionality not working"
					+ extentTest.addScreenCapture(extentReportImage205PO_1));
		}

		return null;
	}

	public String deductInvoiceValid(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFactIV.deductInvVal(Driver);

		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFact = new GenericFactory(Driver);
	}

}
