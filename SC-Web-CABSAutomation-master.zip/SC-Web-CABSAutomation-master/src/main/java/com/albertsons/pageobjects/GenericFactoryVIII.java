package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GenericFactoryVIII {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;
	public WebElement offnum, LCIC;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/div")
	WebElement noDataTxt;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	WebElement searchFirstItem;

	@FindBy(id = "billingName")
	WebElement blngName;

	@FindBy(id = "offerNumber")
	WebElement ofrNbr;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/action-button/button")
	public WebElement searchApply;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement blngNameFirst;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/plain-button/button")
	public WebElement clearAllBtn;

	@FindBy(xpath = "//*[@id='brStatusSearch']/div/span")
	public WebElement brStatusdrp;

	@FindBy(xpath = "//*[@id='brStatusSearch']/div/div/div[2]/input")
	public WebElement brStatusDrpInput;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
	public WebElement brStatus;

	@FindBy(xpath = "//*[@id='assignToPanel']/div/div/div[2]/input")
	public WebElement assignTodrp;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[10]/div/div/span")
	public WebElement assignToVal;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/span")
	public WebElement offer;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
	public WebElement succesMsg;

	@FindBy(xpath = "//*[@id='textareavalue']/span/i-feather")
	public WebElement attachClip;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/cabs-add-file-button/button")
	public WebElement addFileBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/primary-button/button")
	public WebElement doneBtn;

	@FindBy(xpath = "//*[@id='textareavalue']/span/button")
	public WebElement attachCount;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[2]/button")
	public WebElement attachCountIncome;

	@FindBy(xpath = "//*[@id='income-tab']/div[2]/button")
	public WebElement attachCountIncomeMisc;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/div[2]/button")
	public WebElement attachCountHistory;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/div[2]/button")
	public WebElement attachCountHistoryMisc;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/a")
	public WebElement fileName;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div")
	public WebElement fileType;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[4]/div/div")
	public WebElement fileSize;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[5]/div/div")
	public WebElement dateTime;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div")
	public WebElement uploadedBy;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-checkbox/label/span")
	public WebElement rejectCheck;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-checkbox/label/span")
	public WebElement rejectCheckII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/div[2]/plain-button/button")
	public WebElement rejectCancel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[4]/a")
	public WebElement preAudit;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[3]/a")
	public WebElement postAudit;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[1]/h4/span[2]/span")
	public WebElement moreSize;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[1]/h4/span")
	public WebElement titleCheck;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/div[1]/div/div/div/cabs-textarea/div")
	public WebElement rejectReason;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/div[2]/action-button/button")
	public WebElement rejectOK;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/i-feather")
	public WebElement commentReject;

	@FindBy(xpath = "/html/body/ngb-modal-window[2]/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement warningYes;

	@FindBy(xpath = "/html/body/ngb-modal-window[2]/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	public WebElement warningNo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[1]/button/span/i-feather")
	public WebElement intNotesClose;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-0\"]")
	public WebElement allwType0;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-1\"]")
	public WebElement allwType1;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-2\"]")
	public WebElement allwType2;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-3\"]")
	public WebElement allwType3;

	@FindBy(xpath = "//*[@id=\"allowanceType\"]/div/div/div[2]/input")
	public WebElement allwTypeBox;

	@FindBy(xpath = "//*[@id=\"allowanceType\"]/div/div/div[3]/input")
	public WebElement allwTypeBoxAfterSel;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[2]/input")
	public WebElement perf1Box;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[3]/input")
	public WebElement perf1BoxAfterSel;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-0\"]")
	public WebElement p1AlwT0;

	@FindBy(xpath = "//*[@id='ta-performanceCode1-0']")
	public WebElement p1AlwT0II;

	// @FindBy(id="ta-performanceCode1-0")
	// public WebElement p1AlwT0II;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-1\"]")
	public WebElement p1AlwT1;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-2\"]")
	public WebElement p1AlwT2;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-3\"]")
	public WebElement p1AlwT3;

	@FindBy(xpath = "//*[@id='performanceCode1']/div/span")
	public WebElement perf2BoxII;

	@FindBy(xpath = "//*[@id='performanceCode2']/div/span")
	public WebElement perf2BoxIII;

	@FindBy(xpath = "//*[@id=\"performanceCode2\"]")
	public WebElement perf2Box;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-0\"]")
	public WebElement p2AlwT0;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-1\"]")
	public WebElement p2AlwT1;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-2\"]")
	public WebElement p2AlwT2;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-3\"]")
	public WebElement p2AlwT3;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-4\"]")
	public WebElement p2AlwT4;

	@FindBy(xpath = "//*[@id='allow-tab']/div[1]/i-feather")
	public WebElement alwncInfoExpand;

	@FindBy(xpath = "//*[@id='allowanceCollapse']/div/div/div[3]/div/div[2]/div[4]/div/overlap-dropdown/ng-select/div/div/div[3]")
	public WebElement overlapDrp;

	@FindBy(xpath = "//*[@id='heading_10003280']/span")
	public WebElement overlapVal;

	// @FindBy(xpath="//*[@id='ngb-panel-4']/div/table/tbody/tr[2]/td[4]")
	// @FindBy(xpath="/html/body/app-root/cabs-container/div/div[2]/div[2]/br-details/div/cabs-allowance-info/form/section/div/div[2]/div/div/div[3]/div/div[2]/div[4]/div/overlap-dropdown/ng-select/ng-dropdown-panel/div/div[2]/div/ngb-accordion/div[109]/div[2]/div/table/tbody/tr[2]/td[4]")
	@FindBy(name = "items_name")
	public WebElement overlapItem;

	// @FindBy(xpath="//*[@id='ngb-panel-4']/div/table/tbody/tr[3]/td[4]")
	@FindBy(name = "dates_name")
	public WebElement overlapDate;

	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;

	@FindBy(xpath = "//*[@id='undefined']/input")
	public WebElement itemDetailsAmnt;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[2]/div[5]/div")
	public WebElement fromDate;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[3]/div[4]/div")
	public WebElement toDate;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement fromCal;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[3]/div[5]/div")
	public WebElement fromCalopen;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/input")
	public WebElement billDateFrom;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement toCal;

	// @FindBy(xpath =
	// "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[6]/div[5]/div")
	// public WebElement toCalOpen;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[5]/div[4]/div")
	public WebElement toCalOpen;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[4]/div[1]/div")
	public WebElement toCalOpenII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/input")
	public WebElement billDateTo;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement ready;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[2]/i-feather")
	public WebElement clipIncome;

	@FindBy(xpath = "//*[@id='income-tab']/div[2]/i-feather")
	public WebElement clipIncomeMisc;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
	public WebElement incmSubmit;

	@FindBy(xpath = "//*[@id='allowance-history-tab']/div[1]/i-feather")
	public WebElement incHist;

	@FindBy(xpath = "//*[@id='misc-history-tab']/div[1]/i-feather ")
	public WebElement incHistMisc;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/div[2]/i-feather")
	public WebElement incHistClip;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/div[2]/i-feather")
	public WebElement incHistClipMisc;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[3]/div[1]/div")
	public WebElement fromDateFour;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[4]/div[5]/div")
	public WebElement toDateFifteen;

	@FindBy(xpath = "//*[@id=\"leadCIC\"]")
	public WebElement leadCIC;

//	public boolean bRTypeRetailFieldLeadCIC() throws BiffException, IOException {
//		LCIC = leadCIC.findElement(By.className("form-control"));
//		LCIC.click();
//		String file = new File(System.getProperty("user.dir"), "TestData.xls")
//				.getAbsolutePath();
//		// FileInputStream fi = new
//		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");
//
//		FileInputStream fi = new FileInputStream(file);
//
//		Workbook w = Workbook.getWorkbook(fi);
//		Sheet s = w.getSheet(5);
//		String s1 = null;
//		try {
//			for (int i = 2; i < s.getRows(); i++) {
//				// Read data from excel sheet
//				s1 = s.getCell(7, i).getContents();
//
//				Thread.sleep(3000);
//
//				LCIC.sendKeys(s1);
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//
//		if (LCIC.getAttribute("value").equals(s1)) {
//			return true;
//		} else {
//			return false;
//		}
//	}

	public String perf2BoxIISend(WebDriver Driver) {

		perf2BoxII.sendKeys("A");
		// perf2BoxII.sendKeys(Keys.ENTER);

		return null;
	}

	public String incHistClipMisc(WebDriver Driver) {

		incHistClipMisc.click();
		return null;
	}

	public String incHistClipClk(WebDriver Driver) {

		incHistClip.click();
		return null;
	}

	public String incHistClk(WebDriver Driver) {

		incHist.click();
		return null;
	}

	public String incHistMiscClk(WebDriver Driver) {

		incHistMisc.click();
		return null;
	}

	public String incmSubmitClk(WebDriver Driver) {

		incmSubmit.click();
		return null;
	}

	public String clipIncomeClk(WebDriver Driver) {

		clipIncome.click();
		return null;
	}

	public String clipIncomeMiscClk(WebDriver Driver) {

		clipIncomeMisc.click();
		return null;
	}

	public String readyClk(WebDriver Driver) {

		ready.click();
		return null;
	}

	public boolean bRTypeRetailFieldStartDt() throws ParseException {

		fromCal.click();

		fromCalopen.click();

		if (billDateFrom.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldStartDtOne() throws ParseException {

		fromCal.click();
		fromDate.click();

		if (billDateFrom.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldEndDtSeven() {

		toCal.click();
		toDate.click();

		if (billDateTo.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldStartDtFour() throws ParseException {

		fromCal.click();
		fromDateFour.click();

		if (billDateFrom.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldEndDtFifteen() {

		toCal.click();
		toDateFifteen.click();

		if (billDateTo.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldEndDt() {

		toCal.click();
		toCalOpen.click();

		if (billDateTo.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldEndDtII() {

		toCal.click();
		toCalOpenII.click();

		if (billDateTo.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public String titleCheckTxt(WebDriver Driver) {

		return titleCheck.getText();

	}

	public String overlapDate(WebDriver Driver) {

		return overlapDate.getText();

	}

	public String overlapItemTxt(WebDriver Driver) {

		return overlapItem.getText();

	}

	public String overlapDrpClk(WebDriver Driver) {

		overlapDrp.click();
		return null;
	}

	public String alwncInfoExpandClk(WebDriver Driver) {

		alwncInfoExpand.click();
		return null;
	}

	public String intNotesCloseClk(WebDriver Driver) {

		intNotesClose.click();
		return null;
	}

	public String warningNoClk(WebDriver Driver) {

		warningNo.click();
		return null;
	}

	public String warningYesClk(WebDriver Driver) {

		warningYes.click();
		return null;
	}

	public String rejectOKClk(WebDriver Driver) {

		rejectOK.click();
		return null;
	}

	public String rejectReasonn(WebDriver Driver) {

		rejectReason.sendKeys("Test Automation Reason");
		return null;
	}

	public String moreSizeTxt(WebDriver Driver) {

		return moreSize.getText();
	}

	public String preAuditClk(WebDriver Driver) {

		preAudit.click();
		return null;
	}

	public String postAuditClk(WebDriver Driver) {

		postAudit.click();
		return null;
	}

	public String rejectCancelClk(WebDriver Driver) {

		rejectCancel.click();
		return null;
	}

	public String rejectCheckClkII(WebDriver Driver) {

		rejectCheckII.click();
		return null;
	}

	public String rejectCheckClk(WebDriver Driver) {

		rejectCheck.click();
		return null;
	}

	public String uploadedByy(WebDriver Driver) {

		return uploadedBy.getText();
	}

	public String dateTimee(WebDriver Driver) {

		return dateTime.getText();
	}

	public String fileSizee(WebDriver Driver) {

		return fileSize.getText();
	}

	public String fileTypee(WebDriver Driver) {

		return fileType.getText();
	}

	public String fileNamee(WebDriver Driver) {

		return fileName.getText();
	}

	public String attachCountt(WebDriver Driver) {

		return attachCount.getText();
	}

	public String attachCountIncomeTxt(WebDriver Driver) {

		return attachCountIncome.getText();
	}

	public String attachCountIncomeMiscTxt(WebDriver Driver) {

		return attachCountIncomeMisc.getText();
	}

	public String attachCountIncomeHisTxt(WebDriver Driver) {

		return attachCountHistory.getText();
	}

	public String attachCountHistoryMiscTxt(WebDriver Driver) {

		return attachCountHistoryMisc.getText();
	}

	public String doneBtnn(WebDriver Driver) throws InterruptedException {

		doneBtn.click();

		return null;
	}

	public String addFileBtnn(WebDriver Driver) throws InterruptedException {

		addFileBtn.click();
		Thread.sleep(3000);

		// String file = new File(System.getProperty("user.dir"),
		// "txt.txt").getAbsolutePath();
		// addFileBtn.sendKeys(file);

		addFileBtn
				.sendKeys("C:\\Users\\u61282\\Downloads\\SC-Web-CABSAutomation_v0.2\\txt.txt");

		Thread.sleep(5000);
		return null;
	}

	public String attachClipClk(WebDriver Driver) throws InterruptedException {

		attachClip.click();

		return null;
	}

	public String offerTxt(WebDriver Driver) {

		return offer.getText();
	}

	public String assignToVall(WebDriver Driver) {

		return assignToVal.getText();
	}

	public String assignTodrpClk(WebDriver Driver) {
		assignTodrp.sendKeys("Ajith");
		assignTodrp.sendKeys(Keys.ENTER);
		searchApply.click();
		return null;
	}

	public String brStatuss(WebDriver Driver) {

		return brStatus.getText();
	}

	public String brStatusDrpInputt(WebDriver Driver) {

		brStatusDrpInput.sendKeys("Analyze Later");
		brStatusDrpInput.sendKeys(Keys.ENTER);
		searchApply.click();
		return null;
	}

	public String brStatusDrpInputt2(WebDriver Driver) {

		brStatusDrpInput.sendKeys("New");
		brStatusDrpInput.sendKeys(Keys.ENTER);
		searchApply.click();
		return null;
	}

	public String brStatusDrpInputt3(WebDriver Driver) {

		brStatusDrpInput.sendKeys("Ended");
		brStatusDrpInput.sendKeys(Keys.ENTER);
		searchApply.click();
		return null;
	}

	public String brStatusDrpInputt4(WebDriver Driver) {

		brStatusDrpInput.sendKeys("Ready for Income");
		brStatusDrpInput.sendKeys(Keys.ENTER);
		searchApply.click();
		return null;
	}

	public String brStatusDrpInputt5(WebDriver Driver) {

		brStatusDrpInput.sendKeys("Completed");
		brStatusDrpInput.sendKeys(Keys.ENTER);
		searchApply.click();
		return null;
	}

	public String brStatusdrpp(WebDriver Driver) {

		brStatusdrp.click();
		return null;
	}

	public String blngNameFirstTxt(WebDriver Driver) {

		return blngNameFirst.getText();
	}

	public String blngNameClear(WebDriver Driver) {

		blngName.clear();
		return null;
	}

	public String clearAll(WebDriver Driver) {

		clearAllBtn.click();
		return null;
	}

	public String blngNameInput(WebDriver Driver) {

		blngName.findElement(By.className("form-control")).sendKeys("JET*");
		return null;
	}

	public String ofrNbrInput(WebDriver Driver) {

		ofrNbr.findElement(By.className("form-control")).sendKeys("123*");
		return null;
	}

	public String searchApplyClk(WebDriver Driver) {

		searchApply.click();
		return null;

	}

	public String blngNameeCase1(WebDriver Driver) {

		blngName.findElement(By.className("form-control")).sendKeys("a*");

		// blngName.sendKeys("a*");
		searchApply.click();

		return null;
	}

	public String blngNameeCase2(WebDriver Driver) {

		blngName.findElement(By.className("form-control")).sendKeys("*a");
		searchApply.click();

		return null;
	}

	public String blngNameeCase3(WebDriver Driver) {

		blngName.findElement(By.className("form-control")).sendKeys("a*c");
		// blngName.sendKeys("a*c");
		searchApply.click();

		return null;
	}

	public String searchFirstItemm(WebDriver Driver) {

		return searchFirstItem.getText();
	}

	public String searchFirstItemClk(WebDriver Driver) {

		searchFirstItem.click();
		return null;
	}

	public String noDataa(WebDriver Driver) {

		return noDataTxt.getText();
	}

	public Boolean allwTP1P2() throws InterruptedException {

		allwType0.click();
		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(2500);

		p1AlwT0.click();
		Thread.sleep(3000);

		return null;
	}

	public Boolean allwTP1P2COGS() throws InterruptedException {

		allwType0.click();
		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(2500);

		p1AlwT1.click();
		Thread.sleep(3000);

		return null;
	}

	public Boolean allwTP1P2II() throws InterruptedException {

		allwType1.click();
		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(2500);

		p1AlwT0.click();
		Thread.sleep(3000);

		return null;
	}

	public Boolean allwTP1P2III() throws InterruptedException {

		// C Selected
		allwType2.click();

		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(3000);

		return null;
	}

	public Boolean allwTP1P2AA() throws InterruptedException {

		// A Selected
		allwType3.click();

		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(3000);

		return null;
	}

	public Boolean allwTP1P2IV() throws InterruptedException {

		allwType0.click();
		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(2500);

		p1AlwT3.click();
		Thread.sleep(3000);

		return null;
	}

	public Boolean allwTP1P2V() throws InterruptedException {

		allwType0.click();
		Thread.sleep(4000);
		perf1Box.click();
		Thread.sleep(2500);

		p1AlwT1.click();
		Thread.sleep(3000);

		return null;
	}

	public String elmntIntract() {
		deductnum.findElement(By.className("form-control")).sendKeys("510");
		return null;
	}

	public String itemDetailsAmntt(WebDriver Driver)
			throws InterruptedException {
		itemDetailsAmnt.sendKeys("1");
		itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		Thread.sleep(3000);
		save.click();
		Thread.sleep(3000);
		System.out.println("Clicked on Save button");
		 
		return null;
	}
	
		public String itemDetailsAmnttII(WebDriver Driver)
			throws InterruptedException {
		itemDetailsAmnt.sendKeys("1");
	 	//itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		Thread.sleep(3000);
		save.click();
		Thread.sleep(36000);
		System.out.println("Clicked on Save button");
		 
		return null;
	}

	public GenericFactoryVIII(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

}
