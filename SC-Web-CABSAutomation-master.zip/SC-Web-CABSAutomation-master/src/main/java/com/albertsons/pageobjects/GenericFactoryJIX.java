package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class GenericFactoryJIX {

	WebDriver Driver;
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
	public WebElement createBillrcrd;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-0\"]")
	public WebElement allwType0;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[2]/input")
	public WebElement perf1Box;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-0\"]")
	public WebElement p1AlwT0;

	@FindBy(xpath = "//*[@id=\"deductInvoiceNumber\"]")
	public WebElement dedInv;

	@FindBy(xpath = "//*[@id=\"undefined\"]/input")
	public WebElement amt;

	@FindBy(xpath = "//*[@id=\"flatAmount\"]/input")
	public WebElement fAmt;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;

	@FindBy(xpath = "//*[@id=\"allow-tab\"]/div[1]/i-feather")
	public WebElement allowTab;

	@FindBy(xpath = "//*[@id=\"billingRecordId\"]")
	public WebElement brId;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[1]/a")
	public WebElement analysis_wrklist;

	@FindBy(xpath = "//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[4]/div/overlap-dropdown/ng-select/div/div/div[3]")
	public WebElement overlap;

	@FindBy(xpath = "//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[4]/div/overlap-dropdown/ng-select")
	public WebElement overlapCnt;

	@FindBy(name = "items_name")
	public WebElement ovpItem;

	@FindBy(name = "dates_name")
	public WebElement ovpDate;

	@FindBy(xpath = "//*[@id=\"item-tab\"]/div[1]/i-feather")
	public WebElement item;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[5]/div[2]/div")
	public WebElement itemDtEdt;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-datepicker/form")
	public WebElement itemCal1;

	@FindBy(xpath = "//*[@id=\"allowanceType\"]")
	public WebElement alwTyp;

	@FindBy(xpath = "//*[@id=\"ta-alwncTypeValue-2\"]")
	public WebElement alwTypC;

	@FindBy(xpath = "//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[5]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement perfFmCal;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[3]/div[7]/div")
	public WebElement perfFmDt;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[4]/div[2]/div")
	public WebElement perfFmDtII;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[1]/div/i-feather")
	public WebElement itmExp;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[13]/div/i-feather")
	public WebElement itmDel;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[13]/div/i-feather")
	public WebElement itmDelII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement itmDelYs;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[1]/div[3]/cabs-textbox")
	public WebElement itmAddtxtbx;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[1]/div[2]/div[2]/label")
	public WebElement itmAddUPC;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[1]/div[4]/primary-button/button")
	public WebElement itmAddItembutton;

	@FindBy(xpath = "//*[@id=\"brStatus\"]")
	public WebElement bRSts;

	@FindBy(xpath = "//*[@id=\"ta-brStatus-3\"]")
	public WebElement bRStsEnd;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[1]/h6/span")
	public WebElement ovpdtlmodal;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/thead/tr/th[1]")
	public WebElement ovphdrItem;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/thead/tr/th[2]")
	public WebElement ovphdrBR1;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/thead/tr/th[3]")
	public WebElement ovphdrBR2;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/thead/tr/th[4]")
	public WebElement ovlpDys;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/tbody/tr[1]/td[1]")
	public WebElement ovlpItms;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/tbody/tr[1]/td[2]")
	public WebElement ovlpCurntBRDt1;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/tbody/tr[1]/td[3]")
	public WebElement ovlpCurntBRDt2;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/tbody/tr[1]/td[4]")
	public WebElement ovlpOldBRDt1;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/tbody/tr[1]/td[5]")
	public WebElement ovlpOldBRDt2;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form")
	public WebElement itmStDt;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-datepicker/form")
	public WebElement itmEdDt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[2]/div/table/tbody/tr[1]/td[6]")
	public WebElement ovpdys;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-overlap-details/div[3]/label")
	public WebElement maxOvpdys;

	@FindBy(xpath = "//*[@id=\"search\"]/li/a")
	public WebElement searchBR;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[1]")
	public WebElement searchExp;

	@FindBy(xpath = "//*[@id=\"offerNumber\"]")
	public WebElement searchOffr;

	@FindBy(xpath = "//*[@id=\"billRecId\"]")
	public WebElement searchBRId;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/action-button/button")
	public WebElement apply;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement br;

	@FindBy(xpath = "//*[@id=\"textareavalue\"]")
	public WebElement iNotes;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	public WebElement warnMsgNo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement warnMsgYs;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-search-br/div/div/div[1]/nav/label")
	public WebElement srchBRlabl;

	// @FindBy(xpath = "//*[@id='accLookUpType']/div/span")
	@FindBy(xpath = "//*[@id=\"accLookUpType\"]/div/span")
	public WebElement retDivDrp;

	@FindBy(id = "ta-accLookUpType-0")
	public WebElement retDiv;

	@FindBy(xpath = "//*[@id='accLookUpValue']/div/span")
	public WebElement retDivVal;

	@FindBy(id = "ta-accLookUpValue-1")
	public WebElement retValu;

	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	public WebElement brSavebtn;

	@FindBy(xpath = "//*[@id='undefined']")
	public WebElement txtDescr;

	@FindBy(xpath = "//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[4]/div/overlap-dropdown/ng-select/div/div/div[2]")
	public WebElement overlapCntEnd;
	
	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[4]/a")
	public WebElement dialogWrklst;
	
	@FindBy(xpath = "//*[@id=\"dialog-tab\"]/div[4]/button")
	public WebElement addDialog;
	
	@FindBy(xpath = "//*[@id='subjectValue-0']/div/div/div[2]/input")
    WebElement subjectDrpMisc;

	@FindBy(id="ta-subjectValue-0")
    WebElement subjectVal;
	
	@FindBy(xpath = "//*[@id='assignableUsers-0']/div/div/div[2]/input")
    WebElement assignToDrpMisc;
	
	@FindBy(xpath = "//*[@id=\"ta-assignableUsers-0\"]")
    WebElement assignedUser;
	
    @FindBy(xpath = "//*[@id='notifiableUsers-0']/div/div/div[2]/input")
    WebElement notifyDrp;
    
    @FindBy(xpath = "//*[@id=\"ta-notifiableUsers-1\"]")
    WebElement notifiedUser;
    
    @FindBy(xpath = "//*[@id=\"reasonTxt-0\"]")
    WebElement reason;
    
    @FindBy(xpath = "//*[@id='saveBtn-0']/button")
    WebElement dialogSave;

    @FindBy(xpath = "//*[@id=\"worklist\"]/div/div/div[3]/input")
    WebElement wrklstFr;
    
    @FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
    WebElement warngYs;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")
    WebElement parntBr;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
    WebElement parntBrid;
    
 
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[3]/div/span[1]/label")
    WebElement Br;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[4]/div/span[1]/label")
    WebElement area;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/div/span[1]")
    WebElement areaval1;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/div/span[2]")
    WebElement areaval2;
  
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[5]/div/span[1]/label")
    WebElement catgry;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/span")
    WebElement subj;
    
  
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[6]/div/span[1]/label")
    WebElement asgnTo;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[7]/div/span[1]/label")
    WebElement ntfy;
    
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[8]/div/span[1]/label")
    WebElement initBy;
  
    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[9]/div/span[1]/label")
    WebElement rcntCmt;


	GenericFactoryJIX(WebDriver Driver) {

		this.Driver = Driver;
		PageFactory.initElements(Driver, this);

	}

	public void allwTP1P2() throws InterruptedException {

		allwType0.click();
		Thread.sleep(4000);
		perf1Box.click();
		p1AlwT0.click();

	}

	public String BillingID() {

		WebElement elem = brId.findElement(By.className("form-control"));
		return elem.getAttribute("value");

	}

	public String ovrlp(String BillId) {
		// System.out.println("//*[@id=\"title_"+BillId+"\"]/button/i-feather[1]");
		WebElement elem = Driver.findElement(By.xpath("//*[@id=\"title_" + BillId + "\"]/button/i-feather[1]"));

		elem.click();
		return null;
	}

	public String ovrlpItem() {

		return ovpItem.getText();

	}

	public String ovrlpDate() {

		return ovpDate.getText();

	}

	public String EditDate() throws InterruptedException {
		itemCal1.click();
		itemDtEdt.click();
		save.click();
		return null;

	}

	public String changePerfDt() throws InterruptedException {
		perfFmCal.click();
		perfFmDt.click();
		return null;

	}

	public String changePerfDtII() throws InterruptedException {
		perfFmCal.click();
		perfFmDtII.click();
		return null;

	}

	public String DelItm() throws InterruptedException {
		item.click();
		itmExp.click();
		itmDel.click();
		itmDelYs.click();
		return null;
	}

	public String AddItm() throws InterruptedException {
		item.click();
		WebElement itmAddtxtbox = itmAddtxtbx.findElement(By.className("form-control"));
		itmAddtxtbox.sendKeys("8010301");
		itmAddItembutton.click();
		Thread.sleep(15000);
		amt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		return null;

	}

	public String DelItmCIC() throws InterruptedException {
		item.click();
		itmDelII.click();
		itmDelYs.click();
		return null;
	}

	public String chgStus() throws InterruptedException {
		bRSts.click();
		bRStsEnd.click();
		return null;
	}

	public String ovpHdrItm() throws InterruptedException {
		return ovphdrItem.getText();

	}

	public String ovpHdrBR1() throws InterruptedException {
		return ovphdrBR1.getText();

	}

	public String ovpHdrBR2() throws InterruptedException {
		return ovphdrBR2.getText();

	}

	public String ovpHdrDays() throws InterruptedException {
		return ovlpDys.getText();

	}

	public String ovpBdyItm() throws InterruptedException {
		return ovlpItms.getText();

	}

	public String ItmDt1() throws InterruptedException {
		WebElement element = itmStDt.findElement(By.className("form-control"));
		return element.getAttribute("value");

	}

	public String ItmDt2() throws InterruptedException {
		WebElement element = itmEdDt.findElement(By.className("form-control"));
		return element.getAttribute("value");

	}

	public String ovpBdyCurrntBRDt1() throws InterruptedException {
		System.out.println("Current BR dt1 " + ovlpCurntBRDt1.getText());
		return ovlpCurntBRDt1.getText();

	}

	public String ovpBdyCurrntBRDt2() throws InterruptedException {
		System.out.println("Current BR dt2 " + ovlpCurntBRDt2.getText());
		return ovlpCurntBRDt2.getText();

	}

	public String ovpBdyOldBRDt1() throws InterruptedException {
		return ovlpOldBRDt1.getText();

	}

	public String ovpBdyOldBRDt2() throws InterruptedException {
		return ovlpOldBRDt2.getText();

	}

	public String ovpBdyovpdays() throws InterruptedException {
		return ovpdys.getText();

	}

	public String ovpBdyMaxdays() throws InterruptedException {
		System.out.println(maxOvpdys.getText());
		return maxOvpdys.getText();

	}

}
