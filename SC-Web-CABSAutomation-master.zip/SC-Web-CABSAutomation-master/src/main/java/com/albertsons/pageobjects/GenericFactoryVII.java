package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class GenericFactoryVII {
	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
	WebElement createBillrcrd;

			@FindBy(xpath="//*[@id='misc-history-tab']/div[1]/i-feather")
		//@FindBy(xpath="//*[@id='allowance-history-tab']/div[1]/i-feather")
	// @FindBy(xpath="//*[@id='misc-history-tab']/div[1]/i-feather")
//	@FindBy(xpath = "//*[@id='misc-history-tab']/div[1]")
	WebElement miscHistory;

	//@FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	@FindBy(xpath="//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/a")		
	//@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[1]")
	WebElement incmStatus;


	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[1]")
	WebElement incmStatusII;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[3]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[1]")
	WebElement incmStatusIII;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[4]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[1]")
	WebElement incmStatusIV;

	@FindBy(xpath = "//*[@id=\"ta-billingRecordType-2\"]")
	public WebElement nonAllwTyp;

	@FindBy(id = "ta-accountLookupValue-0")
	WebElement RetailDivVal3;

		@FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/plain-button/button")
	//@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/plain-button/button")
	WebElement incHistoryPaybackTxt;

	@FindBy(id = "amountId0")
	public WebElement incAmnt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[2]/div/div[1]/div[1]/ng-select/div/div/div[2]/input")
	public WebElement paybackAprover;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[2]/div/div[1]/div[1]/cabs-textbox/div/input")
	public WebElement paybackAproverII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[2]/div/div[1]/div[1]/label")
	public WebElement paybackLabel;

	@FindBy(xpath = "//*[@id='ta-approvers-10']")
	public WebElement aprover;

	@FindBy(xpath = "//*[@id='reason']/div/div")
	public WebElement reason;

	@FindBy(xpath = "//*[@id='acc2f2e2d759-2']/div")
	public WebElement reasonVal;

	@FindBy(xpath = "//*[@id='acc2f2e2d759-3']/div")
	public WebElement reasonVal2;

	@FindBy(xpath = "//*[@id='acc2f2e2d759-4']/div")
	public WebElement reasonVal3;

	@FindBy(xpath = "//*[@id='user']/div/div/div[2]/input")
	public WebElement users;

	@FindBy(xpath = "//*[@id='ab8cb73873a9-2']/div")
	public WebElement userVal;

	@FindBy(xpath = "//*[@id='ab8cb73873a9-3']/div")
	public WebElement userVal2;

	@FindBy(xpath = "//*[@id='ab8cb73873a9-4']/div")
	public WebElement userVal3;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[3]/action-button/button")
	public WebElement paybackSubmit;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[1]/h4/span[2]")
	public WebElement errMsg;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[1]/button/span/i-feather/svg/line[2]")
	public WebElement closeBtn;
	
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[1]/button/span/i-feather")
	public WebElement closeBtn2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[5]/a")
	public WebElement payBackWorklist;

	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")	
	//@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-payback-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement firstWrklist;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	public WebElement incHistory;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	public WebElement incHistoryAlwnc;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/plain-button/button")
	public WebElement viewPB;
				   
	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/plain-button/button")
	public WebElement viewPB2;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper['+ i + ']/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/plain-button/button")
	public WebElement viewOTLoop;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/plain-button/button")
	public WebElement viewPBRetail;

	@FindBy(xpath = "//*[@id='worklist']/div/div/div[3]/input")
	public WebElement worklistFor;

	@FindBy(id = "ta-worklist-6")
	public WebElement worklistVal;

	@FindBy(id = "ta-worklist-0")
	public WebElement worklistVal2;

	@FindBy(id = "ta-worklist-21")
	public WebElement worklistVal3;
	
	@FindBy(id="ta-worklist-24")
	public WebElement worklistval4;
	
	@FindBy(id="ta-worklist-23")
	public WebElement worklistval5;

	@FindBy(xpath = "//*[@id='reason']/div/div/div[2]/input")
	public WebElement reasonn;

	@FindBy(xpath = "//*[@id='user']/div/div/div[4]/input")
	public WebElement userTxtBox;

	@FindBy(xpath = "//*[@id='reason']/div/div/div[2]/span[1]")
	public WebElement reasonnII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[2]/div/div[2]/div[1]/label")
	public WebElement reasonLabel;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[2]/div/div[2]/div[2]/label")
	public WebElement userLabel;

	@FindBy(xpath = "//*[@id='user']/div/div/div[2]/span[1]")
	public WebElement userr;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[3]/primary-button/button")
	public WebElement approver;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-payback-dialog/div[3]/plain-button/button")
	public WebElement reject;

	@FindBy(id = "item-2")
	public WebElement item2;

	@FindBy(id = "item-1")
	public WebElement item1;

	@FindBy(id = "item-3")
	public WebElement item3;

	@FindBy(xpath = "//*[@id='reason']/div/div/div[3]/span[1]")
	public WebElement reasonItem;

	@FindBy(xpath = "//*[@id='user']/div/div/div[3]/span[1]")
	public WebElement userItem;

	@FindBy(xpath = "//*[@id='reason']/div/div/div[3]/span[2]")
	public WebElement reasonX;

	@FindBy(xpath = "//*[@id='reason']/div/div/div[2]/span[2]")
	public WebElement reasonX2;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[1]")
	public WebElement incStatus;

	@FindBy(xpath = "//*[@id='user']/div/div/div[2]/span[2]")
	public WebElement userX;

	@FindBy(xpath = "//*[@id='user']/div/div/div[3]/span[2]")
	public WebElement userX2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[3]/a")
	public WebElement OTLeft;
					 
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement firstItem;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	public WebElement IncmHistValue;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	public WebElement miscIncHistVal;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-ot-approve-reject/div[1]/button/span/i-feather")
	public WebElement close;

	@FindBy(xpath = "//*[@id='flatAmount']/input")
	public WebElement fltAmnt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement warningYes;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
	public WebElement incmSbmtBtn;
	
	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/action-button/button")
	public WebElement incmSbmtBtnII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-ot-approve-reject/div[2]/div[2]/primary-button/button")
	public WebElement approveBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-ot-approve-reject/div[2]/div[2]/plain-button/button")
	public WebElement rejectBtn;

	@FindBy(xpath = "//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/div/span/p[1]")
	public WebElement incmStatusAlwnce;

	@FindBy(id = "notesId")
	public WebElement notes;
	
	@FindBy(id="commentsId")
	public WebElement notesII;
	
	@FindBy(id="descId0")
	public WebElement descr;

	@FindBy(id = "/html/body/ngb-modal-window/div/div/cabs-ot-approve-reject/div[2]/div[1]/div/div/div/form/cabs-textarea/div")
	// @FindBy(xpath = "//*[@id='textareavalue']/br/textarea")
	public WebElement rejectReason;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-ot-approve-reject/div[2]/div[2]/action-button/button")
	public WebElement rejectReasonOkBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-ot-approve-reject/div[1]/h4/span[2]/span")
	public WebElement rejectErr;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/plain-button/button")
	// @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/plain-button/button")
	public WebElement cancelBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	public WebElement cancelBtnNo;

	@FindBy(xpath = "//*[@id='income-tab']/div[4]/button")
	public WebElement incomeBtnMisc;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/action-button/button")					  
	//@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[3]/action-button/button")
	public WebElement searchApply;

	@FindBy(id = "search")
	public WebElement search;
	
	@FindBy(xpath="//*[@id='assignToPanel']/div/div/div[2]/input")
	public WebElement assignTo;
	
	@FindBy(id="ta-assignTo-47")
	public WebElement assignToVal;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement brResult;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement readyBtn;
	
	@FindBy(id="billRecId")
	public WebElement searchBillId;
	
	@FindBy(xpath="//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[2]")
	public WebElement approvdBy;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[1]/i-feather")
	public WebElement advSearch;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement searchFirstItem;
	
	public String aprovdByTxt(WebDriver Driver){
				
		return approvdBy.getText();
	}
	
	public String searchBillIdd(WebDriver Driver) throws InterruptedException{
		
		//searchBillId.sendKeys("10002277");
		searchBillId.findElement(By.className("form-control")).sendKeys("10002277");
		
		return null;
	}
	
	public String billIDClear(WebDriver Driver){
		
		searchBillId.findElement(By.className("form-control")).clear();
		return null;
	}
	
	public String readyBtnn(WebDriver Driver) {

		readyBtn.click();
		return null;
	}
	
	public String brResultt(WebDriver Driver) {

		brResult.click();
		return null;
	}
	
	public String assignToo(WebDriver Driver) throws InterruptedException{
		
		assignTo.sendKeys("Test");
		Thread.sleep(2500);
		assignToVal.click();
		
		return null;
	}
	
	
	public String searchApplyy(WebDriver Driver) {

		searchApply.click();
		return null;
	}

	public String searchh(WebDriver Driver) {

		search.click();
		return null;
	}

	public String incomeBtnMiscc(WebDriver Driver) {

		incomeBtnMisc.click();
		return null;
	}

	public String cancelBtnNoo(WebDriver Driver) {

		cancelBtnNo.click();
		return null;
	}

	public String cancelBtnTxt(WebDriver Driver) {

		return cancelBtn.getText();
	}

	public String cancelBtnClk(WebDriver Driver) {

		cancelBtn.click();
		return null;
	}

	public String rejectErrTxt(WebDriver Driver) {

		return rejectErr.getText();
	}

	public String rejectReasonOkBtnn(WebDriver Driver) {

		rejectReasonOkBtn.click();
		return null;
	}

	public String rejectReasonn(WebDriver Driver) {

		rejectReason.findElement(By.className("form-control")).sendKeys(
				"Test Automation - Reject Reason");

		// rejectReason.sendKeys("Test Automation - Reject Reason");
		return null;
	}

	public String incmStatusAlwncee(WebDriver Driver) {

		return incmStatusAlwnce.getText();
	}

	public String rejectBtnn(WebDriver Driver) {

		rejectBtn.click();
		return null;
	}

	public String approveBtnn(WebDriver Driver) {

		approveBtn.click();
		return null;
	}

	public String incmSbmtBtnn(WebDriver Driver) {

		incmSbmtBtn.click();
		return null;
	}

	public String warningYess(WebDriver Driver) {

		warningYes.click();
		return null;
	}

public String fltAmntt(WebDriver Driver) throws InterruptedException {

		notesII.sendKeys("Test Automation");
		//notes.sendKeys("Test Automation");
		Thread.sleep(2500);
		
		descr.sendKeys("Test Automation Description");
		
		descr.sendKeys(Keys.TAB,Keys.TAB, "5400");
//		notesII.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
//				"5400", Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "10",
//				Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "10");

		// fltAmnt.sendKeys("5400");
		return null;
	}
	
	public String qtyAmnt(WebDriver Driver) {

		fltAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				"10", Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "10");

		return null;
	}

	// public String LOOP(WebDriver Driver) {
	//
	// for (int i = 1; i <= 20; i++) {
	// Driver.findElement(
	// By.xpath("//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper["
	// + i
	// +
	// "]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/plain-button/button"))
	// .click();
	//
	// }
	// return null;
	// }

	public String closee(WebDriver Driver) {

		close.click();
		return null;
	}

	public String miscIncHistValTxt(WebDriver Driver) {

		return miscIncHistVal.getText();
	}

	public String IncmHistValueTxt(WebDriver Driver) {

		return IncmHistValue.getText();
	}

	public String firstItemTxt(WebDriver Driver) {

		return firstItem.getText();

	}

	public String firstItemClk(WebDriver Driver) {

		firstItem.click();
		return null;
	}

	public String OTLeftClk(WebDriver Driver) {

		OTLeft.click();
		return null;
	}

	public String incStatuss(WebDriver Driver) {

		return incStatus.getText();
	}

	public String approverBtnClk(WebDriver Driver) {

		approver.click();
		return null;
	}

	public String reasonnTxt(WebDriver Driver) {

		return reasonn.getText();
	}

	public String userTxtBoxx(WebDriver Driver) {

		return userTxtBox.getText();
	}
	
	public String userTxtBox(WebDriver Driver) {

		return users.getText();
	}
	

	public String userTxtBoxxClk(WebDriver Driver) {

		userTxtBox.click();
		return null;
	}
	public String userTxtBoxxClk2(WebDriver Driver) {

		users.click();
		return null;
	}
	

	public String reasonXX(WebDriver Driver) throws InterruptedException {

		reasonX.click();
		System.out.println("Removed first item");
		Thread.sleep(1000);
		reasonX2.click();
		System.out.println("Removed second item");
		Thread.sleep(1000);
		reasonX2.click();
		Thread.sleep(1000);
		
		return null;
	}

	public String userXX(WebDriver Driver) throws InterruptedException {

		userX.click();
		Thread.sleep(2500);
		userX.click();
		Thread.sleep(2500);
		// userX2.click();
		// Thread.sleep(1000);

		return null;
	}

	public String item3(WebDriver Driver) {

		item3.click();
		return null;
	}

	public String item1(WebDriver Driver) {

		item1.click();
		return null;
	}

	public String userrClk(WebDriver Driver) {

		userr.click();
		return null;
	}

	public String reasonItemm(WebDriver Driver) {

		return reasonItem.getText();
	}

	public String item2(WebDriver Driver) {

		item2.click();
		return null;
	}

	public String reasonClk(WebDriver Driver) {

		reason.click();
		return null;
	}

	public String rejectTxt(WebDriver Driver) {

		return reject.getText();
	}

	public String rejectClk(WebDriver Driver) {

		reject.click();
		return null;
	}

	public String approverTxt(WebDriver Driver) {

		return approver.getText();
	}

	public String userr(WebDriver Driver) {

		// return userr.getAttribute("value");
		return userr.getText();
	}

	public String reasonnII(WebDriver Driver) {

		// return reasonnII.getAttribute("value");
		return reasonnII.getText();
	}

	public String paybackAproverrrII(WebDriver Driver) {

		return paybackAproverII.getAttribute("value");
	}

	public String usersss(WebDriver Driver) {

		return userLabel.getText();
	}
	
	public String usersssClk(WebDriver Driver) {

		 userLabel.click();
		 return null;
	}
	

	public String reasonnn(WebDriver Driver) {

		return reasonLabel.getText();
	}

	public String paybackLabell(WebDriver Driver) {

		return paybackLabel.getText();
	}

	public String worklistForr(WebDriver Driver) throws InterruptedException {

		worklistFor.sendKeys("Jenny");
		Thread.sleep(2500);
		worklistVal.click();

		return null;
	}

	public String worklistForrII(WebDriver Driver) throws InterruptedException {

		worklistFor.sendKeys("Ajith");
		Thread.sleep(2500);
		worklistVal2.click();

		return null;
	}

	public String worklistForrIII(WebDriver Driver) throws InterruptedException {

		worklistFor.sendKeys("Test");
		Thread.sleep(2500);
		worklistVal3.click();

		return null;
	}
	
	public String worklistForrIV(WebDriver Driver) throws InterruptedException {

		worklistFor.sendKeys("Test");
		Thread.sleep(2500);
		worklistval5.click();

		return null;
	}

	public String viewPBB(WebDriver Driver) {

		return viewPB.getText();
	}
	
	public String viewPBClk(WebDriver Driver) {

		 viewPB.click();
		 return null;
	}


	public String viewPB2(WebDriver Driver) {

		return viewPB2.getText();
	}

	public String viewPBRetailTxt(WebDriver Driver) {

		return viewPBRetail.getText();
	}

	public String viewOTBtnClk(WebDriver Driver) {

		viewPBRetail.click();
		return null;
	}

	public String viewPBRetailClk(WebDriver Driver) {

		viewPBRetail.click();
		return null;
	}

	public String viewPBBClk2(WebDriver Driver) {

		viewPB2.click();
		return null;
	}
 

	public String viewPBBClk(WebDriver Driver) {

		viewPB.click();
		return null;
	}

	public String incHistoryAlwncc(WebDriver Driver) {

		return incHistoryAlwnc.getText();
	}

	public String incHistoryy(WebDriver Driver) {

		return incHistory.getText();
	}

	public String incHistoryClk(WebDriver Driver) {

		 incHistory.click();
		 return null;
	}
	
	public String firstWrklistt(WebDriver Driver) {

		return firstWrklist.getText();
	}

	public String firstWrklisttClk(WebDriver Driver) {

		firstWrklist.click();
		return null;
	}

	public String payBackWorklistt(WebDriver Driver) {

		payBackWorklist.click();
		return null;
	}

	public String closeBtnn(WebDriver Driver) {

		closeBtn.click();
		return null;
	}
	
	public String closeBtnn2(WebDriver Driver) {

		closeBtn2.click();
		return null;
	}
	
	

	public String errMsgTxt(WebDriver Driver) {

		return errMsg.getText();
	}

	public String paybackSubmitt(WebDriver Driver) {

		paybackSubmit.click();
		return null;
	}

	public String userss(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		users.click();
		Thread.sleep(2000);
		userVal.click();
		return null;
	}

	public String userss2(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		userVal2.click();
		return null;
	}

	public String userss3(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		userVal3.click();
		return null;
	}

	public String reasonn(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		reason.click();
		Thread.sleep(2000);
		reasonVal.click();
		return null;
	}

	public String reasonn2(WebDriver Driver) throws InterruptedException {

		reasonVal2.click();
		return null;
	}

	public String reasonn3(WebDriver Driver) throws InterruptedException {

		reasonVal3.click();
		return null;
	}

	public String paybackAproverr(WebDriver Driver) throws InterruptedException {

		paybackAprover.sendKeys("test");
		Thread.sleep(2000);
		aprover.click();

		return null;
	}

	public String paybackAproverrII(WebDriver Driver)
			throws InterruptedException {

		Thread.sleep(2000);
		aprover.click();

		return null;
	}

	public String RetailDivVal33(WebDriver Driver) {

		RetailDivVal3.click();
		return null;
	}

	public String incHistoryPaybackTxtClk(WebDriver Driver) {

		incHistoryPaybackTxt.click();
		return null;
	}

	public String incHistoryPaybackTxtt(WebDriver Driver) {

		return incHistoryPaybackTxt.getText();

	}

	public String nonAllwdrp() {
		nonAllwTyp.click();
		return null;
	}

	public String incmStatuss(WebDriver Driver) {

		return incmStatus.getText();
	}

	public String incmStatussII(WebDriver Driver) {

		return incmStatusII.getText();
	}

	public String incmStatussIII(WebDriver Driver) {

		return incmStatusIII.getText();
	}

	public String incmStatussIV(WebDriver Driver) {

		return incmStatusIV.getText();
	}

	public String miscHistoryy(WebDriver Driver) {

		miscHistory.click();
		return null;
	}

	public String incAmntt(WebDriver Driver) throws InterruptedException {

		incAmnt.findElement(By.className("form-control")).sendKeys("4");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("5");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("0");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("0");
		Thread.sleep(2000);

		return null;
	}

	public String incAmnt(WebDriver Driver) throws InterruptedException {

		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		Thread.sleep(2000);

		return null;
	}

	public GenericFactoryVII(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

}
