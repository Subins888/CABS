package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GenericFactory11 {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;
	public WebElement LCIC;

	@FindBy(xpath = "//*[@id='dialog-tab']/div[4]/button")
	WebElement addDialog;

	@FindBy(xpath = "//*[@id='dialogCollapse']/div/div/div/div/div/trail-item/table/thead/tr/th[2]")
	WebElement subject;

	@FindBy(xpath = "//*[@id='dialog-tab']/div[3]/ul/li[1]/a")
	WebElement active;

	@FindBy(xpath = "//*[@id='dialog-tab']/div[3]/ul/li[2]/a")
	WebElement resolved;

	@FindBy(xpath = "//*[@id='dialog-tab']/div[3]/ul/li[3]/a")
	WebElement related;

	@FindBy(xpath = "//*[@id='dialog-tab']/div[3]/ul/li[4]/a")
	WebElement all;

	@FindBy(xpath = "//*[@id='dialogCollapse']/div/div/div/div/div/trail-item/table/tbody[1]/tr[1]/td[1]/div/i-feather")
	WebElement commentXpand;

	@FindBy(xpath = "//*[@id='cmtbtn_0']/button")
	WebElement addComment;

	@FindBy(xpath = "//*[@id='label']")
	WebElement commentLabel;

	@FindBy(id = "cmntTxt-0")
	WebElement commentText;

	@FindBy(xpath = "//*[@id='saveBtn-0']/button")
	WebElement commentSave;

	@FindBy(xpath = "//*[@id='subjectValue-0']/div/div/div[3]/input")
	WebElement subjectDrp;

	@FindBy(id = "subjectValue-0")
	WebElement subjectDrp2;

	@FindBy(xpath = "//*[@id='subjectValue-0']/div/div/div[2]/input")
	WebElement subjectDrpMisc;

	@FindBy(xpath = "//*[@id='statusValue-0']/div/div/div[3]")
	WebElement statusDrp;

	@FindBy(id = "statusValue-0")
	WebElement statusDrp2;

	@FindBy(xpath = "//*[@id='assignableUsers-0']/div/div/div[3]/input")
	WebElement assignToDrp;

	@FindBy(xpath = "//*[@id='assignableUsers-0']/div/div/div[2]/input")
	WebElement assignToDrpMisc;

	@FindBy(id = "assignableUsers-0")
	WebElement assignToDrp2;

	@FindBy(xpath = "//*[@id='notifiableUsers-0']/div/div/div[2]/input")
	WebElement notifyDrp;

	@FindBy(id = "notifiableUsers-0")
	WebElement notifyDrp2;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	WebElement warningYes;

	@FindBy(xpath = "//*[@id='accountLookupType']/div/div/div[2]")
	WebElement RetailDiv;

	@FindBy(xpath = "//*[@id='accLookUpType']/div/div/div[2]")
	WebElement accountLookUpDrpMisc;

	@FindBy(id = "ta-accLookUpType-0")
	WebElement retailDiv;

	@FindBy(xpath = "//*[@id='accLookUpValue']/div/div/div[2]/input")
	WebElement accountLukUpValue;

	@FindBy(id = "ta-accLookUpValue-1")
	WebElement accountLukUpValueVal;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
	WebElement incomeSubmit;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[2]/label")
	WebElement incomeMsgPopup;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	WebElement incomeMsgPopupNo;

	@FindBy(id = "notesId")
	public WebElement notesComment;

	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[3]/div/div[1]/div/div[2]/label")
	WebElement ARNum;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	WebElement brSave;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	WebElement brSaveMisc;

	@FindBy(id = "ta-subjectValue-0")
	WebElement subjectVal;

	@FindBy(id = "ta-statusList-0")
	WebElement StatusList;

	@FindBy(id = "ta-assignableUsers-0")
	WebElement assindUsers;

	@FindBy(id = "reasonTxt-0")
	WebElement reasonTxt;

	@FindBy(id = "ta-statusList-1")
	WebElement statusVal2;

	@FindBy(xpath = "//*[@id=\"allow-income-tab\"]/div[2]/i-feather")
	WebElement attachmentClip;

	@FindBy(xpath = "//*[@id=\"dialogCollapse\"]/div/div/div/div/div/trail-item/table/tbody/tr[1]/td[3]/i-feather")
	WebElement attachmentClipMisc;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/cabs-add-file-button/button")
	WebElement addFileBtn;

	@FindBy(xpath = "//*[@id=\"allow-income-tab\"]/div[2]/button")
	WebElement attachCount;

	@FindBy(xpath = "//*[@id=\"dialogCollapse\"]/div/div/div/div/div/trail-item/table/tbody/tr[1]/td[3]/button")
	WebElement attachCountMisc;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[1]/h4/span")
	WebElement incomeAttachmentsTitle;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")
	WebElement FileNameTxt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[3]/div/span[1]/label")
	WebElement FileTypeTxt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[4]/div/span[1]/label")
	WebElement FileSizeTxt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[5]/div/span[1]/label")
	WebElement dateTimeTxt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[6]/div/span[1]/label")
	WebElement uploadbyTxt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[7]/div/span[1]/label")
	WebElement rejectTxt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-checkbox/label/span")
	WebElement rejectCheckBox;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/div[1]/div/div/div/cabs-textarea/div")
	WebElement rejectTextArea;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/div[2]/div/div/div[2]/action-button/button")
	WebElement reasonOKBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[2]/div[2]/div/div/div[2]/plain-button/button")
	WebElement reasonCancelBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/cabs-attachment-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-checkbox/label/span")
	WebElement rejectIndication;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[1]/h4/span")
	WebElement rejectReasonTitle;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-add-attachments/div[1]/button/span/i-feather")
	WebElement reasonClose;

	@FindBy(xpath = "//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[3]/cabs-datepicker/form/div/div/input")
	// @FindBy(xpath="//*[@id=\\\"allowanceCollapse\\\"]/div/div/div[1]/div[3]/cabs-datepicker/form/div/div/input")
	WebElement dateTxtFrm;

	@FindBy(xpath = "//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[4]/cabs-datepicker/form/div/div/input")
	WebElement dateTxtTo;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form/div/div/input")
	WebElement dateTxtFrm2;

	@FindBy(xpath = "//*[@id=\"incomeCollapse\"]/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-datepicker/form/div/div/input")
	WebElement dateTxtTo2;
	
	@FindBy(xpath="/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[3]/div[4]/div")
	WebElement disabledDate1;
	
	@FindBy(xpath="/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[5]/div[5]/div")
	WebElement disabledDate2;
	
	@FindBy(xpath="//*[@id='assignToPanel']/div/div/div[2]/input")
	WebElement assignTo;
	
	@FindBy(id="ta-assignTo-62")
	WebElement assignToVal;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[10]/div/div/span")
	WebElement assignToSearchVal;
	
	 @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[3]/action-button/button")
	WebElement searchApply;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-footer/div/datatable-pager/ul/li[4]/a")
	WebElement paginationSearch;
	 
	 @FindBy(xpath="//*[@id='accountLookupType']/div/div/div[2]/input")
	 WebElement accountLookupSearch;
	 
	 @FindBy(id="ta-accountLookupType-1")
	 WebElement accountLookupSearchVal;
	 
	 @FindBy(xpath="//*[@id='accountLookupType']/div/div/div[3]/input")
	 WebElement accountLookupDropdown;
	 
	 @FindBy(xpath="//*[@id='flatAmountFrom']/div/span")
	 WebElement dollarFlatAmnt;
	
	public String waitforAddFile(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(addFileBtn));
		return null;
	}

	public String notesFlatAmntClear(WebDriver Driver) {

		notesComment.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.CLEAR, "10", Keys.TAB, Keys.TAB,
				Keys.TAB, Keys.TAB, "10");

		return null;
	}

	public String elmntIntract(WebDriver Driver) {
		deductnum.findElement(By.className("form-control")).sendKeys("11");
		return null;
	}

	public String elmntIntractAR(WebDriver Driver) {
		deductnum.findElement(By.className("form-control")).sendKeys("10056");

		return null;
	}

	public String elmntIntractInvalid(WebDriver Driver) {
		deductnum.findElement(By.className("form-control")).clear();
		deductnum.findElement(By.className("form-control")).sendKeys("1214");
		return null;
	}

	public GenericFactory11(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

}
