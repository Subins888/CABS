package com.albertsons.pageobjects;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import bsh.ParseException;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsJSSprint3 extends ExtendBaseClass  {
	
    WebDriver Driver;
    GenericFactory pageFact;
    GenericFactoryJSSprint3 pageFactJS3; 
    PageObjects PO = new PageObjects(Driver);
    PageObjectsJSSprint3 POJS3;
    String extentReportImage208PO_2;
    
    public PageObjectsJSSprint3(WebDriver Driver) {
          this.Driver = Driver;
          PageFactory.initElements(Driver, this);
    }
    public File aftermthd() throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}
    public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}
    
    public String wait_forSave(WebDriver Driver) {

        WebDriverWait wait = new WebDriverWait(Driver, 60);
  wait.until(ExpectedConditions.elementToBeClickable(pageFactJS3.AlwSaveBtn));            
        return null;
  }     

    public String  AlwactionBr(WebDriver Driver) throws IOException, InterruptedException, ParseException{                      
        if (pageFactJS3.AlwSavebtntxt(Driver).equals("Save")) {
              System.out.println("PASS:  Save button displayed");
              extentTest.log(LogStatus.INFO, "Save button displayed");
        } else {
              System.out.println("FAIL:  Save button not displayed");
              extentTest.log(LogStatus.FAIL, "Save button not displayed");
        }
        Thread.sleep(5000);
        if (pageFactJS3.AlwReadybtntxt(Driver).equals("Ready")) {
              System.out.println("PASS:  Ready button displayed");
              extentTest.log(LogStatus.INFO, "Ready button displayed");
        } else {
              System.out.println("FAIL:  Ready button not displayed");
              extentTest.log(LogStatus.FAIL, "Ready button not displayed");
        }
    Thread.sleep(5000);
    if (pageFactJS3.AlwCnclbtntxt(Driver).equals("Cancel")) {
              System.out.println("PASS:  Cancel button displayed");
              extentTest.log(LogStatus.INFO, "Cancel button displayed");
        } else {
              System.out.println("FAIL:  Cancel button not displayed");
              extentTest.log(LogStatus.FAIL, "Cancel button not displayed");
        }
        return null;            
}

    public String  ChckAlwactionBr(WebDriver Driver) throws IOException, InterruptedException, ParseException{
        Actions action = new Actions(Driver);
        action.moveToElement(pageFactJS3.AlwIncBtn).perform();;
       if (pageFactJS3.AlwActBr.isDisplayed()) {
             System.out.println("PASS:  Action Bar displayed");
             extentTest.log(LogStatus.INFO, "Action Bar displayed");
       } else {
             System.out.println("FAIL:  Action Bar not displayed");
             extentTest.log(LogStatus.FAIL, "Action Bar not displayed");
       }

       return null;
}
 
    //-------------------------------------------------------
    public String ChkRtSaveMsg(WebDriver Driver) throws IOException, InterruptedException, ParseException{
              Thread.sleep(5000);
              pageFactJS3.RtSave(Driver);  
                             return null;
              
    }
       
    public String ChkRtSaveMsgVal(WebDriver Driver) throws IOException, InterruptedException, ParseException{
            
    	String werr = pageFactJS3.RtSaveError(Driver);
              if (pageFactJS3.RtSaveError(Driver).equals(":  Deduct/Invoice Number,Billing Name is not entered")){

            	  
            System.out.println("PASS:  Correct error message is displayed" + werr);
            extentTest.log(LogStatus.INFO, "Correct Error message displayed" + werr);
      } else {
           System.out.println("FAIL:  Wrong Error message" + werr);
            extentTest.log(LogStatus.FAIL, "Wrong Error message" + werr);
      }
        
                             return null;
              
    }
    
    public String waitforoffsetLoad(WebDriver Driver) {

       WebDriverWait wait = new WebDriverWait(Driver, 60);
      wait.until(ExpectedConditions.elementToBeSelected(pageFactJS3.RtOffset));     
        return null;
  }  
  
    public String VerifyAssignedToValue(WebDriver Driver) throws  BiffException, IOException, InterruptedException{
    	
    	pageFactJS3.SelectAssinTo(Driver);
    	Thread.sleep(2000);
    	//pageFactJS3.asgntoo(Driver);
    	pageFactJS3.asgntoo2(Driver);
    	String uss = pageFactJS3.asgntoo(Driver);
    	System.out.println("asign to user is "  + uss );
              String file = new File(System.getProperty("user.dir"),"TestData.xls").getAbsolutePath();
              FileInputStream fi = new FileInputStream(file);
              Workbook w = Workbook.getWorkbook(fi);
              Sheet s = w.getSheet(2);
                             String s1 = null;
                             try {
                                           for (int i = 1; i < s.getRows(); i++) {
                                           // Read data from excel sheet
                                           s1 = s.getCell(4, i).getContents();
                                           
                                           Thread.sleep(3000);
                                                                                      
                                                                                                                    }
                                           } catch (Exception e) {
                                           System.out.println(e);
                                           }
                             System.out.println("Userid" +s1);
     
      //    if (pageFactJS3.AssignedToVal(Driver).equals(s1)) {
                             if (pageFactJS3.asgntoo(Driver).equals(s1)) {
          System.out.println("PASS:  Assigned to User same as Logged in user");
          extentTest.log(LogStatus.INFO, "Assigned to User same as Logged in userd");
    } else {
          System.out.println("FAIL: Assigned to User is not same as Logged in user");
          extentTest.log(LogStatus.FAIL, "Assigned to User is not same as Logged in user");  
          
        
  }
              return null; 
              
              
    }
    
    public String RtSaveAssign(WebDriver Driver) {
                             pageFactJS3.elmntIntract();
                             return null;
                             
              }
    
    public String SelectAssign(WebDriver Driver) throws InterruptedException {
                             pageFactJS3.SelectAssinTo(Driver);
                             Thread.sleep(3000);
                           pageFactJS3.SelectAsignToo(Driver);
                             return null;
                             
              }
    
    public String RtDVrAssignedToValue(WebDriver Driver) throws  BiffException, IOException{
              String file = new File(System.getProperty("user.dir"),"TestData.xls").getAbsolutePath();   
              FileInputStream fi = new FileInputStream(file);
              Workbook w = Workbook.getWorkbook(fi);
              Sheet s = w.getSheet(0);
                             String s1 = null;
                             try {
                                           for (int i = 3; i < s.getRows(); i++) {
                                           // Read data from excel sheet
                                           s1 = s.getCell(0, i).getContents();
                                           
                                           Thread.sleep(3000);
                                                                                      
                                                                                                                    }
                                           } catch (Exception e) {
                                           System.out.println(e);
                                           }
                             System.out.println("Userid" +s1);
     
          if (pageFactJS3.RtAssignedToVal2(Driver).equals(s1)) {
          System.out.println("PASS:  Assigned to User is remaining same after save ");
          extentTest.log(LogStatus.INFO, "Assigned to User is remaining same after save");
    } else {
          System.out.println("FAIL: Assigned to User is not  remaining same after save");
          extentTest.log(LogStatus.FAIL, "Assigned to User is not  remaining same after save");  
          
        
  }
              return null; 
              
              
    }
    
    public String itemDetailsAmnt2(WebDriver Driver) {
                             pageFactJS3.itemDetailsAmnt2(Driver);
                             return null;
                             
              }
    
    
    public String sectNummbr(WebDriver Driver){
    	
    	pageFactJS3.sectNumm(Driver);
    	
    	return null;
    }
    
    
    public String assignToCheck(WebDriver Driver) throws InterruptedException{
    	
    	pageFactJS3.SelectAssinTo(Driver);
    	Thread.sleep(2000);
    	pageFactJS3.asgntoo2(Driver);
    	String uss = pageFactJS3.asgntoo(Driver);
    	System.out.println("Assign to user is "  + uss );
    	extentTest.log(LogStatus.INFO, "Assign to user is "  + uss);
    	return null;
    }
    
    public String brStatusChk(WebDriver Driver) throws InterruptedException{
    	
    	pageFact.elmntIntract();
		Thread.sleep(3000);
    	pageFactJS3.itemDetailsAmntt(Driver);
    	Thread.sleep(5000);
    	pageFactJS3.brStatusdrpclk(Driver);
		// pageFactAS3.brStatusdropp(Driver);
		Thread.sleep(3000);
		String brStatusvalue = pageFactJS3.newidd(Driver);
    	
		   if (pageFactJS3.newidd(Driver).equals("New")) {
		          System.out.println("BR Status displayed is " + brStatusvalue);
		          extentTest.log(LogStatus.INFO, "BR Status displayed is " + brStatusvalue);
		    } else {
		          System.out.println("BR Status displayed is " + brStatusvalue);
		          extentTest.log(LogStatus.FAIL, "BR Status displayed is " + brStatusvalue);  		        
		  }
		
		
    	return null;
    }
    
	public String getbilngRcrdId(WebDriver Driver){
		
	String testelem=	pageFact.blngRcrdidd();
		System.out
		.println("BR ID displaying after successful save is - "
				+ testelem);
		extentTest.log(LogStatus.INFO,
				"BR ID displaying after successful save is - "
						+ testelem);
		
		return null;
	}

	public String waitErrmsg2(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(pageFact.invalidOfseterr));
		return null;
	}
	
	public String succMsg(WebDriver Driver) throws IOException{
	waitErrmsg2(Driver);
	String SuccErrMsg = pageFact.invalidOfseterro();
	if (pageFact.invalidOfseterro().contains(
			"Billing Record has been saved")) {
		System.out
				.println("Offset number successfully saved, Success message showing is - "
						+ SuccErrMsg);
		extentTest.log(LogStatus.INFO,
				"Offset number successfully saved, Success message showing is - "
						+ SuccErrMsg);
	} else {
		System.out.println("Offset number validation failed");

		extentReportImage208PO_2 = System.getProperty("user.dir")
				+ "\\picture" + "\\extentReportImage208PO_2.png";
		File source = aftermthd();
		File destination = new File(extentReportImage208PO_2);
		FileUtils.copyFile(source, destination);
		extentTest.log(LogStatus.FAIL, "Offset number validation failed"
				+ extentTest.addScreenCapture(extentReportImage208PO_2));
	}
	
	return null;
	}
	
	
	public String ofsetNum(WebDriver Driver){
		
		pageFactJS3.ofsetNumAcnt(Driver);
		String Acnt=	pageFact.blngRcrdidd();
		System.out
		.println("Account number displaying is - "
				+ Acnt);
		extentTest.log(LogStatus.INFO,
				"Account number displaying is - "
						+ Acnt);
		
		pageFactJS3.ofsetNumFac(Driver);
		
		String Faclty=	pageFact.blngRcrdidd();
		System.out
		.println("Facility ID displaying is - "
				+ Faclty);
		extentTest.log(LogStatus.INFO,
				"Facility ID displaying is - "
						+ Faclty);
		pageFactJS3.ofsetNumSec(Driver);
		
		String Section=	pageFact.blngRcrdidd();
		System.out
		.println("Section ID displaying is - "
				+ Section);
		extentTest.log(LogStatus.INFO,
				"Section ID displaying is - "
						+ Section);
		
		return null;
	}
	
  @BeforeTest
  public void beforeTest(WebDriver Driver) {
      pageFactJS3 = new GenericFactoryJSSprint3(Driver); 
      pageFact=new GenericFactory(Driver); 
} 


}

