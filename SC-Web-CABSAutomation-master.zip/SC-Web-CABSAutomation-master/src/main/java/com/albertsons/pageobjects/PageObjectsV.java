package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * 
 * 
 * @author akuma58
 *
 */

public class PageObjectsV extends ExtendBaseClass {

	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactoryV pageFactV;
	GenericFactorySprint3 pageFactAS3;
	String extentReportImage1155PO_0,extentReportImage509PO_00,extentReportImage509PO_001;
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);

	public PageObjectsV(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public File aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}

	public String waitErrmsg2(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(pageFact.invalidOfseterr));
		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String camelChars(WebDriver Driver) {
		waitforbrtxt(Driver);

		return null;
	}

	public String succMsgClear(WebDriver Driver) throws IOException,
			InterruptedException {

		pageFactV.txtAreaa(Driver);
		Thread.sleep(5000);
		try {

			if (pageFact.invalidOfseterr.isDisplayed()) {

				// if (pageFact.invalidOfseterro().contains(
				// "Billing Record has been saved")) {
				System.out
						.println("BR status bar error message not clearing even after modifiying the billing record");

				extentReportImage1155PO_0 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage1155PO_0.png";
				File source = aftermthd(Driver);
				File destination = new File(extentReportImage1155PO_0);
				FileUtils.copyFile(source, destination);
				extentTest
						.log(LogStatus.FAIL,
								"BR status bar error message not clearing even after modifiying the billing record"
										+ extentTest
												.addScreenCapture(extentReportImage1155PO_0));
			} else {

				System.out
						.println("BR status bar error message got cleared successfully after modifiying the billing record");
				extentTest
						.log(LogStatus.INFO,
								"BR status bar error message got cleared successfully after modifiying the billing record");

			}
		} catch (Exception e) {
			// log exception
			System.out
					.println("BR status bar error message got cleared successfully after modifiying the billing record");
			extentTest
					.log(LogStatus.INFO,
							"BR status bar error message got cleared successfully after modifiying the billing record");

		}

		return null;
	}

	public String BrPageCamelChar() {

		if (pageFact.srchBillingrcrd().contains("SEARCH BILLING RECORD")) {
			System.out
					.println("PASS:  HOME Page successully displayed without any error");
			System.out.println("Test Case - CABS-313 Passed");
			extentTest.log(LogStatus.INFO,
					"Home page successfully displayed without any error");
			extentTest.log(LogStatus.INFO,
					"CABS-313 TestCase execution completed");
		} else {
			System.out.println("FAIL:  Home page not displayed");

		}
		return null;
	}

	public String labelChck(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);

		String bill = pageFactV.blngRcrdLabell();
		if (pageFactV.blngRcrdLabell().equals("Billing Record ID")) {
			System.out
					.println("Verified Billing Record Id label all the letters showing in Title case: "
							+ bill);

			extentTest.log(LogStatus.INFO,
					"Verified Billing Record Id label all the letters showing in Title case: "
							+ bill);

		} else {
			System.out
					.println("Verified Billing Record Id label all the letters not showing in Title case: "
							+ bill);
			extentTest.log(LogStatus.FAIL,
					"Verified Billing Record Id label all the letters not showing in Title case: "
							+ bill);
		}

		Thread.sleep(3000);
		String lastDate = pageFactV.lastDatee();
		if (pageFactV.lastDatee().equals("Last Update Date")) {
			System.out
					.println("Verified Last Update Date label all the letters showing in Title case: "
							+ lastDate);

			extentTest.log(LogStatus.INFO,
					"Verified Last Update Date label all the letters showing in Title case: "
							+ lastDate);

		} else {
			System.out
					.println("Verified Last Update Date label all the letters not showing in Title case: "
							+ lastDate);
			extentTest.log(LogStatus.FAIL,
					"Verified Last Update Date label all the letters not showing in Title case: "
							+ lastDate);
		}
		Thread.sleep(3000);
		String brStatus = pageFactV.brStatuss();
		if (pageFactV.brStatuss().equals("BR Status")) {
			System.out
					.println("Verified BR Status label all the letters showing in Title case: "
							+ brStatus);

			extentTest.log(LogStatus.INFO,
					"Verified BR Status label all the letters showing in Title case: "
							+ brStatus);

		} else {
			System.out
					.println("Verified BR Status label all the letters not showing in Title case: "
							+ brStatus);
			extentTest.log(LogStatus.FAIL,
					"Verified BR Status label all the letters not showing in Title case: "
							+ brStatus);
		}
		Thread.sleep(3000);
		String assignTo = pageFactV.assignToo();
		if (pageFactV.assignToo().equals("Assign To")) {
			System.out
					.println("Verified Assign To label all the letters showing in Title case: "
							+ assignTo);

			extentTest.log(LogStatus.INFO,
					"Verified Assign To label all the letters showing in Title case: "
							+ assignTo);

		} else {
			System.out
					.println("Verified Assign To label all the letters not showing in Title case: "
							+ assignTo);
			extentTest.log(LogStatus.FAIL,
					"Verified Assign To label all the letters not showing in Title case: "
							+ assignTo);
		}
		Thread.sleep(3000);
		String AcntLukUp = pageFactV.AcntLukUpp();
		if (pageFactV.AcntLukUpp().equals("Account Lookup Type")) {
			System.out
					.println("Verified Account Lookup Type label all the letters showing in Title case: "
							+ AcntLukUp);

			extentTest.log(LogStatus.INFO,
					"Verified Account Lookup Type label all the letters showing in Title case: "
							+ AcntLukUp);

		} else {
			System.out
					.println("Verified Account Lookup Type label all the letters not showing in Title case: "
							+ AcntLukUp);
			extentTest
					.log(LogStatus.FAIL,
							"Verified Account Lookup Type label all the letters not showing in Title case: "
									+ AcntLukUp);
		}
		Thread.sleep(3000);
		String ofsetNum = pageFactV.ofsetNumm();
		if (pageFactV.ofsetNumm().contains("Offset Num")) {
			System.out
					.println("Verified Offset Number label all the letters showing in Title case: "
							+ ofsetNum);

			extentTest.log(LogStatus.INFO,
					"Verified Offset Number label all the letters showing in Title case: "
							+ ofsetNum);

		} else {
			System.out
					.println("Verified Offset Number label all the letters not showing in Title case: "
							+ ofsetNum);
			extentTest.log(LogStatus.FAIL,
					"Verified Offset Number label all the letters not showing in Title case: "
							+ ofsetNum);
		}
		Thread.sleep(3000);
		String deductInv = pageFactV.deductInvv();
		if (pageFactV.deductInvv().equals("Deduct / Invoice")) {
			System.out
					.println("Verified Deduct / Invoice label all the letters showing in Title case: "
							+ deductInv);

			extentTest.log(LogStatus.INFO,
					"Verified Deduct / Invoice label all the letters showing in Title case: "
							+ deductInv);

		} else {
			System.out
					.println("Verified Deduct / Invoice label all the letters not showing in Title case: "
							+ deductInv);
			extentTest.log(LogStatus.FAIL,
					"Verified Deduct / Invoice label all the letters not showing in Title case: "
							+ deductInv);
		}

		Thread.sleep(3000);
		String blngName = pageFactV.blngNamee();
		if (pageFactV.blngNamee().equals("Billing Name")) {
			System.out
					.println("Verified Billing Name label all the letters showing in Title case: "
							+ blngName);

			extentTest.log(LogStatus.INFO,
					"Verified Billing Name label all the letters showing in Title case: "
							+ blngName);

		} else {
			System.out
					.println("Verified Billing Name label all the letters not showing in Title case: "
							+ blngName);
			extentTest.log(LogStatus.FAIL,
					"Verified Billing Name label all the letters not showing in Title case: "
							+ blngName);
		}
		Thread.sleep(3000);
		String internalNotes = pageFactV.internalNotess();
		if (pageFactV.internalNotess().equals("Internal Notes")) {
			System.out
					.println("Verified Internal Notes label all the letters showing in Title case: "
							+ internalNotes);

			extentTest.log(LogStatus.INFO,
					"Verified Internal Notes label all the letters showing in Title case: "
							+ internalNotes);

		} else {
			System.out
					.println("Verified Internal Notes label all the letters not showing in Title case: "
							+ internalNotes);
			extentTest.log(LogStatus.FAIL,
					"Verified Internal Notes label all the letters not showing in Title case: "
							+ internalNotes);
		}

		// pageFactV.alwpluss(Driver);
		// Thread.sleep(1500);
		// pageFactV.itemTabb(Driver);

		return null;
	}

	public String brtxtcondition(WebDriver Driver) {
		try {
			if (pageFactV.txtDescr.isEnabled()) {

				System.out
						.println("User with proper rights can view the Billing Record page without any error");

				extentTest
						.log(LogStatus.INFO,
								"User with proper rights can view the Billing Record page without any error");

			} else {
				System.out
						.println("User do not have proper privilege to view the Billing Records page");
				extentTest
						.log(LogStatus.INFO,
								"User do not have proper privilege to view the Billing Records page");

			}
		} catch (Exception e) {

			System.out
					.println("User do not have proper privilege to view the Billing Records page");
			extentTest
					.log(LogStatus.INFO,
							"User do not have proper privilege to view the Billing Records page");

		}

		return null;
	}

	public String brSavNonAlw(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactV.retDivDrpp(Driver);
		Thread.sleep(3000);
		pageFactV.retDivv(Driver);
		Thread.sleep(4500);
		pageFactV.retDivVall(Driver);
		Thread.sleep(2000);
		pageFactV.retValuu(Driver);
		pageFactV.elmntIntract(Driver);
		Thread.sleep(2000);
		pageFactV.txtAreaa(Driver);
		Thread.sleep(2000);
		pageFactV.brSavebtnn(Driver);

		Thread.sleep(55000);

		return null;
	}

	public String brSaveAllwnc(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		
		pageFact.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(3000);
		pageFactAS3.itemDetailsAmntt(Driver);
		Thread.sleep(5000);
		pageFactAS3.readyy(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);

		return null;
	}

	public String teamChange(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.billingDrpp(Driver);
		return null;
	}
	
	public String teamChangeV(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactV.teamDrpp(Driver);
		System.out.println("Clicked on Team dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Team dropdown");
		Thread.sleep(2000);
		pageFactV.preAuditt(Driver);
		System.out.println("Selected Pre-Audit");
		extentTest.log(LogStatus.INFO, "Selected Pre-Audit");
		 
		//  pageFact.waitForSpinnerToBeGone();
		Thread.sleep(55000);

		return null;
	}
	
	public String teamChangeIV(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(5000);
		pageFactV.billingDrpp(Driver);

		pageFact.warningYes.click();
		Thread.sleep(55000);
		return null;
	}

	public String teamChangeII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		System.out.println("Clicked on Team dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Team dropdown");
		Thread.sleep(7000);
		pageFactV.preAuditt(Driver);
		System.out.println("Selected Pre-Audit");
		extentTest.log(LogStatus.INFO, "Selected Pre-Audit");
		Thread.sleep(4500);
		pageFact.warningYes.click();
		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(55000);

		return null;
	}
	public String teamChangeIII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		System.out.println("Clicked on Team dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Team dropdown");
		Thread.sleep(5000);
		pageFactV.preAuditt(Driver);
		System.out.println("Selected Pre-Audit");
		extentTest.log(LogStatus.INFO, "Selected Pre-Audit");
		// Thread.sleep(1500);
		// pageFact.warningYes.click();
		//pageFact.waitForSpinnerToBeGone();
		//Thread.sleep(2500);

		Thread.sleep(55000);
		return null;
	}

	public String brSavNonAlw2(WebDriver Driver) throws InterruptedException,
			BiffException, IOException {

		waitforbrtxt(Driver);
		Thread.sleep(3500);
		pageFactV.elmntIntract(Driver);
		Thread.sleep(2000);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				String s1 = s.getCell(0, i).getContents();
				String s2 = s.getCell(1, i).getContents();
				String s3 = s.getCell(2, i).getContents();

				Thread.sleep(3000);

				pageFactAS3.ofsetAcntNum.sendKeys(s1);
				pageFactAS3.ofsetFacNum.sendKeys(s2);
				pageFactAS3.ofsetSecNum.sendKeys(s3);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		Thread.sleep(3000);

		pageFactV.txtAreaa(Driver);
		Thread.sleep(2000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(2000);
		pageFactV.txtAreaa(Driver);
		Thread.sleep(2000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);

		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.preAuditt(Driver);
		pageFactV.srchBilRcrdd(Driver);
		WaitForSearchTxt(Driver);
		pageFactV.firstBrSearchh(Driver);
		waitforbrtxt(Driver);

		Thread.sleep(5000);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				String s1 = s.getCell(0, i).getContents();
				String s2 = s.getCell(1, i).getContents();
				String s3 = s.getCell(2, i).getContents();

				Thread.sleep(3000);

				pageFactAS3.ofsetAcntNum.sendKeys(s1);
				pageFactAS3.ofsetFacNum.sendKeys(s2);
				pageFactAS3.ofsetSecNum.sendKeys(s3);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		Thread.sleep(3000);

		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		Thread.sleep(3000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		Thread.sleep(3000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);

		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Billing Record has been successfully updated with newly entered Offset values");
			extentTest
					.log(LogStatus.INFO,
							"Billing Record has been successfully updated with newly entered Offset values");
		} else {
			System.out
					.println("Error in updating BR details with offset values");
			extentTest.log(LogStatus.FAIL,
					"Error in updating BR details with offset values");
		}

		String valueAccount = pageFactV.ofsetNumAcnt(Driver);
		String valueFacility = pageFactV.ofsetNumFac(Driver);
		String valueSection = pageFactV.ofsetNumSec(Driver);
		System.out
				.println("Billing Record has been successfully updated with newly entered Account ID.  The Account ID entered is : "
						+ valueAccount);
		extentTest
				.log(LogStatus.INFO,
						"Billing Record has been successfully updated with newly entered Account ID.  The Account ID entered is : "
								+ valueAccount);

		System.out
				.println("Billing Record has been successfully updated with newly entered Facility ID.  The Facility ID entered is : "
						+ valueFacility);
		extentTest
				.log(LogStatus.INFO,
						"Billing Record has been successfully updated with newly entered Facility ID.  The Facility ID entered is : "
								+ valueFacility);

		System.out
				.println("Billing Record has been successfully updated with newly entered Section ID.  The section ID entered is : "
						+ valueSection);
		extentTest
				.log(LogStatus.INFO,
						"Billing Record has been successfully updated with newly entered Section ID.  The section ID entered is : "
								+ valueSection);

		return null;
	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactV.createBillrcrd));
		return null;
	}

	public String nonAlwnceNew() throws InterruptedException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		   pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		pageFact.BrTyp();
		Thread.sleep(4500);
		pageFact.nonAllwdrp();
		Thread.sleep(4500);
		pageFact.submitClk();
		waitforbrtxt(Driver);

		return null;
		
	}

	public String getbilngRcrdId(WebDriver Driver) {

		String testelem = pageFact.blngRcrdidd();
		System.out.println("Pre-populated  Billing Record ID is- " + testelem);
		extentTest.log(LogStatus.INFO, "Pre-populated  Billing Record ID is - "
				+ testelem);

		return null;
	}

	public String WaitForSearchTxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(pageFactV.srchTxtII));
		return null;
	}

	public String srchBilRecord(WebDriver Driver) throws InterruptedException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFactV.srchBilRcrdd(Driver);
	
		//NEW SEARCH IMPLEMENTATION
		
		WaitForSearchTxt(Driver);
		pageFact.waitForSpinnerToBeGone();

		pageFact.assignTodrpSearch.sendKeys("TEST");
		Thread.sleep(1500);
		pageFact.assignTodrpSearch.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFact.searchApply.click();
		Thread.sleep(7000);

		pageFact.searchFirstItem.click();
		waitforbrtxt(Driver);

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		

		return null;
	}

	public String editInvalid(WebDriver Driver) throws InterruptedException, IOException {

		Thread.sleep(5000);
		pageFactV.elmntIntractIV(Driver);
		Thread.sleep(3000);
		pageFactV.elmntIntractV(Driver);
		Thread.sleep(2500);
		pageFactV.elmntIntractIII(Driver);
		Thread.sleep(2500);
		pageFactV.elmntIntractIII(Driver);
		Thread.sleep(2500);
		pageFactV.txtAreaa(Driver);
		Thread.sleep(2500);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);
		String valErrMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3.invalidOfseterroMsg().contains("Enter Required Fields")) {
			System.out
					.println("Error message for invalid values displaying is: "
							+ valErrMsg);
			extentTest.log(LogStatus.INFO,
					"Error message for invalid values displaying is: "
							+ valErrMsg);
		} else {
			System.out
					.println("Not showing any error messages in invalid case");
			
			extentReportImage509PO_00 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage509PO_00.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage509PO_00);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Not showing any error messages in invalid case"
					+ extentTest.addScreenCapture(extentReportImage509PO_00));
		}

		return null;
	}

		public String editInvalidII(WebDriver Driver) throws InterruptedException, IOException {

		Thread.sleep(5000);
		pageFactV.elmntIntractIV(Driver);
		Thread.sleep(2500);
		pageFactV.elmntIntractIV(Driver);
		Thread.sleep(3000);
		pageFactV.elmntIntractV(Driver);
		Thread.sleep(2500);
		pageFactV.txtAreaa(Driver);
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(4500);
		pageFactAS3.newBRSave(Driver);		
		//pageFactAS3.savee(Driver);
		Thread.sleep(3000);
		String valErrMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3.invalidOfseterroMsg().contains("Enter Required Fields")) {
			System.out.println("Error message for invalid values displaying is: " + valErrMsg);
			extentTest.log(LogStatus.INFO, "Error message for invalid values displaying is: " + valErrMsg);
		} else {
			System.out.println("Not showing any error messages in invalid case");
			extentReportImage509PO_001 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage509PO_001.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage509PO_001);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Not showing any error messages in invalid case"
					+ extentTest.addScreenCapture(extentReportImage509PO_001));
		}

		return null;
	}


	public String edit(WebDriver Driver) throws InterruptedException {

		try {
		Thread.sleep(3000);
		try {
			if (pageFactV.txtDescr.isEnabled()) {

				System.out
						.println("Able to modify the BR details for user with Edit Rights");
				extentTest
						.log(LogStatus.INFO,
								"Able to modify the BR details for user with Edit Rights");
			} else {

				System.out
						.println("User do not have proper privilege to modify the Billing Records");
				extentTest
						.log(LogStatus.INFO,
								"User do not have proper privilege to modify the Billing Records");
			}
		} catch (Exception e) {

		}

		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		pageFactV.elmntIntract2(Driver);
		Thread.sleep(5000);
		if (pageFactV.brSavebtnII.isEnabled()) {

			System.out
					.println("Save button enabled after making some changes in the existing fields");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Save button enabled after making some changes in the existing fields");
		} else {

			System.out
					.println("Save button not enabled even after making some changes in the existing fields");
			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Save button not enabled even after making some changes in the existing fields");
		}
		Thread.sleep(2000);
		pageFactV.brSavebtnII.click();
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		String valErrMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Billing Record has been successfully updated.  Success message displayed is: "
							+ valErrMsg);
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Billing Record has been successfully updated.  Success message displayed is: "
							+ valErrMsg);
		} else {
			System.out
					.println("Error in updating BR details.  Error message showing is:  "
							+ valErrMsg);
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Error in updating BR details.  Error message showing is:  "
							+ valErrMsg);
		}
		}catch(Exception e) {
			System.out
			.println("User do not have proper privilege to do the action");
	extentTest
			.log(LogStatus.INFO,
					"User do not have proper privilege to do the action");
		}
		return null;
	}
	
	public String editIII(WebDriver Driver) throws InterruptedException {

		try{
		
		Thread.sleep(3000);
		try {
			if (pageFactV.txtDescr.isEnabled()) {

				System.out
						.println("Able to modify the BR details for user with Edit Rights");
				extentTest
						.log(LogStatus.INFO,
								"Able to modify the BR details for user with Edit Rights");
			} else {

				System.out
						.println("User do not have proper privilege to modify the Billing Records");
				extentTest
						.log(LogStatus.INFO,
								"User do not have proper privilege to modify the Billing Records");
			}
		} catch (Exception e) {

			System.out
			.println("User do not have proper privilege to modify the Billing Records");
	extentTest
			.log(LogStatus.INFO,
					"User do not have proper privilege to modify the Billing Records");
	
		}

		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		pageFactV.elmntIntract2(Driver);
		Thread.sleep(5000);
		if (pageFactV.brSavebtnII.isEnabled()) {

			System.out
					.println("Save button enabled after making some changes in the existing fields");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Save button enabled after making some changes in the existing fields");
		} else {

			System.out
					.println("Save button not enabled even after making some changes in the existing fields");
			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Save button not enabled even after making some changes in the existing fields");
		}
		Thread.sleep(2000);
		pageFactV.brSavebtnII.click();
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		String valErrMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Billing Record has been successfully updated.  Success message displayed is: "
							+ valErrMsg);
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Billing Record has been successfully updated.  Success message displayed is: "
							+ valErrMsg);
		} else {
			System.out
					.println("Error in updating BR details.  Error message showing is:  "
							+ valErrMsg);
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Error in updating BR details.  Error message showing is:  "
							+ valErrMsg);
		}
		
		}catch(Exception e){
			System.out
			.println("User do not have proper privilege to modify the Billing Records");
	extentTest
			.log(LogStatus.INFO,
					"User do not have proper privilege to modify the Billing Records");
			
		}
		return null;
	}

	public String editII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		try {
			if (pageFactV.txtDescr.isEnabled()) {

				System.out
						.println("TESTCASE PASSED:  Able to modify the BR details for user with Edit Rights");
				extentTest
						.log(LogStatus.INFO,
								"TESTCASE PASSED:  Able to modify the BR details for user with Edit Rights");
			} else {

				System.out
						.println("TESTCASE FAILED:  User do not have proper privilege to modify the Billing Records");
				extentTest
						.log(LogStatus.FAIL,
								"TESTCASE FAILED:  User do not have proper privilege to modify the Billing Records");
			}
		} catch (Exception e) {

		}

		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		 pageFactV.elmntIntract2(Driver);
		Thread.sleep(5000);
		if (pageFactAS3.newBRSav.isDisplayed()) {

			System.out
					.println("TESTCASE PASSED:  Save button enabled after making some changes in the existing fields");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Save button enabled after making some changes in the existing fields");
		} else {

			System.out
					.println("Save button not enabled even after making some changes in the existing fields");
			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Save button not enabled even after making some changes in the existing fields");
		}
		
		
		Thread.sleep(2000);
		
		pageFactAS3.newBRSav.click();
		//pageFactAS3.savee(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		// pageFactV.txtAreaa2(Driver);
		// Thread.sleep(2000);
		// pageFactV.brSavebtnn(Driver);
		// Thread.sleep(2000);
		// pageFactV.txtAreaa2(Driver);
		// Thread.sleep(2000);
		// pageFactV.brSavebtnn(Driver);
		// Thread.sleep(2000);

		String valErrMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Billing Record has been successfully updated.  Success message displayed is: "
							+ valErrMsg);
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Billing Record has been successfully updated.  Success message displayed is: "
							+ valErrMsg);
		} else {
			System.out
					.println("Error in updating BR details.  Error message showing is:  "
							+ valErrMsg);
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Error in updating BR details.  Error message showing is:  "
							+ valErrMsg);
		}

		return null;
	}

	public String ofsetNum(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		pageFactV.ofsetNumAcnt(Driver);
		String Acnt = pageFactV.ofsetNumAcnt(Driver);
		System.out.println("Previously saved Account number displaying is - "
				+ Acnt);
		extentTest.log(LogStatus.INFO,
				"Previously saved Account number displaying is - " + Acnt);

		pageFactV.ofsetNumFac(Driver);

		String Faclty = pageFactV.ofsetNumFac(Driver);
		System.out.println("Previously saved Facility ID displaying is - "
				+ Faclty);
		extentTest.log(LogStatus.INFO,
				"Previously saved Facility ID displaying is - " + Faclty);
		pageFactV.ofsetNumSec(Driver);

		String Section = pageFactV.ofsetNumSec(Driver);
		System.out.println("Previously saved Section ID displaying is - "
				+ Section);
		extentTest.log(LogStatus.INFO,
				"Previously saved Section ID displaying is - " + Section);

		return null;
	}

	public String ofsetSectionValidation(WebDriver Driver)
			throws InterruptedException {

		waitforBlngbtn(Driver);
//		pageFact.waitForSpinnerToBeGone();
//		Thread.sleep(2500);
		Thread.sleep(55000);
		pageFact.creatBillng();
		Thread.sleep(5500);
		pageFact.BrTyp();
		Thread.sleep(4500);
		pageFact.nonAllwdrp();
		Thread.sleep(4000);
		pageFactV.RetailDivv(Driver);
		Thread.sleep(2000);
		pageFactV.RetailDivValuee(Driver);
		Thread.sleep(3000);
		pageFactV.lukuPp(Driver);
		Thread.sleep(2000);
		pageFactV.RetailDivVall(Driver);

		pageFact.submitClk();
		waitforbrtxt(Driver);
		Thread.sleep(7000);
		pageFactV.sectionInput(Driver);

		pageFactV.elmntIntract(Driver);
		pageFactV.txtAreaa(Driver);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(2000);
		pageFactV.txtAreaa(Driver);
		pageFactV.brSavebtnn(Driver);
		
		//pageFact.waitForSpinnerToBeGone();
		Thread.sleep(32000);
		
		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Billing Record has been successfully updated with manually entered Offset values");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Billing Record has been successfully updated with manually entered Offset values");
		} else {
			System.out
					.println("Error in updating BR details with offset values");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Error in updating BR details with offset values");
		}

		return null;
	}
	
	public String ofsetSectionValidationII(WebDriver Driver) throws InterruptedException{
		
		waitforbrtxt(Driver);

		Thread.sleep(5000);
		pageFactV.ofsetNumAcnt(Driver);
		String Acnt1 = pageFactV.ofsetNumAcnt(Driver);
		System.out.println("Previously saved Account number displaying is - "
				+ Acnt1);
		extentTest.log(LogStatus.INFO,
				"Previously saved Account number displaying is - " + Acnt1);

		pageFactV.ofsetNumFac(Driver);
		String Faclty1 = pageFactV.ofsetNumFac(Driver);
		System.out.println("Previously saved Facility ID displaying is - "
				+ Faclty1);
		extentTest.log(LogStatus.INFO,
				"Previously saved Facility ID displaying is - " + Faclty1);

//		pageFactV.sectionInput(Driver);
//		pageFactV.brSavebtnn(Driver);
//		Thread.sleep(3000);
//		pageFactV.txtAreaa2(Driver);
//		Thread.sleep(3000);
//		pageFactV.brSavebtnn(Driver);
//		Thread.sleep(3000);
//		pageFactV.txtAreaa2(Driver);
//		Thread.sleep(3000);
//		pageFactV.brSavebtnn(Driver);
//		Thread.sleep(3000);
//
//		String valSection = pageFactV.ofsetNumSec(Driver);
//		if (pageFactAS3.invalidOfseterroMsg().contains(
//				"Billing Record has been saved")) {
//			System.out
//					.println("Billing Record has been successfully updated with newly entered Section ID.  The section ID entered is : "
//							+ valSection);
//			extentTest
//					.log(LogStatus.INFO,
//							"Billing Record has been successfully updated with newly entered Section ID.  The section ID entered is : "
//									+ valSection);
//		} else {
//			System.out.println("Error in updating BR details with section id");
//			extentTest.log(LogStatus.FAIL,
//					"Error in updating BR details with section id");
//		}
		
		return null;
	}
	
	

	public String ofsetValidation(WebDriver Driver)
			throws InterruptedException, BiffException, IOException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.billingDrpp(Driver);
		Thread.sleep(5000);
		pageFact.creatBillng();
		Thread.sleep(3000);
		pageFact.BrTyp();
		Thread.sleep(2000);
		pageFact.nonAllwdrp();
		Thread.sleep(3000);
		pageFactV.RetailDivv(Driver);
		Thread.sleep(3000);
		pageFactV.RetailDivValuee(Driver);
		Thread.sleep(3000);
		pageFactV.lukuPp(Driver);
		Thread.sleep(2000);
		pageFactV.RetailDivVal33(Driver);

		pageFact.submitClk();
		waitforbrtxt(Driver);
		Thread.sleep(7000);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				String s1 = s.getCell(0, i).getContents();
				String s2 = s.getCell(1, i).getContents();
				String s3 = s.getCell(2, i).getContents();

				Thread.sleep(3000);

				pageFactAS3.ofsetAcntNum.sendKeys(s1);
				pageFactAS3.ofsetFacNum.sendKeys(s2);
				pageFactAS3.ofsetSecNum.sendKeys(s3);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		Thread.sleep(3000);
		pageFactV.elmntIntract(Driver);
		pageFactV.txtAreaa(Driver);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(2000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(2000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(2000);

		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.preAuditt(Driver);
		
		
//		pageFactV.srchBilRcrdd(Driver);
//		WaitForSearchTxt(Driver);
//		pageFactV.firstBrSearchh(Driver);
//		waitforbrtxt(Driver);
		
		
		POVIII.SearchII(Driver);
		POVIII.searchFirstItemClk(Driver);
		
		Thread.sleep(5000);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				String s1 = s.getCell(0, i).getContents();
				String s2 = s.getCell(1, i).getContents();
				String s3 = s.getCell(2, i).getContents();

				Thread.sleep(3000);

				pageFactAS3.ofsetAcntNum.sendKeys(s1);
				pageFactAS3.ofsetFacNum.sendKeys(s2);
				pageFactAS3.ofsetSecNum.sendKeys(s3);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		Thread.sleep(3000);

		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		Thread.sleep(3000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);
		pageFactV.txtAreaa2(Driver);
		Thread.sleep(3000);
		pageFactV.brSavebtnn(Driver);
		Thread.sleep(3000);

		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Billing Record has been successfully updated with newly entered Offset values");
			extentTest
					.log(LogStatus.INFO,
							"Billing Record has been successfully updated with newly entered Offset values");
		} else {
			System.out
					.println("Error in updating BR details with offset values");
			extentTest.log(LogStatus.FAIL,
					"Error in updating BR details with offset values");
		}

		String valueAccount = pageFactV.ofsetNumAcnt(Driver);
		String valueFacility = pageFactV.ofsetNumFac(Driver);
		String valueSection = pageFactV.ofsetNumSec(Driver);
		System.out
				.println("Billing Record has been successfully updated with newly entered Account ID.  The Account ID entered is : "
						+ valueAccount);
		extentTest
				.log(LogStatus.INFO,
						"Billing Record has been successfully updated with newly entered Account ID.  The Account ID entered is : "
								+ valueAccount);

		System.out
				.println("Billing Record has been successfully updated with newly entered Facility ID.  The Facility ID entered is : "
						+ valueFacility);
		extentTest
				.log(LogStatus.INFO,
						"Billing Record has been successfully updated with newly entered Facility ID.  The Facility ID entered is : "
								+ valueFacility);

		System.out
				.println("Billing Record has been successfully updated with newly entered Section ID.  The section ID entered is : "
						+ valueSection);
		extentTest
				.log(LogStatus.INFO,
						"Billing Record has been successfully updated with newly entered Section ID.  The section ID entered is : "
								+ valueSection);
		
		return null;

	 
	}
	
	 

	// ---------------------

	public String AlwnceBR3(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		Thread.sleep(5000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.preAuditt(Driver);
		Thread.sleep(2000);
		pageFact.creatBillng();
		Thread.sleep(3000);

		// waitforBlngbtn(Driver);
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFactAS3.bRTypeRetailFieldAccValue(Driver);
		pageFact.bRTypeRetailFieldOffNo();
		pageFactAS3.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();

		Thread.sleep(2000);
		pageFact.billDateTo.sendKeys(Keys.TAB, "1");

		Thread.sleep(3000);
		WebElement FC = Driver.findElement(By
				.xpath("//*[@id=\"flatCode\"]/div/div/div[2]/input"));

		FC.click();
		Thread.sleep(3000);
		pageFact.flatCode1.click();
		pageFact.brSubmit.click();

		return null;
	}

	public String BRSaveRet(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);
		pageFact.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(3000);
		// pageFactAS3.itemDetailsAmntt(Driver);
		pageFactAS3.itemDetailsAmnttt(Driver);
		Thread.sleep(3000);
		// pageFactV.brSaveBtnn(Driver);
		pageFactV.savee(Driver);
		Thread.sleep(3000);
		return null;
	}

	public String ofSetError(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.postAuditt(Driver);
		Thread.sleep(2000);

		pageFactV.srchBilRcrdd(Driver);
		WaitForSearchTxt(Driver);
		pageFactV.firstBrSearchh(Driver);
		waitforbrtxt(Driver);
		Thread.sleep(3000);
		pageFactV.txtAreaa(Driver);

		Thread.sleep(3000);
		// pageFactV.brSavebtnn(Driver);
		pageFactV.savee(Driver);
		Thread.sleep(3000);

		String errMsg = pageFactAS3.invalidOfseterroMsg();
		Thread.sleep(3000);
		if (pageFactAS3
				.invalidOfseterroMsg()
				.equals("No Account or Facility has been setup for your team within Retail Div 20")) {
			System.out
					.println("If Section ID is not associated with the Account showing error message: "
							+ errMsg);
			extentTest.log(LogStatus.INFO,
					"If Section ID is not associated with the Account showing error message: "
							+ errMsg);
		} else {
			System.out.println("Wrong error message");
			extentTest.log(LogStatus.FAIL, "Wrong error message");
		}

		return null;
	}

	public String ofSetErrorII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.postAuditt(Driver);
		Thread.sleep(2000);

		pageFactV.srchBilRcrdd(Driver);
		WaitForSearchTxt(Driver);
		pageFactV.firstBrSearchh(Driver);
		waitforbrtxt(Driver);
		pageFactV.txtAreaa(Driver);

		Thread.sleep(3000);
		// pageFactV.brSavebtnn(Driver);
		pageFactV.savee(Driver);
		Thread.sleep(3000);

		String errMsg = pageFactAS3.invalidOfseterroMsg();
		Thread.sleep(3000);
		if (pageFactAS3.invalidOfseterroMsg().equals(
				"Section 280 is not setup for your team within Retail Div 20")) {
			System.out
					.println("If Section ID is not set up for the Team showing error message: "
							+ errMsg);
			extentTest.log(LogStatus.INFO,
					"If Section ID is not set up for the Team showing error message: "
							+ errMsg);
		} else {
			System.out.println("Wrong error message");
			extentTest.log(LogStatus.FAIL,
					"Wrong error message.  Error message showing is:  "
							+ errMsg);
		}

		return null;
	}

	// -------------------------
	public String editAllw(WebDriver Driver) {
		try {
			// if (pageFactV.txtDescr.isEnabled()) {
			if (pageFactV.txtDescr.isEnabled()
					&& pageFact.deductnum.isEnabled()
					&& pageFactV.asignTo.isEnabled()
					&& pageFactAS3.itemDetailsAmnt.isEnabled()
					&& pageFactV.brSaveBtn.isEnabled()
					&& pageFactAS3.ready.isEnabled()) {
				System.out
						.println("Able to view/Edit the BR details for user with proper Billing Record Rights");
				extentTest
						.log(LogStatus.INFO,
								"Able to view/Edit the BR details for user with proper Billing Record Rights");
			} else {

				System.out
						.println("User do not have proper privilege to view the Billing Records");
				extentTest
						.log(LogStatus.INFO,
								"User do not have proper privilege to view the Billing Records");
			}
		} catch (Exception e) {
		}
		return null;
	}

	public String editAllwIncm(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.incmeButtonAddd(Driver);
		Thread.sleep(3000);
		if (pageFactV.fltAmnt.equals("1")) {
			System.out
					.println("Income section loaded the saved income associated with the BR");
			extentTest
					.log(LogStatus.INFO,
							"Income section loaded the saved income associated with the BR");
		} else {

			System.out
					.println("Income section not loaded the saved income associated with the BR");
			extentTest
					.log(LogStatus.INFO,
							"Income section not loaded the saved income associated with the BR");
		}

		return null;
	}

	public String editAllw2(WebDriver Driver) {
		try {
			if (pageFactV.txtDescr.isEnabled()
					&& pageFact.deductnum.isEnabled()
					&& pageFactV.asignTo.isEnabled()
					&& pageFactAS3.itemDetailsAmnt.isEnabled()) {

				System.out
						.println("Able to view the BR details for user with view Billing Record Rights");
				extentTest
						.log(LogStatus.INFO,
								"Able to view the BR details for user with view Billing Record Rights");
			} else {

				System.out
						.println("User do not have proper privilege to view the Billing Records");
				extentTest
						.log(LogStatus.INFO,
								"User do not have proper privilege to view the Billing Records");
			}
		} catch (Exception e) {
		}
		return null;
	}

	public String AlwnceBR2(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {
		waitforBlngbtn(Driver);

		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();

		Thread.sleep(2000);
		pageFact.billDateTo.sendKeys(Keys.TAB, "1");

		Thread.sleep(3000);
		WebElement FC = Driver.findElement(By
				.xpath("//*[@id=\"flatCode\"]/div/div/div[2]/input"));

		FC.click();
		Thread.sleep(3000);
		pageFact.flatCode1.click();
		pageFact.brSubmit.click();

		return null;
	}

	public String errCaseSectionID(WebDriver Driver)
			throws InterruptedException {

		waitforbrtxt(Driver);
		Thread.sleep(3000);
		pageFactAS3.elmntIntract(Driver);
		Thread.sleep(3000);
		pageFactAS3.itemDetailsAmntt(Driver);
		Thread.sleep(3000);
		pageFactAS3.brSaveBtnn(Driver);

		String errMsg = pageFactAS3.invalidOfseterroMsg();
		Thread.sleep(3000);
		if (pageFactAS3
				.invalidOfseterroMsg()
				.equals("No Account or Facility has been setup for your team within Retail Div 20")) {
			System.out
					.println("If Section ID is not associated with the Account showing error message: "
							+ errMsg);
			extentTest.log(LogStatus.INFO,
					"If Section ID is not associated with the Account showing error message: "
							+ errMsg);
		} else {
			System.out.println("Wrong error message");
			extentTest.log(LogStatus.FAIL, "Wrong error message");
		}

		return null;
	}

	public String BRSaveNewReady(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactAS3.readyy(Driver);
		Thread.sleep(20000);

		System.out.println("Clicked on Ready Button");
		extentTest.log(LogStatus.INFO, "Clicked on Ready Button");
		 
		return null;
	}

	public String asignToChange(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.asignToo(Driver);
		Thread.sleep(3000);
		pageFactV.asignToThre(Driver);
		pageFactV.brSaveBtnn(Driver);
		srchBilRecord(Driver);

		try {
			// if (pageFactV.txtDescr.isEnabled()) {
			if (pageFactV.txtDescr.isEnabled()
					&& pageFact.deductnum.isEnabled()
					&& pageFactV.asignTo.isEnabled()
					&& pageFactAS3.itemDetailsAmnt.isEnabled()
					&& pageFactV.brSaveBtn.isEnabled()
					&& pageFactAS3.ready.isEnabled()) {
				System.out
						.println("Able to edit the BR even it is assigned to different user");
				extentTest
						.log(LogStatus.FAIL,
								"Able to edit the BR even it is assigned to different user");
			} else {

				System.out
						.println("Not able to edit the BR as it is assigned to different user");
				extentTest
						.log(LogStatus.INFO,
								"Not able to edit the BR as it is assigned to different user");
			}
		} catch (Exception e) {
		}

		return null;
	}

	public String cicExpand(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		pageFactV.cicItemDetailss(Driver);
		pageFactV.itemDetailsAmntt(Driver);
		srchBilRecord(Driver);

		if (pageFactV.cicItemColaps.isDisplayed()) {

			System.out.println("CIC is expanded as the Amount is different");
			extentTest.log(LogStatus.INFO,
					"CIC is expanded as the Amount is different");
		} else {

			System.out
					.println("The Amount is different but the CIC is not expanded");
			extentTest.log(LogStatus.FAIL,
					"The Amount is different but the CIC is not expanded");
		}

		return null;
	}

	public String brStatusDrppChng(WebDriver Driver)
			throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.brStatusDrpp(Driver);
		pageFactV.brStatusDrpValOne(Driver);
		extentTest.log(LogStatus.INFO, "BR Status changed");
		Thread.sleep(2000);

		if (pageFactV.brSaveBtn.isEnabled() && pageFactV.cancelBtn.isEnabled()) {

			System.out
					.println("Save & Cancel button is enabled after changing the BR Status");
			extentTest
					.log(LogStatus.INFO,
							"Save & Cancel button is enabled after changing the BR Status");
		} else {

			System.out
					.println("Save & Cancel button is disabled after changing the BR Status");
			extentTest
					.log(LogStatus.FAIL,
							"Save & Cancel button is disabled after changing the BR Status");
		}

		return null;
	}

	public String incmeValidation(WebDriver Driver) throws InterruptedException {

		Thread.sleep(5000);
		pageFactV.incmeButtonAddd(Driver);
		Thread.sleep(3000);
		pageFactV.fltAmntt(Driver);
		pageFactV.incmSavee(Driver);
		Thread.sleep(3000);
		pageFactV.incmWarnS(Driver);
		Thread.sleep(3000);
		return null;
	}

	public String AddIncome(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);

		if (pageFactV.incomeBtnNonAlw.isEnabled()) {

			System.out
					.println("Add Income Button enabled after filling all the valid values");
			extentTest
					.log(LogStatus.INFO,
							"Add Income Button enabled after filling all the valid values");
		} else {

			System.out
					.println("Add Income Button disabled even after filling all the valid values");
			extentTest
					.log(LogStatus.FAIL,
							"Add Income Button disabled even after filling all the valid values");
		}

		return null;
	}

		public String trashDelete(WebDriver Driver) throws InterruptedException {

		
		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		try {
		
		pageFactV.cicItemColapss(Driver);
		Thread.sleep(3000);
		try {
			if (pageFactV.trash.isEnabled()) {

				System.out.println("Trash button is enabled for the BR");
				extentTest.log(LogStatus.INFO,
						"TESTCASE PASSED:  Trash button is enabled for the BR");
			} else {

				System.out.println("Trash button is not enabled for the BR");
				extentTest
						.log(LogStatus.FAIL,
								"TESTCASE FAILED:  Trash button is not enabled for the BR");
			}
		} catch (Exception e) {
			// log exception
			System.out
					.println("Trash icon disabled, as the user doesn't have proper priviege to view the icon");
			extentTest
					.log(LogStatus.INFO,
							"Trash icon disabled, as the user doesn't have proper priviege to view the icon");
		}
		}catch(Exception e) {
			
			System.out
			.println("Trash icon disabled, as the user doesn't have proper priviege to view the icon");
	extentTest
			.log(LogStatus.INFO,
					"Trash icon disabled, as the user doesn't have proper priviege to view the icon");
			
		}

		return null;
	}

	public String trashDeleteIII(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		try {
			if (pageFactV.trash.isEnabled()) {

				System.out.println("Trash button is enabled for the BR");
				extentTest.log(LogStatus.INFO,
						"TESTCASE PASSED:  Trash button is enabled for the BR");
			} else {

				System.out.println("Trash button is not enabled for the BR");
				extentTest
						.log(LogStatus.FAIL,
								"TESTCASE FAILED:  Trash button is not enabled for the BR");
			}
		} catch (Exception e) {
			// log exception
			System.out
					.println("Trash icon disabled, as the user doesn't have proper priviege to view the icon");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Trash icon disabled, as the user doesn't have proper priviege to view the icon");
		}

		return null;
	}

	public String trashDeleteII(WebDriver Driver) throws InterruptedException {

		pageFactV.srchBilRcrdd(Driver);

		WaitForSearchTxt(Driver);
		pageFact.waitForSpinnerToBeGone();

		pageFact.assignTodrpSearch.sendKeys("Ajith");
		Thread.sleep(1500);
		pageFact.assignTodrpSearch.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFact.searchApply.click();
		Thread.sleep(7000);

		pageFact.searchFirstItem.click();
		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		// pageFactV.firstBrSearchh(Driver);

		return null;
	}

	public String trashDeleteClk(WebDriver Driver) throws InterruptedException {

		try {

			pageFactV.trashh(Driver);
			Thread.sleep(3000);
			pageFactV.trashNoo(Driver);

			System.out
					.println("Clicked on NO button from the delete alert pop up");
			extentTest.log(LogStatus.INFO,
					"Clicked on NO button from the delete alert pop up");

			if (pageFactV.trash.isDisplayed()) {

				System.out
						.println("Item displaying inact, as the user clicked on the NO button");
				extentTest
						.log(LogStatus.INFO,
								"Item displaying inact, as the user clicked on the NO button");
			} else {

				System.out.println("No button click not working properly");
				extentTest.log(LogStatus.FAIL,
						"No button click not working properly");
			}

			pageFactV.trashh(Driver);
			Thread.sleep(3000);
			pageFactV.trashYess(Driver);
			System.out
					.println("Clicked on YES button from the delete alert pop up");
			extentTest.log(LogStatus.INFO,
					"Clicked on YES button from the delete alert pop up");
			try {
				if (pageFactV.trash.isDisplayed()) {

					System.out
							.println("Delete not working, item still displaying on the list");
					extentTest
							.log(LogStatus.FAIL,
									"Delete not working, item still displaying on the list");
				} else {

					System.out.println("Delete working properly");
					extentTest.log(LogStatus.INFO, "Delete working properly");
				}
			} catch (Exception e) {
				// log exception
				System.out.println("Delete working properly");
				extentTest.log(LogStatus.INFO, "Delete working properly");
			}

			Thread.sleep(3000);
			pageFactV.savee(Driver);
			Thread.sleep(5000);

		} catch (Exception e) {
			System.out
					.println("Logged in user do not have proper privilege to deleting the record");
			extentTest
					.log(LogStatus.INFO,
							"Logged in user do not have proper privilege to deleting the record");

		}

		return null;
	}

	public String trashIncome(WebDriver Driver) throws InterruptedException {
		
		try{

		Thread.sleep(2500);
		pageFactV.incmeButtonAddd(Driver);
		Thread.sleep(2500);

		try {
			if (pageFactV.incomeScndLine.isDisplayed()) {

				System.out
						.println("Delete not working properly, item still displaying on the Income list");
				extentTest
						.log(LogStatus.FAIL,
								"Delete not working properly, item still displaying on the Income list");
			} else {

				System.out
						.println("Delete working properly, the deleted item not displaying in the Income list");
				extentTest
						.log(LogStatus.INFO,
								"Delete working properly, the deleted item not displaying in the Income list");
			}
		} catch (Exception e) {
			// log exception
			System.out
					.println("Delete working properly, the deleted item not displaying in the Income list");
			extentTest
					.log(LogStatus.INFO,
							"Delete working properly, the deleted item not displaying in the Income list");
		}
		
		}catch(Exception e){
			
			System.out
			.println("Income section is disabled for the user");
	extentTest
			.log(LogStatus.INFO,
					"Income section is disabled for the user");

			
		}

		return null;
	}

	public String waitforIncmLine(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactV.incomeNewLine));
		return null;
	}

	public String waitforErrorIcon(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactV.errorIcon));
		return null;
	}

	public String searchCIC(WebDriver Driver) throws BiffException, IOException, InterruptedException {

		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		try {
			
		
		if (pageFactV.cicItemDetails.isDisplayed()) {

			System.out.println("Item Details section is enabled");
			extentTest.log(LogStatus.INFO, "Item Details section is enabled");
		} else {

			System.out.println("Item Details section is not enabled");
			extentTest.log(LogStatus.FAIL, "Item Details section is not enabled");
		}

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactV.leadCICItemm(Driver);

		waitforIncmLine(Driver);

		if (pageFactV.incomeNewLine.isDisplayed()) {

			System.out.println("New CIC Item successfully added");
			extentTest.log(LogStatus.INFO, "New CIC Item successfully added");
		} else {

			System.out.println("Failed to add new CIC item");
			extentTest.log(LogStatus.FAIL, "Failed to add new CIC item");
		}}
		catch(Exception e) {
			
			System.out.println("Item Details disabled for the logged in user");
			extentTest.log(LogStatus.INFO, "Item Details disabled for the logged in user");
		}

		return null;
	}

	public String waitforUPCLine(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactV.upcItem1));
		return null;
	}

	public String searchUPC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		waitforbrtxt(Driver);
		Thread.sleep(5000);
		if (pageFactV.brSaveBtn.isDisplayed()) {

			System.out.println("Item Details section is enabled");
			extentTest.log(LogStatus.INFO, "TESTCASE PASSED:  Item Details section is enabled");
		} else {

			System.out.println("Item Details section is not enabled");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Item Details section is not enabled");
		}
		Thread.sleep(5000);
		pageFactV.leadUPCItemm(Driver);
		Thread.sleep(2000);
		waitforUPCLine(Driver);

		String upcitem = pageFactV.upcItemOne(Driver);
		if (pageFactV.upcItem1.isDisplayed()) {

				System.out.println("UPC Items displaying is:  " + upcitem);
			extentTest.log(LogStatus.INFO, "TESTCASE PASSED:  UPC Items displaying is:  "
					+ upcitem);
		} else {

			System.out.println("No UPC Items displaying");
			extentTest.log(LogStatus.FAIL, "TESTCASE FAILED:  No UPC Items displaying");
		}

		// waitforIncmLine(Driver);
		//
		// if (pageFactV.incomeNewLine.isDisplayed()) {
		//
		// System.out.println("New CIC Item successfully added");
		// extentTest.log(LogStatus.INFO, "New CIC Item successfully added");
		// } else {
		//
		// System.out.println("Failed to add new CIC item");
		// extentTest.log(LogStatus.FAIL, "Failed to add new CIC item");
		// }

		return null;
	}

	public String invalidCIC(WebDriver Driver) throws BiffException, IOException, InterruptedException {

		try {
			pageFactV.leadCICItemmII(Driver);
			waitforErrorIcon(Driver);
			Thread.sleep(5000);
			pageFactV.errorIconn(Driver);
			Thread.sleep(2000);

			// String ErrMsg = pageFactV.errMsgg(Driver);

			// if (pageFactV.errMsgg(Driver)
			// .equals("This item is not valid in this billing record's location and time
			// frame")) {

			if (pageFactV.errorIcon.isDisplayed()) {
				System.out.println(
						"Invalid CIC error message - 'This item is not valid in this billing record's location and time frame' displaying properly");
				extentTest.log(LogStatus.INFO,
						"Invalid CIC error message - 'This item is not valid in this billing record's location and time frame' displaying properly");
			} else {

				System.out.println("Error message displaying is wrong: ");
				extentTest.log(LogStatus.FAIL, "Error message displaying is wrong: ");
			}
		} catch (Exception e) {

			System.out.println("Invalid CIC error message not showing");
			extentTest.log(LogStatus.INFO, "Invalid CIC error message not showing");
		}

		return null;
	}

	public String invalidUPC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		pageFactV.leadUPCItemmII(Driver);
		waitforErrorIcon(Driver);
		Thread.sleep(5000);
//		pageFactV.errorIconn(Driver);
//		Thread.sleep(2000);

		//String ErrMsg = pageFactV.errMsgg(Driver);

		if (pageFactV
				.errorIcon
				.isDisplayed()) {

			System.out.println("Invalid UPC error message displaying properly");
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Invalid UPC error message displaying properly");
		} else {

			System.out.println("No error message showing even in case of Invalid UPC");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  No error message showing even in case of Invalid UPC");
		}

		return null;
	}

	public String CICDetails(WebDriver Driver) {

		String firstCic = pageFactV.FirstCICc(Driver);
		System.out.println("CIC Value displaying in the Item details is:  "
				+ firstCic);
		extentTest.log(LogStatus.INFO,
				"CIC Value displaying in the Item details is:  " + firstCic);

		String FirstUPccc = pageFactV.FirstUPCc(Driver);
		System.out.println("UPC Value displaying in the Item details is:  "
				+ FirstUPccc);
		extentTest.log(LogStatus.INFO,
				"UPC Value displaying in the Item details is:  " + FirstUPccc);

		String cost = pageFactV.costt(Driver);
		System.out.println("Cost displaying in the Item details is:  " + cost);
		extentTest.log(LogStatus.INFO,
				"Cost displaying in the Item details is:  " + cost);

		String descr = pageFactV.decripp(Driver);
		System.out.println("Description displaying in the Item details is:  "
				+ descr);
		extentTest.log(LogStatus.INFO,
				"Description displaying in the Item details is:  " + descr);

		String pack = pageFactV.packk(Driver);
		System.out.println("Pack displaying in the Item details is:  " + pack);
		extentTest.log(LogStatus.INFO,
				"Pack displaying in the Item details is:  " + pack);

		String disp = pageFactV.dispp(Driver);
		System.out.println("Disp displaying in the Item details is:  " + disp);
		extentTest.log(LogStatus.INFO,
				"Disp displaying in the Item details is:  " + disp);

		return null;
	}

	public String duplicateCIC(WebDriver Driver) throws InterruptedException {

		try {
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactV.leadCicClear(Driver);
		Thread.sleep(3000);
		pageFactV.leadCICValu(Driver);

		Thread.sleep(2500);
		pageFactV.CICAdditemm(Driver);
		System.out.println("Add Item button clicked1");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		// pageFactV.CICAdditemm(Driver);
		// System.out.println("Add Item button clicked2");
		// Thread.sleep(2500);
		// pageFactV.CICAdditemm(Driver);
		// System.out.println("Add Item button clicked3");

		waitforErrorIcon(Driver);
		Thread.sleep(5000);
		pageFactV.errorIconn(Driver);
		Thread.sleep(2000);

		// String ErrMsg = pageFactV.errMsgg(Driver);

		// if (pageFactV.errMsgg(Driver).equals("This item already exists in this
		// billing record")) {

		if (pageFactV.errorIcon.isDisplayed()) {
			System.out.println("Duplicate error message displaying properly");
			extentTest.log(LogStatus.INFO, "Duplicate error message displaying properly");
		} else {

			System.out.println("Error message not properly displaying");
			extentTest.log(LogStatus.FAIL, "Error message not properly displaying");
		}}
		catch(Exception e) {
			
			System.out.println("Add Item button disabled");
			extentTest.log(LogStatus.INFO, "Add Item button disabled");	
			
		}

		return null;
	}

	public String duplicateUPC(WebDriver Driver) throws InterruptedException {

		pageFactV.UPCClear(Driver);
		Thread.sleep(3000);
		pageFactV.leadUPCValu(Driver);

		Thread.sleep(2500);
		pageFactV.CICAdditemm(Driver);
		System.out.println("Add Item button clicked1");
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		try {
			if (pageFactV.noItemFound.isDisplayed()) {

				Thread.sleep(2500);
				pageFactV.doneBtnn(Driver);
				System.out.println("Clicked on Done button");
				extentTest.log(LogStatus.FAIL, "Clicked on Done button");

			} else {

				System.out
						.println("Error occured while searching for duplicate UPC items");
				extentTest
						.log(LogStatus.FAIL,
								"Error occured while searching for duplicate UPC items");
			}
		} catch (Exception e) {

			System.out.println("No duplicate items listed");
			extentTest.log(LogStatus.INFO, "TESTCASE PASSED:  No duplicate items listed");

		}

		return null;
	}

	public String itemDetailBtn(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		Thread.sleep(5000);
		pageFactV.leadCicInvalid(Driver);

		try {
			if (pageFactV.CICAdditem.isEnabled()) {

				System.out
						.println("Add Item button is enabled even if entered value is invalid");
				extentTest
						.log(LogStatus.FAIL,
								"Add Item button is enabled even if entered value is invalid");
			} else {

				System.out
						.println("Add Item button is disabled when user try to enter invalid data");
				extentTest
						.log(LogStatus.INFO,
								"Add Item button is disabled when user try to enter invalid data");

			}
		} catch (Exception e) {

			System.out
					.println("Add Item button is disabled when user try to enter invalid data");
			extentTest
					.log(LogStatus.INFO,
							"Add Item button is disabled when user try to enter invalid data");

		}
		Thread.sleep(2000);
		pageFactV.leadCICValu(Driver);
		if (pageFactV.CICAdditem.isEnabled()) {

			System.out
					.println("Add Item button is enabled when user enters valid data");
			extentTest.log(LogStatus.INFO,
					"Add Item button is enabled when user enters valid data");
		} else {

			System.out
					.println("Add Item button is disabled when user try to enter valid data");
			extentTest
					.log(LogStatus.FAIL,
							"Add Item button is disabled when user try to enter valid data");

		}
		return null;
	}

	public String itemDetailBtnII(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactV.leadCicInvalid(Driver);

		try {
			if (pageFactV.CICAdditem.isEnabled()) {

				System.out
						.println("Edit My Billing Record Right:  Add Item button is enabled even if entered value is invalid");
				extentTest
						.log(LogStatus.FAIL,
								"Edit My Billing Record Right:  Add Item button is enabled even if entered value is invalid");
			} else {

				System.out
						.println("Edit My Billing Record Right:  Add Item button is disabled when user try to enter invalid data");
				extentTest
						.log(LogStatus.INFO,
								"Edit My Billing Record Right:  Add Item button is disabled when user try to enter invalid data");

			}
		} catch (Exception e) {

			System.out
					.println("Edit My Billing Record Right: Add Item button is disabled when user try to enter invalid data");
			extentTest
					.log(LogStatus.INFO,
							"Edit My Billing Record Right: Add Item button is disabled when user try to enter invalid data");

		}
		Thread.sleep(2000);
		pageFactV.leadCICValu(Driver);
		if (pageFactV.CICAdditem.isEnabled()) {

			System.out
					.println("Edit My Billing Record Right: Add Item button is enabled when user enters valid data");
			extentTest
					.log(LogStatus.INFO,
							"Edit My Billing Record Right:  Add Item button is enabled when user enters valid data");
		} else {

			System.out
					.println("Edit My Billing Record Right:  Add Item button is disabled when user try to enter valid data");
			extentTest
					.log(LogStatus.FAIL,
							"Edit My Billing Record Right:  Add Item button is disabled when user try to enter valid data");

		}
		return null;
	}

	public String itemDetailBtnIII(WebDriver Driver)
			throws InterruptedException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		// pageFactV.leadCicInvalid(Driver);

		try {
			if (pageFactV.CICAdditem.isEnabled()) {

				System.out
						.println("Edit Others Billing Record Right:  Add Item button is enabled even if entered value is invalid");
				extentTest
						.log(LogStatus.FAIL,
								"Edit Others Billing Record Right:  Add Item button is enabled even if entered value is invalid");
			} else {

				System.out
						.println("Edit Others Billing Record Right:  Add Item button is disabled when user try to enter invalid data");
				extentTest
						.log(LogStatus.INFO,
								"Edit My Billing Record Right:  Add Item button is disabled when user try to enter invalid data");

			}
		} catch (Exception e) {

			System.out
					.println("Edit Others Billing Record Right: Add Item button is disabled");
			extentTest
					.log(LogStatus.INFO,
							"Edit Others Billing Record Right: Add Item button is disabled");

		}
		Thread.sleep(2000);

		
		return null;
	}

	public String SearchII(WebDriver Driver) throws InterruptedException {

		pageFactV.srchBilRcrdd(Driver);
		Thread.sleep(2500);
		pageFact.warningYes.click();
		
		WaitForSearchTxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
 	
		pageFact.assignTodrpSearch.sendKeys("Ajith");
		Thread.sleep(1500);
		pageFact.assignTodrpSearch.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFact.searchApply.click();
		Thread.sleep(7000);

		pageFact.searchFirstItem.click();
		waitforbrtxt(Driver);
		 
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		return null;
	}

	public String Search(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactV.srchBilRcrdd(Driver);
		WaitForSearchTxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		// NEW SEARCH CODE IMPLEMENTATION

		pageFact.assignTodrpSearch.sendKeys("TEST");
		Thread.sleep(1500);
		pageFact.assignTodrpSearch.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFact.searchApply.click();
		Thread.sleep(7000);

		pageFact.searchFirstItem.click();
		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		// pageFactV.firstBrSearchh(Driver);
		// waitforbrtxt(Driver);
		// pageFact.waitForSpinnerToBeGone();
		// Thread.sleep(2500);

		return null;
	}

	public String SearchFields(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactV.srchBilRcrdd(Driver);

		System.out
				.println("Clicked on Search Billing Record button from the left panel");
		extentTest.log(LogStatus.INFO,
				"Clicked on Search Billing Record button from the left panel");

		WaitForSearchTxt(Driver);

		if (pageFactV.srchTxtII.isDisplayed()) {

			System.out.println("Search Billing Record page displayed");
			extentTest.log(LogStatus.INFO,
					"Search Billing Record page displayed");
		} else {

			System.out.println("Search Billing Record page not displayed");
			extentTest.log(LogStatus.FAIL,
					"Search Billing Record page not displayed");
		}

		// Label check

		String br = pageFactV.brlabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + br);

			extentTest.log(LogStatus.INFO, "Field name showing is:  " + br);

		} else {
			System.out.println("Field name showing is BR:  " + br);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  " + br);
		}

		String blngName = pageFactV.blngNameLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + blngName);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ blngName);

		} else {
			System.out.println("Field name showing is BR:  " + blngName);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ blngName);
		}

		String brStatusLabell = pageFactV.brStatusLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + brStatusLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ brStatusLabell);

		} else {
			System.out.println("Field name showing is BR:  " + brStatusLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ brStatusLabell);
		}

		String areaLabell = pageFactV.areaLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + areaLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ areaLabell);

		} else {
			System.out.println("Field name showing is BR:  " + areaLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ areaLabell);
		}

		String sectionLabell = pageFactV.sectionLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + sectionLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ sectionLabell);

		} else {
			System.out.println("Field name showing is BR:  " + sectionLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ sectionLabell);
		}

		String allowanceLabell = pageFactV.allowanceLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + allowanceLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ allowanceLabell);

		} else {
			System.out.println("Field name showing is BR:  " + allowanceLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ allowanceLabell);
		}

		String offerLabell = pageFactV.offerLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + offerLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ offerLabell);
		} else {
			System.out.println("Field name showing is BR:  " + offerLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ offerLabell);
		}

		String fltAmntLabell = pageFactV.fltAmntLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + fltAmntLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ fltAmntLabell);
		} else {
			System.out.println("Field name showing is BR:  " + fltAmntLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ fltAmntLabell);
		}

		String asignTOLabell = pageFactV.asignTOLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + asignTOLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ asignTOLabell);
		} else {
			System.out.println("Field name showing is BR:  " + asignTOLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ asignTOLabell);
		}

		String dialogLabell = pageFactV.dialogLabell(Driver);
		if (pageFactV.brlabell(Driver).equals("BR")) {
			System.out.println("Field name showing is:  " + dialogLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is:  "
					+ dialogLabell);
		} else {
			System.out.println("Field name showing is BR:  " + dialogLabell);

			extentTest.log(LogStatus.INFO, "Field name showing is BR:  "
					+ dialogLabell);
		}
		

		Thread.sleep(7000);
		pageFactV.brStatusSearch.click();
		Thread.sleep(2500);
		pageFactV.brStatusSearch.sendKeys("Ready");
		Thread.sleep(2500);
		pageFactV.brStatusSearch.sendKeys(Keys.ENTER);
		Thread.sleep(2500);
		
		pageFactV.searchApply.click();
		
		Thread.sleep(7000);
		
		
		pageFactV.firstBrSearchh(Driver);
		System.out.println("Clicked on First BR from the search list");
		extentTest.log(LogStatus.INFO,
				"Clicked on First BR from the search list");

		waitforbrtxt(Driver);

		if (pageFact.BRtxt.isDisplayed()) {

			System.out
					.println("The user successfully redirected to the New BR page");
			extentTest.log(LogStatus.INFO,
					"The user successfully redirected to the New BR page");
		} else {

			System.out.println("Not redirected to the New BR page");
			extentTest.log(LogStatus.FAIL, "Not redirected to the New BR page");

		}

		return null;
	}

	public String UPC(WebDriver Driver) throws InterruptedException {
		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFactV.upcRadioo(Driver);
		Thread.sleep(2500);
		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactV = new GenericFactoryV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFact = new GenericFactory(Driver);
		POVIII.beforeTest(Driver);
	}

}
