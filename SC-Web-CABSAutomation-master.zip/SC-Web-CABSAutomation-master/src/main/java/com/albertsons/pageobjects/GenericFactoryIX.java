package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

public class GenericFactoryIX {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/allowinc-header-flat/div/div[1]/div[1]/cabs-checkbox/label/span")
	WebElement headerCheckBox;
	
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	 WebElement warningYes;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[1]/div/div[1]/cabs-checkbox/label/span")
	WebElement itemCheckBox;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/allowinc-header-flat/div/div[2]/form/div/div[2]/cabs-datepicker/form/div/div/div")
	WebElement perfDate;

	@FindBy(xpath = "//*[@id='allowance-history-tab']/div[1]/i-feather")
	WebElement alwHistPlus;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	WebElement CICtxt;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/plain-button/button")
	WebElement incCancel;

	@FindBy(xpath = "//*[@id='lastUpdate']/div/span")
	WebElement lastUpdate;

	@FindBy(xpath = "//*[@id='ta-lastUpdate-0']/label")
	WebElement lastUpdateDate;

	@FindBy(xpath = "//*[@id='ta-lastUpdate-0']/span[1]")
	WebElement History;

	@FindBy(xpath = "//*[@id='ta-lastUpdate-0']/span[2]")
	WebElement status;
	
	@FindBy(xpath="//*[@id='ta-lastUpdate-1']/span")
	WebElement historyTxt;
	
	@FindBy(id="deductInvoiceNumber")
	WebElement deduct;
	
	@FindBy(xpath="//*[@id='billingName']/div/div/div[3]/input")
	WebElement blngName;
	
	@FindBy(xpath="//*[@id='brStatus']/div/div/div[3]/input")
	WebElement brStatus;
	 
	@FindBy(id="ta-assignTo-47")
	WebElement assignToVal;
	
	@FindBy(xpath="//*[@id='assignTo']/div/div/div[3]/input")
	WebElement asignTo;
	
	@FindBy(xpath="//*[@id='income-tab']/div[4]/button")
	WebElement addIncome;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	WebElement BRSaveBtn;
	
	@FindBy(xpath="//*[@id='allow-tab']/div[3]/span")
	WebElement warning;
	
	@FindBy(xpath="//*[@id='ngb-popover-8']")
	WebElement warningContent;
	
	@FindBy(xpath="//*[@id='heading_10003510']/span")
	WebElement billingID;
	
	@FindBy(xpath="//*[@id='heading_10003510']/span/span")
	WebElement dates;
	
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/table/thead/tr/th[2]")
	WebElement firstCol;
	
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/table/thead/tr/th[3]")
	WebElement secondCol;
	
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/table/thead/tr/th[4]")
	WebElement thirdCol;
	
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/table/tbody/tr[1]/td[3]")
	WebElement stores;
	
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/table/tbody/tr[2]/td[3]")
	WebElement items;
	
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/table/tbody/tr[3]/td[4]")
	WebElement dateOverlap;
 
	@FindBy(xpath="//*[@id='ngb-panel-0']/div/div/cabs-checkbox/label/span")
	WebElement intention;
	
	@FindBy(xpath="//*[@id='ngb-panel-1']/div/div/cabs-checkbox/label/span")
	WebElement intentionII;
	
	
	@FindBy(xpath="//*[@id='ngb-panel-2']/div/div/cabs-checkbox/label/span")
	WebElement intentionIII;
	
	@FindBy(xpath="//*[@id='ngb-panel-3']/div/div/cabs-checkbox/label/span")
	WebElement intentionIV;
	
	@FindBy(xpath="//*[@id='allowanceCollapse']/div/div/div[3]/div/div[2]/div[4]/div/overlap-dropdown/ng-select/div/div/div[2]")
	WebElement overlapValue;
	
	@FindBy(xpath="//*[@id='title_10004037']/button/i-feather[1]")
	WebElement overlapVal;
	
	public String overlapValueTxt(WebDriver Driver) {

		return overlapValue.getText();
	}
	

	public String billingIDTxt(WebDriver Driver) {

		return billingID.getText();
	}
	
	public String datesTxt(WebDriver Driver) {

		return dates.getText();
	}
	
	
	public String warningContentTxt(WebDriver Driver) {

		return warningContent.getText();
	}
	
	public String assignToClk(WebDriver Driver) {

		asignTo.click();
		assignToVal.click();
		return null;
	}
	
	public String historyTxtClk(WebDriver Driver) {

		historyTxt.click();
		return null;
	}
	
	public String statusTxt(WebDriver Driver) {

		return status.getText();
	}

	public String HistoryTxt(WebDriver Driver) {

		return History.getText();
	}

	public String lastUpdateTxt(WebDriver Driver) {

		return lastUpdateDate.getText();
	}

	public String lastUpdateClk(WebDriver Driver) {

		lastUpdate.click();
		return null;
	}

	public String itemCheckBoxClk(WebDriver Driver) {

		itemCheckBox.click();
		return null;
	}

	public String headerCheckBoxClk(WebDriver Driver) {

		headerCheckBox.click();
		return null;
	}

	public GenericFactoryIX(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}
}
