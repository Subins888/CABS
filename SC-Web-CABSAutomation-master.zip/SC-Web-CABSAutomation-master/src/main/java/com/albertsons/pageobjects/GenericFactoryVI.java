package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

public class GenericFactoryVI {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;

	public WebElement LCIC;

	// @FindBy(xpath =
	// "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[1]/div/i-feather/svg/line[1]")
	// public WebElement itemDetailExp;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[1]/div/i-feather")
	public WebElement itemDetailExp;

	// @FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/cabs-amount/div/div/div/input")
	// @FindBy(xpath = "//*[@id='textvalue']/div/div/input")
	// @FindBy(xpath="//*[@id='undefined']/div/input")
	@FindBy(xpath = "//*[@id='undefined']/input")
	public WebElement allwAmnt;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[1]/div[3]/cabs-textbox/div/input")
	public WebElement leadCICItem;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
	public WebElement invalidOfseterr;

	@FindBy(id = "ta-billingRecordType-1")
	public WebElement cogsType;

	@FindBy(id = "ta-performanceCode1-0")
	public WebElement p2AlwT1;

	@FindBy(id = "ta-performanceCode2-1")
	public WebElement p2AlwT11;

	@FindBy(xpath = "//*[@id=\"leadCIC\"]")
	public WebElement leadCIC;

	@FindBy(xpath = "//*[@id='accLookUpType']/div/div/div[2]")
	public WebElement actLukUpCogs;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span")
	public WebElement closeBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span/i-feather")
	public WebElement closeBtnII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/h4/span[2]")
	public WebElement errMsg;

	@FindBy(xpath = "//*[@id=\"accountLookupValue\"]")
	public WebElement accLkUpVal;

	@FindBy(id = "ta-accountLookupValue-82")
	public WebElement selAccLkUpVal;

	@FindBy(id = "ta-accountLookupValue-14")
	public WebElement selAcctlkupVal14;
	
	@FindBy(id="ta-accountLookupValue-5")
	public WebElement selAccLkUpValII;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement fromCal;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[2]/div[2]/div")
	public WebElement fromCalopen;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement toCal;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[4]/div[4]/div")
	public WebElement toCalOpen;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/input")
	public WebElement billDateTo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/input")
	public WebElement billDateFrom;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[2]/a")
	public WebElement xternal;

	@FindBy(xpath = "//*[@id=\"allowanceType\"]/div/div/div[2]/input")
	public WebElement allwTypeBox;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-0\"]")
	public WebElement allwType0;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-1\"]")
	public WebElement allwType1;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[2]/input")
	public WebElement perf1Box;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-0\"]")
	public WebElement p1AlwT0;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-1\"]")
	public WebElement p1AlwT1;

	@FindBy(xpath = "//*[@id=\"performanceCode2\"]")
	public WebElement perf2Box;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-0\"]")
	public WebElement p2AlwT0;

	@FindBy(id = "ta-performanceCode2-2")
	public WebElement p3val3;

	@FindBy(id = "ta-performanceCode2-3")
	public WebElement p3val4;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[3]/input")
	public WebElement perf1BoxAfterSel;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[3]/div[1]/div/div/span")
	public WebElement itemizedLabel;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/label")
	public WebElement allwTypeLabel;

	@FindBy(xpath = "//*[@id='allowanceType']/div/span")
	public WebElement alwncTypDrp;

	@FindBy(id = "notesId")
	public WebElement notesComment;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[4]/span[2]/button")
	public WebElement incomeWarning;
	
	@FindBy(xpath="//*[@id='income-tab']/div[4]/span[2]/button")
	public WebElement miscIncomeWarn;

	@FindBy(xpath="//*[@id='allow-income-tab']/div[4]/span[2]/button")
	public WebElement warningM;

	@FindBy(xpath = "//*[@id='ngb-popover-7']/div[2]")
	public WebElement WarningMsg;
	
	@FindBy(xpath="//*[@id='ngb-popover-14']/div[2]")
	public WebElement miscWarningMsg;
	
	//@FindBy(xpath="//*[@id='ngb-popover-6']/div[2]")
	 @FindBy(className="popover-body")
	public WebElement miscWarningMsgII;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[3]/div[2]/label")
	public WebElement acruelabl;
	
	@FindBy(xpath="//*[@id='income-tab']/div[3]/div[2]/label")
	public WebElement acruelablMisc;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[3]/div[3]/label")
	public WebElement bilNdacru;
	
	 @FindBy(id = "amountId0")
		public WebElement incAmnt;
	 
	 @FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/action-button/button")
	 public WebElement addIncomeMisc;
	 
	 @FindBy(xpath="//*[@id='income-tab']/div[3]/div[3]/label")
	 public WebElement bilNdAcruMisc;
	 
	 @FindBy(xpath="//*[@id='allowance-history-tab']/div[1]/i-feather")
	 public WebElement incmHistory;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/plain-button/button")
	 public WebElement incHistCancel;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/div[2]/label")
	 public WebElement amntincHistory;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span/p[1]")
	 public WebElement alwnceHistory;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[1]")
	 public WebElement frmHist;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p[2]")
	 public WebElement toHist;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/div/span/p")
	 public WebElement usrIDHist;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/div/span/p[1]")
	 public WebElement statusHist;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	 public WebElement invHist1;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	 public WebElement invHist2;
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[3]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	 public WebElement invHist3;
	 
	 
	 @FindBy(xpath="//*[@id='allowanceIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[4]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	 public WebElement invHist4;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[3]/a")
	 public WebElement OTWorklistLeft;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	 public WebElement OTWorklistData;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	 public WebElement OTWorklistData2;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label/span")
	 public WebElement paginationTop;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")
	public WebElement brLabel;		
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	 public WebElement blngName;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
	 public WebElement incmType;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/span/a")
	 public WebElement areaa;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/span")
	 public WebElement section;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/span/a")
	 public WebElement alwnce;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/span")
	 public WebElement offer;
	 
	 @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-over-tolerance-worklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[10]/div/div/span")
	 public WebElement amnt;
	 
	 @FindBy(xpath="//*[@id='worklist']/div/div/div[3]/input")
	 public WebElement smartDrpdwn;
	 
	 @FindBy(xpath="//*[@id='ta-worklist-0']")
	 public WebElement valueClk;
	 
//	  @FindBy(xpath="//*[@id='ngb-popover-17']/div[2]")
	 @FindBy(className="popover-body")
	 public WebElement warngMsgMisc;
	
	@FindBy(xpath="//*[@id='allowanceType']/div/div/div[3]/input")
	public WebElement allwTypeBoxII;
	
	@FindBy(id="ta-alwncTypeValue-0")
	public WebElement perffirst;
	
	@FindBy(xpath="//*[@id=\"performanceCode1\"]/div/div")
	public WebElement perf1BoxII;
	
	@FindBy(id="ta-perfOneValue-0")
	public WebElement perf1ValNew;
	
	@FindBy(id="ta-perfOneValue-1")
	public WebElement perf1ValNew2;
	 
	@FindBy(xpath="//*[@id=\"performanceCode2\"]/div/div/div[2]/input")
	public WebElement perf2BoxII;
	
	@FindBy(id="ta-perfTwoValue-0")
	public WebElement perf2ValNew;
	
	@FindBy(id="ta-alwncTypeValue-1")
	public WebElement TYPEA; 
	
	@FindBy(xpath="//*[@id=\"performanceCode1\"]/div/div/div[2]")
	public WebElement perf1A;
	 

	 public String warngMsgMiscc(WebDriver Driver) {

		 return warngMsgMisc.getText();
			  
		}

	 public String OTWorklistLeftTxt(WebDriver Driver) {

		 return OTWorklistLeft.getText();
			  
		}
	 
	 
	 public String valueClkk(WebDriver Driver) {

		 valueClk.click();
		  return null;	  
		}	
	 
	 
	 public String smartDrpdwnn(WebDriver Driver) {

		  smartDrpdwn.sendKeys("Ajith");
		  return null;	  
		}	
	 
	 

	 public String amntt(WebDriver Driver) {

		 return amnt.getText();
			  
		}	
	 
	 public String offerr(WebDriver Driver) {

		 return offer.getText();
			  
		}	
	 
	 public String alwncee(WebDriver Driver) {

		 return alwnce.getText();
			  
		}	
	 
	 public String sectionn(WebDriver Driver) {

		 return section.getText();
			  
		}	
	 
	 public String areaa1(WebDriver Driver) {

		 return areaa.getText();
			  
		}	
	 
	 
	 public String incmTypee(WebDriver Driver) {

		 return incmType.getText();
			  
		}	
	 
	 public String blngNamee(WebDriver Driver) {

		 return blngName.getText();
			  
		}	 
	 
	 
	 public String brLabell(WebDriver Driver) {

		 return brLabel.getText();
			  
		}	 
	 
	 public String paginationTopp(WebDriver Driver) {

		  paginationTop.click();
		  return null;
			  
		}
	 
	 public String OTWorklistDataa(WebDriver Driver) {

		 return OTWorklistData.getText();
			  
		}
	 
	 public String OTWorklistDataaClk(WebDriver Driver) {

		 OTWorklistData.click();
			return null;
		}
	 
	 public String OTWorklistData2a(WebDriver Driver) {

		 return OTWorklistData2.getText();
			  
		}
	 
	 
	 public String OTWorklistLeftt(WebDriver Driver) {

		 OTWorklistLeft.click();
			return null;
		}
	  
	 public String invHist4t(WebDriver Driver) {

		 return invHist4.getText();
			  
		}
	 
	 
	 public String invHist3t(WebDriver Driver) {

		 return invHist3.getText();
			  
		}
	 
	 public String invHist1t(WebDriver Driver) {

		 return invHist1.getText();
			  
		}
	 
	 public String invHist2t(WebDriver Driver) {

		 return invHist2.getText();
			  
		}
	 
	 public String statusHistt(WebDriver Driver) {

		 return statusHist.getText();
			  
		}
	 
	 public String usrIDHistt(WebDriver Driver) {

		 return usrIDHist.getText();
			  
		}
	 
	 public String toHistt(WebDriver Driver) {

		 return toHist.getText();
			  
		}
	 
	 public String frmHistt(WebDriver Driver) {

		 return frmHist.getText();
			  
		}
	 
	 public String alwnceHistoryy(WebDriver Driver) {

		 return alwnceHistory.getText();
			  
		}
	 
	 
	 public String amntincHistoryy(WebDriver Driver) {

		 return amntincHistory.getText();
			  
		}
	 
	 public String incmHistoryy(WebDriver Driver) {

		 incmHistory.click();
			return null;
		}
	 
	 public String bilNdAcruMiscc(WebDriver Driver) {

		 bilNdAcruMisc.click();
			return null;
		}
	 
	 
	 public String addIncomeMiscc(WebDriver Driver) {

		 addIncomeMisc.click();
			return null;
		}
	 
	 public String acruelablMiscc(WebDriver Driver) {

		 acruelablMisc.click();
			return null;
		}
	 
	 
	 
	 public String miscIncomeWarnn(WebDriver Driver) {

		 miscIncomeWarn.click();
			return null;
		}


	public String bilNdacruu(WebDriver Driver) {

		bilNdacru.click();
		return null;
	}

	public String acruelabll(WebDriver Driver) {

		acruelabl.click();
		return null;
	}

	public String miscWarningMsgg(WebDriver Driver) {

		return miscWarningMsg.getText();
	}
	
	public String miscWarningMsgIIg(WebDriver Driver) {

		return miscWarningMsgII.getText();
	}
	
	
	public String WarningMsgg(WebDriver Driver) {

		return WarningMsg.getText();
	}

	public String incomeWarningg(WebDriver Driver) {

		incomeWarning.click();
		return null;
	}

	public String alwncTypDrpp(WebDriver Driver) {

		alwncTypDrp.click();
		return null;
	}

	public String xternall(WebDriver Driver) {

		xternal.click();
		return null;
	}

	public String errMsgg(WebDriver Driver) {

		return errMsg.getText();
	}

	public boolean bRTypeRetailFieldAccValue() throws InterruptedException {
		
		Thread.sleep(2500);
		accLkUpVal.click();
		Thread.sleep(2500);
		//selAccLkUpVal.click();
		selAccLkUpValII.click();

		if (accLkUpVal.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public boolean bRTypeRetailFieldAccValueII() throws InterruptedException {

		accLkUpVal.click();
		Thread.sleep(2000);
		selAcctlkupVal14.click();

		if (accLkUpVal.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public String closeBtnn(WebDriver Driver) {

		closeBtn.click();
		return null;
	}

	public String closeBtnnII(WebDriver Driver) {

		closeBtnII.click();
		return null;
	}

	public String cogsNumAcnt2(WebDriver Driver) {

		return actLukUpCogs.getText();
	}

	public String cogsNumAcnt3(WebDriver Driver) {

		return actLukUpCogs.getAttribute("value");
	}

	public String cogsNumAcnt(WebDriver Driver) {

		WebElement elem = actLukUpCogs;
		return elem.getText();
		// return elem.getAttribute("value");

	}

	public String cogsTypee(WebDriver Driver) {

		cogsType.click();
		return null;
	}

	public String allwAmntt(WebDriver Driver) {

		return allwAmnt.getText();

	}

	public String allwAmnttt(WebDriver Driver) {

		leadCICItem.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");

		return null;

	}

	public String allwAmntTab(WebDriver Driver) {

		leadCICItem.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				"20");

		return null;

	}

	public String differntAmnt(WebDriver Driver) {

		leadCICItem.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				Keys.TAB, "25");

		return null;

	}

	public String itemDetailExpp(WebDriver Driver) {

		itemDetailExp.click();
		return null;
	}

	public boolean bRTypeRetailFieldLeadCIC() throws BiffException, IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				//s1 = s.getCell(7, i).getContents();
				s1 = s.getCell(19, i).getContents();
				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
	}
	

	public boolean bRTypeRetailFieldLeadCIC942() throws BiffException, IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(11, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean bRTypeRetailFieldLeadCIC942invalid() throws BiffException, IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(12, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean bRTypeRetailFieldLeadCICnoOfset() throws BiffException,
			IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(19, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean bRTypeRetailFieldLeadCICnoOfsetII() throws BiffException,
			IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(9, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean bRTypeRetailFieldLeadCICnoOfsetIII() throws BiffException,
			IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
		LCIC.click();
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(10, i).getContents();

				Thread.sleep(3000);

				LCIC.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		if (LCIC.getAttribute("value").equals(s1)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean bRTypeRetailFieldStartDt() throws ParseException {

		fromCal.click();

		fromCalopen.click();

		if (billDateFrom.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldEndDt() {

		toCal.click();
		toCalOpen.click();

		if (billDateTo.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public Boolean allwtypeCOGS() throws InterruptedException {

		allwTypeBox.click();

		if (allwType0.getText().equals("C") && allwType1.getText().equals("A")) {
			return true;
		} else {
			return false;
		}
	}

	public String itemAlwType() throws InterruptedException {

		if (itemizedLabel.getText().equals("ITEMIZED")) {

			return allwTypeLabel.getText();
		}
		return null;

	}

	public Boolean allwTP1P2() throws InterruptedException {

		//allwType0.click();
		allwTypeBoxII.click();
		Thread.sleep(5000);
	//	 perf1Box.click();
	
		 perf1BoxII.click();
		 Thread.sleep(2000);

		if (perf1ValNew.getText().equals("01") && perf1ValNew2.getText().equals("48")) {
			perf1ValNew.click();
			Thread.sleep(3000);
			perf2BoxII.click();
			if (perf2ValNew.getText().equals("01")) {

//				perf1BoxAfterSel.click();
//				Thread.sleep(3000);
//				p1AlwT1.click();
//				Thread.sleep(5000);
//				perf1ValNew2.click();
//				Thread.sleep(5000);
				
				return true;
//				if (p2AlwT0.getText().equals("85")
//						&& p2AlwT11.getText().equals("88")) {
//					return true;
//
//				}
			}
		}
		return false;
	}

	public Boolean allwSP1P2() throws InterruptedException {

		// allwTypeBox.click();
	//	alwncTypDrpp(Driver);
		allwTypeBoxII.click();
		Thread.sleep(5000);
		
	 
		TYPEA.click();
		Thread.sleep(5000);
		//perf1Box.click();

		if (perf1A.getText().equals("A")) {
//			p1AlwT0.click();
//			Thread.sleep(5000);
//			perf2Box.click();
//			Thread.sleep(3000);
//			if (p2AlwT0.getText().equals("08")
//					&& p2AlwT11.getText().equals("88")
//					&& p3val3.getText().equals("96")
//					&& p3val4.getText().equals("99")) {

				// perf1BoxAfterSel.click();
				// p1AlwT1.click();
				// Thread.sleep(2000);
				// perf2Box.click();

				// if (p2AlwT0.getText().equals("01")
				// && p2AlwT11.getText().equals("88")) {
				return true;
				// }
			//}
		}
		return false;
	}

	public String notesTabFlatAmt(WebDriver Driver) throws InterruptedException {

		notesComment.sendKeys("Test Notes Automation");
		notesComment.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				"40000");

		Thread.sleep(5000);

		notesComment.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "10000");

		return null;
	}
	
	
	
	public String notesFlatAmntClear(WebDriver Driver){
		
		notesComment.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,Keys.CLEAR,"10");
		
		return null;
	}

	public String notesTabFlatAmtII(WebDriver Driver)
			throws InterruptedException {

		notesComment.sendKeys("Test Notes Automation");
		notesComment.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				"1");

		Thread.sleep(5000);

		notesComment.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
				Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, "50000");

		return null;
	}
	
	public String incAmntt(WebDriver Driver) throws InterruptedException{
		
		
		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		Thread.sleep(2000);
		incAmnt.findElement(By.className("form-control")).sendKeys("1");
		
			 return null;
			 
		}

	public GenericFactoryVI(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}
}
