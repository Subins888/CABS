package com.albertsons.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class GenericFactorySJX {
              WebDriver Driver;
              GenericFactorySJX POJS10;
              GenericFactorySJIX POJS9;

              public GenericFactorySJX(WebDriver Driver) {
                             this.Driver = Driver;
                             PageFactory.initElements(Driver, this);
              }

              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/plain-button/button")
              WebElement brCancel;
              @FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog")
              public WebElement warnDialog;

              @FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
              public WebElement warnYes;
              @FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
              public WebElement warnNo;

              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-home/div/div/nav/ol/li")
              public WebElement homePage;
              @FindBy(xpath = "//*[@id='billingRecordId']")
              public WebElement billRecId;
              @FindBy(xpath = "//*[@id='allow-tab']/div[1]/i-feather")
              public WebElement alwTab;
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[1]/i-feather")
              public WebElement advSearch; 
              @FindBy(xpath = "//*[@id='accountLookupType']/div/div/div[2]/input")
              public WebElement acctLkUpTypeClick;
              @FindBy(xpath = "//*[@id='ta-accountLookupType-0']")
              public WebElement acctLkUpTypeRetail;              
              @FindBy(xpath = "//*[@id='accountLookupValue']/div/div/div[2]/input")
              public WebElement acctLkUpValClick;
              @FindBy(xpath = "//*[@id='ta-accountLookupValue-0']")
              public WebElement acctLkUpValRetail;  
              @FindBy(xpath = "//*[@id='section']/div/div/div[2]/input")
              public WebElement sectionClick;
              @FindBy(xpath = "//*[@id='ta-section-0']")
              public WebElement sectionVal;
              @FindBy(xpath = "//*[@id='allowanceType']/div/div/div[2]/input")
              public WebElement alwTypeClick;
              @FindBy(xpath = "//*[@id='ta-alwncTypeValue-0']")
              public WebElement alwTypeVal;
              @FindBy(xpath = "//*[@id='performanceCode1']/div/div/div[2]/input")
              public WebElement alwPerf1Click;
              @FindBy(xpath = "//*[@id='ta-perfOneValue-0']")
              public WebElement alwPerf1Val;
              @FindBy(xpath = "//*[@id='performanceCode2']/div/div/div[2]/input")
              public WebElement alwPerf2Click;
              @FindBy(xpath = "//*[@id='ta-perfTwoValue-0']")
              public WebElement alwPerf2Val;
              @FindBy(xpath = "//*[@id='flatAmountFrom']/input")
              public WebElement fltAmtFromVal;
              @FindBy(xpath = "//*[@id='flatAmountTo']/input")
              public WebElement fltAmtToVal;
              @FindBy(xpath = "//*[@id='flatAmountFrom']/div/span")
              public WebElement fltAmtFromValdollar;
              @FindBy(xpath = "//*[@id='flatAmountTo']/div/span")
              public WebElement fltAmtToValdollar;  
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div")
              public WebElement areaResult;

              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/span")
              public WebElement sectionResult;

              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[14]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span[1]")
              public WebElement area_lkupType;
                                                          
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[14]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span[2]")
              public WebElement area_lkupVal;           
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/div/span")
              public WebElement alwncVal;    
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[9]/div/span[1]/label")
              public WebElement flatamtSort;              
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/span")
              public WebElement flatamtVal;
                             
              @FindBy(xpath = "//*[@id='dialog']/div/div/div[2]/input")
              public WebElement dialogClick;
              @FindBy(xpath = "//*[@id='ta-dialogName-0']")
              public WebElement dialogActive;
              @FindBy(xpath = "//*[@id='ta-dialogName-1']")
              public WebElement dialogResolved;       
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span[1]")
              public WebElement area_Multiple_lkTy;              
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div/span[2]")
              public WebElement area_Multiple_lkTyVal;        
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/span")
              public WebElement section_Multiple;    
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/div/span[1]")
              public WebElement alw_Multiple;                         
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/plain-button/button")
              public WebElement search_clear;            
              @FindBy(xpath = "//*[@id='ta-accountLookupType-1']")
              public WebElement acctLkUpTypeCogs; 
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/div")
              public WebElement acctLkUpTypeCogsRes;                       
              @FindBy(xpath = "//*[@id='accountLookupType']/div/span[1]")
              public WebElement acctLkUpTypeCogsClear;
              @FindBy(xpath = "//*[@id='section']/div/div/div[2]/span[1]")
              public WebElement sectionSelected;      
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[11]/div/div")
    public WebElement activeResult;  
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div")
    public WebElement sectionAll; 
    @FindBy(xpath="//*[@id='dialog']/div/span[1]")
    public WebElement activeClear;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[11]/div/div")
    public WebElement ResolvedResult;
    
    @FindBy(xpath="//*[@id='allowanceType']/div/span[1]")
    public WebElement alwTClear;
    
    @FindBy(xpath="//*[@id='performanceCode1']/div/span[1]")
    public WebElement perf1Clear;
    @FindBy(xpath="//*[@id='performanceCode2']/div/span[1]")
    public WebElement perf2Clear;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[11]/div/div")
    public WebElement activeResultMisc;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[11]/div/div/span")
    public WebElement miscActiveRes;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/div")
    public WebElement alwResult;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[2]/a")
    public WebElement incomeWorkList;
    
    @FindBy(xpath="//*[@id='worklist']/div/div/div[2]/span[2]")
    public WebElement incomeWorkListDropDownVal;
    
    @FindBy(xpath="//*[@id='worklist']/div/div/div[3]/input")
    public WebElement incomeWorkListDropDown;
    
    @FindBy(xpath="//*[@id='ta-worklist-22']")
    public WebElement testIdSelected;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")
    public WebElement incomeWorkListBR;
                                                          
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
    public WebElement incomeWorkListBRVal;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[3]/div/span[1]/label")
    public WebElement incomeWorkListBillName;
    @FindBy(xpath=" //*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div")
    public WebElement incomeWorkListBillNameVal;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[4]/div/span[1]/label")
    public WebElement incomeWorkListIncomeType;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div")
    public WebElement incomeWorkListIncomeTypeVal;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[5]/div/span[1]/label")
    public WebElement incomeWorkListIncomeStat;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div")
    public WebElement incomeWorkListIncomeStatVal;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[6]/div/span[1]/label")
    public WebElement incomeWorkListArea; 
  
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div")
    public WebElement incomeWorkListAreaVal;
    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span[1]")
    public WebElement incomeWorkListAreaVal1;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[7]/div/span[1]/label")
    public WebElement incomeWorkListSection;
   
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/span")
    public WebElement incomeWorkListSectionVal;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[8]/div/span[1]/label")
    public WebElement incomeWorkListAlw;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/div")
    public WebElement incomeWorkListAlwVal;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[9]/div/span[1]/label")
    public WebElement incomeWorkListOffer;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/span")
    public WebElement incomeWorkListOfferVal;  
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[10]/div/span[1]/label")
    public WebElement incomeWorkListFlatRemain;    
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[10]/div/div/span")
    public WebElement incomeWorkListFlatRemainVal;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[11]/div/span[1]/label")
    public WebElement incomeWorkListDialog;  
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-brworklist/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[11]/div/div")
    public WebElement incomeWorkListDialogVal;  
    @FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/button")
    public WebElement miscIncSave;  
    @FindBy(xpath="//*[@id='ta-brStatus-0']")
    public WebElement miscBrStatus;
    @FindBy(xpath="//*[@id='brStatus']/div/div/div[3]/input")
    public WebElement miscBrStatusClick;
    @FindBy(xpath="//*[@id='ta-brStatus-1']")
    public WebElement miscBrStatusEnd;
    @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
    public WebElement miscBrSave;
    
    
              public String brCnclClick(WebDriver Driver) {
                             brCancel.click();
                             System.out.println("Clicked on cancel");

                             return null;
              }
              


              public String WarningHeader(WebDriver Driver) {
                             return warnDialog.findElement(By.className("modal-header")).getText();

              }

              public String WarningBody(WebDriver Driver) {
                             return warnDialog.findElement(By.className("modal-body")).getText();

              }

              public String RetrieveBR(WebDriver Driver) {
                             WebElement brVal = billRecId.findElement(By.className("form-control"));
                             return brVal.getAttribute("value");
              }

              public String ItemAmt(WebDriver Driver) {
                             // return deductnum.findElement(By.className("form-control")).getText();
                             return POJS9.itemDetailsAmnt.getAttribute("value");

              }

}
