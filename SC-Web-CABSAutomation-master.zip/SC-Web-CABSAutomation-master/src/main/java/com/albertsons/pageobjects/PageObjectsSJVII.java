package com.albertsons.pageobjects;

import java.io.IOException;

import java.util.ArrayList;

import java.util.Collections;

import java.util.Properties;

import jxl.common.Assert;

import org.apache.poi.hssf.usermodel.HSSFCell;

import org.apache.poi.hssf.usermodel.HSSFSheet;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.openqa.selenium.By;

import org.openqa.selenium.Dimension;

import org.openqa.selenium.OutputType;

import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;

import com.albertsons.reportGeneration.ExtendBaseClass;

import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsSJVII extends ExtendBaseClass {

	WebDriver Driver;

	GenericFactory pageFact;

	Properties prop;

	HSSFWorkbook workbook;

	HSSFSheet sheet;

	HSSFCell cell;

	GenericFactoryIV pageFactIV;

	GenericFactorySprint3 pageFactAS3;

	GenericFactorySJVI pageFactSJVI;

	GenericFactorySJVII pageFactSJVII;

	GenericFactoryV pageFactV;

	public PageObjectsSJVII(WebDriver Driver) {

		this.Driver = Driver;

		PageFactory.initElements(Driver, this);

	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;

		// File source = ts.getScreenshotAs(OutputType.FILE);

		String source1 = ts.getScreenshotAs(OutputType.BASE64);

		return source1;

	}

	@Test

	public String paybackWorkListMenuClick(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();

		Thread.sleep(3500);

		pageFactSJVII.paybackWorkListMenu(Driver);

		paybackWorkListHyperLinkVal(Driver);

		return null;

	}

	public String paybackWorkListHyperLinkVal(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions.elementToBeClickable(pageFactSJVII.paybackWorkListMenu));

		Actions action = new Actions(Driver);

		action.moveToElement(pageFactSJVII.paybackWorkListMenu).perform();

		System.out.println("On clicking PAYBACK WORKLIST menu changed to color  : Blue {"
				+ pageFactSJVII.paybackWorkListMenu.getCssValue("color") + "}");

		extentTest.log(LogStatus.INFO, "On clicking PAYBACK WORKLIST menu changed to color  : Blue {"
				+ pageFactSJVII.paybackWorkListMenu.getCssValue("color") + "}");

		return null;

	}

	public String paybackWorkListIncmCount(WebDriver Driver) throws InterruptedException {

		Thread.sleep(5000);

		String IncCount = pageFactSJVII.paybackWorkListCount(Driver);

		String IncomeCount = IncCount.replaceAll("\\D+", "");

		System.out.println("Count of income records for selected user in the Payback work list : " + IncomeCount);

		extentTest.log(LogStatus.INFO,
				"Count of income records for selected user  in the Payback work list : " + IncomeCount);

		return null;

	}

	public String PaybackWorkListFields(WebDriver Driver) throws InterruptedException, IOException {

		Thread.sleep(5000);

		String BRList = pageFactSJVII.paybackWorkListDataBR(Driver).replaceAll("\\W+", "");

		if (BRList.equals("BR")) {

			System.out.println("PASS:  BR Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "BR Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  BR Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "BR Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataInv(Driver).equals("Invoice")) {

			System.out.println("PASS:  Invoice Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Invoice Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Invoice Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Invoice Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataBillName(Driver).equals("Billing Name")) {

			System.out.println("PASS:  Billing Name Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Billing Name Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Billing Name is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Billing Name Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataArea(Driver).equals("Area")) {

			System.out.println("PASS:  Area Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Area Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Area Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Area Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataOffer(Driver).equals("Offer")) {

			System.out.println("PASS:  Offer Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Offer Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Offer Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Offer Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataBillBy(Driver).equals("Billed By")) {

			System.out.println("PASS:  Billed By Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Billed By Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Billed By Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Billed By Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataInvDetails(Driver).equals("Invoice Details")) {

			System.out.println("PASS: Invoice Details Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Invoice Details Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Invoice Details Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Invoice Details Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(5000);

		if (pageFactSJVII.paybackWorkListDataInvReason(Driver).equals("Reason")) {

			System.out.println("PASS: Reason Field is displayed in PayBack WorkList table");

			extentTest.log(LogStatus.INFO, "Reason Field is displayed in PayBack WorkList table");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  Reason Field is not displayed in PayBack WorkList table");

			extentTest.log(LogStatus.FAIL, "Reason Field is not displayed in PayBack WorkList table"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;

	}

	public String PaybackWorkListFieldsVal(WebDriver Driver) throws InterruptedException {

		Thread.sleep(5000);

		String BrVal = pageFactSJVII.paybackWorkListDataBRVal(Driver);

		System.out.println("BR value in the Payback work list is : " + BrVal);

		extentTest.log(LogStatus.INFO, "BR value in the Payback work list is : " + BrVal);

		String InvVal = pageFactSJVII.paybackWorkListDataInvVal(Driver);

		System.out.println("Invoice value in the Payback work list is : " + InvVal);

		extentTest.log(LogStatus.INFO, "Invoice value in the Payback work list is : " + InvVal);

		String BillNmVal = pageFactSJVII.paybackWorkListDataBillNameVal(Driver);

		System.out.println("Billing Name value in the Payback work list is : " + BillNmVal);

		extentTest.log(LogStatus.INFO, "Billing Name value in the Payback work list is : " + BillNmVal);

		Thread.sleep(5000);

		String AreaVal1 = pageFactSJVII.paybackWorkListDataAreaVal(Driver);

		String AreaVal2 = pageFactSJVII.paybackWorkListDataAreaVal2(Driver);

		System.out.println(
				"Area values shown in double decker format in the Payback work list  : " + AreaVal1 + " " + AreaVal2);

		extentTest.log(LogStatus.INFO,
				"Area values shown in double decker format in the Payback work list  : " + AreaVal1 + " " + AreaVal2);

		String OfferRtVal = pageFactSJVII.paybackWorkListDataOfferValRt(Driver);

		System.out.println("Offer nbr value for retail BR in the Payback work list is : " + OfferRtVal);

		extentTest.log(LogStatus.INFO, "Offer nbr value for retail BR in the Payback work list is : " + OfferRtVal);

		String OfferMiscVal = pageFactSJVII.paybackWorkListDataOfferValMisc(Driver);

		System.out.println("Offer nbr value for Misc BR in the Payback work list is  blank: " + OfferMiscVal);

		extentTest.log(LogStatus.INFO,
				"Offer nbr value for Misc BR in the Payback work list is  blank: " + OfferMiscVal);

		String BillByVal = pageFactSJVII.paybackWorkListDataBillByVal(Driver);

		System.out.println("Billed By value for retail BR in the Payback work list is : " + BillByVal);

		extentTest.log(LogStatus.INFO, "Billed By value for retail BR in the Payback work list is : " + BillByVal);

		String Inv1 = pageFactSJVII.paybackWorkListDataInvDetails1(Driver);

		String Inv2 = pageFactSJVII.paybackWorkListDataInvDetails2(Driver);

		System.out.println("Invoice Details values shown in double decker format in the Payback work list  : " + Inv1
				+ " " + Inv2);

		extentTest.log(LogStatus.INFO,
				"Invoice Details values shown in double decker format in the Payback work list  : " + Inv1 + " "
						+ Inv2);

		String InvRsn1 = pageFactSJVII.paybackWorkListDataInvReason1(Driver);

		String InvRsn2 = pageFactSJVII.paybackWorkListDataInvReason2(Driver);

		System.out.println("Invoice Reason values shown in  double decker format in the Payback work list  : " + InvRsn1
				+ ", " + InvRsn2);

		extentTest.log(LogStatus.INFO,
				"Invoice Reason values shown in double decker format in the Payback work list  : " + InvRsn1 + ", "
						+ InvRsn2);

		return null;

	}

	public String PaybackMultipleIncomeVal(WebDriver Driver) throws InterruptedException {

		String BrVal = pageFactSJVII.paybackWorkListDataBRVal(Driver);

		System.out.println("First BR value in the Payback work list is : " + BrVal);

		extentTest.log(LogStatus.INFO, "First BR value in the Payback work list is : " + BrVal);

		String InvVal = pageFactSJVII.paybackWorkListDataInvVal(Driver);

		System.out.println("First Invoice value in the Payback work list is : " + InvVal);

		extentTest.log(LogStatus.INFO, "First Invoice value in the Payback work list is : " + InvVal);

		String BrVal2 = pageFactSJVII.paybackWorkListDataBRVal2(Driver);

		System.out.println("Second BR value in the Payback work list is : " + BrVal2);

		extentTest.log(LogStatus.INFO, "Second BR value in the Payback work list is : " + BrVal2);

		String InvVal2 = pageFactSJVII.paybackWorkListDataInvVal2(Driver);

		System.out.println("Second Invoice value in the Payback work list is : " + InvVal2);

		extentTest.log(LogStatus.INFO, "Second Invoice value in the Payback work list is : " + InvVal2);

		System.out.println(
				"BR is listed more than one time since multiple payback income records are associated with it");

		extentTest.log(LogStatus.INFO,
				"BR is listed more than one time since multiple payback income records are associated with it");

		return null;

	}

	public String ascndingBR(WebDriver Driver) throws InterruptedException, IOException {

		Thread.sleep(5000);

		String BrVal1 = pageFactSJVII.paybackWorkListDataBRVal(Driver);

		String BrVal2 = pageFactSJVII.paybackWorkListDataBRVal2(Driver);

		String BrVal3 = pageFactSJVII.paybackWorkListDataBRVal3(Driver);

		// BR nbr sorting

		ArrayList<String> sortList = new ArrayList<String>();

		ArrayList<String> ObtList = new ArrayList<String>();

		sortList.add(BrVal1);

		sortList.add(BrVal2);

		sortList.add(BrVal3);

		ObtList.add(BrVal1);

		ObtList.add(BrVal2);

		ObtList.add(BrVal3);

		Collections.sort(sortList);

		// Inv nbr sorting

		String InvValS1 = pageFactSJVII.paybackWorkListDataInvVal(Driver);

		String InvValS2 = pageFactSJVII.paybackWorkListDataInvVal2(Driver);

		String InvValS3 = pageFactSJVII.paybackWorkListDataInvVal3(Driver);

		ArrayList<String> sortListInv = new ArrayList<String>();

		ArrayList<String> ObtListInv = new ArrayList<String>();

		sortListInv.add(InvValS1);

		sortListInv.add(InvValS2);

		sortListInv.add(InvValS3);

		ObtListInv.add(InvValS1);

		ObtListInv.add(InvValS2);

		ObtListInv.add(InvValS3);

		Collections.sort(sortListInv);

		int sortFlagBR = 0;

		int sortFlagInv = 0;

		System.out.println("BR obtained list from UI " + ObtList);

		extentTest.log(LogStatus.INFO, "BR obtained list from UI " + ObtList);

		System.out.println("BR sorted list is " + sortList);

		extentTest.log(LogStatus.INFO, "BR sorted list is" + sortList);

		System.out.println("Invoices obtained list from UI " + ObtListInv);

		extentTest.log(LogStatus.INFO, "Invoiced obtained list from UI " + ObtListInv);

		System.out.println("Invoices sorted list is " + sortListInv);

		extentTest.log(LogStatus.INFO, "Invoices sorted list is" + sortListInv);

		if (sortList.equals(ObtList)) {

			sortFlagBR = 1;

			System.out.println("BR is sorted");

		}

		else {

			sortFlagBR = 0;

			System.out.println("BR is Not sorted");

		}

		if (sortListInv.equals(ObtListInv)) {

			sortFlagInv = 1;

			System.out.println("Invoice nbr is sorted");

		}

		else {

			sortFlagInv = 0;

			System.out.println("Invoice nbr is Not sorted");

			System.out.println("Obtained inv nbr as" + ObtListInv);

			System.out.println("Sorted inv nbr as" + sortListInv);

		}

		// validate BR,invoice nbr sorting

		if (sortFlagBR == 1 && sortFlagInv == 1)

		{

			System.out.println("Default sort is by Billing record ID, Invoice Nbr - ascending order");

			extentTest.log(LogStatus.INFO, "Default sort is by Billing record ID, Invoice Nbr - ascending order");
		}

		else

		{

			String source = aftermthd(Driver);

			System.out.println("Default sort is not by ascending order  - Billing record ID, Invoice Nbr ");

			extentTest.log(LogStatus.FAIL, "Default sort is not  by ascending order - Billing record ID, Invoice Nbr"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;

	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));

		return null;

	}

	public String BRClick(WebDriver Driver) throws InterruptedException, IOException {

		pageFactSJVII.BRclick(Driver);

		System.out
				.println("PASS: User having  at least view-only role in the selected team is able to click on the BR ");

		extentTest.log(LogStatus.INFO,
				"User having at least view-only role in the selected team is able to click on the BR ");

		waitforbrtxt(Driver);

		if (pageFactSJVII.newBRPage(Driver).contains("New BR")) {

			System.out
					.println("PASS: On clicking on BR,User is  taken to billing record page for the billing record ID");

			extentTest.log(LogStatus.INFO,
					"On clicking on BR,User is  taken to billing record page for the billing record ID");

		} else {

			String source = aftermthd(Driver);

			System.out.println("FAIL:  User is  not taken to billing record page for the billing record ID");

			extentTest.log(LogStatus.FAIL, "User is  not taken to billing record page for the billing record ID"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;

	}

	@BeforeTest

	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);

		pageFactV = new GenericFactoryV(Driver);

		pageFactAS3 = new GenericFactorySprint3(Driver);

		pageFact = new GenericFactory(Driver);

		pageFactSJVI = new GenericFactorySJVI(Driver);

		pageFactSJVII = new GenericFactorySJVII(Driver);

	}

}
