package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsIX extends ExtendBaseClass {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactoryVI pageFactVI;
	GenericFactoryVII pageFactVII;
	GenericFactoryVIII pageFactVIII;
	GenericFactoryV pageFactV;
	GenericFactorySprint3 pageFactAS3;
	GenericFactoryJSprint3 pageFactJS3;
	GenericFactoryIX pageFactIX;
	PageObjectsVIII POVIII;

	static String billingId;

	public PageObjectsIX(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String readExcel(WebDriver Driver, String tcName) throws IOException {
		String xlfile = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fis = new FileInputStream(xlfile);

		HSSFWorkbook CABS_TestRslt = null;

		CABS_TestRslt = new HSSFWorkbook(fis);

		HSSFSheet s = CABS_TestRslt.getSheet("TestExecutionMetrics");

		int Norows = s.getLastRowNum();

		for (int i = 1; i <= Norows; i++) {

			String s1 = s.getRow(i).getCell(0).toString();

			String s2 = s.getRow(i).getCell(1).toString();
			String s3 = s.getRow(i).getCell(2).toString();

			// System.out.println("s1" + s1);
			// System.out.println("s2" + s2);
			// System.out.println("s3" + s3);
			// System.out.println(tcName);

			if (s1.contentEquals(tcName)) {

				if (s2.contentEquals("Y")) {

					return s3;
				} else {

					return null;
				}
			}
		}
		return null;
	}

	public String writeExcel(WebDriver Driver, String status, String tcName)
			throws IOException {
		String xlfile = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fis = new FileInputStream(xlfile);

		HSSFWorkbook CABS_TestRslt = null;

		CABS_TestRslt = new HSSFWorkbook(fis);

		HSSFSheet s = CABS_TestRslt.getSheet("TestExecutionMetrics");

		int Norows = s.getLastRowNum();

		for (int i = 1; i <= Norows; i++) {

			String s1 = s.getRow(i).getCell(0).toString();

			String s2 = s.getRow(i).getCell(1).toString();
			String s3 = s.getRow(i).getCell(2).toString();

			// System.out.println("s1" + s1);
			// System.out.println("s2" + s2);
			// System.out.println("s3" + s3);

			if (s1.contentEquals(tcName)) {
				if (s2.contentEquals("Y")) {
					Row row = s.getRow(i);

					String[] valueToWrite = { status };

					int j = 5;

					Cell cell = row.createCell(j);
					System.out.println("Cell Created");

					cell.setCellValue(valueToWrite[0]);

					System.out.println("value written");

					fis.close();

					FileOutputStream fos = new FileOutputStream(xlfile);
					CABS_TestRslt.write(fos);
					fos.close();
					return null;

				}
			}

		}
		return null;
	}

	public String waitforSearchPage(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVII.searchApply));
		return null;
	}

	public String waitforSearchItem(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVIII.searchFirstItem));
		return null;
	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVII.createBillrcrd));
		return null;
	}

	public Boolean SearchData(WebDriver Driver, String valu)
			throws BiffException, IOException, InterruptedException {

		waitforBlngbtn(Driver);
		Thread.sleep(55000);
		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);
		Thread.sleep(5000);

		if (pageFactVIII.noDataa(Driver).contains("No data to display")) {

			String searchData = pageFactVIII.noDataa(Driver);
			System.out
					.println("Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
							+ searchData);
			extentTest
					.log(LogStatus.INFO,
							"Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
									+ searchData);

		} else {
			System.out
					.println("Search page NOT displayed by clicking on the Search Billing Record button");
			extentTest
					.log(LogStatus.FAIL,
							"Search page NOT displayed by clicking on the Search Billing Record button");

		}
		//New line added - Advanced Search BR input
		pageFactVII.advSearch.click();
		Thread.sleep(1500);
		
		System.out.println("value is " + valu);
		pageFactVII.searchBillId.findElement(By.className("form-control"))
				.sendKeys(valu);

		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		// waitforSearchItem(Driver);

		Thread.sleep(5000);
		pageFactVIII.searchFirstItemClk(Driver);

		waitforbrtxt(Driver);

		if (pageFact.BRtxt.isDisplayed()) {

			System.out.println("BR Page displayed");
			return true;

		} else {
			System.out.println("BR Page not displayed");

			return false;
		}

	}

	public String WarningYES(WebDriver Driver) {

		pageFactIX.warningYes.click();
		return null;
	}
	
	public String Search(WebDriver Driver) throws BiffException, IOException,
			InterruptedException {

				Thread.sleep(55000);
		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);
				Thread.sleep(5000);

		if (pageFactVIII.noDataa(Driver).contains("No data to display")) {

			String searchData = pageFactVIII.noDataa(Driver);
			System.out
					.println("Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
							+ searchData);
			extentTest
					.log(LogStatus.INFO,
							"Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
									+ searchData);

		} else {
			System.out
					.println("Search page NOT displayed by clicking on the Search Billing Record button");
			extentTest
					.log(LogStatus.FAIL,
							"Search page NOT displayed by clicking on the Search Billing Record button");

		}

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(18, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);

		return null;
	}

	public String SearchFirstItemClk(WebDriver Driver) {

		pageFactVIII.searchFirstItemClk(Driver);
		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String scroldown(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);
		act.moveToElement(pageFactIX.alwHistPlus).perform();
		return null;
	}

	public String headerCheck(WebDriver Driver) throws InterruptedException,
			IOException {

				Thread.sleep(5000);
		pageFactV.incmeButtonAddd(Driver);
		Thread.sleep(5000);
		pageFactIX.headerCheckBoxClk(Driver);
		System.out.println("Clicked on Header Flat Income check box");
		extentTest.log(LogStatus.INFO,
				"Clicked on Header Flat Income check box");
		scroldown(Driver);
		Thread.sleep(2500);

		if (pageFactIX.headerCheckBox.isSelected()) {

			String source = aftermthd(Driver);
			System.out
					.println("Header Flat Income checkbox still selected even after unchecking the check box");
			extentTest
					.log(LogStatus.FAIL,
							"Header Flat Income checkbox still selected even after unchecking the check box"
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
		} else {

			System.out
					.println("Header Flat Income checkbox successfully un-selected");
			extentTest.log(LogStatus.INFO,
					"Header Flat Income checkbox successfully un-selected");
		}

		try {

			if (pageFactIX.perfDate.isDisplayed()) {
				String source = aftermthd(Driver);
				System.out
						.println("Header Flat Income section displaying even after un-checking the checkbox");
				extentTest
						.log(LogStatus.FAIL,
								"Header Flat Income section displaying even after un-checking the checkbox"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			} else {
				System.out
						.println("Header Flat Income section not showing after un-checking the check box");
				extentTest
						.log(LogStatus.INFO,
								"Header Flat Income section not showing after un-checking the check box");
			}

		} catch (Exception e) {

			System.out
					.println("Header Flat Income section not showing after un-checking the check box");
			extentTest
					.log(LogStatus.INFO,
							"Header Flat Income section not showing after un-checking the check box");

		}

		return null;
	}

	public String itemizedCheck(WebDriver Driver) throws IOException,
			InterruptedException {

				Thread.sleep(20000);
		pageFactIX.itemCheckBoxClk(Driver);

		System.out.println("Clicked on Itemized Income check box");
		extentTest.log(LogStatus.INFO, "Clicked on Itemized Income check box");

		Thread.sleep(2500);

		if (pageFactIX.itemCheckBox.isSelected()) {

			String source = aftermthd(Driver);
			System.out
					.println("Itemized Income checkbox still selected even after unchecking the check box");
			extentTest.log(
					LogStatus.FAIL,
					"Itemized Income checkbox still selected even after unchecking the check box"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		} else {

			System.out
					.println("Itemized Income checkbox successfully un-selected");
			extentTest.log(LogStatus.INFO,
					"Itemized Income checkbox successfully un-selected");
		}

		try {

			if (pageFactIX.CICtxt.isDisplayed()) {
				String source = aftermthd(Driver);
				System.out
						.println("Itemized Income section displaying even after un-checking the checkbox");
				extentTest
						.log(LogStatus.FAIL,
								"Itemized Income section displaying even after un-checking the checkbox"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			} else {
				System.out
						.println("Itemized Income section not showing after un-checking the check box");
				extentTest
						.log(LogStatus.INFO,
								"Itemized Income section not showing after un-checking the check box");
			}

		} catch (Exception e) {

			System.out
					.println("Itemized Income section not showing after un-checking the check box");
			extentTest
					.log(LogStatus.INFO,
							"Itemized Income section not showing after un-checking the check box");

		}

		return null;
	}

	public String buttonEnabledCheck(WebDriver Driver) {

		try {

			if (pageFactIX.incCancel.isEnabled()
					&& pageFactIV.incSave.isEnabled()
					&& pageFactIV.incSave2.isEnabled()) {
				String source = aftermthd(Driver);
				System.out
						.println("Save, Submit and Cancel buttons are Enabled even after un-checking the Header and Itemized checkboxes");
				extentTest
						.log(LogStatus.FAIL,
								"Save, Submit and Cancel buttons are Enabled even after un-checking the Header and Itemized checkboxes"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			} else {
				System.out
						.println("Save, Submit and Cancel buttons are disabled as both Header and Itemized checkboxes are un-checked");
				extentTest
						.log(LogStatus.INFO,
								"Save, Submit and Cancel buttons are disabled as both Header and Itemized checkboxes are un-checked");
			}

		} catch (Exception e) {

			System.out
					.println("Save, Submit and Cancel buttons are disabled as both Header and Itemized checkboxes are un-checked");
			extentTest
					.log(LogStatus.INFO,
							"Save, Submit and Cancel buttons are disabled as both Header and Itemized checkboxes are un-checked");

		}

		return null;
	}

	public String headerCheckII(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactV.incmeButtonAddd(Driver);
		Thread.sleep(5000);

		scroldown(Driver);
		Thread.sleep(2500);

		if (pageFactIX.headerCheckBox.isDisplayed()) {

			System.out.println("Header Flat Income checkbox is selected");
			extentTest.log(LogStatus.INFO,
					"Header Flat Income checkbox is selected");

		} else {
			String source = aftermthd(Driver);
			System.out.println("Header Flat Income checkbox is un-selected");
			extentTest.log(
					LogStatus.FAIL,
					"Header Flat Income checkbox is un-selected"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		try {

			if (pageFactIX.CICtxt.isDisplayed()) {
				String source = aftermthd(Driver);
				System.out
						.println("User provided only Header Flat Income, but Itemized Income section is enabled");
				extentTest
						.log(LogStatus.FAIL,
								"User provided only Header Flat Income, but Itemized Income section is enabled"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			} else {
				System.out
						.println("Itemized Income section is disabled, as the user provided only Header Flat Income");
				extentTest
						.log(LogStatus.INFO,
								"Itemized Income section is disabled, as the user provided only Header Flat Income");
			}

		} catch (Exception e) {

			System.out
					.println("Itemized Income section is disabled, as the user provided only Header Flat Income");
			extentTest
					.log(LogStatus.INFO,
							"Itemized Income section is disabled, as the user provided only Header Flat Income");

		}

		return null;
	}

	public String headerCheckIII(WebDriver Driver) throws InterruptedException,
			IOException {

		try {
			Thread.sleep(55000);
			pageFactV.incmeButtonAddd(Driver);
			System.out.println("Clicked on Add Income Button");
			extentTest.log(LogStatus.INFO, "Clicked on Add Income Button");
			Thread.sleep(5000);

			scroldown(Driver);
			Thread.sleep(2500);

			if (pageFactIX.itemCheckBox.isDisplayed()) {

				System.out.println("Header Flat Income checkbox is selected");
				extentTest.log(LogStatus.INFO,
						"Header Flat Income checkbox is selected");

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Header Flat Income checkbox is un-selected");
				extentTest
						.log(LogStatus.FAIL,
								"Header Flat Income checkbox is un-selected"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));
			}

			try {

				if (pageFactIX.perfDate.isDisplayed()) {
					String source = aftermthd(Driver);
					System.out
							.println("User provided only Itemized Income, but Header Flat Income section is enabled");
					extentTest
							.log(LogStatus.FAIL,
									"User provided only Itemized Income, but Header Flat Income section is enabled"
											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));

				} else {
					System.out
							.println("Header Flat Income section is disabled, as the user provided only Itemized Income");
					extentTest
							.log(LogStatus.INFO,
									"Header Flat Income section is disabled, as the user provided only Itemized Income");
				}

			} catch (Exception e) {

				System.out
						.println("Header Flat Income section is disabled, as the user provided only Itemized Income");
				extentTest
						.log(LogStatus.INFO,
								"Header Flat Income section is disabled, as the user provided only Itemized Income");

			}
		} catch (Exception e) {

			System.out
					.println("Header Flat Income section is disabled, as the user do not have proper privilege to perform the action");
			extentTest
					.log(LogStatus.INFO,
							"Header Flat Income section is disabled, as the user do not have proper privilege to perform the action");

		}

		return null;
	}

	public String AlwnceBRNoHeader(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(3000);

		pageFact.allwtype();
		pageFact.allwTP1P2();
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String lastUpdateView(WebDriver Driver) throws InterruptedException,
			IOException {

				Thread.sleep(55000);
		pageFactIX.lastUpdateClk(Driver);
		Thread.sleep(2500);

		String LastUpdateDate = pageFactIX.lastUpdateTxt(Driver);
		String HistoryTxt = pageFactIX.HistoryTxt(Driver);

		if (pageFactIX.lastUpdateDate.isDisplayed()) {

			System.out.println("Last Update Date displaying is : "
					+ LastUpdateDate);
			extentTest.log(LogStatus.INFO, "Last Update Date displaying is : "
					+ LastUpdateDate);

			System.out.println("Last Updated History displaying is : "
					+ HistoryTxt);
			extentTest.log(LogStatus.INFO,
					"Last Updated History displaying is : " + HistoryTxt);

		} else {
			String source = aftermthd(Driver);

			System.out
					.println("Last Update Date not displaying in the dropdown");
			extentTest.log(
					LogStatus.FAIL,
					"Last Update Date not displaying in the dropdown"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		if (pageFactIX.statusTxt(Driver).contains("Current")) {

			System.out.println("The most recent Edit showing is 'Current'");
			extentTest.log(LogStatus.INFO,
					"The most recent Edit showing is 'Current'");

		} else {
			String source = aftermthd(Driver);
			System.out.println("The most recent Edit not showing 'Current'");
			extentTest.log(
					LogStatus.FAIL,
					"The most recent Edit not showing 'Current'"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;
	}

	public String modifyBR(WebDriver Driver) {

		pageFactIX.assignToClk(Driver);
		System.out.println("Modified Assign To User");
		extentTest.log(LogStatus.INFO, "Modified Assign To User");

		pageFactIX.BRSaveBtn.click();

		return null;
	}

	public String lastUpdateViewDisabled(WebDriver Driver)
			throws InterruptedException {

		try {
			Thread.sleep(55000);
			pageFactIX.lastUpdateClk(Driver);
			Thread.sleep(2500);
			pageFactIX.historyTxtClk(Driver);
			Thread.sleep(5000);

			try {

				if (pageFactIX.deduct.isEnabled()
						&& pageFactIX.blngName.isEnabled()
						&& pageFactIX.brStatus.isEnabled()
						&& pageFactIX.asignTo.isEnabled()
						&& pageFactIX.addIncome.isEnabled()) {
					String source = aftermthd(Driver);
					System.out
							.println("BR section is enabled, possible to update even the History");
					extentTest
							.log(LogStatus.FAIL,
									"BR section is enabled, possible to update even the History"
											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));

				} else {
					System.out
							.println("BR Section along with the Income Section is Disabled in the History view");
					extentTest
							.log(LogStatus.INFO,
									"BR Section along with the Income Section is Disabled in the History view");
				}

			} catch (Exception e) {

				System.out
						.println("BR Section along with the Income Section is Disabled in the History view");
				extentTest
						.log(LogStatus.INFO,
								"BR Section along with the Income Section is Disabled in the History view");

			}
		} catch (Exception e) {
			System.out
					.println("BR Section along with the Income Section is Disabled in the History view");
			extentTest
					.log(LogStatus.INFO,
							"BR Section along with the Income Section is Disabled in the History view");

		}

		return null;
	}

	public String overlapWarning(WebDriver Driver) throws InterruptedException,
			IOException {

		try {

			if (pageFactIX.warning.isDisplayed()) {

				System.out
						.println("Warning icon displaying properly on overlapped BR");
				extentTest.log(LogStatus.INFO,
						"Warning icon displaying properly on overlapped BR");

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("Warning icon NOT displaying properly on overlapped BR");
				extentTest
						.log(LogStatus.FAIL,
								"Warning icon NOT displaying properly on overlapped BR"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));
			}

		} catch (Exception e) {
			String source = aftermthd(Driver);
			System.out
					.println("Warning icon NOT displaying properly on overlapped BR");
			extentTest.log(
					LogStatus.FAIL,
					"Warning icon NOT displaying properly on overlapped BR"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		Thread.sleep(5000);

		// MOUSE OVER CODE

//		WebElement we = pageFactIX.warning;
//		Actions action = new Actions(Driver);
//		action.moveToElement(we).build().perform();
//		WebElement toolTipElement = pageFactIX.warningContent;
//		String toolTipText = toolTipElement.getText();
//		System.out.println(toolTipText);
//		extentTest.log(LogStatus.INFO, "The tooltip text displaying is: "
//				+ toolTipText);

		try {

			if (pageFactIX.addIncome.isEnabled()) {
				String source = aftermthd(Driver);
				System.out
						.println("Income section is enabled by default for overlapped items");
				extentTest
						.log(LogStatus.FAIL,
								"Income section is enabled by default for overlapped items"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			} else {
				System.out
						.println("Income section is disabled by default for overlapped items");
				extentTest
						.log(LogStatus.INFO,
								"Income section is disabled by default for overlapped items");
			}

		} catch (Exception e) {

			System.out
					.println("Income section is disabled by default for overlapped items");
			extentTest
					.log(LogStatus.INFO,
							"Income section is disabled by default for overlapped items");

		}

		return null;
	}

	public String overlapValidation(WebDriver Driver)
			throws InterruptedException, IOException {

		Thread.sleep(3000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By
				.xpath("//*[@id='title_10003510']/button/i-feather[1]"));

		if (overlapValII.isDisplayed()) {
			System.out
					.println("Overlap items displaying properly in the Overlap dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Overlap items displaying properly in the Overlap dropdown");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Overlap items not displaying properly in the Overlap dropdown");

			extentTest.log(
					LogStatus.FAIL,
					"Overlap items not displaying properly in the Overlap dropdown"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		String blngid = pageFactIX.billingIDTxt(Driver);
		String date = pageFactIX.datesTxt(Driver);

		System.out
				.println("Overlapped billing record id and Itemized values are: "
						+ blngid);
		extentTest.log(LogStatus.INFO,
				"Overlapped billing record id and Itemized values are: "
						+ blngid);

		System.out.println("Overlapped from and to dates are: " + date);
		extentTest.log(LogStatus.INFO, "Overlapped from and to dates are: "
				+ date);

		return null;
	}

	public String overlapValidationII(WebDriver Driver)
			throws InterruptedException {

		WebElement overlapValII = Driver.findElement(By
				.xpath("//*[@id='title_10003510']/button/i-feather[1]"));

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");
		Thread.sleep(3000);

		String firstColumn = pageFactIX.firstCol.getText();
		String secondColumn = pageFactIX.secondCol.getText();
		String thirdColumn = pageFactIX.thirdCol.getText();

		if (firstColumn.equals("10004037") && secondColumn.equals("10003510")
				&& thirdColumn.equals("Overlaps")) {

			System.out
					.println("Current BR ID showing in the first column is : "
							+ firstColumn);
			extentTest.log(LogStatus.INFO,
					"Current BR ID showing in the first column is: "
							+ firstColumn);

			System.out
					.println("The overlapped BR ID showing in the second column is : "
							+ secondColumn);
			extentTest.log(LogStatus.INFO,
					"The overlapped BR ID showing in the second column is: "
							+ secondColumn);

			System.out.println("The text showing in Third column is : "
					+ thirdColumn);
			extentTest.log(LogStatus.INFO,
					"The text showing in Third column is: " + thirdColumn);
		} else {

			System.out
					.println("Current BR ID showing in the first column is wrong : "
							+ firstColumn);
			extentTest.log(LogStatus.INFO,
					"Current BR ID showing in the first column is wrong: "
							+ firstColumn);

			System.out
					.println("The overlapped BR ID showing in the second column is wrong: "
							+ secondColumn);
			extentTest.log(LogStatus.INFO,
					"The overlapped BR ID showing in the second column is wrong: "
							+ secondColumn);

			System.out.println("The text showing in Third column is wrong: "
					+ thirdColumn);
			extentTest
					.log(LogStatus.INFO,
							"The text showing in Third column is wrong: "
									+ thirdColumn);

		}

		return null;
	}

	public WebDriver NewTabTitle(WebDriver Driver) throws IOException,
			InterruptedException {

		Thread.sleep(5000);

		// String title = Driver.getTitle();
		ArrayList<String> tabs2 = new ArrayList<String>(
				Driver.getWindowHandles());
		WebDriver title = Driver.switchTo().window(tabs2.get(1));

		try {
			if (title.equals("CABS")) {
				System.out.println("Title is: " + title);
				extentTest.log(LogStatus.INFO,
						"Clicking on overlap hyperlink opens the BR in new tab : "
								+ title);

			}
		} catch (Exception e) {
			System.out.println("Title is: " + title);
			extentTest.log(LogStatus.INFO,
					"Clicking on overlap hyperlink opens the BR in new tab: "
							+ title);

		}

		String billingRecId = pageFactV.blngRcrdidd();

		System.out
				.println("BR id in the newly opened tab is : " + billingRecId);
		extentTest.log(LogStatus.INFO, "BR id in the newly opened tab is: "
				+ billingRecId);

		return title;

	}

	public String hyperlinkStoresCount(WebDriver Driver) throws IOException,
			InterruptedException {

		String stores = pageFactIX.stores.getText();
		System.out.println("Stores count is : " + stores);
		extentTest.log(LogStatus.INFO, "Stores count is : " + stores);

		String items = pageFactIX.items.getText();
		System.out.println("Items count is : " + items);
		extentTest.log(LogStatus.INFO, "Items count is : " + items);

		String dateOverlap = pageFactIX.dateOverlap.getText();
		System.out.println("Overlap date count is : " + dateOverlap);
		extentTest
				.log(LogStatus.INFO, "Overlap date count is : " + dateOverlap);

		pageFactIX.secondCol.click();
		Thread.sleep(3000);

		NewTabTitle(Driver);

		return null;
	}

	public String intentionalOverlap(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactVIII.overlapDrpClk(Driver);
		Thread.sleep(3000);
		WebElement overlapValIII = Driver.findElement(By
				.xpath("//*[@id='title_10004037']/button/i-feather[1]"));

		overlapValIII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");
		Thread.sleep(3000);

		pageFactIX.intention.click();

		System.out.println("Clicked on Intentional Overlap check box");
		extentTest.log(LogStatus.INFO,
				"Clicked on Intentional Overlap check box");
		Thread.sleep(7000);

		String overlapVal = pageFactIX.overlapValueTxt(Driver);

		if (overlapVal.contains("0/1")) {

			System.out
					.println("Overlap resolved after clicking on Intentional Overlap check box"
							+ overlapVal);
			extentTest
					.log(LogStatus.INFO,
							"Overlap resolved after clicking on Intentional Overlap check box");
		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Overlap NOT resolved after clicking on Intentional Overlap check box"
							+ overlapVal);

			extentTest.log(
					LogStatus.FAIL,
					"Overlap NOT resolved after clicking on Intentional Overlap check box"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		Thread.sleep(7000);
		pageFactIX.overlapVal.click();
		Thread.sleep(3000);
		pageFactIX.intentionII.click();

		System.out.println("Unchecked the Intentional Overlap check box");
		extentTest.log(LogStatus.INFO,
				"Unchecked the Intentional Overlap check box");
		Thread.sleep(7000);

		// if (overlapVal.contains("1/1")) {
		//
		// System.out
		// .println("Overlap retained after clicking on Intentional Overlap check box"
		// + overlapVal);
		// extentTest
		// .log(LogStatus.INFO,
		// "Overlap retained after clicking on Intentional Overlap check box");
		// } else {
		//
		// String source = aftermthd(Driver);
		//
		// System.out
		// .println("Overlap NOT retained even after clicking on Intentional Overlap check box"
		// + overlapVal);
		//
		// extentTest
		// .log(LogStatus.FAIL,
		// "Overlap NOT retained even after clicking on Intentional Overlap check box"
		// + extentTest
		// .addScreenCapture("data:image/png;base64,"
		// + source));
		//
		//
		// }

		return null;
	}
	
	public String intentionalIncome(WebDriver Driver) throws InterruptedException, IOException{
		
		Thread.sleep(7000);
		pageFactIX.overlapVal.click();
		Thread.sleep(3000);
		pageFactIX.intentionIII.click();
		System.out.println("Clicked on Intentional Overlap check box and made it disabled");
		extentTest.log(LogStatus.INFO,
				"Clicked on Intentional Overlap check box and made it disabled");
		Thread.sleep(7000);
		
		if(pageFactV.incmeButtonAdd.isEnabled()){
			System.out.println("Add Income button enabled after checking the Intentional overlap check box");
			extentTest.log(LogStatus.INFO,
					"Add Income button enabled after checking the Intentional overlap check box");
			
		}else
		{
			String source = aftermthd(Driver);
			System.out.println("Add Income button NOT enabled after checking the Intentional overlap check box");
		 
 		extentTest
					.log(LogStatus.FAIL,
							"Clicked on Intentional Overlap check box and made it disabled"
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
			
		}
		
		Thread.sleep(5000);
		pageFactIX.overlapVal.click();
		Thread.sleep(3000);
		pageFactIX.intentionIV.click();
		
		
		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactV = new GenericFactoryV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFactJS3 = new GenericFactoryJSprint3(Driver);
		pageFact = new GenericFactory(Driver);
		pageFactVI = new GenericFactoryVI(Driver);
		pageFactVII = new GenericFactoryVII(Driver);
		pageFactVIII = new GenericFactoryVIII(Driver);
		pageFactIX = new GenericFactoryIX(Driver);
		POVIII = new PageObjectsVIII(Driver);
	}

}
