package com.albertsons.pageobjects;

import java.io.IOException;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsSJVI extends ExtendBaseClass{
              WebDriver Driver;
              GenericFactory pageFact;
              Properties prop;
              HSSFWorkbook workbook;
              HSSFSheet sheet;
              HSSFCell cell;
              GenericFactoryIV pageFactIV;
              GenericFactorySprint3 pageFactAS3;
              GenericFactorySJVI pageFactSJVI;
              GenericFactoryV pageFactV;
  
  public  PageObjectsSJVI(WebDriver Driver) {
                             this.Driver = Driver;
                             PageFactory.initElements(Driver, this);
  }
  
  public String aftermthd(WebDriver Driver) throws IOException {

      TakesScreenshot ts = (TakesScreenshot) Driver;
      // File source = ts.getScreenshotAs(OutputType.FILE);
      String source1 = ts.getScreenshotAs(OutputType.BASE64);
      return source1;

}
  
  public String brSbmtNonAlw(WebDriver Driver,String Btn, Integer time) throws InterruptedException {
                
    pageFact.waitForSpinnerToBeGone();
                Thread.sleep(5000);
                pageFactSJVI.nonAlwIncomeClick(Driver);
                Thread.sleep(5000);
                System.out.println("Clicked Add income with " +Btn);
                //System.out.println("Button value is  :" + Btn);
                if (Btn.equals("BnA")){
                pageFactSJVI.nonAlwBillnAccruSelect(Driver);
                
                Thread.sleep(2000);
                System.out.println("Clicked on Bill and Accrue Radio Button");
                extentTest.log(LogStatus.INFO,
                                                          "Clicked on Bill and Accrue Radio Button");
                }
                else if (Btn.equals("A"))
                {
                               pageFactSJVI.nonAlwAccruSelect(Driver);
                               Thread.sleep(2000);
                               System.out.println("Clicked on Accrue Radio Button");
                               extentTest.log(LogStatus.INFO,
                                                                        "Clicked on  Accrue Radio Button");
                }
                else if (Btn.equals("B"))
                {                           
                               Thread.sleep(2000);
                               pageFactSJVI.nonAlwBillSelect(Driver);
                               
                               System.out.println("Clicked on Bill Radio Button");
                               extentTest.log(LogStatus.INFO,
                                                                        "Clicked on Bill Radio Button");
                }
                Thread.sleep(2000);
                
                pageFactSJVI.nonAlwAddIncomeComment(Driver);
                System.out.println("Income Comments Added");
                extentTest.log(LogStatus.INFO,
                                                          "Income Comments Added");
                
                pageFactSJVI.nonAlwAddDesc(Driver);
                System.out.println("Description Added");
                extentTest.log(LogStatus.INFO,
                                                          "Description Added");
                
                pageFactSJVI.nonAlwAddAmt(Driver);
                System.out.println("Allowance Amount Added");
                extentTest.log(LogStatus.INFO,
                                                          "Allowance Amount Added");
                
                
                scroldown(Driver);
                Thread.sleep(3000);
                pageFactSJVI.nonAlwIncomeSubmitClick(Driver);           
                pageFact.waitForSpinnerToBeGone();
                Thread.sleep(3000);
                System.out.println(" No.of Times for which income is submited is " +time);
            if (!time.equals(1) && (!Btn.equals("A") ) )
               // if (!time.equals(1))
                {
                
                               if (pageFactSJVI.nonAlwIncomeConf.isDisplayed()) {
                                             System.out.println("Income already exists for this billing record -Warning message is shown.Clicking Yes");
                                             extentTest.log(LogStatus.INFO,
                                                                        "Income already exists for this billing record -Warning message is shown.Clicking Yes");
                               
                                             pageFactSJVI.nonAlwIncomeConfYes.click(); 
                                             Thread.sleep(5000);
                                                                                                                                                }
                }
                else
                {
                Thread.sleep(5000);
                System.out.println("Misc-Income Submitted");
                extentTest.log(LogStatus.INFO,
                                                          "Misc-Income Submitted");
                pageFact.waitForSpinnerToBeGone();
                Thread.sleep(7000);
                pageFactSJVI.nonAlwIncomeHistClick(Driver);
                System.out.println("Misc-Income History Expanded");
                extentTest.log(LogStatus.INFO,
                                                          "Misc-Income History Expanded");
                }
                
                pageFact.waitForSpinnerToBeGone();
                Thread.sleep(7000);
                
              return null;
                
  }
  
  public String scroldown(WebDriver Driver) {
                
      // pageFactJS3.allwTab(Driver);

      Actions act = new Actions(Driver);
      act.moveToElement(pageFactSJVI.nonAlwIncmHistry).perform();
      return null;
} 

  
  public String NonAlwFieldsVal(WebDriver Driver) throws InterruptedException, IOException {
                String AccrNbr=pageFactSJVI.nonAlwIncmHistryAccrue();
                String InvNbr = pageFactSJVI.nonAlwIncmHistryInvNbr();
                if(!AccrNbr.isEmpty() && !InvNbr.isEmpty())
                {
                               System.out.println("Both Accrual and Bill Invoice is created ");
          extentTest.log(LogStatus.INFO, "Both Accrual and Bill Invoice is created"); 
                }             
                else {
                               String source = aftermthd(Driver);
          System.out.println("Both Accrual and Bill Invoice are not created ");
          extentTest.log(LogStatus.FAIL, "First Invoice are not created"
                               + extentTest.addScreenCapture("data:image/png;base64,"+ source)  );  
                             }

                if (pageFactSJVI.nonAlwIncmHistryAccrue().equals("Accrual")) {
          System.out.println("PASS:  First Invoice  value is Accrue ");
          extentTest.log(LogStatus.INFO, "First Invoice value is Accrue");
    } else {
                String source = aftermthd(Driver);
          System.out.println("FAIL:  First Invoice value is not Accrue  ");
          extentTest.log(LogStatus.FAIL, "First Invoice value  is not Accrue"
                               + extentTest.addScreenCapture("data:image/png;base64,"+ source));               
                             }
                
                System.out
                                           .println("First Invoice Value is: "
                                                                        + AccrNbr);
                               extentTest.log(LogStatus.INFO,
                                                            "First Invoice Value is: "
                                                                                                     + AccrNbr);
                               
                String AccreDate=pageFactSJVI.nonAlwIncmAccrueDate();  
                System.out
                             .println("Accrue Date is : "
                                                          + AccreDate);
                extentTest.log(LogStatus.INFO,
                                                          "Accure Date is  :  "
                                                                                      + AccreDate);
                  
                System.out
                             .println("Second Invoice Value is : "
                                                          + InvNbr);
                extentTest.log(LogStatus.INFO,
                                             "Second Invoice Value is: "
                                                                                      + InvNbr);
                                            
                String InvDate=pageFactSJVI.nonAlwIncmHistryInvDate();
                System.out
                             .println("Invoice Date for Bill income type is : "
                                                          + InvDate);
                extentTest.log(LogStatus.INFO,
                                                          "Invoice Date for Bill income type is :  "
                                                                                      + InvDate);
                
                System.out
                                           .println("For Bill & Accrue records associated with a billing record with same date & time,Accrue record is on top followed by Billing income record.");
                               extentTest.log(LogStatus.INFO,
                                                            "Bill & Accrue records associated with a billing record with same date & time ,Accrue record is on top followed by Billing income record. ");

                
                if (pageFactSJVI.nonAlwIncmHistryAttchColum.isDisplayed()) {
             System.out.println("PASS:  Attachment Clip column is displayed");
             extentTest.log(LogStatus.INFO, "Attachment Clip column is  displayed");
       } else {
                 String source = aftermthd(Driver);
             System.out.println("FAIL:  Attachment Clip column is not displayed");
             extentTest.log(LogStatus.FAIL, "Attachment Clip column is not displayed"
                              + extentTest.addScreenCapture("data:image/png;base64,"+ source));
       }
                
                String AccrIncmAmt=pageFactSJVI.nonAlwIncmHistryAccrAmt();
                System.out
                             .println("Income Amount for the Accrual  is : "
                                                          + AccrIncmAmt);
                extentTest.log(LogStatus.INFO,
                                                          "Income Amount for the Accrual  is :  "
                                                                                      + AccrIncmAmt);
                
                String IncmAmt=pageFactSJVI.nonAlwIncmHistryBillAmt();
                System.out
                             .println("Income Amount for the invoice  is : "
                                                          + IncmAmt);
                extentTest.log(LogStatus.INFO,
                                                          "Income Amount for the invoice  is :  "
                                                                                      + IncmAmt);
                
                
                String AccUserId=pageFactSJVI.nonAlwIncmHistryAccUserId();
                System.out
                             .println("User id  for the Accrue is : "
                                                          + AccUserId);
                extentTest.log(LogStatus.INFO,
                                                          "User id  for the invoice is :  "
                                                                                      + AccUserId);
                
                String BillUserId=pageFactSJVI.nonAlwIncmHistryBillUserId();
                System.out
                             .println("User id  for the Bill invoice is : "
                                                          + BillUserId);
                extentTest.log(LogStatus.INFO,
                                                          "User id  for the Bill invoice is :  "
                                                                                      + BillUserId);
                
                String AccIncStat=pageFactSJVI.nonAlwIncmHistryAccStats();
                System.out
                             .println("Income status for the Accrue invoice is : "
                                                          + AccIncStat);
                extentTest.log(LogStatus.INFO,
                                                          "Income status for the Accrue invoice is :  "
                                                                                      + AccIncStat);
                
                String BillIncStat=pageFactSJVI.nonAlwIncmHistryBillStats();
                System.out
                             .println("Income status for the Bill invoice is : "
                                                          + BillIncStat);
                extentTest.log(LogStatus.INFO,
                                                          "Income status for the Bill invoice is :  "
                                                                                      + BillIncStat);
                
                if (pageFactSJVI.nonAlwAccCnclBtn().equals("Cancel")) {
          System.out.println("PASS:  Cancel button displayed for Accrue Record");
          extentTest.log(LogStatus.INFO, "Cancel button displayed for Accrue Record");
    } else {
              String source = aftermthd(Driver);
          System.out.println("FAIL:  Cancel button not displayed for Accrue Record");
          extentTest.log(LogStatus.FAIL, "Cancel button not displayed for Accrue Record"
                               + extentTest.addScreenCapture("data:image/png;base64,"+ source));
                
                             }
                
                if (pageFactSJVI.nonAlwBillCnclBtn().equals("Cancel")) {
          System.out.println("PASS:  Cancel button displayed for Bill Record");
          extentTest.log(LogStatus.INFO, "Cancel button displayed for Bill Record");
    } else {
              String source = aftermthd(Driver);
          System.out.println("FAIL:  Cancel button not displayed for Bill Record");
          extentTest.log(LogStatus.FAIL, "Cancel button not displayed for Bill Record"
                               + extentTest.addScreenCapture("data:image/png;base64,"+ source));
                
                             }
                
              
                
                return null;
  }
  
  //public String NonAlwCancelButtonVal(WebDriver Driver) throws InterruptedException {
//
//                         return null;
// }
  
  @BeforeTest
  public void beforeTest(WebDriver Driver) {

                pageFactIV = new GenericFactoryIV(Driver);
                             pageFactV = new GenericFactoryV(Driver);
                             pageFactAS3 = new GenericFactorySprint3(Driver);
                             pageFact = new GenericFactory(Driver);
                             pageFactSJVI=new GenericFactorySJVI(Driver);
  }

}
