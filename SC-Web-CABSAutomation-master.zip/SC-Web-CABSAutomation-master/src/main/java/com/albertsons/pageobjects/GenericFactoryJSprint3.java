package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.albertsons.pages.PageObjects;

public class GenericFactoryJSprint3 {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[1]/nav/ol/li")
	public WebElement newBR;
	
	@FindBy(xpath = "//*[@id=\"allow-tab\"]/div[2]")
	public WebElement allwTab;
	
	@FindBy(xpath = "//*[@id=\"offerNumber\"]")
	public WebElement offno;
	
	@FindBy(xpath ="//*[@id=\"section\"]")
	public WebElement sect;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[3]/cabs-datepicker")
	public WebElement billDtFm;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[4]/cabs-datepicker")
	public WebElement billDtTo;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[5]/cabs-datepicker")
	public WebElement perfDtFm;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[6]/cabs-datepicker")
	public WebElement perfDtTo;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[2]/div[1]/div/div/span")
	public WebElement header;

	@FindBy(xpath ="//*[@id=\"flatAmount\"]")
	public WebElement fltamt;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[2]/div[2]/div[2]/div/label")
	public WebElement fltcode;
	

	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[1]/div/div/span")
	public WebElement itemized;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[1]/div/label")
	public WebElement alwtyp;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[2]/div/label")
	public WebElement p1;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[3]/div/label")
	public WebElement p2;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[3]/div/div[2]/div[4]/div/label")
	public WebElement overlap;
	
	@FindBy(xpath ="//*[@id=\"allow-tab\"]/div[2]")
	//@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[3]")
	public WebElement scroll;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[3]/cabs-datepicker/form/div/div/input")
	public WebElement bDatefm;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[4]/cabs-datepicker/form/div/div/input")
	public WebElement bDateTo;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[5]/cabs-datepicker/form/div/div/input")
	public WebElement pDateFm;
	
	@FindBy(xpath ="//*[@id=\"allowanceCollapse\"]/div/div/div[1]/div[6]/cabs-datepicker/form/div/div/input")
	public WebElement pDateTo;
	
	@FindBy(xpath ="//*[@id=\"flatAmount\"]/input")
	public WebElement fAmt;
	
	@FindBy(xpath ="//*[@id=\"flatAmount\"]")
	public WebElement fAmt1;
	
	@FindBy(xpath ="//*[@id=\"flatCode\"]")
	public WebElement fCode;
	
	@FindBy(xpath ="//*[@id=\"allowanceType\"]")
	public WebElement allwtType;
	
	@FindBy(xpath ="//*[@id=\"performanceCode1\"]")
	public WebElement pf1;
	
	@FindBy(xpath ="//*[@id=\"performanceCode2\"]")
	public WebElement pf2;
	
	@FindBy(xpath ="//*[@id=\"deductInvoiceNumber\"]")
	public WebElement dedInv;
	
	@FindBy(xpath ="//*[@id=\"undefined\"]/input")
	public WebElement amt;
	
		
	@FindBy(xpath ="//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;
	
	 @FindBy(xpath ="//*[@id=\"allow-tab\"]/div[3]/span/button/span")
	//@FindBy(xpath ="//*[@id=\"allow-tab\"]/div[3]/span")
	public WebElement allwWarn;
	
	//@FindBy(xpath ="//*[@id=\"ngb-popover-9\"]/div[2]")
	@FindBy(xpath ="//*[@id=\"ngb-popover-15\"]")
	public WebElement allwWarnMsg;
	
	@FindBy(xpath="//*[@id=\"allowanceType\"]/div/div/div[2]/input")
	//@FindBy(xpath="//*[@id=\"allowanceType\"]/div/div/div[3]/input")
	public WebElement allwType;
	
	public GenericFactoryJSprint3(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}
	
	public String allwTab(WebDriver Driver) {
		Actions act = new Actions(Driver);
		act.moveToElement(scroll).perform();
		return allwTab.getText();
	}
	
	public String allwTabOffNo(WebDriver Driver) {
		return offno.getText();
	}
	
	public String allwTabSect(WebDriver Driver) {
		return sect.getText();
	}

	public String allwTabBillDtFrm(WebDriver Driver) {
		return billDtFm.getText();
	}
	
	public String allwTabBillDtTo(WebDriver Driver) {
		return billDtTo.getText();
	}
	
	public String allwTabPerfDtFrm(WebDriver Driver) {
		return perfDtFm.getText();
	}
	
	public String allwTabPerfDtTo(WebDriver Driver) {
		return perfDtTo.getText();
	}
	
	public String allwTabHdr(WebDriver Driver) {
        Actions act= new Actions(Driver);
        act.moveToElement(header).perform();
        System.out.println(header.getText());

		return header.getText();
	}
	
	public String allwTabFltAmt(WebDriver Driver) {
		
		return fltamt.getText();
	}
	
	public String allwTabFltcode(WebDriver Driver) {
		return fltcode.getText();
	}
	
	public String allwTabItemized(WebDriver Driver) {
		return itemized.getText();
	}
	
	public String allwTabAlwTyp(WebDriver Driver) {
		return alwtyp.getText();
	}
	
	public String allwTabPerf1(WebDriver Driver) {
		return p1.getText();
	}
	public String allwTabPerf2(WebDriver Driver) {
		return p2.getText();
	}
	public String allwTabOverlaps(WebDriver Driver) {
		return overlap.getText();
	}
	public Boolean allwTabOfferVal(WebDriver Driver) {
		System.out.println(PO.offer);
		WebElement offnum = offno.findElement(By.className("form-control"));
		System.out.println(offnum.getAttribute("value"));
		if(offnum.getAttribute("value").contentEquals(PO.offer)) {
		return true;}
		else {
			return false;}
	}
	public Boolean allwTabBillDtFrmVal(WebDriver Driver) {
		System.out.println(PO.dtFrm);
		System.out.println(bDatefm.getAttribute("value"));
		if(bDatefm.getAttribute("value").contentEquals(PO.dtFrm)) {
		return true;}
		else {
			return false;}
	}	
	public Boolean allwTabBillDtToVal(WebDriver Driver) {
		System.out.println(PO.dtTo);
		System.out.println(bDateTo.getAttribute("value"));
		if(bDateTo.getAttribute("value").contentEquals(PO.dtTo)) {
		return true;}
		else {
			return false;}
	}
	public Boolean allwTabPerDtFrmVal(WebDriver Driver) {
		System.out.println(PO.dtFrm);
		System.out.println(pDateFm.getAttribute("value"));
		if(pDateFm.getAttribute("value").contentEquals(PO.dtFrm)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean allwTabPerDtToVal(WebDriver Driver) {
		System.out.println(PO.dtTo);
		System.out.println(pDateTo.getAttribute("value"));
		if(pDateTo.getAttribute("value").contentEquals(PO.dtTo)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean allwTabFlatAmtVal(WebDriver Driver) {
		System.out.println(PO.ftAmt);
		System.out.println(fAmt.getAttribute("value"));
		if(fAmt.getAttribute("value").contentEquals(PO.ftAmt)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean allwTabFlatCodeVal(WebDriver Driver) {
		System.out.println(PO.ftCode);
		WebElement element = fCode.findElement(By.className("ng-value-label")) ;
		System.out.println(element.getText());
		
		if(element.getText().contentEquals(PO.ftCode)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean allwTabAlwTypVal(WebDriver Driver) {
		System.out.println(PO.allwTyp);
		WebElement element = allwtType.findElement(By.className("ng-value-label")) ;
		System.out.println(element.getText());
	
		if(element.getText().contentEquals(PO.allwTyp)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean allwTabPerf1Val(WebDriver Driver) {
		System.out.println(PO.perf1);
		WebElement element = pf1.findElement(By.className("ng-value-label")) ;
		System.out.println(element.getText());
			
		if(element.getText().contentEquals(PO.perf1)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean allwTabPerf2Val(WebDriver Driver) {
		System.out.println(PO.perf2);
		WebElement element = pf2.findElement(By.className("ng-value-label")) ;
		System.out.println(element.getText());
		
		if(element.getText().contentEquals(PO.perf2)) {
		return true;}
		else {
			return false;}
	}
	
	public Boolean NoHeadItemSub(WebDriver Driver) throws InterruptedException {
        Thread.sleep(2000);
        
        dedInv.findElement(By.className("form-control")).sendKeys(Keys.ENTER,"45375");
        Thread.sleep(6000);
        fAmt.clear();
  //     amt.sendKeys("10");
  //     amt.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,"20");
        Thread.sleep(2000);
        save.click();
        Thread.sleep(36000);
        Actions act = new Actions(Driver);
        act.moveToElement(allwWarn).perform();
        
        
        Thread.sleep(2000);
        if(allwWarnMsg.getText().contentEquals("Please fill Header/Itemized section")) {
               return true;
               
        }
        else {
        return false;}
        
        
  }

	
	public Boolean FlatAmtNoCode(WebDriver Driver) throws InterruptedException {
		fAmt.sendKeys("1");
		save.click();
		Actions act = new Actions(Driver);
	       act.moveToElement(allwWarn).perform();

	//	allwWarn.click();
		Thread.sleep(2000);
		if(allwWarnMsg.getText().contentEquals("Please enter required fields")) {
			return true;
		}
		else {
		return false;}
	}
	
	public Boolean AlwNoPerf1(WebDriver Driver) throws InterruptedException {
		fAmt.click();
		fAmt.sendKeys(Keys.TAB,Keys.ENTER,Keys.ARROW_DOWN,Keys.ENTER);
		allwType.click();
		allwType.sendKeys(Keys.ARROW_DOWN,Keys.ENTER);
		save.click();
        Actions act = new Actions(Driver);
        act.moveToElement(allwWarn).perform();

		//allwWarn.click();
		Thread.sleep(2000);
		if(allwWarnMsg.getText().contentEquals("Please enter required fields")) {
			return true;
		}
		else {
		return false;}
	}
       
       }

