package com.albertsons.pageobjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsVIII extends ExtendBaseClass {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactoryVI pageFactVI;
	GenericFactoryVII pageFactVII;
	GenericFactoryVIII pageFactVIII;
	GenericFactoryV pageFactV;
	GenericFactorySprint3 pageFactAS3;
	GenericFactoryJSprint3 pageFactJS3;
	static String billingId;

	public PageObjectsVIII(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		// File source = ts.getScreenshotAs(OutputType.FILE);
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVII.createBillrcrd));
		return null;
	}

	public String waitforHistory(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVII.miscHistory));
		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String waitForSpinnerToBeGone(WebDriver Driver) {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	
	public String waitforbillType(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFact.blngRcrdType0));
		return null;
	}

	public String waitforSearchItem(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVIII.searchFirstItem));
		return null;
	}

	public String waitforSearchPage(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVII.searchApply));
		return null;
	}

	public String waitforSuccessMsgBr(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVIII.succesMsg));
		return null;
	}

	public Boolean SearchData(WebDriver Driver, String valu)
			throws BiffException, IOException, InterruptedException {

		waitforBlngbtn(Driver);
		waitForSpinnerToBeGone(Driver);
		//Thread.sleep(20000);
		Thread.sleep(2500);
		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		if (pageFactVIII.noDataa(Driver).contains("No data to display")) {

			String searchData = pageFactVIII.noDataa(Driver);
			System.out
					.println("Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
							+ searchData);
			extentTest
					.log(LogStatus.INFO,
							"Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
									+ searchData);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Search page NOT displayed by clicking on the Search Billing Record button");
			
			
			
			extentTest
			.log(LogStatus.FAIL,
					"Search page NOT displayed by clicking on the Search Billing Record button"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			
			 
		}

		System.out.println("value is " + valu);
		
		Thread.sleep(5000);
		// New Advanced search click
		pageFactVII.advSearch.click();
		Thread.sleep(1500);
		
		pageFactVII.searchBillId.findElement(By.className("form-control"))
				.sendKeys(valu);

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);

		Thread.sleep(3000);
		String firstITem = pageFactVIII.searchFirstItemm(Driver);

		System.out.println("First value is: " + firstITem);
		if (pageFactVIII.searchFirstItemm(Driver).contains(valu)) {

			System.out.println("BR # filtered and listed in search results");
			extentTest.log(LogStatus.INFO,
					"BR # filtered and listed in search results");
			return true;

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("BR # not displaying in the search result, or BR # showing in the search result not matching with the search query");
				
			extentTest
			.log(LogStatus.FAIL,
					"BR # not displaying in the search result, or BR # showing in the search result not matching with the search query"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			return false;
		}
	}

	public String Search(WebDriver Driver) throws BiffException, IOException,
			InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		if (pageFactVIII.noDataa(Driver).contains("No data to display")) {

			String searchData = pageFactVIII.noDataa(Driver);
			System.out
					.println("Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
							+ searchData);
			extentTest
					.log(LogStatus.INFO,
							"Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
									+ searchData);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Search page NOT displayed by clicking on the Search Billing Record button");
			
			
			
			extentTest
			.log(LogStatus.FAIL,
					"Search page NOT displayed by clicking on the Search Billing Record button"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(13, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);

		for (int i = 2; i < s.getRows(); i++) {
			// Read data from excel sheet

			String s3 = s.getCell(13, i).getContents();
			Thread.sleep(3000);
			String firstITem = pageFactVIII.searchFirstItemm(Driver);

			System.out.println("First value is: " + firstITem);
			if (pageFactVIII.searchFirstItemm(Driver).contains(s3)) {

				System.out
						.println("BR # filtered and listed in search results");
				extentTest.log(LogStatus.INFO,
						"BR # filtered and listed in search results");

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("BR # not displaying in the search result, or BR # showing in the search result not matching with the search query");
				
				extentTest
				.log(LogStatus.FAIL,
						"BR # not displaying in the search result, or BR # showing in the search result not matching with the search query"
	
								+ extentTest
										.addScreenCapture("data:image/png;base64,"
												+ source));
			
			}
		}

		return null;
	}

	public String SearchII(WebDriver Driver) throws BiffException, IOException,
			InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		if (pageFactVIII.noDataa(Driver).contains("No data to display")) {

			String searchData = pageFactVIII.noDataa(Driver);
			System.out
					.println("Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
							+ searchData);
			extentTest
					.log(LogStatus.INFO,
							"Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
									+ searchData);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Search page NOT displayed by clicking on the Search Billing Record button");
			
			
			extentTest
			.log(LogStatus.FAIL,
					"Search page NOT displayed by clicking on the Search Billing Record button"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(16, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);

		for (int i = 2; i < s.getRows(); i++) {
			// Read data from excel sheet

			String s3 = s.getCell(13, i).getContents();
			Thread.sleep(3000);
			String firstITem = pageFactVIII.searchFirstItemm(Driver);

			System.out.println("First value is: " + firstITem);
			if (pageFactVIII.searchFirstItemm(Driver).contains(s3)) {

				System.out
						.println("BR # filtered and listed in search results");
				extentTest.log(LogStatus.INFO,
						"BR # filtered and listed in search results");

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("BR # not displaying in the search result, or BR # showing in the search result not matching with the search query");
				
				
				extentTest
				.log(LogStatus.FAIL,
						"BR # not displaying in the search result, or BR # showing in the search result not matching with the search query"
								
								+ extentTest
										.addScreenCapture("data:image/png;base64,"
												+ source));
				
			}
		}

		return null;
	}

	public String SearchTestData(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		if (pageFactVIII.noDataa(Driver).contains("No data to display")) {

			String searchData = pageFactVIII.noDataa(Driver);
			System.out
					.println("Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
							+ searchData);
			extentTest
					.log(LogStatus.INFO,
							"Search page displayed by clicking on the Search Billing Record button, by default the text displaying is: "
									+ searchData);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Search page NOT displayed by clicking on the Search Billing Record button");
			
			extentTest
			.log(LogStatus.FAIL,
					"Search page NOT displayed by clicking on the Search Billing Record button"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(13, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);

		for (int i = 2; i < s.getRows(); i++) {
			// Read data from excel sheet

			String s3 = s.getCell(13, i).getContents();
			Thread.sleep(3000);
			String firstITem = pageFactVIII.searchFirstItemm(Driver);

			System.out.println("First value is: " + firstITem);
			if (pageFactVIII.searchFirstItemm(Driver).contains(s3)) {

				System.out
						.println("BR # filtered and listed in search results");
				extentTest.log(LogStatus.INFO,
						"BR # filtered and listed in search results");

			} else {
				String source = aftermthd(Driver);
				System.out
						.println("BR # not displaying in the search result, or BR # showing in the search result not matching with the search query");
				
				extentTest
				.log(LogStatus.FAIL,
						"BR # not displaying in the search result, or BR # showing in the search result not matching with the search query"
								
								+ extentTest
										.addScreenCapture("data:image/png;base64,"
												+ source));
				
				
			}
		}

		return null;
	}

	public String searchNameFiltering(WebDriver Driver) throws IOException, InterruptedException {

		pageFactVIII.clearAll(Driver);
		pageFactVIII.blngNameeCase1(Driver);
		waitforSearchItem(Driver);
		Thread.sleep(5000);

		if (pageFactVIII.blngNameFirstTxt(Driver).startsWith("A")) {

			System.out
					.println("Name filtered 'A*' results in showing names starting with 'A'");
			extentTest
					.log(LogStatus.INFO,
							"Name filtered 'A*' results in showing names starting with 'A'");

		} else {
			String source = aftermthd(Driver);
			System.out.println("Name filtering not working properly");
			
			extentTest
			.log(LogStatus.FAIL,
					"Name filtering not working properly"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			
		}

		pageFactVIII.clearAll(Driver);
		pageFactVIII.blngNameeCase2(Driver);
		waitforSearchItem(Driver);

		if (pageFactVIII.blngNameFirstTxt(Driver).endsWith("A")) {

			System.out
					.println("Name filtered '*A' results in showing names ends with 'A'");
			extentTest
					.log(LogStatus.INFO,
							"Name filtered '*A' results in showing names ends with 'A'");

		} else {
			String source = aftermthd(Driver);
			System.out.println("Name filtering not working properly");
			
			
			extentTest
			.log(LogStatus.FAIL,
					"Name filtering not working properly"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		pageFactVIII.clearAll(Driver);
		pageFactVIII.blngNameeCase3(Driver);
		waitforSearchItem(Driver);

		if (pageFactVIII.blngNameFirstTxt(Driver).startsWith("A")) {

			System.out
					.println("Name filtered 'A*C' results in showing names starting with 'A'");
			extentTest
					.log(LogStatus.INFO,
							"Name filtered 'A*C' results in showing names starting with 'A'");

			if (pageFactVIII.blngNameFirstTxt(Driver).endsWith("C")) {
				System.out
						.println("Name filtered 'A*C' results in showing names ends with 'C'");
				extentTest
						.log(LogStatus.INFO,
								"Name filtered 'A*C' results in showing names ends with 'C'");

			}

		} else {
			String source = aftermthd(Driver);
			System.out.println("Name filtering not working properly");
			
			extentTest
			.log(LogStatus.FAIL,
					"Name filtering not working properly"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		waitforSearchItem(Driver);

		return null;
	}

	public String brStatusValidation(WebDriver Driver)
			throws InterruptedException {

		try {
			pageFactVIII.clearAll(Driver);

			pageFactVIII.brStatusdrpp(Driver);
			Thread.sleep(2000);
			pageFactVIII.brStatusDrpInputt(Driver);
			// waitforSearchItem(Driver);
			Thread.sleep(7500);

			try {

				if (pageFactVIII.brStatuss(Driver).equals("Analyze Later")) {

					System.out
							.println("Search results showing data with status 'Analyze Later'");
					extentTest
							.log(LogStatus.INFO,
									"Search results showing data with status 'Analyze Later'");

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));

				}

			} catch (Exception e) {

				System.out
						.println("No search result for the status 'Analyze Later'");
				extentTest.log(LogStatus.INFO,
						"No search result for the status 'Analyze Later'");

			}

			pageFactVIII.clearAll(Driver);

			pageFactVIII.brStatusdrpp(Driver);
			Thread.sleep(2000);
			pageFactVIII.brStatusDrpInputt2(Driver);
			// waitforSearchItem(Driver);
			Thread.sleep(7500);

			try {

				if (pageFactVIII.brStatuss(Driver).equals("New")) {

					System.out
							.println("Search results showing data with status 'New'");
					extentTest.log(LogStatus.INFO,
							"Search results showing data with status 'New'");

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));

				}

			} catch (Exception e) {

				System.out.println("No search result for the status 'New'");
				extentTest.log(LogStatus.INFO,
						"No search result for the status 'New'");

			}

			pageFactVIII.clearAll(Driver);

			pageFactVIII.brStatusdrpp(Driver);
			Thread.sleep(2000);
			pageFactVIII.brStatusDrpInputt3(Driver);
			// waitforSearchItem(Driver);
			Thread.sleep(7500);

			try {

				if (pageFactVIII.brStatuss(Driver).equals("Ended")) {

					System.out
							.println("Search results showing data with status 'Ended'");
					extentTest.log(LogStatus.INFO,
							"Search results showing data with status 'Ended'");

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));

				}

			} catch (Exception e) {

				System.out.println("No search result for the status 'Ended'");
				extentTest.log(LogStatus.INFO,
						"No search result for the status 'Ended'");

			}

			pageFactVIII.clearAll(Driver);

			pageFactVIII.brStatusdrpp(Driver);
			Thread.sleep(2000);
			pageFactVIII.brStatusDrpInputt4(Driver);
			// waitforSearchItem(Driver);
			Thread.sleep(7500);

			try {

				if (pageFactVIII.brStatuss(Driver).equals("Ready for Income")) {

					System.out
							.println("Search results showing data with status 'Ready for Income'");
					extentTest
							.log(LogStatus.INFO,
									"Search results showing data with status 'Ready for Income'");

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));
				}

			} catch (Exception e) {

				System.out
						.println("No search result for the status 'Ready for Income'");
				extentTest.log(LogStatus.INFO,
						"No search result for the status 'Ready for Income'");

			}

			pageFactVIII.clearAll(Driver);

			pageFactVIII.brStatusdrpp(Driver);
			Thread.sleep(2000);
			pageFactVIII.brStatusDrpInputt5(Driver);
			// waitforSearchItem(Driver);
			Thread.sleep(7500);

			try {

				if (pageFactVIII.brStatuss(Driver).equals("Completed")) {

					System.out
							.println("Search results showing data with status 'Completed'");
					extentTest
							.log(LogStatus.INFO,
									"Search results showing data with status 'Completed'");

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));
				}

			} catch (Exception e) {

				System.out
						.println("No search result for the status 'Completed'");
				extentTest.log(LogStatus.INFO,
						"No search result for the status 'Completed'");

			}
		} catch (Exception e) {

			System.out
					.println("Search filter not loaded because of privilege/unexpected error");
			extentTest
					.log(LogStatus.INFO,
							"Search filter not loaded because of privilege/unexpected error");

		}
		return null;
	}

	public String assignToDrpValidation(WebDriver Driver)
			throws InterruptedException {

		try {

			pageFactVIII.clearAll(Driver);
			pageFactVIII.assignTodrpClk(Driver);

			Thread.sleep(7500);

			String asinTo = pageFactVIII.assignToVall(Driver);

			try {

				if (pageFactVIII.assignToVall(Driver).contains("Ajith")) {

					System.out
							.println("Search results showing data with Assign To : "
									+ asinTo);
					extentTest.log(LogStatus.INFO,
							"Search results showing data with Assign To : "
									+ asinTo);

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));
				}

			} catch (Exception e) {

				System.out
						.println("No search result for the status 'Completed'");
				extentTest.log(LogStatus.INFO,
						"No search result for the status 'Completed'");

			}
		} catch (Exception e) {

			System.out.println("No search result for the Assign To");
			extentTest
					.log(LogStatus.INFO, "No search result for the Assign To");

		}

		return null;
	}

	public String multipleFilters(WebDriver Driver) throws InterruptedException {

		try {
			pageFactVIII.clearAll(Driver);

			pageFactVIII.blngNameInput(Driver);
			pageFactVIII.brStatusDrpInputt4(Driver);
			Thread.sleep(3000);
			pageFactVIII.assignTodrpClk(Driver);
			waitforSearchItem(Driver);

			try {

				if (pageFactVIII.assignToVall(Driver).contains("Ajith")
						&& pageFactVIII.brStatuss(Driver).equals(
								"Ready for Income")
						&& pageFactVIII.blngNameFirstTxt(Driver)
								.contains("JET")) {

					System.out
							.println("Search results displaying properly with multiple filters");
					extentTest
							.log(LogStatus.INFO,
									"Search results displaying properly with multiple filters");

				} else {
					String source = aftermthd(Driver);
					System.out.println("Error in search result");

					extentTest
							.log(LogStatus.FAIL,
									"Error in search result"

											+ extentTest
													.addScreenCapture("data:image/png;base64,"
															+ source));
				}

			} catch (Exception e) {

				System.out
						.println("No search result when searching with multiple filter options");
				extentTest
						.log(LogStatus.INFO,
								"No search result when searching with multiple filter options");

			}
		} catch (Exception e) {
			System.out
					.println("No search result when searching with multiple filter options");
			extentTest
					.log(LogStatus.INFO,
							"No search result when searching with multiple filter options");

		}
		return null;
	}


	public String offerNumber(WebDriver Driver) throws IOException,
			InterruptedException {
				
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);
		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		pageFactVIII.ofrNbrInput(Driver);
		Thread.sleep(3000);
		pageFactVIII.searchApplyClk(Driver);
		waitforSearchItem(Driver);
		String ofernum = pageFactVIII.offerTxt(Driver);

		if (pageFactVIII.offerTxt(Driver).startsWith("123")) {
			System.out
					.println("User able to do wild card search by inputting '123*' in the Offer Number text box.  And the result obtained is:  "
							+ ofernum);
			extentTest
					.log(LogStatus.INFO,
							"User able to do wild card search by inputting '123*' in the Offer Number text box.  And the result obtained is:  "
									+ ofernum);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("User NOT able to do wild card search by inputting '123*' in the Offer Number text box.  And the result obtained is:  "
							+ ofernum);
			extentTest
					.log(LogStatus.FAIL,
							"User NOT able to do wild card search by inputting '123*' in the Offer Number text box.  And the result obtained is:  "
									+ ofernum
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		return null;
	}

	public String waitforAddFile(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVIII.addFileBtn));
		return null;
	}

	public String attachment(WebDriver Driver) throws InterruptedException {

		// Actions action = new Actions(Driver);

		pageFactVIII.attachClipClk(Driver);
		waitforAddFile(Driver);

		// action.sendKeys(Keys.TAB).perform();
		//
		// System.out.println("CLICKED tab BUTTON");
		// action.sendKeys(Keys.TAB).perform();
		// System.out.println("CLICKED ON tab BUTTON AGAIN");
		// action.sendKeys(Keys.ENTER).perform();
		// System.out.println("CLICKED Enter BUTTON");
		//
		// Thread.sleep(5000);
		pageFactVIII.addFileBtnn(Driver);

		Thread.sleep(3000);

		pageFactVIII.doneBtnn(Driver);

		return null;
	}

	public String attachmentII(WebDriver Driver) throws InterruptedException,
			AWTException, IOException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(3000);

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {
			String source = aftermthd(Driver);
			System.out.println("Error in displaying the count");
			
			extentTest
			.log(LogStatus.FAIL,
					"Error in search result"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;
	}

	public String attachmentCOGS(WebDriver Driver) throws InterruptedException,
			AWTException, IOException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		Thread.sleep(5000);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		Thread.sleep(5000);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out
				.println("Clicked on Done button after attaching files in COGS BR");
		extentTest.log(LogStatus.INFO,
				"Clicked on Done button after attaching files in COGS BR");
		Thread.sleep(3000);

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {
			String source = aftermthd(Driver);
			System.out.println("Error in displaying the count");
			extentTest
			.log(LogStatus.FAIL,
					"Error in displaying the count"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;
	}

	public String attachmentCount(WebDriver Driver) throws IOException {

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			String source = aftermthd(Driver);
			System.out.println("Error in displaying the count");
			extentTest
			.log(LogStatus.FAIL,
					"Error in displaying the count"
							
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;
	}

	public String searchBtn(WebDriver Driver) {

		pageFactVII.searchh(Driver);
		return null;
	}

	public String searchBrNum(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(14, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);
		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);

		return null;
	}

	public String searchBrNumII(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(16, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);
		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);

		return null;
	}

	public String closeClk(WebDriver Driver) {

		pageFactVIII.intNotesCloseClk(Driver);
		return null;
	}

	public String searchBrNumAlwnce(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(15, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);
		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);

		return null;
	}

	public String searchFirstItemClk(WebDriver Driver)
			throws InterruptedException {

		
		pageFactVIII.assignTodrp.sendKeys("Ajith");
		Thread.sleep(1500);
		pageFactVIII.assignTodrp.sendKeys(Keys.ENTER);
		Thread.sleep(1500);

		pageFactVIII.searchApply.click();
		Thread.sleep(7000);

		pageFactVII.searchFirstItem.click();
		waitforbrtxt(Driver);		 
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);

		return null;
	}

	public String searchBrNumCOGS(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		pageFactVII.searchh(Driver);
		waitforSearchPage(Driver);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);

		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(16, i).getContents();
				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);
				pageFactVII.searchBillId.findElement(
						By.className("form-control")).sendKeys(s3);

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		// pageFactVII.searchBillIdd(Driver);
		Thread.sleep(3000);
		pageFactVII.searchApplyy(Driver);
		waitforSearchItem(Driver);
		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);

		return null;
	}

		public String BRSave(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		pageFactVIII.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(5000);

		// Commenting below line as the Flat amount field is disabled now
		// pageFactVIII.itemDetailsAmntt(Driver);

		readyBtnClk(Driver);
		Thread.sleep(55000);
		// pageFact.brStatusdrpclk();
		// pageFactAS3.brStatusdropp(Driver);

		return null;
	}

	public String BRSaveItemDetails(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		pageFactVIII.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(5000);

		 
		pageFactVIII.itemDetailsAmnttII(Driver);

		readyBtnClk(Driver);
		Thread.sleep(55000);
		// pageFact.brStatusdrpclk();
		// pageFactAS3.brStatusdropp(Driver);

		return null;
	}
	
	public String getBillingRecordId(WebDriver Driver) {

		billingId = pageFactV.blngRcrdidd();
		System.out.println("Billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Billing record id is: " + billingId);

		return null;

	}

	public String attachmentModel(WebDriver Driver) throws InterruptedException, IOException {

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		Thread.sleep(2500);

		String filename = pageFactVIII.fileNamee(Driver);
		if (pageFactVIII.fileName.isDisplayed()) {

			System.out.println("The file name displaying is : " + filename);
			extentTest.log(LogStatus.INFO, "The file name displaying is : "
					+ filename);

		} else {
			String source = aftermthd(Driver);
			System.out.println("No file name displaying");
			

			extentTest
					.log(LogStatus.FAIL,
							"No file name displaying"
									
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
			
			
		}

		String filetyp = pageFactVIII.fileTypee(Driver);
		if (pageFactVIII.fileType.isDisplayed()) {

			System.out.println("The file type displaying is : " + filetyp);
			extentTest.log(LogStatus.INFO, "The file type displaying is : "
					+ filetyp);

		} else {

			String source = aftermthd(Driver);
			System.out.println("No file type displaying");
			

			extentTest
					.log(LogStatus.FAIL,
							"No file type displaying"
									
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
		}

		String filesiz = pageFactVIII.fileSizee(Driver);
		if (pageFactVIII.fileSize.isDisplayed()) {

			System.out.println("The file size displaying is : " + filesiz);
			extentTest.log(LogStatus.INFO, "The file size displaying is : "
					+ filesiz);

		} else {

			String source = aftermthd(Driver);
			System.out.println("No file size displaying");
			

			extentTest
					.log(LogStatus.FAIL,
							"No file size displaying"
									
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
		}

		String datetym = pageFactVIII.dateTimee(Driver);
		if (pageFactVIII.dateTime.isDisplayed()) {

			System.out.println("The Date/Time displaying is : " + datetym);
			extentTest.log(LogStatus.INFO, "The Date/Time displaying is : "
					+ datetym);

		} else {
			String source = aftermthd(Driver);
			System.out.println("No Date/Time displaying");
			

			extentTest
					.log(LogStatus.FAIL,
							"No Date/Time displaying"
									
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
			
		}

		String uploadedByy = pageFactVIII.uploadedByy(Driver);
		if (pageFactVIII.uploadedBy.isDisplayed()) {

			System.out.println("The uploaded By name displaying is : "
					+ uploadedByy);
			extentTest.log(LogStatus.INFO,
					"The uploaded By name displaying is : " + uploadedByy);

		} else {

			String source = aftermthd(Driver);
			System.out.println("No uploaded By name displaying");
			

			extentTest
					.log(LogStatus.FAIL,
							"No uploaded By name displaying"
									
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
			
		}

		pageFactVIII.rejectCheckClk(Driver);
		if (pageFactVIII.rejectCancel.isDisplayed()) {

			System.out
					.println("Clicking on Reject Checkbox redirected to the Reject Reason section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on Reject Checkbox redirected to the Reject Reason section");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Reject check box click not working");
			

			extentTest
					.log(LogStatus.FAIL,
							"Reject check box click not working"
									
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));
			
			
		}

		return null;
	}

	public String attachmentModelHistory(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFactVIII.incHistClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		String title = pageFactVIII.titleCheckTxt(Driver);
		if (pageFactVIII.titleCheckTxt(Driver).equals("Income Attachments")) {

			System.out
					.println("The Title Add Attachment pop up displaying is : "
							+ title);
			extentTest.log(LogStatus.INFO,
					"The Title Add Attachment pop up displaying is : " + title);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("The Title Add Attachment pop up displaying is wrong : "
							+ title);
			
			extentTest
			.log(LogStatus.FAIL,
					"The Title Add Attachment pop up displaying is wrong: "
							+ title
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		waitforAddFile(Driver);
		Thread.sleep(5000);

		if (pageFactVIII.addFileBtn.isDisplayed()) {

			System.out
					.println("'Add File' button displaying properly in the pop up");
			extentTest.log(LogStatus.INFO,
					"'Add File' button displaying properly in the pop up");

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Add File' button NOT displaying properly in the pop up");
			
			extentTest
			.log(LogStatus.FAIL,
					"Add File' button NOT displaying properly in the pop up"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		if (pageFactVIII.doneBtn.isDisplayed()) {

			System.out
					.println("'Done' button displaying properly in the pop up");
			extentTest.log(LogStatus.INFO,
					"'Done' button displaying properly in the pop up");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("'Done' button NOT displaying properly in the pop up");
			
			extentTest
			.log(LogStatus.FAIL,
					"'Done' button NOT displaying properly in the pop up"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			
		}

		String filename = pageFactVIII.fileNamee(Driver);
		if (pageFactVIII.fileName.isDisplayed()) {

			System.out.println("The file name displaying is : " + filename);
			extentTest.log(LogStatus.INFO, "The file name displaying is : "
					+ filename);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("No file name displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No file name displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		String filetyp = pageFactVIII.fileTypee(Driver);
		if (pageFactVIII.fileType.isDisplayed()) {

			System.out.println("The file type displaying is : " + filetyp);
			extentTest.log(LogStatus.INFO, "The file type displaying is : "
					+ filetyp);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("No file type displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No file type displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		String filesiz = pageFactVIII.fileSizee(Driver);
		if (pageFactVIII.fileSize.isDisplayed()) {

			System.out.println("The file size displaying is : " + filesiz);
			extentTest.log(LogStatus.INFO, "The file size displaying is : "
					+ filesiz);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("No file size displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No file size displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		String datetym = pageFactVIII.dateTimee(Driver);
		if (pageFactVIII.dateTime.isDisplayed()) {

			System.out.println("The Date/Time displaying is : " + datetym);
			extentTest.log(LogStatus.INFO, "The Date/Time displaying is : "
					+ datetym);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("No Date/Time displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No Date/Time displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			
		}

		String uploadedByy = pageFactVIII.uploadedByy(Driver);
		if (pageFactVIII.uploadedBy.isDisplayed()) {

			System.out.println("The uploaded By name displaying is : "
					+ uploadedByy);
			extentTest.log(LogStatus.INFO,
					"The uploaded By name displaying is : " + uploadedByy);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("No uploaded By name displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No uploaded By name displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		pageFactVIII.rejectCheckClk(Driver);
		if (pageFactVIII.rejectCancel.isDisplayed()) {

			System.out
					.println("Clicking on Reject Checkbox redirected to the Reject Reason section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on Reject Checkbox redirected to the Reject Reason section");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Reject check box click not working");
			
			extentTest
			.log(LogStatus.FAIL,
					"Reject check box click not working"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		return null;
	}

	public String attachmentModelHistoryMisc(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFactVIII.incHistClipMisc(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		String title = pageFactVIII.titleCheckTxt(Driver);
		if (pageFactVIII.titleCheckTxt(Driver).equals("Income Attachments")) {

			System.out
					.println("The Title Add Attachment pop up displaying is : "
							+ title);
			extentTest.log(LogStatus.INFO,
					"The Title Add Attachment pop up displaying is : " + title);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("The Title Add Attachment pop up displaying is wrong : "
							+ title);
			
			extentTest
			.log(LogStatus.FAIL,
					"The Title Add Attachment pop up displaying is wrong: "
							+ title
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		waitforAddFile(Driver);
		Thread.sleep(5000);

		if (pageFactVIII.addFileBtn.isDisplayed()) {

			System.out
					.println("'Add File' button displaying properly in the pop up");
			extentTest.log(LogStatus.INFO,
					"'Add File' button displaying properly in the pop up");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("'Add File' button NOT displaying properly in the pop up");
			
			extentTest
			.log(LogStatus.FAIL,
					"'Add File' button NOT displaying properly in the pop up"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		if (pageFactVIII.doneBtn.isDisplayed()) {

			System.out
					.println("'Done' button displaying properly in the pop up");
			extentTest.log(LogStatus.INFO,
					"'Done' button displaying properly in the pop up");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("'Done' button NOT displaying properly in the pop up");
			
			extentTest
			.log(LogStatus.FAIL,
					"'Done' button NOT displaying properly in the pop up"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			
		}

		String filename = pageFactVIII.fileNamee(Driver);
		if (pageFactVIII.fileName.isDisplayed()) {

			System.out.println("The file name displaying is : " + filename);
			extentTest.log(LogStatus.INFO, "The file name displaying is : "
					+ filename);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("No file name displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No file name displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
			
		}

		String filetyp = pageFactVIII.fileTypee(Driver);
		if (pageFactVIII.fileType.isDisplayed()) {

			System.out.println("The file type displaying is : " + filetyp);
			extentTest.log(LogStatus.INFO, "The file type displaying is : "
					+ filetyp);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("No file type displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No file type displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		String filesiz = pageFactVIII.fileSizee(Driver);
		if (pageFactVIII.fileSize.isDisplayed()) {

			System.out.println("The file size displaying is : " + filesiz);
			extentTest.log(LogStatus.INFO, "The file size displaying is : "
					+ filesiz);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("No file size displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No file size displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
		}

		String datetym = pageFactVIII.dateTimee(Driver);
		if (pageFactVIII.dateTime.isDisplayed()) {

			System.out.println("The Date/Time displaying is : " + datetym);
			extentTest.log(LogStatus.INFO, "The Date/Time displaying is : "
					+ datetym);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("No Date/Time displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No Date/Time displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		String uploadedByy = pageFactVIII.uploadedByy(Driver);
		if (pageFactVIII.uploadedBy.isDisplayed()) {

			System.out.println("The uploaded By name displaying is : "
					+ uploadedByy);
			extentTest.log(LogStatus.INFO,
					"The uploaded By name displaying is : " + uploadedByy);

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("No uploaded By name displaying");
			
			extentTest
			.log(LogStatus.FAIL,
					"No uploaded By name displaying"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		pageFactVIII.rejectCheckClk(Driver);
		if (pageFactVIII.rejectCancel.isDisplayed()) {

			System.out
					.println("Clicking on Reject Checkbox redirected to the Reject Reason section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on Reject Checkbox redirected to the Reject Reason section");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("Reject check box click not working");
			
			extentTest
			.log(LogStatus.FAIL,
					"Reject check box click not working"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));
			
		}

		return null;
	}

	public String teamChangeII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		System.out.println("Clicked on Team dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Team dropdown");
		Thread.sleep(2000);
		pageFactVIII.preAuditClk(Driver);
		System.out.println("Selected Pre-Audit");
		extentTest.log(LogStatus.INFO, "Selected Pre-Audit");
		return null;
	}

	public String teamChangePostAudit(WebDriver Driver)
			throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		System.out.println("Clicked on Team dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Team dropdown");
		Thread.sleep(2000);
		pageFactVIII.postAuditClk(Driver);
		System.out.println("Selected Post-Audit");
		extentTest.log(LogStatus.INFO, "Selected Post-Audit");
		return null;
	}

	public String attachRoleValidation(WebDriver Driver)
			throws InterruptedException {

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		Thread.sleep(5000);

		try {
			if (pageFactVIII.addFileBtn.isEnabled()) {

				System.out
						.println("Add File button enabled even after changing the role to non privleged user");
				extentTest
						.log(LogStatus.FAIL,
								"Add File button enabled even after changing the role to non privleged user");

			} else {
				System.out
						.println("Add File button disabled after changing the role to non privleged user");
				extentTest
						.log(LogStatus.INFO,
								"Add File button disabled after changing the role to non privleged user");

			}
		} catch (Exception e) {

			System.out.println("exception " + e);
			System.out
					.println("Add File button disabled after changing the role to non privleged user");
			extentTest
					.log(LogStatus.INFO,
							"Add File button disabled after changing the role to non privleged user");

		}

		return null;
	}

	public String attachDiffFiles1(WebDriver Driver)
			throws InterruptedException, AWTException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "Email1_eml.eml";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button after attaching .eml file");
		extentTest.log(LogStatus.INFO,
				"Clicked on Done button after attaching .eml file");
		Thread.sleep(3000);

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.FAIL, "Error in displaying the count");

		}

		return null;
	}

	public String attachDiffFiles2(WebDriver Driver)
			throws InterruptedException, AWTException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "Pic1_jpg.jpg";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button after attaching .jpg file");
		extentTest.log(LogStatus.INFO,
				"Clicked on Done button after attaching .jpg file");
		Thread.sleep(3000);

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.FAIL, "Error in displaying the count");

		}

		return null;
	}

	public String attachDiffFiles3(WebDriver Driver)
			throws InterruptedException, AWTException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "Sample1_xlsx.xlsx";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button after attaching .xlsx file");
		extentTest.log(LogStatus.INFO,
				"Clicked on Done button after attaching .xlsx file");
		Thread.sleep(3000);

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.FAIL, "Error in displaying the count");

		}

		return null;
	}

	public String attachDiffFiles4(WebDriver Driver)
			throws InterruptedException, AWTException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "Test_pdf.pdf";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button after attaching .pdf file");
		extentTest.log(LogStatus.INFO,
				"Clicked on Done button after attaching .pdf file");
		Thread.sleep(3000);

		String attachCount = pageFactVIII.attachCountt(Driver);
		if (pageFactVIII.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.FAIL, "Error in displaying the count");

		}

		return null;
	}

	public String attachInvalidFile(WebDriver Driver)
			throws InterruptedException, AWTException {

		Robot robot2 = new Robot();

		pageFactVIII.attachClipClk(Driver);
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "2More Than 10MB file_docx.docx";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);

		String filesize = pageFactVIII.moreSizeTxt(Driver);

		if (pageFactVIII.moreSize.isDisplayed()) {
			System.out
					.println("Error message displayed while attaching file with size more than 10MB is "
							+ filesize);
			extentTest.log(LogStatus.INFO,
					"Error message displayed while attaching file with size more than 10MB is "
							+ filesize);

		} else {

			System.out
					.println("No error message while tried to attach file with more size");
			extentTest
					.log(LogStatus.FAIL,
							"No error message while tried to attach file with more size");

		}

		return null;
	}

	public String attachmentReject(WebDriver Driver)
			throws InterruptedException {

		pageFactVIII.attachClipClk(Driver);
		waitforAddFile(Driver);
		Thread.sleep(2500);
		pageFactVIII.rejectCheckClk(Driver);
		Thread.sleep(3000);
		if (pageFactVIII.rejectCancel.isDisplayed()) {

			System.out
					.println("Clicking on Reject Checkbox redirected to the Reject Reason section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on Reject Checkbox redirected to the Reject Reason section");

		} else {

			System.out.println("Reject check box click not working");
			extentTest
					.log(LogStatus.FAIL, "Reject check box click not working");
		}

		// pageFactVIII.rejectReasonn(Driver);

		pageFactVIII.rejectCancelClk(Driver);
		System.out.println("Clicked on Cancel button from the Reject section");
		extentTest.log(LogStatus.INFO,
				"Clicked on Cancel button from the Reject section");

		if (pageFactVIII.addFileBtn.isDisplayed()) {

			System.out
					.println("Clicking on 'Cancel' button redirects user back to the 'Add File' section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on 'Cancel' button redirects user back to the 'Add File' section");

		} else {

			System.out.println("'Cancel' button click not working properly");
			extentTest.log(LogStatus.FAIL,
					"'Cancel' button click not working properly");
		}

		Thread.sleep(3000);
		pageFactVIII.rejectCheckClk(Driver);
		Thread.sleep(3000);
		Actions action = new Actions(Driver);

		action.sendKeys(Keys.TAB).sendKeys("Test Automation").perform();
		Thread.sleep(3000);

		pageFactVIII.rejectOKClk(Driver);
		System.out.println("Clicked on OK button from the Reject section");

		extentTest.log(LogStatus.INFO,
				"Clicked on OK button from the Reject section");

		Thread.sleep(3000);

		if (pageFactVIII.commentReject.isDisplayed()) {

			System.out.println("Reject comment successfully added");
			extentTest.log(LogStatus.INFO, "Reject comment successfully added");

		} else {

			System.out.println("Reject not working");
			extentTest.log(LogStatus.FAIL, "Reject not working");
		}

		return null;
	}

	public String attachmentRejectIncm(WebDriver Driver)
			throws InterruptedException {

		pageFactVIII.incHistClipClk(Driver);

		waitforAddFile(Driver);
		Thread.sleep(2500);
		pageFactVIII.rejectCheckClk(Driver);
		Thread.sleep(3000);
		if (pageFactVIII.rejectCancel.isDisplayed()) {

			System.out
					.println("Clicking on Reject Checkbox redirected to the Reject Reason section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on Reject Checkbox redirected to the Reject Reason section");

		} else {

			System.out.println("Reject check box click not working");
			extentTest
					.log(LogStatus.FAIL, "Reject check box click not working");
		}

		// pageFactVIII.rejectReasonn(Driver);

		pageFactVIII.rejectCancelClk(Driver);
		System.out.println("Clicked on Cancel button from the Reject section");
		extentTest.log(LogStatus.INFO,
				"Clicked on Cancel button from the Reject section");

		if (pageFactVIII.addFileBtn.isDisplayed()) {

			System.out
					.println("Clicking on 'Cancel' button redirects user back to the 'Add File' section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on 'Cancel' button redirects user back to the 'Add File' section");

		} else {

			System.out.println("'Cancel' button click not working properly");
			extentTest.log(LogStatus.FAIL,
					"'Cancel' button click not working properly");
		}

		Thread.sleep(3000);
		pageFactVIII.rejectCheckClk(Driver);
		Thread.sleep(3000);
		Actions action = new Actions(Driver);

		action.sendKeys(Keys.TAB).sendKeys("Test Automation").perform();
		Thread.sleep(3000);

		pageFactVIII.rejectOKClk(Driver);
		System.out.println("Clicked on OK button from the Reject section");

		extentTest.log(LogStatus.INFO,
				"Clicked on OK button from the Reject section");

		Thread.sleep(3000);

		if (pageFactVIII.commentReject.isDisplayed()) {

			System.out.println("Reject comment successfully added");
			extentTest.log(LogStatus.INFO, "Reject comment successfully added");

		} else {

			System.out.println("Reject not working");
			extentTest.log(LogStatus.FAIL, "Reject not working");
		}

		return null;
	}

	public String attachmentRejectIncmMisc(WebDriver Driver)
			throws InterruptedException {

		pageFactVIII.incHistClipMisc(Driver);
		waitforAddFile(Driver);
		Thread.sleep(2500);
		pageFactVIII.rejectCheckClk(Driver);
		Thread.sleep(3000);
		if (pageFactVIII.rejectCancel.isDisplayed()) {

			System.out
					.println("Clicking on Reject Checkbox redirected to the Reject Reason section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on Reject Checkbox redirected to the Reject Reason section");

		} else {

			System.out.println("Reject check box click not working");
			extentTest
					.log(LogStatus.FAIL, "Reject check box click not working");
		}

		// pageFactVIII.rejectReasonn(Driver);

		pageFactVIII.rejectCancelClk(Driver);
		System.out.println("Clicked on Cancel button from the Reject section");
		extentTest.log(LogStatus.INFO,
				"Clicked on Cancel button from the Reject section");

		if (pageFactVIII.addFileBtn.isDisplayed()) {

			System.out
					.println("Clicking on 'Cancel' button redirects user back to the 'Add File' section");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on 'Cancel' button redirects user back to the 'Add File' section");

		} else {

			System.out.println("'Cancel' button click not working properly");
			extentTest.log(LogStatus.FAIL,
					"'Cancel' button click not working properly");
		}

		Thread.sleep(3000);
		pageFactVIII.rejectCheckClk(Driver);
		Thread.sleep(3000);
		Actions action = new Actions(Driver);

		action.sendKeys(Keys.TAB).sendKeys("Test Automation").perform();
		Thread.sleep(3000);

		pageFactVIII.rejectOKClk(Driver);
		System.out.println("Clicked on OK button from the Reject section");

		extentTest.log(LogStatus.INFO,
				"Clicked on OK button from the Reject section");

		Thread.sleep(3000);

		if (pageFactVIII.commentReject.isDisplayed()) {

			System.out.println("Reject comment successfully added");
			extentTest.log(LogStatus.INFO, "Reject comment successfully added");

		} else {

			System.out.println("Reject not working");
			extentTest.log(LogStatus.FAIL, "Reject not working");
		}

		return null;
	}

	public String rejectValidation(WebDriver Driver)
			throws InterruptedException {

		pageFactVIII.rejectCheckClkII(Driver);
		System.out.println("Clicked on Reject checkbox again");
		extentTest.log(LogStatus.INFO, "Clicked on Reject checkbox again");

		Thread.sleep(2000);

		if (pageFactVIII.warningYes.isDisplayed()) {

			System.out
					.println("Clicking on checkbox resulted in displaying the Warning pop up");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on checkbox resulted in displaying the Warning pop up");

		} else {

			System.out
					.println("Clicking on checkbox not showing the warning pop up");
			extentTest.log(LogStatus.FAIL,
					"Clicking on checkbox not showing the warning pop up");

		}

		pageFactVIII.warningNoClk(Driver);

		System.out.println("Clicked on No from the Warning pop up");
		extentTest.log(LogStatus.INFO, "Clicked on No from the Warning pop up");

		if (pageFactVIII.commentReject.isDisplayed()) {

			System.out.println("Clicking on 'No' retains the comment rejected");
			extentTest.log(LogStatus.INFO,
					"Clicking on 'No' retains the comment rejected");

		} else {

			System.out.println("'No' click not working");
			extentTest.log(LogStatus.FAIL, "'No' click not working");
		}

		pageFactVIII.rejectCheckClkII(Driver);
		Thread.sleep(2000);
		pageFactVIII.warningYesClk(Driver);
		System.out.println("Clicked on 'Yes' from the Warning pop up");
		extentTest.log(LogStatus.INFO,
				"Clicked on 'Yes' from the Warning pop up");

		Thread.sleep(7000);

		try {
			if (pageFactVIII.commentReject.isDisplayed()) {

				System.out.println("'Yes' clicking not working properly");
				extentTest.log(LogStatus.FAIL,
						"'Yes' clicking not working properly");

			} else {

				System.out
						.println("'Clicking on 'Yes' successfully 'un-rejected' the attachment");
				extentTest
						.log(LogStatus.INFO,
								"Clicking on 'Yes' successfully 'un-rejected' the attachment");
			}
		} catch (Exception e) {

			System.out
					.println("'Clicking on 'Yes' successfully 'un-rejected' the attachment");
			extentTest
					.log(LogStatus.INFO,
							"Clicking on 'Yes' successfully 'un-rejected' the attachment");

		}

		return null;
	}

	public String AlwnceBRRetailOverlap(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		Thread.sleep(3500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(2500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDt();
		pageFactVIII.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(2500);
		pageFact.itemAlwType();
		Thread.sleep(2500);
		pageFact.allwtype();
		Thread.sleep(2500);
		pageFactVIII.allwTP1P2();
		Thread.sleep(3000);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapII(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3500);
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		Thread.sleep(4500);
		pageFact.retailalw();
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldLeadCIC();
		Thread.sleep(4500);
		pageFactVIII.bRTypeRetailFieldStartDt();
		pageFactVIII.bRTypeRetailFieldEndDtII();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		Thread.sleep(4500);
		pageFact.allwtype();
		Thread.sleep(4500);
		pageFactVIII.allwTP1P2();
		Thread.sleep(3000);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	// S-6 NULL
	public String AlwnceBRRetailOverlapIII(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDt();
		pageFactVIII.bRTypeRetailFieldEndDtII();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFactVIII.allwTP1P2II();
		Thread.sleep(3000);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	// C-51
	public String AlwnceBRRetailOverlapC51(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2III();
		Thread.sleep(3000);

		pageFact.p1AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapC51II(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2III();
		Thread.sleep(3000);

		pageFact.p1AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT30(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2();
		Thread.sleep(3000);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT05(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2();
		Thread.sleep(3000);

		// pageFact.p1AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapS06(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2II();
		Thread.sleep(3000);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT20(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2IV();
		Thread.sleep(5000);
		pageFactVIII.perf2Box.click();
		Thread.sleep(2500);
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT2077(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2V();
		Thread.sleep(5000);
		pageFactVIII.perf2Box.click();
		Thread.sleep(2500);
		pageFact.p2AlwT2.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT2077II(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2V();
		Thread.sleep(5000);
		pageFactVIII.perf2Box.click();
		Thread.sleep(2500);
		pageFact.p2AlwT2.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT38(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2IV();
		Thread.sleep(5000);
		pageFactVIII.perf2Box.click();
		Thread.sleep(2500);
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapA04(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2AA();
		Thread.sleep(5000);
		pageFactVIII.p1AlwT0II.click();
		Thread.sleep(4500);

		pageFactVIII.perf2BoxIII.click();
		Thread.sleep(4500);
		pageFactVIII.p2AlwT0.click();

		Thread.sleep(2500);
		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapA08(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2AA();
		Thread.sleep(5000);
		pageFactVIII.p1AlwT0II.click();
		Thread.sleep(4500);

		pageFactVIII.perf2BoxIII.click();
		Thread.sleep(4500);
		pageFactVIII.p2AlwT1.click();

		Thread.sleep(2500);
		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapA88(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2AA();
		Thread.sleep(5000);
		pageFactVIII.p1AlwT0II.click();
		Thread.sleep(4500);

		pageFactVIII.perf2BoxIII.click();
		Thread.sleep(4500);
		pageFactVIII.p2AlwT2.click();

		Thread.sleep(2500);
		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapA04II(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2AA();
		Thread.sleep(5000);
		pageFactVIII.p1AlwT0II.click();
		Thread.sleep(4500);

		pageFactVIII.perf2BoxIII.click();
		Thread.sleep(4500);
		pageFactVIII.p2AlwT0.click();

		Thread.sleep(2500);
		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT38II(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2IV();
		Thread.sleep(5000);
		pageFactVIII.perf2Box.click();
		Thread.sleep(2500);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapT20II(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2IV();
		Thread.sleep(5000);
		pageFactVIII.perf2Box.click();
		Thread.sleep(2500);
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRRetailOverlapS06II(WebDriver Driver)
			throws IOException, InterruptedException, ParseException,
			BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(1500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(1500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2II();
		Thread.sleep(3000);
		// pageFact.p2AlwT0.click();
		// Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String overlaps(WebDriver Driver) throws BiffException, IOException,
			InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);
		AlwnceBRRetailOverlapII(Driver);
		BRSave(Driver);
		Thread.sleep(5000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);

		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("2")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsII(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapT30(Driver);
		BRSave(Driver);
		Thread.sleep(5000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);

		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("2")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsS06(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapS06II(Driver);
		BRSave(Driver);
		Thread.sleep(5000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);

		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("1")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsC51(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapC51II(Driver);
		BRSave(Driver);
		Thread.sleep(5000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);

		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("2")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsC51CIC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapC51II(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("1")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsT20CIC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapT20II(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("2")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsT2077CIC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapT2077II(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("2")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsT38CIC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapT38II(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("2")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsCOGS(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		COGSAlwnceBRII(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(5000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("1")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsA04CIC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapA04II(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("1")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("0")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String overlapsA08CIC(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		pageFactVII.searchh(Driver);
		Thread.sleep(5000);
		AlwnceBRRetailOverlapA88(Driver);
		BRSave(Driver);

		Thread.sleep(10000);
		// String billingId= pageFactV.blngRcrdidd();
		// System.out.println("Billing record id is: " + billingId);
		// extentTest
		// .log(LogStatus.INFO,
		// "Billing record id is: " + billingId);
		pageFactVIII.alwncInfoExpandClk(Driver);
		Thread.sleep(2500);
		System.out.println("Allowance Information section expanded");
		extentTest
				.log(LogStatus.INFO, "Allowance Information section expanded");
		Thread.sleep(2000);

		pageFactVIII.overlapDrpClk(Driver);

		System.out.println("Clicked on Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap dropdown");
		Thread.sleep(5000);

		// WebElement overlapVal =
		// Driver.findElement(By.xpath("//*[@id='heading_"+ billingId
		// +"']/span"));
		WebElement overlapValII = Driver.findElement(By.xpath("//*[@id='title_"
				+ billingId + "']/button/i-feather[1]"));

		System.out.println("Overlapped billing record id is: " + billingId);
		extentTest.log(LogStatus.INFO, "Overlapped billing record id is: "
				+ billingId);

		overlapValII.click();
		System.out.println("Clicked on Overlap Value");
		extentTest.log(LogStatus.INFO, "Clicked on Overlap Value");

		Thread.sleep(5000);
		if (pageFactVIII.overlapItem.isDisplayed()) {
			System.out
					.println("The Overlapped BR displaying in the 'Overlaps' dropdown");
			extentTest.log(LogStatus.INFO,
					"The Overlapped BR displaying in the 'Overlaps' dropdown");

		} else {
			System.out
					.println("The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"The Overlapped BR NOT displaying in the 'Overlaps' dropdown");
		}

		String overlapItems = pageFactVIII.overlapItemTxt(Driver);
		String overlapDate = pageFactVIII.overlapDate(Driver);

		if (overlapItems.equals("1")) {

			System.out.println("Overlap item displaying is : " + overlapItems);
			extentTest.log(LogStatus.INFO, "Overlap item displaying is : "
					+ overlapItems);
		} else {

			System.out.println("Overlap item displaying is wrong"
					+ overlapItems);
			extentTest.log(LogStatus.FAIL, "Overlap item displaying is wrong"
					+ overlapItems);
		}

		if (overlapDate.equals("4")) {

			System.out.println("Overlap date displaying is : " + overlapDate);
			extentTest.log(LogStatus.INFO, "Overlap date displaying is : "
					+ overlapDate);

		} else {

			System.out.println("Overlap date displaying is wrong: "
					+ overlapDate);
			extentTest.log(LogStatus.FAIL, "Overlap date displaying is wrong"
					+ overlapDate);
		}

		return null;
	}

	public String waitforReadyBtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVIII.ready));
		return null;
	}

	public String AlwnceBRNoItemizd(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		//Thread.sleep(30000);	
		pageFact.waitForSpinnerToBeGone();
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(25000);
				
		pageFact.blngrcrdDrp();
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(5000);
		
		pageFact.retailalw();
		Thread.sleep(5500);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldLeadCIC();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(3000);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(3000);
		pageFact.itemAlwType();
		Thread.sleep(3000);
		pageFact.brSubmit.click();

		return null;

	}

	public String waitforAlwncType(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVI.cogsType));
		return null;
	}

	public String COGSAlwnceBRNoItemized(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		Thread.sleep(25000);
		pageFact.creatBillng();
		Thread.sleep(3500);
		pageFact.blngrcrdDrp();
				Thread.sleep(3500);
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(3000);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(3000);
		pageFact.itemAlwType();
		Thread.sleep(3000);

		pageFact.brSubmit.click();

		return null;

	}

	public String COGSAlwnceBR(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(2500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");

		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");

		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtOne();
		pageFactVIII.bRTypeRetailFieldEndDtSeven();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2COGS();
		Thread.sleep(5000);
		pageFactVIII.perf2BoxIII.click();
		Thread.sleep(4500);
 
		pageFactVIII.p2AlwT0.click();
		Thread.sleep(3500);

		// pageFact.allwTP1P2();
		// Thread.sleep(2500);
		// pageFactVI.p2AlwT1.click();
		// Thread.sleep(3500);

		pageFact.brSubmit.click();

		 
		 return null;

	}

	public boolean COGSAlwnceBRII(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(2500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");

		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");

		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFactVIII.bRTypeRetailFieldStartDtFour();
		pageFactVIII.bRTypeRetailFieldEndDtFifteen();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();

		pageFactVIII.allwTP1P2COGS();
		Thread.sleep(5000);
		pageFactVIII.perf2BoxIII.click();
		Thread.sleep(4500);
 
		pageFactVIII.p2AlwT0.click();
		Thread.sleep(3500);

		// pageFact.allwTP1P2();
		// Thread.sleep(2500);
		// pageFactVI.p2AlwT1.click();
		// Thread.sleep(3500);

		pageFact.brSubmit.click();

		waitforbrtxt(Driver);
		Thread.sleep(2500);

		if (pageFact.BRtxt.isDisplayed()) {

			return true;

		} else {

			return false;
		}

		// return null;

	}

	public String readyBtnClk(WebDriver Driver) {

		pageFactVIII.readyClk(Driver);
		System.out.println("Clicked on Ready Button");
		extentTest.log(LogStatus.INFO, "Clicked on Ready Button");
		return null;
	}

	public String incomeAttach(WebDriver Driver) throws InterruptedException,
			AWTException {

		Robot robot3 = new Robot();

		pageFactVIII.clipIncomeClk(Driver);

		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot3.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(5000);

		String attachCount = pageFactVIII.attachCountIncomeTxt(Driver);
		if (pageFactVIII.attachCountIncome.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.INFO, "Error in displaying the count");

		}

		return null;
	}

	public String MiscincomeAttach(WebDriver Driver)
			throws InterruptedException, AWTException {

		Robot robot3 = new Robot();

		pageFactVIII.clipIncomeMiscClk(Driver);

		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot3.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(5000);

		String attachCount = pageFactVIII.attachCountIncomeMiscTxt(Driver);
		if (pageFactVIII.attachCountIncomeMisc.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.INFO, "Error in displaying the count");

		}

		return null;
	}

	public String incmSave(WebDriver Driver) throws InterruptedException {

		pageFactAS3.notesTxtBoxx(Driver);
		// pageFactAS3.flatAmtt(Driver);
		pageFactAS3.notesTabFlatAmt(Driver);
		// pageFactAS3.incmSaveBtnn(Driver);
		// extentTest.log(LogStatus.INFO, "Clicked on Save button");

		pageFactVIII.incmSubmitClk(Driver);
		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");

		Thread.sleep(5000);

		return null;
	}

	public String miscAddIncome(WebDriver Driver) {

		pageFactAS3.incmbtnclk();

		return null;
	}

	public String incmSaveMisc(WebDriver Driver) {

		return null;
	}

	public String incHistory(WebDriver Driver) throws AWTException,
			InterruptedException {

		pageFactVIII.incHistClk(Driver);
		Thread.sleep(2500);
		pageFactVIII.incHistClipClk(Driver);

		Robot robot4 = new Robot();
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot4.keyPress(KeyEvent.VK_ESCAPE);

		Thread.sleep(5000);

		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(5000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(5000);

		String attachCount = pageFactVIII.attachCountIncomeHisTxt(Driver);
		if (pageFactVIII.attachCountHistory.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.INFO, "Error in displaying the count");

		}

		return null;
	}

	public String MiscincSaveBtn() throws IOException, InterruptedException {

		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		pageFactAS3.incAmntt(Driver);
		Thread.sleep(3000);
		pageFactAS3.incmSubmtt();
		System.out.println("Misc Income successfully Submitted");
		extentTest.log(LogStatus.INFO, "Misc Income successfully Submitted");

		Thread.sleep(3000);

		return null;
	}

	public String incHistoryMisc(WebDriver Driver) throws AWTException,
			InterruptedException {

		pageFactVIII.incHistMiscClk(Driver);
		Thread.sleep(2500);
		pageFactVIII.incHistClipMisc(Driver);

		Robot robot4 = new Robot();
		System.out.println("Clicked on Attach Clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on Attach Clip icon");

		waitforAddFile(Driver);
		robot4.keyPress(KeyEvent.VK_ESCAPE);

		Thread.sleep(5000);

		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(5000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\"
				+ "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(5000);

		String attachCount = pageFactVIII.attachCountHistoryMiscTxt(Driver);
		if (pageFactVIII.attachCountHistoryMisc.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Count displaying is : "
					+ attachCount);

		} else {

			System.out.println("Error in displaying the count");
			extentTest.log(LogStatus.INFO, "Error in displaying the count");

		}

		return null;
	}

	public String addfileRights(WebDriver Driver) throws InterruptedException {

		pageFactVIII.clipIncomeClk(Driver);
		Thread.sleep(3000);
		try {

			if (pageFactVIII.addFileBtn.isEnabled()) {

				System.out
						.println("'Add File' button displaying for user who do not have proper privileges");
				extentTest
						.log(LogStatus.FAIL,
								"'Add File' button displaying for user who do not have proper privileges");

			} else {

				System.out
						.println("'Add File' button is disabled, as the user do not have proper privileges");
				extentTest
						.log(LogStatus.INFO,
								"'Add File' button is disabled, as the user do not have proper privileges");

			}

		} catch (Exception e) {

			System.out
					.println("'Add File' button is disabled, as the user do not have proper privileges");
			extentTest
					.log(LogStatus.INFO,
							"'Add File' button is disabled, as the user do not have proper privileges");

		}

		try {

			if (pageFactVIII.rejectCheck.isSelected()) {

				System.out
						.println("'Reject' button displaying for user who do not have proper privileges");
				extentTest
						.log(LogStatus.FAIL,
								"'Reject' button displaying for user who do not have proper privileges");

			} else {
				System.out
						.println("'Reject' button is disabled, as the user do not have proper privileges");
				extentTest
						.log(LogStatus.INFO,
								"'Reject' button is disabled, as the user do not have proper privileges");

			}

		} catch (Exception e) {

			System.out
					.println("'Reject' button is disabled, as the user do not have proper privileges");
			extentTest
					.log(LogStatus.INFO,
							"'Reject' button is disabled, as the user do not have proper privileges");

		}

		return null;
	}

	public String addFileRightsII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		pageFactVIII.incHistClk(Driver);
		Thread.sleep(2500);
		pageFactVIII.incHistClipClk(Driver);
		Thread.sleep(3000);

		try {

			if (pageFactVIII.addFileBtn.isEnabled()) {

				System.out
						.println("Income History:  'Add File' button displaying for user who do not have proper privileges");
				extentTest
						.log(LogStatus.FAIL,
								"Income History:  'Add File' button displaying for user who do not have proper privileges");

			} else {

				System.out
						.println("Income History:  'Add File' button is disabled, as the user do not have proper privileges");
				extentTest
						.log(LogStatus.INFO,
								"Income History:  'Add File' button is disabled, as the user do not have proper privileges");
			}

		} catch (Exception e) {

			System.out
					.println("Income History:  'Add File' button is disabled, as the user do not have proper privileges");
			extentTest
					.log(LogStatus.INFO,
							"Income History:  'Add File' button is disabled, as the user do not have proper privileges");

		}

		try {

			if (pageFactVIII.rejectCheck.isSelected()) {

				System.out
						.println("Income History:  'Reject' button displaying for user who do not have proper privileges");
				extentTest
						.log(LogStatus.FAIL,
								"Income History:  'Reject' button displaying for user who do not have proper privileges");

			} else {

				System.out
						.println("Income History:  'Reject' button is disabled, as the user do not have proper privileges");
				extentTest
						.log(LogStatus.INFO,
								"Income History:  'Reject' button is disabled, as the user do not have proper privileges");

			}

		} catch (Exception e) {

			System.out
					.println("Income History:  'Reject' button is disabled, as the user do not have proper privileges");
			extentTest
					.log(LogStatus.INFO,
							"Income History:  'Reject' button is disabled, as the user do not have proper privileges");

		}

		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactV = new GenericFactoryV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFactJS3 = new GenericFactoryJSprint3(Driver);
		pageFact = new GenericFactory(Driver);
		pageFactVI = new GenericFactoryVI(Driver);
		pageFactVII = new GenericFactoryVII(Driver);
		pageFactVIII = new GenericFactoryVIII(Driver);
	}

}
