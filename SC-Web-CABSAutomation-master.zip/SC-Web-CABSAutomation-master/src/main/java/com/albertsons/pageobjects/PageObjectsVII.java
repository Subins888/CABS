package com.albertsons.pageobjects;

import java.io.File;

import java.io.FileInputStream;

import java.io.IOException;

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

import java.util.Properties;

import jxl.Sheet;

import jxl.Workbook;

import jxl.read.biff.BiffException;

import org.apache.poi.hssf.usermodel.HSSFCell;

import org.apache.poi.hssf.usermodel.HSSFSheet;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.openqa.selenium.By;

import org.openqa.selenium.OutputType;

import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;

import com.albertsons.reportGeneration.ExtendBaseClass;

import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsVII extends ExtendBaseClass {

	/**
	 * 
	 *
	 * 
	 *
	 * 
	 * @author akuma58
	 * 
	 *
	 */

	WebDriver Driver;

	GenericFactory pageFact;

	Properties prop;

	HSSFWorkbook workbook;

	HSSFSheet sheet;

	HSSFCell cell;

	GenericFactoryIV pageFactIV;

	GenericFactoryVI pageFactVI;

	GenericFactoryVII pageFactVII;

	GenericFactoryV pageFactV;

	GenericFactorySprint3 pageFactAS3;

	GenericFactoryJSprint3 pageFactJS3;

	public PageObjectsVII(WebDriver Driver) {

		this.Driver = Driver;

		PageFactory.initElements(Driver, this);

	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		// File source = ts.getScreenshotAs(OutputType.FILE);
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	// public File aftermthd(WebDriver Driver) throws IOException {
	//
	//
	//
	// TakesScreenshot ts = (TakesScreenshot) Driver;
	//
	// File source = ts.getScreenshotAs(OutputType.FILE);
	//
	//
	//
	// return source;
	//
	// }

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions

		.elementToBeClickable(pageFactVII.createBillrcrd));

		return null;

	}

	public String waitforHistory(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions

		.elementToBeClickable(pageFactVII.miscHistory));

		return null;

	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));

		return null;

	}

	public String waitforbillType(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions

		.elementToBeClickable(pageFact.blngRcrdType0));

		return null;

	}

	public String waitforSearchItem(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions

		.elementToBeClickable(pageFactVII.firstItem));

		return null;

	}

	public String nonAlwnceNoRetailType(WebDriver Driver)
	throws InterruptedException {

		waitforBlngbtn(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		
		Thread.sleep(7000);
		pageFact.BrTyp();
		waitforbillType(Driver);
		Thread.sleep(2000);
		pageFact.nonAllwdrp();
		Thread.sleep(5500);
		pageFact.submitClk();
		waitforbrtxt(Driver);

		return null;

	}

	public String nonAlwnceType(WebDriver Driver) throws InterruptedException,

	BiffException, IOException {

		waitforBlngbtn(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		 

		pageFact.BrTyp();
		Thread.sleep(3000);
		pageFactVII.nonAllwdrp();
		Thread.sleep(4500);
		pageFactV.RetailDivv(Driver);
		Thread.sleep(4500);
		pageFactV.RetailDivValuee(Driver);
		Thread.sleep(4500);

		pageFactV.lukuPp(Driver);
		Thread.sleep(5000);
		pageFactVII.RetailDivVal33(Driver);
		pageFact.submitClk();

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
 
		String file = new File(System.getProperty("user.dir"), "TestData.xls")
		.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);
		Workbook w = Workbook.getWorkbook(fi);

		Sheet s = w.getSheet(1);
		try {

			for (int i = 2; i < s.getRows(); i++) {

				// Read data from excel sheet

				String s3 = s.getCell(2, i).getContents();
				Thread.sleep(3000);
				pageFactAS3.ofsetSecNum.sendKeys(s3);

			}

		} catch (Exception e) {

			System.out.println(e);

		}

		Thread.sleep(3000);
		pageFactV.elmntIntract(Driver);
		pageFactV.txtAreaa(Driver);
		Thread.sleep(3000);
		pageFactV.brSavebtnn(Driver);

//		pageFact.waitForSpinnerToBeGone();
//		pageFact.waitForSpinnerToBeGoneII();
		Thread.sleep(55000);

		return null;

	}

	public String ofsetValidationMisc(WebDriver Driver)

	throws InterruptedException, BiffException, IOException {

		Thread.sleep(2000);

		waitforbrtxt(Driver);

		Thread.sleep(5000);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")

		.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);

		Sheet s = w.getSheet(1);

		try {

			for (int i = 2; i < s.getRows(); i++) {

				// Read data from excel sheet

				String s1 = s.getCell(0, i).getContents();

				String s2 = s.getCell(1, i).getContents();

				String s3 = s.getCell(2, i).getContents();

				Thread.sleep(3000);

				pageFactAS3.ofsetAcntNum.sendKeys(s1);

				pageFactAS3.ofsetFacNum.sendKeys(s2);

				pageFactAS3.ofsetSecNum.sendKeys(s3);

			}

		} catch (Exception e) {

			System.out.println(e);

		}

		Thread.sleep(3000);

		pageFactV.elmntIntract(Driver);

		pageFactV.txtAreaa(Driver);

		pageFactV.brSavebtnn(Driver);

		Thread.sleep(2000);

		pageFactV.brSavebtnn(Driver);

		Thread.sleep(2000);

		pageFactV.brSavebtnn(Driver);

		Thread.sleep(2000);

		return null;

	}

	public String miscIncmeBtnClk(WebDriver Driver) {

		pageFactAS3.incmbtnclk();

		return null;

	}

	public String miscHistoryPlus(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactVII.miscHistoryy(Driver);
		System.out.println("Clicked on Income History '+' button");
		extentTest.log(LogStatus.INFO, "Clicked on Income History '+' button");

		Thread.sleep(2500);

		if (pageFactVII.incmStatus.isDisplayed()) {

			System.out.println("Income History section expanded");
			extentTest.log(LogStatus.INFO, "Income History section expanded");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Income History section NOT expanded");

			extentTest.log(
					LogStatus.FAIL,
					"TESTCASE FAILED: Income History section NOT expanded"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String pendingOTCheck(WebDriver Driver) throws InterruptedException,
			IOException {

		String pendingOTTxt = pageFactVII.incmStatuss(Driver);

		Thread.sleep(2500);

		if (pageFactVII.incmStatuss(Driver).equals("Pending OT")) {

			System.out

			.println("The created income record is in Pending OT status: "

			+ pendingOTTxt);

			extentTest.log(LogStatus.INFO,

			"The created income record is in Pending OT status: "

			+ pendingOTTxt);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("The created income record is not in Pending OT status: "
							+ pendingOTTxt);
			extentTest.log(
					LogStatus.FAIL,
					"The created income record is not in Pending OT status: "
							+ pendingOTTxt
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String pendingOTCheckAcru(WebDriver Driver)

	throws InterruptedException, IOException {

		String pendingOTTxt = pageFactVII.incmStatussII(Driver);

		Thread.sleep(2500);

		if (pageFactVII.incmStatussII(Driver).equals("Pending OT")) {

			System.out

					.println("Accrue: The created income record is in Pending OT status: "

							+ pendingOTTxt);

			extentTest.log(LogStatus.INFO,

			"Accrue: The created income record is in Pending OT status: "

			+ pendingOTTxt);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Accrue: The created income record is not in Pending OT status: "
							+ pendingOTTxt);
			extentTest.log(
					LogStatus.FAIL,
					"Accrue: The created income record is not in Pending OT status: "
							+ pendingOTTxt
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String pendingOTCheckBilNdAcru(WebDriver Driver)

	throws InterruptedException, IOException {

		String pendingOTTxt = pageFactVII.incmStatussIV(Driver);

		Thread.sleep(2500);

		if (pageFactVII.incmStatussIV(Driver).equals("Pending OT")) {

			System.out

					.println("Bill & Accrue - Accrue: The created income record is in Pending OT status: "

							+ pendingOTTxt);

			extentTest.log(LogStatus.INFO,

			"Bill & Accrue - Accrue:  The created income record is in Pending OT status: "

			+ pendingOTTxt);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Bill & Accrue - Accrue:  The created income record is not in Pending OT status: "
							+ pendingOTTxt);
			extentTest
					.log(LogStatus.FAIL,
							"Bill & Accrue - Accrue:  The created income record is not in Pending OT status: "
									+ pendingOTTxt
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		String pendingOTTxt2 = pageFactVII.incmStatussIII(Driver);

		if (pageFactVII.incmStatussIII(Driver).equals("Pending OT")) {

			System.out

					.println("Bill & Accrue - Bill: The created income record is in Pending OT status: "

							+ pendingOTTxt2);

			extentTest.log(LogStatus.INFO,

			"Bill & Accrue - Bill:  The created income record is in Pending OT status: "

			+ pendingOTTxt2);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Bill & Accrue - Bill:  The created income record is not in Pending OT status: "
							+ pendingOTTxt2);
			extentTest
					.log(LogStatus.FAIL,
							"Bill & Accrue - Bill:  The created income record is not in Pending OT status: "
									+ pendingOTTxt2
									+ extentTest
											.addScreenCapture("data:image/png;base64,"
													+ source));

		}

		return null;

	}

	public String otMiscII(WebDriver Driver) throws InterruptedException,
			IOException {

		Thread.sleep(2000);

		pageFactAS3.comentTxtBox(Driver);

		pageFactAS3.descripTxtBo(Driver);

		Thread.sleep(5000);

		pageFactVII.incAmntt(Driver);

		Thread.sleep(5000);

		if (pageFactVI.miscIncomeWarn.isDisplayed()) {

			System.out.println("OT Warning message displayed");

			extentTest.log(LogStatus.INFO, "OT Warning message displayed");

		} else {

			System.out.println("OT Warning message NOT displayed");

			extentTest.log(LogStatus.INFO, "OT Warning message NOT displayed");

		}

		pageFactVI.miscIncomeWarnn(Driver);

		Thread.sleep(5000);

		String warngMsg = pageFactVI.warngMsgMiscc(Driver);

		if (pageFactVI.miscWarningMsgIIg(Driver).contains(

		"Income will be sent for approval")) {

			System.out

			.println("Misc OT Limit exceeds, showing warning message: "

			+ warngMsg);

			extentTest.log(LogStatus.INFO,

			"Misc OT Limit exceeds, showing warning message: "

			+ warngMsg);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Misc OT Limit exceeds not showing any warning messages");

			extentTest.log(
					LogStatus.FAIL,
					"Misc OT Limit exceeds not showing any warning messages"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVI.addIncomeMiscc(Driver);

		System.out.println("Clicked on Income Submit button");

		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");

		return null;

	}

	public String AddIncmMisc(WebDriver Driver) {

		pageFactVI.addIncomeMiscc(Driver);

		return null;

	}

	public String AddIncmMiscII(WebDriver Driver) {

		pageFactVII.incomeBtnMiscc(Driver);

		return null;

	}

	public String otMiscIII(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);

		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);

		Thread.sleep(5000);

		pageFactVII.incAmnt(Driver);
		Thread.sleep(5000);

		pageFactVI.addIncomeMiscc(Driver);
		System.out.println("Clicked on Income Submit button");
		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");

		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(55000);

		return null;

	}

	public String payback(WebDriver Driver) {

		String incHistTxt = pageFactVII.incHistoryPaybackTxtt(Driver);

		try {

			pageFactVII.incHistoryPaybackTxtt(Driver).contains("Payback");

			{

				Thread.sleep(2500);

				pageFactVII.incHistoryPaybackTxtClk(Driver);

				System.out.println("Payback creation pop up displayed");

				extentTest.log(LogStatus.INFO,

				"Payback creation pop up displayed");

				Thread.sleep(2500);

				pageFactVII.paybackAproverr(Driver);

				System.out.println("Approver selected");

				extentTest.log(LogStatus.INFO, "Approver selected");

				pageFactVII.reasonn(Driver);

				System.out.println("Reason added");

				extentTest.log(LogStatus.INFO, "Reason added");

				pageFactVII.userss(Driver);

				System.out.println("Users added");

				extentTest.log(LogStatus.INFO, "Users added");

				pageFactVII.paybackSubmitt(Driver);

				System.out.println("Clicked on Submit button");

				extentTest.log(LogStatus.INFO, "Clicked on Submit button");

			}

		} catch (Exception e) {

			System.out

					.println("Income Status not changed to Sent to Vendor so button displaying is:  "

							+ incHistTxt);

			extentTest.log(LogStatus.INFO,

			"Income Status not changed to Sent to Vendor so button displaying is:  "

			+ incHistTxt);

		}

		return null;

	}

	public String paybackValidation(WebDriver Driver) {

		try {

			pageFactVII.incHistoryPaybackTxtt(Driver).contains("Payback");

			{

				Thread.sleep(2500);

				pageFactVII.incHistoryPaybackTxtClk(Driver);

				Thread.sleep(2500);

				System.out.println("Payback creation pop up displayed");

				extentTest.log(LogStatus.INFO,

				"Payback creation pop up displayed");

				Thread.sleep(2500);

				pageFactVII.paybackSubmitt(Driver);

				System.out

						.println("Clicked on Submit button without filling the payback approver details");

				extentTest

						.log(LogStatus.INFO,

						"Clicked on Submit button without filling the payback approver details");

				Thread.sleep(2500);

				String ErrMsg = pageFactVII.errMsgTxt(Driver);

				if (pageFactVII.errMsgTxt(Driver).contains(

				"Please enter the required")) {

					System.out.println("Error message displaying is :  "

					+ ErrMsg);

					extentTest.log(LogStatus.INFO,

					"Error message displaying is :  " + ErrMsg);

				} else {

					System.out

							.println("No Error message or error message showing is wrong :  "

									+ ErrMsg);

					extentTest.log(LogStatus.INFO,

					"No Error message or error message showing is wrong :  "

					+ ErrMsg);

				}

			}

		} catch (Exception e) {

			System.out

					.println("Income Status not changed to Sent to Vendor so button displaying is:  ");

			extentTest

					.log(LogStatus.INFO,

					"Income Status not changed to Sent to Vendor so button displaying is:  ");

		}

		return null;

	}

	public boolean dropDownListSortedOrNot(WebDriver Driver)

	throws InterruptedException {

		try {

			pageFactVII.paybackAproverrII(Driver);

			List<WebElement> dropDownvalues = pageFactVII.incHistoryPaybackTxt

			.findElements(By.className("ng-input"));

			ArrayList<String> listValues = new ArrayList<String>();

			for (WebElement value : dropDownvalues) {

				listValues.add(value.getText());

			}

			ArrayList<String> SortlistValues = new ArrayList<String>();

			for (String s : listValues) {

				SortlistValues.add(s);

			}

			Collections.sort(SortlistValues);

			System.out.println("Values obtained from UI are " + listValues);

			System.out.println("After Sorting the values obtained are "

			+ SortlistValues);

			if (SortlistValues.equals(listValues)) {

				return true;

			} else {

				return false;

			}

		} catch (Exception e) {
			System.out

					.println("Unable to sort because of some unexpected error/privlege issue");

			extentTest

					.log(LogStatus.INFO,

					"Unable to sort because of some unexpected error/privlege issue");
			return false;

		}

	}

	public String scroldown(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);

		act.moveToElement(pageFactVII.miscHistory).perform();

		return null;

	}

	//

	// public String scroldownII(WebDriver Driver) {

	//

	// // pageFactJS3.allwTab(Driver);

	//

	// Actions act = new Actions(Driver);

	//

	//

	//

	// act.moveToElement(pageFactAS3.comentTxtBox).perform();

	// return null;

	// }

	public String reasonCheck(WebDriver Driver) throws InterruptedException {
		
		try{

		pageFactVII.paybackAproverr(Driver);

		Thread.sleep(2000);

		pageFactVII.reasonn(Driver);

		pageFactVII.reasonn2(Driver);

		pageFactVII.reasonn3(Driver);

		pageFactVII.paybackSubmitt(Driver);

		Thread.sleep(3000);

		String errmsg = pageFactVII.errMsgTxt(Driver);

		if (pageFactVII.errMsg.isDisplayed()) {

			System.out.println("Error message displaying is :  " + errmsg);

			extentTest.log(LogStatus.INFO, "Error message displaying is :  "

			+ errmsg);

		} else {

			System.out

			.println("No Error message or error message showing is wrong :  "

			+ errmsg);

			extentTest.log(LogStatus.FAIL,

			"No Error message or error message showing is wrong :  "

			+ errmsg);

		}}
		catch(Exception e){
			
			System.out.println("No error message displaying");

			extentTest.log(LogStatus.INFO, "No error message displaying");
		}

		return null;

	}

	public String UserCheck(WebDriver Driver) throws InterruptedException {

		try{
		Thread.sleep(2000);

		pageFactVII.userss(Driver);

		pageFactVII.userss2(Driver);

		pageFactVII.userss3(Driver);

		pageFactVII.paybackSubmitt(Driver);

		Thread.sleep(3000);

		String errmsg = pageFactVII.errMsgTxt(Driver);

		if (pageFactVII.errMsg.isDisplayed()) {

			System.out.println("Error message displaying is :  " + errmsg);

			extentTest.log(LogStatus.INFO, "Error message displaying is :  "

			+ errmsg);

		} else {

			System.out

			.println("No Error message or error message showing is wrong :  "

			+ errmsg);

			extentTest.log(LogStatus.INFO,

			"No Error message or error message showing is wrong :  "

			+ errmsg);

		}}
		catch(Exception e){
			
			
			System.out.println("No error message displaying");

			extentTest.log(LogStatus.INFO, "No error message displaying");
		}

		return null;

	}


	public String close(WebDriver Driver) {

		pageFactVII.closeBtnn(Driver);

		return null;

	}

	public String closeII(WebDriver Driver) {

		pageFactVII.closeBtnn2(Driver);

		return null;

	}

	public String waitforFirstWrklist(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions

		.elementToBeClickable(pageFactVII.firstWrklist));

		return null;

	}

public String paybackWorklistLeft(WebDriver Driver)

	throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFactVII.payBackWorklistt(Driver);

		System.out.println("Clicked on PayBack button from the left panel");

		extentTest.log(LogStatus.INFO,

		"Clicked on PayBack button from the left panel");

		//waitforFirstWrklist(Driver);
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(7500);
	
		String worklist = pageFactVII.firstWrklist.getText();

		try {

			if (pageFactVII.firstWrklist.isDisplayed())

				System.out

				.println("Payback worklist BRs displaying in the page");

			extentTest.log(LogStatus.INFO,

			"Payback worklist BRs displaying in the page");

		} catch (Exception e) {

			System.out

			.println("Payback worklist BRs NOT displaying in the page");

			extentTest.log(LogStatus.INFO,

			"Payback worklist BRs NOT displaying in the page");

		}

		System.out.println("BR displaying in the Payback Worklist is: "

		+ worklist);

		extentTest.log(LogStatus.INFO,

		"BR displaying in the Payback Worklist is: " + worklist);

		pageFactVII.firstWrklisttClk(Driver);

		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		//String incHistory = pageFactVII.incHistoryy(Driver);
		String incHistory = pageFactVII.incHistoryAlwncc(Driver);
		

		try {

			if (pageFactVII.incHistory.isDisplayed())

				System.out

						.println("Income History  Expanded and Invoices displaying in the Income History section");

			extentTest

					.log(LogStatus.INFO,

							"Income History  Expanded and Invoices displaying in the Income History section");

		} catch (Exception e) {

			System.out.println("Income History  not Expanded");

			extentTest.log(LogStatus.INFO, "Income History  not Expanded");

		}

		System.out

		.println("Invoice displaying in the Income History section is : "

		+ incHistory);

		extentTest.log(LogStatus.INFO,

		"Invoice displaying in the Income History section is : "

		+ incHistory);

		return null;

	}

	public String paybackWorklistLeftII(WebDriver Driver)

	throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFactVII.payBackWorklistt(Driver);

		System.out.println("Clicked on PayBack button from the left panel");

		extentTest.log(LogStatus.INFO,

		"Clicked on PayBack button from the left panel");

		waitforFirstWrklist(Driver);

		String worklist = pageFactVII.firstWrklistt(Driver);

		try {

			if (pageFactVII.firstWrklist.isDisplayed())

				System.out

				.println("Payback worklist BRs displaying in the page");

			extentTest.log(LogStatus.INFO,

			"Payback worklist BRs displaying in the page");

		} catch (Exception e) {

			System.out

			.println("Payback worklist BRs NOT displaying in the page");

			extentTest.log(LogStatus.INFO,

			"Payback worklist BRs NOT displaying in the page");

		}

		System.out.println("BR displaying in the Payback Worklist is: "

		+ worklist);

		extentTest.log(LogStatus.INFO,

		"BR displaying in the Payback Worklist is: " + worklist);

		pageFactVII.firstWrklisttClk(Driver);

		waitforbrtxt(Driver);

		Thread.sleep(5000);

		 String incHistory = pageFactVII.incHistoryAlwncc(Driver);

	//	String incHistory = pageFactVII.incHistoryy(Driver);

		try {

			// if (pageFactVII.incHistoryAlwnc.isDisplayed())

			if (pageFactVII.incHistory.isDisplayed())

				System.out

						.println("Income History  Expanded and Invoices displaying in the Income History section");

			extentTest

					.log(LogStatus.INFO,

							"Income History  Expanded and Invoices displaying in the Income History section");

		} catch (Exception e) {

			System.out.println("Income History  not Expanded");

			extentTest.log(LogStatus.INFO, "Income History  not Expanded");

		}

		System.out

		.println("Invoice displaying in the Income History section is : "

		+ incHistory);

		extentTest.log(LogStatus.INFO,

		"Invoice displaying in the Income History section is : "

		+ incHistory);

		return null;

	}

	public String viewPb(WebDriver Driver) {

		// String viewpbb = pageFactVII.viewPBB(Driver);

		// String viewpbb = pageFactVII.viewPB2(Driver);

		String viewpbb = pageFactVII.incHistoryPaybackTxtt(Driver);

		try {

			if (pageFactVII.incHistoryPaybackTxtt(Driver).contains("View PB")) {

				System.out

						.println("Button displaying in the Income History section is : "

								+ viewpbb);

				extentTest.log(LogStatus.INFO,

				"Button displaying in the Income History section is : "

				+ viewpbb);

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String viewPbbClick(WebDriver Driver) throws InterruptedException {

		Thread.sleep(5500);

		try {

			if (pageFactVII.incHistoryPaybackTxtt(Driver).contains("View PB")) {

				Thread.sleep(2500);

				// pageFactVII.viewPBBClk2(Driver);

				pageFactVII.incHistoryPaybackTxtClk(Driver);

				System.out.println("Clicked on view PBB button");

				extentTest.log(LogStatus.INFO, "Clicked on view PBB button");

				Thread.sleep(2500);

			} else {

				String source = aftermthd(Driver);
				System.out.println("Failed");

				extentTest
						.log(LogStatus.FAIL,
								"Failed"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB  button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB  button is not there in the UI as the Income status is : "

			+ status);

		}

		String paybackLabel = pageFactVII.paybackLabell(Driver);

		try {

			if (pageFactVII.paybackLabel.isDisplayed()) {

				System.out

						.println("Payback Approver dropdown displaying properly in the pop up, the label showing is : "

								+ paybackLabel);

				extentTest

						.log(LogStatus.INFO,

								"Payback Approver dropdown displaying properly in the pop up, the label showing is : "

										+ paybackLabel);

			} else {

				String source = aftermthd(Driver);
				System.out
						.println("Payback Approver dropdown NOT displaying properly in the pop up, the label showing is : "
								+ paybackLabel);
				extentTest
						.log(LogStatus.FAIL,
								"Payback Approver dropdown NOT displaying properly in the pop up, the label showing is : "
										+ paybackLabel
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		String ReasonLabel = pageFactVII.reasonnn(Driver);

		try {

			// if (pageFactVII.reasonn.isDisplayed()) {

			if (pageFactVII.reasonLabel.isDisplayed()) {

				System.out

						.println("Reasons dropdown displaying properly in the pop up, the label showing is : "

								+ ReasonLabel);

				extentTest.log(LogStatus.INFO,

				"Reasons dropdown displaying properly in the pop up, the label showing is : "

				+ ReasonLabel);

			} else {

				String source = aftermthd(Driver);
				System.out
						.println("Reasons dropdown NOT displaying properly in the pop up, the label showing is : "
								+ ReasonLabel);
				extentTest
						.log(LogStatus.FAIL,
								"Reasons dropdown NOT displaying properly in the pop up, the label showing is : "
										+ ReasonLabel
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		String users = pageFactVII.usersss(Driver);

		try {

			if (pageFactVII.userr.isDisplayed()) {

				System.out

						.println("Users dropdown displaying properly in the pop up, the label showing is : "

								+ users);

				extentTest.log(LogStatus.INFO,

				"Users dropdown displaying properly in the pop up, the label showing is : "

				+ users);

			} else {

				String source = aftermthd(Driver);
				System.out
						.println("Users dropdown NOT displaying properly in the pop up, the label showing is : "
								+ users);
				extentTest
						.log(LogStatus.FAIL,
								"Users dropdown NOT displaying properly in the pop up, the label showing is : "
										+ users
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		String apprver = pageFactVII.approverTxt(Driver);

		try {

			if (pageFactVII.approver.isDisplayed()) {

				System.out

						.println("Approver button is displaying and the label text showing is : "

								+ apprver);

				extentTest.log(LogStatus.INFO,

				"Approver button is displaying and the label text showing is : "

				+ apprver);

			} else {

				String source = aftermthd(Driver);
				System.out
						.println("Approver button not displaying or the label text showing is wrong: "
								+ apprver);
				extentTest
						.log(LogStatus.FAIL,
								"Approver button not displaying or the label text showing is wrong: "
										+ apprver
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		String reject = pageFactVII.rejectTxt(Driver);

		try {

			if (pageFactVII.approver.isDisplayed()) {

				System.out

						.println("Reject button is displaying and the label text showing is : "

								+ reject);

				extentTest.log(LogStatus.INFO,

				"Reject button is displaying and the label text showing is : "

				+ reject);

			} else {

				String source = aftermthd(Driver);
				System.out
						.println("Reject button not displaying or the label text showing is wrong: "
								+ reject);
				extentTest
						.log(LogStatus.FAIL,
								"Reject button not displaying or the label text showing is wrong: "
										+ reject
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String worklistForUserChange(WebDriver Driver)

	throws InterruptedException {

		pageFactVII.worklistForr(Driver);

		// pageFactVII.worklistForrII(Driver);

		Thread.sleep(5000);

		return null;

	}

	public String worklistForUserChangeII(WebDriver Driver)

	throws InterruptedException {

		pageFactVII.worklistForrIII(Driver);

		// pageFactVII.worklistForrII(Driver);

		Thread.sleep(5000);

		return null;

	}

	public String approver(WebDriver Driver) {

		try {

			String paybackAprr = pageFactVII.paybackAproverrrII(Driver);

			System.out.println("Payback approver name showing is : "

			+ paybackAprr);

			extentTest.log(LogStatus.INFO,

			"Payback approver name showing is : " + paybackAprr);

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String reason(WebDriver Driver) {

		try {

			String reason = pageFactVII.reasonnII(Driver);

			System.out.println("Reasons displaying is : " + reason);

			extentTest.log(LogStatus.INFO, "Reasons displaying is : " + reason);

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String users(WebDriver Driver) {

		try {

			String users = pageFactVII.userr(Driver);

			System.out.println("Users displaying is : " + users);

			extentTest.log(LogStatus.INFO, "Users displaying is : " + users);

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String reasonClick(WebDriver Driver) throws InterruptedException {

		try {

			pageFactVII.reasonClk(Driver);

			Thread.sleep(2500);

			pageFactVII.item2(Driver);

			Thread.sleep(2500);

			if (pageFactVII.reasonItem.isDisplayed()) {

				System.out.println("User able to add new Reason");

				extentTest.log(LogStatus.INFO, "User able to add new Reason");

			} else {

				System.out.println("User NOT able to add new Reason");

				extentTest.log(LogStatus.INFO,

				"User NOT able to add new Reason");

			}

			// pageFactVII.userrClk(Driver);

			pageFactVII.usersssClk(Driver);

			System.out.println("Clicked on USERS");

			Thread.sleep(2500);

			// pageFactVII.item1(Driver);

			// System.out.println("Selected USER TYPE");

			// Thread.sleep(4500);

			// if (pageFactVII.userItem.isDisplayed()) {

			if (pageFactVII.userr.isDisplayed()) {

				System.out.println("User able to add new Users");

				extentTest.log(LogStatus.INFO, "User able to add new Users");

			} else {

				System.out.println("User able to add new Users");

				extentTest.log(LogStatus.INFO, "User able to add new Users");

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String reasonRemove(WebDriver Driver) throws InterruptedException {

		try {

			pageFactVII.reasonXX(Driver);

			if (pageFactVII.reasonnTxt(Driver).isEmpty()) {

				System.out

				.println("Able to remove Reasons by clicking 'x' button");

				extentTest.log(LogStatus.INFO,

				"Able to remove Reasons by clicking 'x' button");

			} else {

				System.out

				.println("Not able to remove Reasons by clicking 'x' button");

				extentTest.log(LogStatus.INFO,

				"Not able to remove Reasons by clicking 'x' button");

			}

			pageFactVII.reasonClk(Driver);

			Thread.sleep(2500);

			pageFactVII.item2(Driver);

			Thread.sleep(2500);

			pageFactVII.item3(Driver);

			Thread.sleep(2500);

			pageFactVII.item1(Driver);

			Thread.sleep(2500);

			pageFactVII.approverBtnClk(Driver);

			Thread.sleep(5000);

			String ErrMsg = pageFactVII.errMsgTxt(Driver);

			if (pageFactVII

			.errMsgTxt(Driver)

			.contains(

			"Maximum allowed limit is 2 for Reasons & Responsible Users")) {

				System.out.println("Error message displaying is :  " + ErrMsg);

				extentTest.log(LogStatus.INFO,

				"Error message displaying is :  " + ErrMsg);

			} else {

				System.out

						.println("No Error message or error message showing is wrong :  "

								+ ErrMsg);

				extentTest.log(LogStatus.INFO,

				"No Error message or error message showing is wrong :  "

				+ ErrMsg);

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out.println("Exception is : " + e);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String userRemove(WebDriver Driver) throws InterruptedException {

		try {

			pageFactVII.userXX(Driver);

			// if (pageFactVII.userTxtBoxx(Driver).isEmpty()) {

			if (pageFactVII.userTxtBox(Driver).isEmpty()) {

				System.out

				.println("Able to remove Users by clicking 'x' button");

				extentTest.log(LogStatus.INFO,

				"Able to remove Users by clicking 'x' button");

			} else {

				System.out

				.println("Not able to remove Users by clicking 'x' button");

				extentTest.log(LogStatus.INFO,

				"Not able to remove Users by clicking 'x' button");

			}

			pageFactVII.userTxtBoxxClk2(Driver);

			Thread.sleep(2500);

			pageFactVII.item2(Driver);

			Thread.sleep(2500);

			pageFactVII.item3(Driver);

			Thread.sleep(2500);

			pageFactVII.item1(Driver);

			Thread.sleep(2500);

			pageFactVII.approverBtnClk(Driver);

			Thread.sleep(2500);

			String ErrMsg = pageFactVII.errMsgTxt(Driver);

			if (pageFactVII

			.errMsgTxt(Driver)

			.contains(

			"Maximum allowed limit is 2 for Reasons & Responsible Users")) {

				System.out.println("Error message displaying is :  " + ErrMsg);

				extentTest.log(LogStatus.INFO,

				"Error message displaying is :  " + ErrMsg);

			} else {

				System.out

						.println("No Error message or error message showing is wrong :  "

								+ ErrMsg);

				extentTest.log(LogStatus.INFO,

				"No Error message or error message showing is wrong :  "

				+ ErrMsg);

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out.println("Exception is : " + e);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String OTLeft(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforBlngbtn(Driver);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);
		// Thread.sleep(20000);

		pageFactVII.OTLeftClk(Driver);

		waitforSearchItem(Driver);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);

		pageFactVII.firstItemClk(Driver);

		waitforbrtxt(Driver);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);

		String incmVal = pageFactVII.IncmHistValueTxt(Driver);

		try {

			if (pageFactVII.IncmHistValue.isDisplayed()) {

				System.out

						.println("Income history section displayed and is Expanded, Invoice Value :  "

								+ incmVal);

				extentTest
						.log(LogStatus.INFO,

								"TESTCASE PASSED:  Income history section displayed and is Expanded, Invoice Value :  "

										+ incmVal);

			} else {

				String source = aftermthd(Driver);
				System.out.println("Income history section NOT displayed");

				extentTest
						.log(LogStatus.FAIL,
								"TESTCASE FAILED:  Income history section NOT displayed"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			if (pageFactVII.miscIncHistVal.isDisplayed()) {

				System.out

						.println("Income history section displayed and is Expanded, Invoice Value :  "

								+ incmVal);

				extentTest
						.log(LogStatus.INFO,

								"TESTCASE PASSED:  Income history section displayed and is Expanded, Invoice Value :  "

										+ incmVal);

			} else {

				String source = aftermthd(Driver);
				System.out.println("Income history section NOT displayed");

				extentTest
						.log(LogStatus.FAIL,
								"TESTCASE FAILED:  Income history section NOT displayed"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		}

		return null;

	}

	public String userChangeOT(WebDriver Driver) throws InterruptedException {

		pageFactVII.worklistForrII(Driver);

		Thread.sleep(20000);

		pageFactVII.OTLeftClk(Driver);

		waitforSearchItem(Driver);

		try {

			if (pageFactVII.IncmHistValueTxt(Driver).contains("10002496")) {

				String source = aftermthd(Driver);
				System.out
						.println("Logged in user's BR listing even in other user's OT worklist");

				extentTest
						.log(LogStatus.FAIL,
								"Logged in user's BR listing even in other user's OT worklist"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			System.out

					.println("Logged in user's BR not listing in other user's OT worklist");

			extentTest

			.log(LogStatus.INFO,

			"Logged in user's BR not listing in other user's OT worklist");

		}

		return null;

	}

	public String userChange(WebDriver Driver) throws InterruptedException {

		pageFactVII.worklistForrII(Driver);

		System.out.println("User changed");

		extentTest.log(LogStatus.INFO, "User changed");

		Thread.sleep(5000);

		return null;

	}

	public String viewOTbtn(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforSearchItem(Driver);

		Thread.sleep(5000);

		pageFactVII.firstItemClk(Driver);

		waitforbrtxt(Driver);

		Thread.sleep(5000);

		waitforbrtxt(Driver);

		Thread.sleep(10000);

		AddIncome(Driver);

		Thread.sleep(5000);

		// if (pageFactVII.viewPBRetailTxt(Driver).equals("View OT")) {

		if (pageFactVII.cancelBtnTxt(Driver).equals("View OT")) {

			System.out.println("User able to see VIEW OT button");

			extentTest.log(LogStatus.INFO, "User able to see VIEW OT button");

		}

		else {

			String source = aftermthd(Driver);
			System.out.println("User NOT able to see VIEW OT button");

			extentTest.log(
					LogStatus.FAIL,
					"User NOT able to see VIEW OT button"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String viewOTbtnLogdnUser(WebDriver Driver)

	throws InterruptedException, IOException {

		try {

			pageFactVII.worklistForrIV(Driver);

			Thread.sleep(7000);

			pageFactVII.OTLeftClk(Driver);

			Thread.sleep(2500);

			pageFactVII.warningYes.click();

			Thread.sleep(2500);

			waitforSearchItem(Driver);

			pageFactVII.firstItemClk(Driver);

			waitforbrtxt(Driver);

			Thread.sleep(5000);

			waitforbrtxt(Driver);

			Thread.sleep(5000);

			AddIncome(Driver);

			Thread.sleep(5000);

			if (pageFactVII.viewPBRetailTxt(Driver).equals("View OT")) {

				System.out.println("Logged in user able to see VIEW OT button");

				extentTest.log(LogStatus.INFO,

				"Logged in user able to see VIEW OT button");

			}

			else {

				String source = aftermthd(Driver);
				System.out
						.println("Logged in user NOT able to see VIEW OT button");

				extentTest
						.log(LogStatus.FAIL,
								"Logged in user NOT able to see VIEW OT button"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			System.out.println("Logged in user able to see VIEW OT button");

			extentTest.log(LogStatus.INFO,

			"TESTCASE PASSED: Logged in user able to see VIEW OT button");
		}

		return null;

	}

	public String closePopup(WebDriver Driver) throws InterruptedException,
			IOException {

		pageFactVII.viewOTBtnClk(Driver);

		Thread.sleep(2500);

		pageFactVII.closee(Driver);

		System.out.println("Clicked on Close (X) button");

		extentTest.log(LogStatus.INFO, "Clicked on Close (X) button");

		try {

			if (pageFactVII.IncmHistValue.isDisplayed()) {

				System.out

						.println("Clicking on Close (X) button successfully closed the pop up");

				extentTest

				.log(LogStatus.INFO,

				"Clicking on Close (X) button successfully closed the pop up");

			}

		} catch (Exception e) {

			String source = aftermthd(Driver);
			System.out
					.println("Clicking on Close (X) button not closing the pop up");

			extentTest.log(
					LogStatus.FAIL,
					"Clicking on Close (X) button not closing the pop up"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	// public String loopViewOT(WebDriver Driver){

	//

	//

	//

	// return null;

	// }

	public String AddIncome(WebDriver Driver) throws InterruptedException {

		pageFactV.incomeBtnNonAlww(Driver);

		// pageFactV.incmeButtonAddd(Driver);

		Thread.sleep(3000);

		pageFactVII.fltAmntt(Driver);

		Thread.sleep(5000);

		// pageFactVII.qtyAmnt(Driver);

		// Thread.sleep(2500);

		// pageFactVII.incmSbmtBtnn(Driver);

		pageFactVII.incmSbmtBtnII.click();

		Thread.sleep(3000);

		try {

			if (pageFactVII.warningYes.isDisplayed()) {

				pageFactVII.warningYess(Driver);

				System.out.println("Clicked on YES Submit button Income");

			}

		} catch (Exception e) {

			System.out.println("No warning pop up displayed");

		}

		Thread.sleep(3000);

		return null;

	}

	public String approveOT(WebDriver Driver) throws InterruptedException,
			IOException {

		Thread.sleep(2500);

		pageFactVII.viewOTBtnClk(Driver);

		Thread.sleep(2500);

		pageFactVII.approveBtnn(Driver);

		System.out.println("Clicked on Approve button");

		extentTest.log(LogStatus.INFO, "Clicked on Approve button");

		Thread.sleep(5000);

		if (pageFactVII.incmStatusAlwncee(Driver).equals("Submitted")) {

			System.out

					.println("Successfully approved and Income status changed to 'Submitted'");

			extentTest

			.log(LogStatus.INFO,

			"Successfully approved and Income status changed to 'Submitted'");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Error while approving");

			extentTest.log(
					LogStatus.FAIL,
					"Error while approving"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String rejectOT(WebDriver Driver) throws InterruptedException,
			IOException {

		Thread.sleep(2500);

		pageFactVII.viewOTBtnClk(Driver);

		Thread.sleep(2500);

		pageFactVII.rejectBtnn(Driver);

		System.out.println("Clicked on Reject button");

		extentTest.log(LogStatus.INFO, "Clicked on Reject button");

		Thread.sleep(2500);

		pageFactVII.rejectReasonOkBtnn(Driver);

		System.out

		.println("Clicked on Reject button without entering the reason");

		extentTest.log(LogStatus.INFO,

		"Clicked on Reject button without entering the reason");

		Thread.sleep(5000);

		String rejectReasonErr = pageFactVII.rejectErrTxt(Driver);

		if (pageFactVII.rejectErrTxt(Driver).contains("Reason for rejection")) {

			System.out

					.println("Error message showing when clicking on OK button without filling the Reason is : "

							+ rejectReasonErr);

			extentTest

					.log(LogStatus.INFO,

							"Error message showing when clicking on OK button without filling the Reason is : "

									+ rejectReasonErr);

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Not showing any error message or error showing is wrong : "
							+ rejectReasonErr);
			extentTest.log(
					LogStatus.FAIL,
					"Not showing any error message or error showing is wrong : "
							+ rejectReasonErr
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVII.rejectReasonn(Driver);

		pageFactVII.rejectReasonOkBtnn(Driver);

		System.out.println("Entered Reject Reason and clicked on Ok button");

		extentTest.log(LogStatus.INFO,

		"Entered Reject Reason and clicked on Ok button");

		if (pageFactVII.incmStatusAlwncee(Driver).equals("Cancelled")) {

			System.out

					.println("Successfully Rejected and Income status changed to 'Cancelled'");

			extentTest

			.log(LogStatus.INFO,

			"Successfully Rejected and Income status changed to 'Cancelled'");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Error while rejecting");

			extentTest.log(
					LogStatus.FAIL,
					"Error while rejecting"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String cancel(WebDriver Driver) throws InterruptedException,
			IOException {

		if (pageFactVII.cancelBtnTxt(Driver).equals("Cancel")) {

			System.out

					.println("Cancel button displaying for a Income Status 'Completed' record");

			extentTest

			.log(LogStatus.INFO,

			"TESTCASE PASSED:  Cancel button displaying for a Income Status 'Completed' record");

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Cancel button NOT displaying for a Income Status 'Completed' record");

			extentTest.log(
					LogStatus.FAIL,
					"TESTCASE FAILED:  Cancel button NOT displaying for a Income Status 'Completed' record"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVII.cancelBtnClk(Driver);

		System.out.println("Clicked on Cancel button");

		extentTest.log(LogStatus.INFO, "Clicked on Cancel button");

		Thread.sleep(2500);

		pageFactVII.cancelBtnNoo(Driver);

		System.out.println("Clicked on Cancel button - NO");

		extentTest.log(LogStatus.INFO, "Clicked on Cancel button - NO");

		Thread.sleep(5000);

		if (pageFactVII.incmStatuss(Driver).contains("Submitted")) {

			System.out.println("No button clicked didn't cancel the record");

			extentTest.log(LogStatus.INFO,

			"TESTCASE PASSED:  No button clicked didn't cancel the record");

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("No button clicked not working or it cancelled the record");

			extentTest.log(
					LogStatus.FAIL,
					"TESTCASE FAILED:  No button clicked not working or it cancelled the record"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVII.cancelBtnClk(Driver);

		Thread.sleep(3000);

		pageFactVII.warningYess(Driver);

		System.out.println("Clicked on Cancel button - YES");

		extentTest.log(LogStatus.INFO, "Clicked on Cancel button - YES");

		Thread.sleep(3000);

		if (pageFactVII.incmStatuss(Driver).equals("Cancelled")) {

			System.out

					.println("Successfully Cancelled and Income status changed to 'Cancelled'");

			extentTest

			.log(LogStatus.INFO,

			"TESTCASE PASSED:  Successfully Cancelled and Income status changed to 'Cancelled'");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Error while cancelling");

			extentTest.log(
					LogStatus.FAIL,
					"TESTCASE FAILED:  Error while cancelling"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;

	}

	public String waitforSearchPage(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);

		wait.until(ExpectedConditions

		.elementToBeClickable(pageFactVII.searchApply));

		return null;

	}

	public String readyBtnClk(WebDriver Driver) {

		pageFactVII.readyBtnn(Driver);

		return null;

	}

	public String Search(WebDriver Driver) throws InterruptedException {

		pageFactVII.searchh(Driver);

		waitforSearchPage(Driver);

		pageFactVII.assignToo(Driver);

		Thread.sleep(2500);

		pageFactVII.searchApplyy(Driver);

		Thread.sleep(3000);

		pageFactVII.brResultt(Driver);

		waitforbrtxt(Driver);

		Thread.sleep(3000);

		return null;

	}

	public String SearchII(WebDriver Driver) throws BiffException, IOException,

	InterruptedException {

		pageFactVII.searchh(Driver);

		waitforSearchPage(Driver);

		Thread.sleep(5000);

		// String file = new File(System.getProperty("user.dir"),

		// "TestData.xls")

		// .getAbsolutePath();

		//

		// FileInputStream fi = new FileInputStream(file);

		//

		// Workbook w = Workbook.getWorkbook(fi);

		// Sheet s = w.getSheet(1);

		//

		// try {

		// for (int i = 2; i < s.getRows(); i++) {

		// // Read data from excel sheet

		//

		// String s3 = s.getCell(13, i).getContents();

		// Thread.sleep(3000);

		//

		// pageFactVII.searchBillId.sendKeys(s3);

		// System.out.println("reachd here");

		// }

		// } catch (Exception e) {

		// System.out.println(e);

		// }

		pageFactVII.searchBillIdd(Driver);

		Thread.sleep(3000);

		pageFactVII.searchApplyy(Driver);

		Thread.sleep(3000);

		pageFactVII.brResultt(Driver);

		waitforbrtxt(Driver);

		Thread.sleep(3000);

		return null;

	}

	public String SearchNew(WebDriver Driver) throws InterruptedException,
			BiffException, IOException {

		pageFactVII.searchh(Driver);

		waitforSearchPage(Driver);

		Thread.sleep(5000);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")

		.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);

		Sheet s = w.getSheet(1);

		try {

			for (int i = 2; i < s.getRows(); i++) {

				// Read data from excel sheet

				String s3 = s.getCell(17, i).getContents();

				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);

				pageFactVII.searchBillId.findElement(

				By.className("form-control")).sendKeys(s3);

			}

		} catch (Exception e) {

			System.out.println(e);

		}

		// pageFactVII.searchBillIdd(Driver);

		Thread.sleep(3000);

		pageFactVII.searchApplyy(Driver);

		// waitforSearchItem(Driver);

		return null;

	}

	public String paybackApprove(WebDriver Driver) throws InterruptedException {

		String incmSta = pageFactVII.incStatuss(Driver);

		String approvedBy = pageFactVII.aprovdByTxt(Driver);

		String Invoice = pageFactVII.incHistoryy(Driver);

		closeII(Driver);

		Thread.sleep(5000);

		scroldown(Driver);

		Thread.sleep(5000);

		try {

			if (pageFactVII.viewPB2(Driver).contains("View PB")) {

				pageFactVII.viewPBClk(Driver);

				System.out.println("Clicked on View PB button");

				extentTest.log(LogStatus.INFO, "Clicked on View PB button");

				Thread.sleep(5000);

				pageFactVII.approverBtnClk(Driver);

				System.out.println("Clicked on 'Approve' button");

				extentTest.log(LogStatus.INFO, "Clicked on 'Approve' button");

				// CABS1658

				System.out

						.println("Income Status displaying after clicking on Approve button is: "

								+ incmSta);

				extentTest.log(LogStatus.INFO,

				"Income Status displaying after clicking on Approve button is: "

				+ incmSta);

				// CABS1657

				System.out

				.println("Income Status Approver Name displaying is: "

				+ approvedBy);

				extentTest.log(LogStatus.INFO,

				"Income Status Approver Name displaying is: "

				+ approvedBy);

				// CABS1659

				System.out.println("Invoice Number displaying is: " + Invoice);

				extentTest.log(LogStatus.INFO, "Invoice Number displaying is: "

				+ Invoice);

			} else {

				String source = aftermthd(Driver);
				System.out.println("Error occured while approving View PB");

				extentTest
						.log(LogStatus.FAIL,
								"Error occured while approving View PB"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out.println("Exception is" + e);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String rejectClick(WebDriver Driver) {

		String incmSta = pageFactVII.incStatuss(Driver);

		try {

			if (pageFactVII.viewPB2(Driver).contains("View PB")) {

				pageFactVII.viewPBClk(Driver);

				System.out.println("Clicked on View PB button");

				extentTest.log(LogStatus.INFO, "Clicked on View PB button");

				Thread.sleep(3000);

				pageFactVII.rejectClk(Driver);

				System.out.println("Clicked on Reject button from the pop up");

				extentTest.log(LogStatus.INFO,

				"Clicked on Reject button from the pop up");

				System.out

						.println("Income Status displaying after clicking on Reject button is: "

								+ incmSta);

				extentTest.log(LogStatus.INFO,

				"Income Status displaying after clicking on Reject button is: "

				+ incmSta);

			} else {

				String source = aftermthd(Driver);
				System.out.println("Error occured while Rejecting View PB");

				extentTest
						.log(LogStatus.FAIL,
								"Error occured while Rejecting View PB"
										+ extentTest
												.addScreenCapture("data:image/png;base64,"
														+ source));

			}

		} catch (Exception e) {

			String status = pageFactVII.incStatuss(Driver);

			System.out

					.println("View PB button is not there in the UI as the Income status is : "

							+ status);

			extentTest.log(LogStatus.INFO,

			"View PB button is not there in the UI as the Income status is : "

			+ status);

		}

		return null;

	}

	public String waitForSpinnerToBeGone(WebDriver Driver) {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	
	public String SearchIII(WebDriver Driver) throws BiffException,

	IOException, InterruptedException {

			waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);
		
		pageFactVII.searchh(Driver);

		waitforSearchPage(Driver);

		Thread.sleep(5000);

		String file = new File(System.getProperty("user.dir"), "TestData.xls")

		.getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);

		Sheet s = w.getSheet(1);

		try {

			for (int i = 2; i < s.getRows(); i++) {

				// Read data from excel sheet

				String s3 = s.getCell(13, i).getContents();

				Thread.sleep(3000);

				// pageFactVII.searchBillId.sendKeys(s3);

				pageFactVII.advSearch.click();
				Thread.sleep(1500);
				
				pageFactVII.searchBillId.findElement(

				By.className("form-control")).sendKeys(s3);

			}

		} catch (Exception e) {

			System.out.println(e);

		}

		// pageFactVII.searchBillIdd(Driver);

		Thread.sleep(3000);

		pageFactVII.searchApplyy(Driver);

		Thread.sleep(3000);

		pageFactVII.brResultt(Driver);

		waitforbrtxt(Driver);

		Thread.sleep(3000);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(3000);

		return null;

	}

	public String pdfClick(WebDriver Driver) throws InterruptedException {

		String incHistory = pageFactVII.incHistoryy(Driver);

		try {

			if (pageFactVII.incHistory.isDisplayed())

				System.out

						.println("Income History  Expanded and PDF Invoices displaying in the Income History section : "

								+ incHistory);

			extentTest

					.log(LogStatus.INFO,

							"Income History  Expanded and PDF Invoices displaying in the Income History section : "

									+ incHistory);

		} catch (Exception e) {

			System.out.println("Income History  not Expanded");

			extentTest.log(LogStatus.INFO, "Income History  not Expanded");

		}

		Thread.sleep(2500);

		pageFactVII.incHistoryClk(Driver);

		return null;

	}

	public WebDriver NewTabTitle(WebDriver Driver) throws IOException,

	InterruptedException {

		Thread.sleep(5000);

		// String title = Driver.getTitle();

		ArrayList<String> tabs2 = new ArrayList<String>(

		Driver.getWindowHandles());

		WebDriver title = Driver.switchTo().window(tabs2.get(1));

		try {

			if (title.equals("CABS - Centralized Accounting Billing System")) {

				System.out.println("Title is: " + title);

				extentTest.log(LogStatus.FAIL,

				"TestCase Failed:  PDF NOT Opened in new tab, title displaying is : "

				+ title);

			}

		} catch (Exception e) {

			System.out.println("Title is: " + title);

			extentTest.log(LogStatus.INFO,

			"TestCase Passed:  PDF Opened in new tab and PDF title is: " + title);

		}

		System.out.println("Title is: " + title);

		extentTest.log(LogStatus.INFO,

		"TestCase Passed:  PDF Opened in new tab and PDF title is: " + title);

		return title;

	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);

		pageFactV = new GenericFactoryV(Driver);

		pageFactAS3 = new GenericFactorySprint3(Driver);

		pageFactJS3 = new GenericFactoryJSprint3(Driver);

		pageFact = new GenericFactory(Driver);

		pageFactVI = new GenericFactoryVI(Driver);

		pageFactVII = new GenericFactoryVII(Driver);

	}

}
