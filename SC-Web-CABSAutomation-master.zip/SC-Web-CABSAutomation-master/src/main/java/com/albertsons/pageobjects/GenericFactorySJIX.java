package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class GenericFactorySJIX {
	WebDriver Driver;
	GenericFactorySJIX POJS9;

	public GenericFactorySJIX(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	@FindBy(xpath = "//*[@id='lastUpdate']/div/div/div[3]/input")
	WebElement clickLastUpdate;
	@FindBy(xpath = "//*[@id='ta-lastUpdate-0']/span[1]")
	WebElement createBRHist;
	@FindBy(xpath = "//*[@id='ta-lastUpdate-0']/label")
	WebElement createBRHistdate;
	@FindBy(xpath = "//*[@id='ta-lastUpdate-1']/label")
	WebElement createBRHistdate_1;
	@FindBy(xpath = "//*[@id='ta-lastUpdate-0']/span[2]/b")
	WebElement createBRHistCurrent;
	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;
	@FindBy(id = "textarea")
	public WebElement txtArea;
	@FindBy(xpath = "//*[@id='undefined']")
	public WebElement txtDescr;
	@FindBy(xpath = "//*[@id='undefined']/input")
	public WebElement itemDetailsAmnt;
	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement ready;
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[1]/nav/ol/li")
	public WebElement BRtxt;
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[1]/div[1]/div/label")
	public WebElement accLkpType;
	@FindBy(xpath = "//*[@id='accLookUpType']/div/div/div[3]")
	public WebElement accLkpTypeHist;
	@FindBy(xpath = "//*[@id='billingName']/div/div/div[3]/input")
	public WebElement BillingName;
	@FindBy(xpath = "//*[@id='flatAmount']/input")
	public WebElement FlatAmt;
	@FindBy(xpath = "//*[@id='flatCode']")
	public WebElement flatCode;
	@FindBy(xpath = "//*[@id='ad44d6910b84-1']")
	public WebElement flatCodeBox;
	@FindBy(xpath = "//*[@id='allow-income-tab']/div[1]/i-feather")
	public WebElement SubmitIncomeClick;
	@FindBy(xpath = "//*[@id='item-tab']/div[1]/i-feather")
	public WebElement Itemtab;
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement saveBtn;
	@FindBy(xpath = "//*[@id='allow-income-tab']/div[4]/button")
	public WebElement AddIncome;
	@FindBy(xpath = "//*[@id='notesId']")
	public WebElement AddIncomeComments;
	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[2]")
	public WebElement AddIncomeSubmit;
	@FindBy(xpath = "//*[@id='allowanceType']/div/div/div[2]/input")
	public WebElement itemAlTypeClick;
	@FindBy(xpath = "//*[@id='ta-alwncTypeValue-0']")
	public WebElement itemAlPerf1;
	@FindBy(xpath = "//*[@id='performanceCode1']/div/div/div[2]/input")
	public WebElement itemAlPerf2Click;
	@FindBy(xpath = "//*[@id='ta-perfOneValue-0']")
	public WebElement itemAlPerf2;
	@FindBy(xpath = "//*[@id='performanceCode2']/div/div/div[2]/input")
	public WebElement itemAlPerf3Click;
	@FindBy(xpath = "//*[@id='ta-perfTwoValue-0']")
	public WebElement itemAlPerf3;

	public String flatCodeSend(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		flatCode.sendKeys(Keys.ENTER);
		flatCode.sendKeys(Keys.ENTER);
		flatCode.sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		return null;
	}

	public String clickLastUpdate(WebDriver Driver) throws InterruptedException {
		Thread.sleep(2000);
		clickLastUpdate.click();
		return null;
	}

	public String createBRHistdateClick(WebDriver Driver) {
		createBRHistdate.click();
		return null;
	}

	public String createBRHist(WebDriver Driver) {
		return createBRHist.getText();

	}

	public String accLkpType(WebDriver Driver) {
		return accLkpType.getText();

	}

	public String createBRHistdate(WebDriver Driver) {
		return createBRHistdate.getText();

	}

	public String createBRHistCurrent(WebDriver Driver) {
		return createBRHistCurrent.getText();

	}

	public String BillingNameVal(WebDriver Driver) {
		// return deductnum.findElement(By.className("form-control")).getText();
		return deductnum.findElement(By.className("form-control"))
				.getAttribute("value");

	}

	public String BillingNameClick(WebDriver Driver) {
		BillingName.click();
		return null;

	}

	public String BillingName(WebDriver Driver) throws InterruptedException {
		deductnum.findElement(By.className("form-control")).sendKeys("510");
		Thread.sleep(3000);

		return null;
	}

	public String EditHeaderBillName(WebDriver Driver)
			throws InterruptedException {
		deductnum.findElement(By.className("form-control")).clear();
		deductnum.findElement(By.className("form-control")).sendKeys("510");
		Thread.sleep(3000);

		return null;
	}

	// public String EditMultiple(WebDriver Driver) throws InterruptedException
	// {
	// deductnum.findElement(By.className("form-control")).clear();
	// deductnum.findElement(By.className("form-control")).sendKeys("857");
	// txtDescr.clear();
	// txtDescr.sendKeys("Test Automation-updated");
	// Thread.sleep(2000);
	// System.out.println("Internal notes updated");
	// Itemtab.click();
	// System.out.println("Clicked on Item tab");
	// itemDetailsAmnt.sendKeys("9.99");
	// /System.out.println("Edited Item amount");
	// Thread.sleep(2000);
	// save.click();
	// Thread.sleep(3000);

	// alwTab

	// return null;
	// }

	public String NonAlwNotesVal(WebDriver Driver) {
		return txtDescr.getAttribute("value");

	}

	public String txtArea(WebDriver Driver) {
		// txtArea.sendKeys("Test Automation");
		txtDescr.sendKeys("Test Automation");
		return null;
	}

	public String FlatAmtChange(WebDriver Driver) throws InterruptedException {
		// txtArea.sendKeys("Test Automation");
		Thread.sleep(5000);
		FlatAmt.sendKeys(Keys.CONTROL + "a");
		FlatAmt.sendKeys("10.99");
		Thread.sleep(3000);
		return null;
	}

	public String FlatAmtVal(WebDriver Driver) {
		// return deductnum.findElement(By.className("form-control")).getText();
		return FlatAmt.getAttribute("value");

	}

	public String itemDetailsAmnt(WebDriver Driver) throws InterruptedException {
		itemDetailsAmnt.sendKeys("1");
		itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		Thread.sleep(2000);
		save.click();
		return null;
	}

	public String EdititemDetailsAmnt(WebDriver Driver)
			throws InterruptedException {
		itemDetailsAmnt.clear();
		Thread.sleep(2000);
		save.click();
		return null;
	}

	public String ready(WebDriver Driver) {

		ready.click();
		return null;
	}

	public String Save(WebDriver Driver) {

		saveBtn.click();
		return null;
	}
}
