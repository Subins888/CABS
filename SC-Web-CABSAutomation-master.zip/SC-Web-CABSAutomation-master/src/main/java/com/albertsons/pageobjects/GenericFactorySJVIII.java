package com.albertsons.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class GenericFactorySJVIII {
              WebDriver Driver;
              GenericFactorySJVIII POJS8;
              public GenericFactorySJVIII(WebDriver Driver) {
                             this.Driver = Driver;
                             PageFactory.initElements(Driver, this);
              }
              
              
              
              @FindBy(xpath = "//*[@id='search']/li/a")
              WebElement SearchBRMenu;
              @FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
              WebElement FirstInv;
              @FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
              WebElement SecondInv;
              @FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[3]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
              WebElement ThirdInv;
              @FindBy(xpath = "//*[@id='billRecId']")
              WebElement EnterBR;
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/action-button/button")
              WebElement SearchBRApply;
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
              WebElement SelectBR;
              @FindBy(xpath = "//*[@id='income-tab']/div[4]/button")
              WebElement nonAlwAddIncome;
              @FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
              WebElement FirstIncome;
              @FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
              WebElement PaybkIncome;
              @FindBy(xpath = "//*[@id='misc-history-tab']/div[1]")
              WebElement miscHistory; 
              @FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
              WebElement createBR;
              @FindBy(xpath = "//*[@id='billingRecordType']/div/span")
              public WebElement BrType;
              @FindBy(xpath = "//*[@id='ta-billingRecordType-2']")
              public WebElement BrTypeNonAlw;
              
              @FindBy(xpath = "//*[@id='accountLookupType']/div/span")
              public WebElement NonAlwAcctLkup;
              @FindBy(xpath = "//*[@id='ta-accountLookupType-0']")
              public WebElement NonAlwAcctLkupSelect;
              
              @FindBy(xpath = "//*[@id='accountLookupValue']/div/div/div[2]")
              public WebElement NonAlwAcctLkupVal;
              @FindBy(xpath = "//*[@id='ta-accountLookupValue-0']")
              public WebElement NonAlwAcctLkupSel;             
              @FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[1]/div[1]/div/button")
              public WebElement NonAlwAddrow;      
              @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[1]/i-feather")
              public WebElement advSearch; 

              
              //*[@id="ta-billingRecordType-2"]
              
              
              
              
              
              
              

                             

              
              
                public String SearchBRMenu(WebDriver Driver) {
                               SearchBRMenu.click();
                                           return null;
                             }
                public String SearchBRApply(WebDriver Driver) {
                               SearchBRApply.click();
                                           return null;
                             }
                public String SelectBRVal(WebDriver Driver) {
                               SelectBR.click();
                                           return null;
                             }
                             public String EnterBRVal() {
                                           EnterBR.findElement(By.className("form-control")).sendKeys("10003582");
                                           //EnterBR.sendKeys("10003582");
                                           return null;
                             }
                             
                 public String nonAlwAddIncomeClick(WebDriver Driver) {
                                             nonAlwAddIncome.click();
                                             return null;
                                           }
                               
                public String FirstInv(WebDriver Driver) {
                               return FirstInv.getText();
                                           
                             }
                public String SecondInv(WebDriver Driver) {
                               return SecondInv.getText();
                                           
                             }
                public String ThirdInv(WebDriver Driver) {
                               return ThirdInv.getText();
                                           
                             }
                public String FirstIncomeVal(WebDriver Driver) {
                               return FirstIncome.getText();
                                           
                             }
                public String PaybkIncomeVal(WebDriver Driver) {
                               return PaybkIncome.getText();
                                           
                             }
                
                public String nonAlwIncomeHistClick(WebDriver Driver) {
                               miscHistory.click();
                                           return null;
                             }
                
                             public String creatBillng2() {
                                           createBR.click();
                                           return null;

                             }
                             
                             public String BrTypClick() {

                                           BrType.click();

                                           return null;
                             }

                             public String BrTypeNonAlwClick() {

                                           BrTypeNonAlw.click();

                                           return null;
                             }
                             public String NonAlwAcctLkupClick() {

                                           NonAlwAcctLkup.click();

                                           return null;
                             }
                             public String NonAlwAcctLkupSelectClick() {

                                           NonAlwAcctLkupSelect.click();

                                           return null;
                             }
                             public String NonAlwAcctLkupValClick() {
                                           NonAlwAcctLkupVal.click();
                                           return null;
                             }
                             
                             public String NonAlwAcctLkupSelClick() {
                                           NonAlwAcctLkupSel.click();
                                           return null;
                             }
                             
}
