package com.albertsons.pageobjects;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class pageObjectsJSprint4 extends ExtendBaseClass{

	WebDriver Driver;
	GenericFactory pageFact;
	GenericFactoryJSprint3 pageFactS3;
	GenericFactoryJSprint4 pageFactS4;
	PageObjects PO = new PageObjects(Driver);
	Properties prop;

	String extentReportImage453PO_01, extentReportImage453PO_02, extentReportImage453PO_03, extentReportImage453PO_04,extentReportImage453PO_05
	,extentReportImage453PO_06,extentReportImage453PO_07,extentReportImage453PO_08,extentReportImage453PO_09,extentReportImage453PO_10,extentReportImage453PO_11,
	extentReportImage453PO_12,extentReportImage453PO_13,extentReportImage453PO_14,extentReportImage453PO_15,extentReportImage453PO_16,extentReportImage453PO_17,
	extentReportImage453PO_18,extentReportImage453PO_19,extentReportImage453PO_20,extentReportImage453PO_21,extentReportImage453PO_22,extentReportImage453PO_23,
	extentReportImage453PO_24,extentReportImage453PO_25,extentReportImage453PO_26,extentReportImage453PO_27;

	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;

	public pageObjectsJSprint4(WebDriver Driver) {
		this.Driver = Driver;

	}
	
	public String headrFlatChkBox(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if (pageFactS4.headrChkBox(Driver)== true) {
			
			System.out.println("Header flat income checkbox is pre-selected, if user has previously saved Flat code in allowance section and flat remaining > 0");
			extentTest.log(LogStatus.INFO, "Header flat income checkbox is pre-selected, if user has previously saved Flat code in allowance section and flat remaining > 0");
		} else {
			System.out.println("Header flat income checkbox is not pre-selected, if user has previously saved Flat code in allowance section and flat remaining > 0");
			extentReportImage453PO_01 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_01.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_01);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Header flat income checkbox is not pre-selected, if user has previously saved Flat code in allowance section and flat remaining > 0"
					+ extentTest.addScreenCapture(extentReportImage453PO_01));
		}
		return null;
	}

	public String headrFlatLabel(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if (pageFactS4.headrLbl(Driver)== true) {
			
			System.out.println("Header flat income label is showing the flat code associated with the flat income");
			extentTest.log(LogStatus.INFO, "Header flat income label is showing the flat code associated with the flat income");
		} else {
			System.out.println("Header flat income label is not showing the flat code associated with the flat income");
			extentReportImage453PO_02 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_02.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_02);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Header flat income label is not showing the flat code associated with the flat income"
					+ extentTest.addScreenCapture(extentReportImage453PO_02));
		}
		return null;
	}
	
	public String perfDtFrmTo(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		Thread.sleep(3000);
		if (pageFactS4.perfDtFrmToDflt(Driver)== true) {
			
			System.out.println("Perf Date from,To in the header flat income is showing the previously saved Perf Date from & To in allowance section by default");
			extentTest.log(LogStatus.INFO, "Perf Date from,To in the header flat income is showing the previously saved Perf Date from & To in allowance section by default");
		} else {
			System.out.println("Perf Date from,To in the header flat income is not showing the previously saved Perf Date from & To in allowance section by default");
			extentReportImage453PO_03 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_03.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_03);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Perf Date from,To in the header flat income is not showing the previously saved Perf Date from & To in allowance section by default"
					+ extentTest.addScreenCapture(extentReportImage453PO_03));
		}
		return null;
	}
	
	public String flatRemain(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if (pageFactS4.FltRemain(Driver)== true) {
			
			System.out.println("Flat remaining is showing the remaining amount that has not been billed");
			extentTest.log(LogStatus.INFO, "Flat remaining is showing the remaining amount that has not been billed");
		} else {
			System.out.println("Flat remaining is not showing the remaining amount that has not been billed");
			extentReportImage453PO_04 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_04.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_04);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Flat remaining is not showing the remaining amount that has not been billed"
					+ extentTest.addScreenCapture(extentReportImage453PO_04));
		}
		return null;
	}
	
	public String flatRemainLessZero(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if (pageFactS4.flatRemainLssZero(Driver)== true) {
			
			System.out.println("Flat remaining is showing $0 when Flat remaining is < 0");
			extentTest.log(LogStatus.INFO, "Flat remaining is showing $0 when Flat remaining is < 0");
		} else {
			System.out.println("Flat remaining is not showing $0 when Flat remaining is < 0");
			extentReportImage453PO_05 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_05.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_05);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Flat remaining is not showing $0 when Flat remaining is < 0"
					+ extentTest.addScreenCapture(extentReportImage453PO_05));
		}
		return null;
	}
	
	public String flatAmt(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if (pageFactS4.flatAmtVerify(Driver)== true) {
			
			System.out.println("User is able to edit flat amount");
			extentTest.log(LogStatus.INFO, "User is able to edit flat amount");
		} else {
			System.out.println("User is not able to edit flat amount");
			extentReportImage453PO_06 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_06.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_06);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "User is not able to edit flat amount"
					+ extentTest.addScreenCapture(extentReportImage453PO_06));
		}
		return null;
	}
	
	public String useRemBal(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.useRemBalance(Driver)== true) {
			
			System.out.println("When user select Use remaining balance checkbox, Flat amount is equal to Flat remaining");
			extentTest.log(LogStatus.INFO, "When user select Use remaining balance checkbox, Flat amount is equal to Flat remaining");
		} else {
			System.out.println("When user select Use remaining balance checkbox, Flat amount is not equal to Flat remaining");
			extentReportImage453PO_07 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_07.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_07);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "When user select Use remaining balance checkbox, Flat amount is not equal to Flat remaining"
					+ extentTest.addScreenCapture(extentReportImage453PO_07));
		}
		return null;
	}
	
	public String buttonsEnb(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if(pageFactS4.buttonsEnable(Driver)== true) {
			System.out.println("The 3 buttons( Save, Submit, Cancel) are enabled, if Header flat income checkbox is enabled");
			Thread.sleep(2000);
			pageFactS4.incChk.click();
			pageFactS4.itemized.click();
			
			if(pageFactS4.buttonsEnable(Driver)== true) {
				System.out.println("The 3 buttons( Save, Submit, Cancel) are enabled, if Itemized income checkbox is enabled");
				
				pageFactS4.incChk.click();
				if(pageFactS4.buttonsEnable(Driver)== true) {
					System.out.println("The 3 buttons( Save, Submit, Cancel) are enabled, if Both checkbox are enabled");
					pageFactS4.incChk.click();
					pageFactS4.itemized.click();
					if(pageFactS4.buttonsEnable(Driver)== true) {
						System.out.println("The 3 buttons( Save, Submit, Cancel) are disabled, if both are not selected");
						System.out.println("The 3 buttons( Save, Submit, Cancel) are enabled, if Header flat income checkbox or Itemized income checkbox or both is selected");
						extentTest.log(LogStatus.INFO, "The 3 buttons( Save, Submit, Cancel) are enabled, if Header flat income checkbox or Itemized income checkbox or both are selected");
					}
					else {
						System.out.println("The 3 buttons( Save, Submit, Cancel) are enabled, if both are not selected");
						System.out.println("The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected");
						extentReportImage453PO_08 = System.getProperty("user.dir") + "\\picture"
						+ "\\extentReportImage453PO_08.png";
						File source =aftermthd(Driver);
						File destination = new File(extentReportImage453PO_08);
						FileUtils.copyFile(source, destination);
						extentTest.log(LogStatus.FAIL, "The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected"
						+ extentTest.addScreenCapture(extentReportImage453PO_08));
					}
				} 
				else {
					System.out.println("The 3 buttons( Save, Submit, Cancel) are disabled, if Both checkbox are enabled");
					System.out.println("The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected");
					extentReportImage453PO_08 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_08.png";
					File source =aftermthd(Driver);
					File destination = new File(extentReportImage453PO_08);
					FileUtils.copyFile(source, destination);
					extentTest.log(LogStatus.FAIL, "The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected"
					+ extentTest.addScreenCapture(extentReportImage453PO_08));
				}
			}
			else {
				
				System.out.println("The 3 buttons( Save, Submit, Cancel) are disabled, if Itemized income checkbox is enabled");
				System.out.println("The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected");
				extentReportImage453PO_08 = System.getProperty("user.dir") + "\\picture"
				+ "\\extentReportImage453PO_08.png";
				File source =aftermthd(Driver);
				File destination = new File(extentReportImage453PO_08);
				FileUtils.copyFile(source, destination);
				extentTest.log(LogStatus.FAIL, "The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected"
				+ extentTest.addScreenCapture(extentReportImage453PO_08));
			}
		}
		else {
			System.out.println("The 3 buttons( Save, Submit, Cancel) are disabled, if Header flat income checkbox is enabled");
			System.out.println("The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected");
			extentReportImage453PO_08 = System.getProperty("user.dir") + "\\picture"
			+ "\\extentReportImage453PO_08.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_08);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "The 3 buttons( Save, Submit, Cancel) are not enabled, if Header flat income checkbox or Itemized income checkbox or both are selected"
			+ extentTest.addScreenCapture(extentReportImage453PO_08));
		}	
		return null;
	}
	
	public String FlatAGRSaveSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatAmtGRemSaveSub(Driver)== true) {
			
			System.out.println("Income record saved and submitted successfully with Flat amount > Flat remaining");
			extentTest.log(LogStatus.INFO, "Income record saved and submitted successfully with Flat amount > Flat remaining");
		} else {
			System.out.println("Income record doesn't saved and submitted successfully with Flat amount > Flat remaining");
			extentReportImage453PO_09 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_09.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_09);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income record doesn't saved and submitted successfully with Flat amount > Flat remaining"
					+ extentTest.addScreenCapture(extentReportImage453PO_09));
		}
		return null;
	}
	
	public String FlatAGRSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatAmtGRemSub(Driver)== true) {
			
			System.out.println("Income record submitted successfully with Flat amount > Flat remaining");
			extentTest.log(LogStatus.INFO, "Income record submitted successfully with Flat amount > Flat remaining");
		} else {
			System.out.println("Income record doesn't submitted successfully with Flat amount > Flat remaining");
			extentReportImage453PO_10 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_10.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_10);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income record doesn't submitted successfully with Flat amount > Flat remaining"
					+ extentTest.addScreenCapture(extentReportImage453PO_10));
		}
		return null;
	}
	
	public String FlatALRSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatAmtLRemSub(Driver)== true) {
			
			System.out.println("Income record submitted successfully with Flat amount < Flat remaining");
			extentTest.log(LogStatus.INFO, "Income record submitted successfully with Flat amount < Flat remaining");
		} else {
			System.out.println("Income record doesn't submitted successfully with Flat amount < Flat remaining");
			extentReportImage453PO_11 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_11.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_11);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income record doesn't submitted successfully with Flat amount < Flat remaining"
					+ extentTest.addScreenCapture(extentReportImage453PO_11));
		}
		return null;
	}
	
	public String FlatAERSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatAmtERemSub(Driver)== true) {
			
			System.out.println("Income record submitted successfully with Flat amount = Flat remaining");
			extentTest.log(LogStatus.INFO, "Income record submitted successfully with Flat amount = Flat remaining");
		} else {
			System.out.println("Income record doesn't submitted successfully with Flat amount = Flat remaining");
			extentReportImage453PO_12 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_12.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_12);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income record doesn't submitted successfully with Flat amount < Flat remaining"
					+ extentTest.addScreenCapture(extentReportImage453PO_12));
		}
		return null;
	}
	
	public String FlatARBillSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatARSub(Driver)== true) {
			
			System.out.println("Income Bill type record submitted successfully");
			extentTest.log(LogStatus.INFO, "Income Bill type record submitted successfully");
		} else {
			System.out.println("Income Bill type record doesn't submitted successfully");
			extentReportImage453PO_12 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_12.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_12);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income Bill type record doesn't submitted successfully"
					+ extentTest.addScreenCapture(extentReportImage453PO_12));
		}
		return null;
	}
	
	public String FlatARAccrueSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		pageFactS4.accrue.click();
		if (pageFactS4.FlatARSub(Driver)== true) {
			
			System.out.println("Income Accrue type record submitted successfully");
			extentTest.log(LogStatus.INFO, "Income Accrue type record submitted successfully");
		} else {
			System.out.println("Income Accrue type record doesn't submitted successfully");
			extentReportImage453PO_13 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_13.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_13);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income Accrue type record doesn't submitted successfully"
					+ extentTest.addScreenCapture(extentReportImage453PO_13));
		}
		return null;
	}
	
	public String FlatARBillAccrueSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		pageFactS4.billAccrue.click();
		if (pageFactS4.FlatARSub(Driver)== true) {
			
			System.out.println("Income Bill & Accrue type records submitted successfully");
			extentTest.log(LogStatus.INFO, "Income Bill & Accru type records submitted successfully");
		} else {
			System.out.println("Income Bill & Accru type records doesn't submitted successfully");
			extentReportImage453PO_14 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_14.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_14);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Income Bill & Accru type records doesn't submitted successfully"
					+ extentTest.addScreenCapture(extentReportImage453PO_14));
		}
		return null;
	}
	
	public String FlatRemZeroSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
			
		if (pageFactS4.headrChkBoxFlatRemzero(Driver)== true) {
			
			System.out.println("Header flat income checkbox is not selected as flat remaining is not >0");
			extentTest.log(LogStatus.INFO, "Header flat income checkbox is not selected as flat remaining is not >0");
		} else {
			System.out.println("Header flat income checkbox is selected eventhough flat remaining is not >0");
			extentReportImage453PO_15 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_15.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_15);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Header flat income checkbox is selected eventhough flat remaining is not >0"
					+ extentTest.addScreenCapture(extentReportImage453PO_15));
		}
		return null;
	}
	
	public String TotFlatEqBill(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.TotFlatEqualBill(Driver)== true) {
			
			System.out.println("Flat remaining is coming as 0 since total flat amount in allowance = Bill amount");
			extentTest.log(LogStatus.INFO, "Flat remaining is coming as 0 since total flat amount in allowance = Bill amount");
		} else {
			System.out.println("Flat remaining is not coming as 0 eventhough total flat amount in allowance = Bill amount");
			extentReportImage453PO_15 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_15.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_15);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Flat remaining is not coming as 0 eventhough total flat amount in allowance = Bill amount"
					+ extentTest.addScreenCapture(extentReportImage453PO_15));
		}
		return null;
	}
	
	public String FlatAmtzeroSaveSub(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatzeroSaveSub(Driver)== true) {
			
			System.out.println("User is not able to submit the details since Flat amount = 0");
			extentTest.log(LogStatus.INFO, "User is not able to submit the details since Flat amount = 0");
		} else {
			System.out.println("User is able to submit the details eventhough Flat amount = 0");
			extentReportImage453PO_15 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_15.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_15);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "User is able to submit the details eventhough Flat amount = 0"
					+ extentTest.addScreenCapture(extentReportImage453PO_15));
		}
		return null;
	}
	
	public String FlatARSaveSubBill(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		if (pageFactS4.FlatAmtRemSaveSub(Driver)== true) {
			
			System.out.println("Bill Type Income record saved and submitted successfully");
			extentTest.log(LogStatus.INFO, "Bill Type Income record saved and submitted successfully");
		} else {
			System.out.println("Bill Type Income record doesn't saved and submitted successfully");
			extentReportImage453PO_16 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_16.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_16);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Bill Type Income record doesn't saved and submitted successfully"
					+ extentTest.addScreenCapture(extentReportImage453PO_16));
		}
		return null;
	}
	
	
	public String FlatARSaveSubAccrue(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		pageFactS4.accrue.click();
		if (pageFactS4.FlatAmtRemSaveSub(Driver)== true) {
			
			System.out.println("Accrue Type Income record saved and submitted successfully");
			extentTest.log(LogStatus.INFO, "Accrue Type Income record saved and submitted successfully");
		} else {
			System.out.println("Accrue Type Income record doesn't saved and submitted successfully");
			extentReportImage453PO_17 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_17.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_17);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Accrue Type Income record doesn't saved and submitted successfully"
					+ extentTest.addScreenCapture(extentReportImage453PO_17));
		}
		return null;
	}
	
	public String FlatARSaveSubBillAccrue(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		pageFactS4.headrChkBox(Driver);
		pageFactS4.billAccrue.click();
		if (pageFactS4.FlatAmtRemSaveSub(Driver)== true) {
			
			System.out.println("Bill & Accrue Type Income record saved and submitted successfully");
			extentTest.log(LogStatus.INFO, "Bill & Accrue Type Income record saved and submitted successfully");
		} else {
			System.out.println("Bill & Accrue Type Income record doesn't saved and submitted successfully");
			extentReportImage453PO_18 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_18.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_18);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Bill & Accrue Type Income record doesn't saved and submitted successfully"
					+ extentTest.addScreenCapture(extentReportImage453PO_18));
		}
		return null;
	}
	
	public String itemizedChkBox(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		if (pageFactS4.itemChkBox(Driver)== true) {
			
			System.out.println("Itemized income checkbox is pre-selected, if user has previously saved Allowance Type in allowance section");
			extentTest.log(LogStatus.INFO, "Itemized income checkbox is pre-selected, if user has previously saved Allowance Type in allowance section");
		} else {
			System.out.println("Itemized income checkbox is not pre-selected, if user has previously saved Allowance Type in allowance section");
			extentReportImage453PO_19 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_19.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_19);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Itemized income checkbox is not pre-selected, if user has previously saved Allowance Type in allowance section"
					+ extentTest.addScreenCapture(extentReportImage453PO_19));
		}
		
		//		if (pageFactS4.itemChkBoxLbl(Driver)== true) {
//			
//			System.out.println("Itemized income label is showing Allowance Type,Perf code1 & Perf Code 2 also if saved previously");
//			extentTest.log(LogStatus.INFO, "Itemized income label is showing Allowance Type,Perf code1 & Perf Code 2 also if saved previously");
//		} else {
//			System.out.println("Itemized income label is not showing Allowance Type,Perf code1 & Perf Code 2 also if saved previously");
//			extentReportImage453PO_20 = System.getProperty("user.dir") + "\\picture"
//					+ "\\extentReportImage453PO_20.png";
//			File source =aftermthd(Driver);
//			File destination = new File(extentReportImage453PO_20);
//			FileUtils.copyFile(source, destination);
//			extentTest.log(LogStatus.FAIL, "Itemized income label is not showing Allowance Type,Perf code1 & Perf Code 2 also if saved previously"
//					+ extentTest.addScreenCapture(extentReportImage453PO_20));
//		}
		return null;
	}
	
	public String itemizedFields(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {
		
		Thread.sleep(3000);
		
		if (pageFactS4.itemFieldsCIC(Driver)== true) {
			
			System.out.println("CIC field in itemized section is showing from item details section");
			extentTest.log(LogStatus.INFO, "CIC field in itemized section is showing from item details section");
		} else {
			System.out.println("CIC field in itemized section is not showing from item details section");
			extentReportImage453PO_21 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_21.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_21);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "CIC field in itemized section is not showing from item details section"
					+ extentTest.addScreenCapture(extentReportImage453PO_21));
		}
		
		if (pageFactS4.itemFieldsUPC(Driver)== true) {
			
			System.out.println("UPC field in itemized section is showing from item details section");
			extentTest.log(LogStatus.INFO, "UPC field in itemized section is showing from item details section");
		} else {
			System.out.println("UPC field in itemized section is not showing from item details section");
			extentReportImage453PO_22 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_22.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_22);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "UPC field in itemized section is not showing from item details section"
					+ extentTest.addScreenCapture(extentReportImage453PO_22));
		}
		
		if (pageFactS4.itemFieldsDtFrm(Driver)== true) {
			
			System.out.println("Item Date From field in itemized section is showing from item details section");
			extentTest.log(LogStatus.INFO, "Item Date From field in itemized section is showing from item details section");
		} else {
			System.out.println("Item Date From field in itemized section is not showing from item details section");
			extentReportImage453PO_23 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_23.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_23);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Item Date From field in itemized section is not showing from item details section"
					+ extentTest.addScreenCapture(extentReportImage453PO_23));
		}
		
		if (pageFactS4.itemFieldsDtTo(Driver)== true) {
			
			System.out.println("Item Date To field in itemized section is showing from item details section");
			extentTest.log(LogStatus.INFO, "Item Date To field in itemized section is showing from item details section");
		} else {
			System.out.println("Item Date To field in itemized section is not showing from item details section");
			extentReportImage453PO_23 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_23.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_23);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Item Date To field in itemized section is not showing from item details section"
					+ extentTest.addScreenCapture(extentReportImage453PO_23));
		}
		
		if (pageFactS4.itemFieldsAlwAmt(Driver)== true) {
			
			System.out.println("Allowance amount field in itemized section is showing from item details section");
			extentTest.log(LogStatus.INFO, "Allowance amount field in itemized section is showing from item details section");
		} else {
			System.out.println("Allowance amount field in itemized section is not showing from item details section");
			extentReportImage453PO_24 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_24.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_24);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance amount field in itemized section is not showing from item details section"
					+ extentTest.addScreenCapture(extentReportImage453PO_24));
		}
		
if (pageFactS4.itemFieldsQty(Driver)== true) {
			
			System.out.println("Quantity field in itemized section is showing blank initially");
			extentTest.log(LogStatus.INFO, "Quantity field in itemized section is showing blank initially");
		} else {
			System.out.println("Quantity field in itemized section is not showing blank initially");
			extentReportImage453PO_25 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage453PO_25.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage453PO_25);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Quantity field in itemized section is not showing blank initially"
					+ extentTest.addScreenCapture(extentReportImage453PO_25));
		}

//if (pageFactS4.itemFieldsTot(Driver)== true) {
//	
//	System.out.println("Total field in itemized section is showing 0.00 as quantity is blank initially");
//	extentTest.log(LogStatus.INFO, "Total field in itemized section is showing 0.00 as quantity is blank initially");
//} else {
//	System.out.println("Total field in itemized section is not showing 0.00 eventhough quantity is blank initially");
//	extentReportImage453PO_26 = System.getProperty("user.dir") + "\\picture"
//			+ "\\extentReportImage453PO_26.png";
//	File source =aftermthd(Driver);
//	File destination = new File(extentReportImage453PO_26);
//	FileUtils.copyFile(source, destination);
//	extentTest.log(LogStatus.FAIL, "Total field in itemized section is not showing 0.00 eventhough quantity is blank initially"
//			+ extentTest.addScreenCapture(extentReportImage453PO_26));
//}
		return null;
	}
	
//	public String itemizedItemIncome(WebDriver Driver)
//			throws InterruptedException, AWTException, ParseException, IOException {
//		
//		
//		if (pageFactS4.itemizedItmInc(Driver)== true) {
//			
//			System.out.println("Bill & Accrue Type Income record saved and submitted successfully");
//			extentTest.log(LogStatus.INFO, "Bill & Accrue Type Income record saved and submitted successfully");
//		} else {
//			System.out.println("Bill & Accrue Type Income record doesn't saved and submitted successfully");
//			extentReportImage453PO_18 = System.getProperty("user.dir") + "\\picture"
//					+ "\\extentReportImage453PO_18.png";
//			File source =aftermthd(Driver);
//			File destination = new File(extentReportImage453PO_18);
//			FileUtils.copyFile(source, destination);
//			extentTest.log(LogStatus.FAIL, "Bill & Accrue Type Income record doesn't saved and submitted successfully"
//					+ extentTest.addScreenCapture(extentReportImage453PO_18));
//		}
//		return null;
//	}	
	
	public String qtySum(WebDriver Driver) throws InterruptedException{
		
		pageFactS4.qtyfield(Driver);
		Thread.sleep(2000);
		pageFactS4.totalSum(Driver);
		 
		
		return null;
	}
	
	public String qtyfieldenter(WebDriver Driver){
		
		pageFactS4.qtyfield(Driver);
		pageFactS4.notess(Driver);
		System.out.println("Able to enter values in Notes field");
		extentTest.log(LogStatus.INFO, "Able to enter values in Notes field");
		return null;
	}
	
	
public String qtyfieldenter0(WebDriver Driver){
		
		pageFactS4.qtyfield0(Driver);
		
		return null;
	}
	

	public String fltAmntFieldenter(WebDriver Driver){
		
		pageFactS4.flatAmnt(Driver);
		
		return null;
	}
	
	public String BRSaveNew(WebDriver Driver) throws InterruptedException{
		
		
		pageFactS4.elmntIntract(Driver);
		Thread.sleep(3000);
		pageFactS4.brSaveBtnn(Driver);
		Thread.sleep(2000);
		pageFactS4.readyy(Driver);
		Thread.sleep(2000);
		pageFactS4.readyy(Driver);
		Thread.sleep(2000);
		pageFactS4.addIncmeBtnn(Driver);
		
		
		return null;
	}
	
	
	public String incomeClk(WebDriver Driver){
			
		pageFactS4.addIncmeBtnn(Driver);
		
		System.out.println("Clicked on Add Income button");
		extentTest.log(LogStatus.INFO, "Clicked on Add Income button");
		return null;
	}
	
	public String acrueClk(WebDriver Driver){
		
		
		pageFactS4.accrueee(Driver);

		System.out.println("Clicked on Accrue button");
		extentTest.log(LogStatus.INFO, "Clicked on Accrue button");
		return null;
	}
public String BillacrueClk(WebDriver Driver){
		
		
		pageFactS4.billNaccruee(Driver);
		System.out.println("Clicked on Bill & Accrue button");
		extentTest.log(LogStatus.INFO, "Clicked on Bill & Accrue button");
		return null;
	}


public String clickable(WebDriver Driver){
	
 
	if(ExpectedConditions.elementToBeClickable(pageFactS4.clckable) != null){
		System.out.println("No Text box over Cost field");
		extentTest.log(LogStatus.PASS, "No Text box over Cost field");
		
	}else{
		System.out.println("Text box over Cost field");
		extentTest.log(LogStatus.INFO, "Text box over Cost field");
		
	}
 
	return null;
}


	public File aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) throws InterruptedException {

		pageFactS3 = new GenericFactoryJSprint3(Driver);
		pageFactS4 = new GenericFactoryJSprint4(Driver);
	
		pageFactS4.beforeTest(Driver);

	}
}
