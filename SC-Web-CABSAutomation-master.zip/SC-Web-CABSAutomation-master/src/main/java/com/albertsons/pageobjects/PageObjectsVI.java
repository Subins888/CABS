package com.albertsons.pageobjects;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Base64;
import java.util.List;
import java.util.Properties;

import jxl.read.biff.BiffException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.google.common.collect.Ordering;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsVI extends ExtendBaseClass {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactoryVI pageFactVI;
	GenericFactoryV pageFactV;
	GenericFactorySprint3 pageFactAS3;
	String extentReportImage1155PO_0, extentReportImage509PO_00,
			extentReportImage509PO_001;

	public static String offer, lead, dtFrm, dtTo, ftAmt, ftCode, allwTyp,
			perf1, perf2;

	public PageObjectsVI(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public File aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactV.createBillrcrd));
		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String waitforErrPopup(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVI.errMsg));
		return null;
	}

	public String waitforIncomeBtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactAS3.addIncmeBtn));
		return null;
	}

	public String MiscincomeAddClk(WebDriver Driver) {

		pageFactAS3.incmbtnclk();
		return null;
	}

	public String AddIncAlwncClk(WebDriver Driver) {

		pageFactAS3.addIncmeBtnn(Driver);
		return null;
	}

	public String waitforMiscIncomeBtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactAS3.incombtn));
		return null;
	}

	public String waitforIncmWarning(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVI.incomeWarning));
		return null;
	}

	public String waitforMiscIncmWarning(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 10);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVI.miscIncomeWarn));
		return null;
	}

	public String waitforbrErr(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFactVI.invalidOfseterr));
		return null;
	}

	public String ascndingUPC(WebDriver Driver) throws InterruptedException {

		pageFactVI.itemDetailExpp(Driver);

		Thread.sleep(5000);

		String FirstUPccc = pageFactV.FirstUPCc(Driver);
		String SecondUPccc = pageFactV.SecondUPCc(Driver);

		System.out.println("FirstUPccc is " + FirstUPccc);
		System.out.println("ScndtUPccc is " + SecondUPccc);

		int value1 = Integer.parseInt(FirstUPccc);
		int value2 = Integer.parseInt(SecondUPccc);

		System.out.println("Firstval is " + value1);
		System.out.println("Scndtval is " + value2);
		// boolean ascc = value1 > value2;
		if (value1 < value2) {

			System.out.println("sorted");

			extentTest.log(LogStatus.INFO, "UPC Value sorted");
		} else {

			System.out.println("Not sorted");
			extentTest.log(LogStatus.FAIL, "UPC Value not sorted");
		}

		return null;
	}

	public String colapseData(WebDriver Driver) throws InterruptedException {
		pageFactVI.itemDetailExpp(Driver);
		Thread.sleep(5000);

		pageFactVI.allwAmnttt(Driver);

		if (pageFactVI.itemDetailExp.isDisplayed()) {

			System.out
					.println("Allow amount field value is same as that of the above CIC value");
			extentTest
					.log(LogStatus.INFO,
							"Allow amount field value is same as that of the above CIC value");
		} else {

			System.out
					.println("Allow amount field value is not same as that of the above CIC value");
			extentTest
					.log(LogStatus.FAIL,
							"Allow amount field value is not same as that of the above CIC value");
		}
		return null;
	}

	public String editNextRow(WebDriver Driver) throws InterruptedException {

		pageFactVI.itemDetailExpp(Driver);
		Thread.sleep(2500);
		pageFactVI.allwAmntTab(Driver);
		if (pageFactVI.itemDetailExp.isDisplayed()) {

			System.out
					.println("Able to expand and edit the second row of UPC line");
			extentTest.log(LogStatus.INFO,
					"Able to expand and edit the second row of UPC line");
		} else {

			System.out
					.println("Able to expand and edit the second row of UPC line");
			extentTest.log(LogStatus.FAIL,
					"Able to expand and edit the second row of UPC line");
		}

		return null;
	}

	public String colapsEnable(WebDriver Driver) {

		if (pageFactVI.itemDetailExp.isDisplayed()) {

			System.out
					.println("Able to expand and edit the second row of UPC line");
			extentTest.log(LogStatus.INFO,
					"Able to expand and edit the second row of UPC line");
		} else {

			System.out
					.println("Able to expand and edit the second row of UPC line");
			extentTest.log(LogStatus.FAIL,
					"Able to expand and edit the second row of UPC line");
		}

		return null;
	}

	public String noColaps(WebDriver Driver) throws InterruptedException {

		pageFactVI.differntAmnt(Driver);
		Thread.sleep(5000);

		// WebDriverWait wait = new WebDriverWait(Driver, 5);
		// wait.until(ExpectedConditions.elementToBeClickable(pageFactV.errorIcon));
		//
		try {
			if (pageFactV.SecondUPC.isDisplayed()) {

				System.out
						.println("Not able to collapse the row as the values are different");
				extentTest
						.log(LogStatus.INFO,
								"Not able to collapse the row as the values are different");

			} else {

				System.out
						.println("Able to collapse the row even if the values are different");
				extentTest
						.log(LogStatus.FAIL,
								"Able to collapse the row even if the values are different");
			}
		} catch (Exception e) {

			System.out
					.println("Able to collapse the row even if the values are different");
			extentTest
					.log(LogStatus.FAIL,
							"Able to collapse the row even if the values are different");
		}

		return null;

	}
	
	public String waitForSpinnerToBeGone(WebDriver Driver) {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}

	public String brSaveAfterEdit(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		//Thread.sleep(20000);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);
		
		pageFact.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(3000);
		pageFactAS3.itemDetailsAmntt(Driver);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(5000);
		waitforbrErr(Driver);
		
		if (pageFactAS3.invalidOfseterroMsg().contains(
				"Billing Record has been saved")) {
			System.out.println("Billing Record has been successfully saved");
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Billing Record has been successfully saved");
		} else {
			System.out
					.println("Error in updating BR details with offset values");
			extentTest.log(LogStatus.FAIL,
					"TESTCASE FAILED:  Error in updating BR details with offset values");
		}
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);
		
		return null;
	}

	public String BrReady(WebDriver Driver) {

		pageFactAS3.readyy(Driver);
		return null;
	}

	public String waitforAlwncType(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVI.cogsType));
		return null;
	}

	public String COGSAlwnceBR(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
	//	Thread.sleep(20000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");

		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFactVI.bRTypeRetailFieldAccValue();
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(4500);
		pageFactVI.bRTypeRetailFieldLeadCIC();
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		Thread.sleep(4500);
		pageFact.allwtype();
		Thread.sleep(4500);
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();

		return null;

	}

	public String COGSAlwnceBRinvalid(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		// Thread.sleep(20000);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(2500);

		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(5000);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(2000);
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();
		Thread.sleep(5000);
		waitforErrPopup(Driver);
		Thread.sleep(2500);
		String ErrMsg = pageFactVI.errMsgg(Driver);

		if (pageFactVI
				.errMsgg(Driver)
				.contains(
						"This item is not valid in this billing record's location and time frame")) {
			System.out
					.println("Error message displaying when giving invalid CIC id is: "
							+ ErrMsg);
			extentTest.log(LogStatus.INFO,
					"Error message displaying when giving invalid CIC id is: "
							+ ErrMsg);
		} else {
			System.out
					.println("Error message displaying when giving invalid CIC id is: "
							+ ErrMsg);
			extentTest.log(LogStatus.FAIL,
					"Error message displaying when giving invalid CIC id is: "
							+ ErrMsg);
		}

		pageFactVI.closeBtnn(Driver);

		return null;

	}

	public String COGSAlwnceBRnoOfset(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		Thread.sleep(20000);
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFactVI.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCICnoOfset();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();

		return null;

	}

	public String COGSAlwnceBRnoOfsetII(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(20000);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFactVI.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCIC();
		pageFactVI.bRTypeRetailFieldStartDt();
		pageFactVI.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();

		return null;

	}

	public String COGSAlwnceBRnoOfsetIII(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		Thread.sleep(2500);
		pageFactV.srchBilRcrdd(Driver);

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(2500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCICnoOfsetII();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();
		waitforbrtxt(Driver);

		if (pageFact.BRtxt.isDisplayed()) {

			System.out
					.println("Able to see New BR page after giving the CIC with the date range from Tera DB");
			extentTest
					.log(LogStatus.INFO,
							"Able to see New BR page after giving the CIC with the date range from Tera DB");
		} else {

			System.out
					.println("Not able to see the New BR page after giving the CIC with the date range from Tera DB");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see the New BR page after giving the CIC with the date range from Tera DB");
		}

		Thread.sleep(5000);
		// pageFactVI.closeBtnnII(Driver);
		// pageFactVI.closeBtnn(Driver);
		Driver.navigate().refresh();
		System.out.println("Page refreshed");
		return null;

	}

	public String COGSAlwnceBRnoOfsetIV(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitforBlngbtn(Driver);
		Thread.sleep(2500);
		pageFactV.srchBilRcrdd(Driver);

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(2500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFactVI.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();

		Thread.sleep(3500);

		pageFact.brSubmit.click();

		// waitforbrtxt(Driver);
		Thread.sleep(5000);
		String ErrMsg = pageFactVI.errMsgg(Driver);

		if (pageFactVI
				.errMsgg(Driver)
				.contains(
						"This item is not valid in this billing record's location and time frame")) {
			System.out
					.println("Error message displaying when given CIC id not matches with the Tera DB date range:"
							+ ErrMsg);
			extentTest
					.log(LogStatus.INFO,
							"Error message displaying when given CIC id not matches with the Tera DB date range:"
									+ ErrMsg);
		} else {
			System.out
					.println("Error message not displaying when given CIC id not matches with the Tera DB date range");
			extentTest
					.log(LogStatus.FAIL,
							"Error message not displaying when given CIC id not matches with the Tera DB date range");
		}
		Thread.sleep(5000);
		pageFactVI.closeBtnn(Driver);

		return null;
	}

	public String COGSAlwnceBRnoOfsetV(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		Thread.sleep(2500);
		pageFactV.srchBilRcrdd(Driver);

		waitforBlngbtn(Driver);
		pageFact.creatBillng();
		Thread.sleep(2500);
		pageFact.blngrcrdDrp();
		waitforAlwncType(Driver);
		Thread.sleep(3500);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(2500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFactVI.bRTypeRetailFieldLeadCICnoOfsetIII();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		Thread.sleep(2500);
		pageFactVI.p2AlwT1.click();
		Thread.sleep(3500);

		pageFact.brSubmit.click();
		waitforbrtxt(Driver);

		if (pageFact.BRtxt.isDisplayed()) {

			System.out
					.println("Able to see New BR page after giving the CIC with the date range from Tera DB");
			extentTest
					.log(LogStatus.INFO,
							"Able to see New BR page after giving the CIC with the date range from Tera DB");
		} else {

			System.out
					.println("Not able to see the New BR page after giving the CIC with the date range from Tera DB");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see the New BR page after giving the CIC with the date range from Tera DB");
		}

		return null;

	}

	public String cogsChck(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		Thread.sleep(20000);
		String em = pageFactVI.cogsNumAcnt3(Driver);
		String em1 = pageFactVI.cogsNumAcnt2(Driver);
		System.out.println("value is :" + em);
		System.out.println("value is aa :" + em1);
		if (pageFactVI.cogsNumAcnt2(Driver).contains("COGS")) {
			System.out
					.println("COGS Facilities value displaying by default in the Account Lookup Type dropdown in the BR page");
			extentTest
					.log(LogStatus.INFO,
							"COGS Facilities value displaying by default in the Account Lookup Type dropdown in the BR page");
		} else {
			System.out
					.println("COGS Facilities value not displaying by default in the Account Lookup Type dropdown in the BR page");
			extentTest
					.log(LogStatus.FAIL,
							"COGS Facilities value not displaying by default in the Account Lookup Type dropdown in the BR page");
		}

		return null;
	}

	public String ofsetNum(WebDriver Driver) throws InterruptedException {

		Thread.sleep(3000);
		pageFactV.ofsetNumAcnt(Driver);
		String Acnt = pageFactV.ofsetNumAcnt(Driver);
		System.out.println("Account number displaying is - " + Acnt);
		extentTest
				.log(LogStatus.INFO, "Account number displaying is - " + Acnt);

		pageFactV.ofsetNumFac(Driver);

		String Faclty = pageFactV.ofsetNumFac(Driver);
		System.out.println("Facility ID displaying is - " + Faclty);
		extentTest.log(LogStatus.INFO, "Facility ID displaying is - " + Faclty);
		pageFactV.ofsetNumSec(Driver);

		String Section = pageFactV.ofsetNumSec(Driver);
		System.out.println("Section ID displaying is - " + Section);
		extentTest.log(LogStatus.INFO, "Section ID displaying is - " + Section);

		return null;
	}

	public String BRSaveRet(WebDriver Driver) throws InterruptedException,
			IOException {

		waitforbrtxt(Driver);
		pageFact.elmntIntract();
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);
		Thread.sleep(3000);
		// pageFactAS3.itemDetailsAmntt(Driver);
		pageFactAS3.itemDetailsAmnttt(Driver);
		Thread.sleep(3000);
		// pageFactV.brSaveBtnn(Driver);
		pageFactV.savee(Driver);
		Thread.sleep(3000);
		return null;
	}

	public String ofsetInvalid(WebDriver Driver) throws BiffException,
			IOException, InterruptedException, ParseException {

		try{
		waitforBlngbtn(Driver);
		//Thread.sleep(15000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFactV.srchBilRcrdd(Driver);
		Thread.sleep(5000);
		COGSAlwnceBRnoOfset(Driver);
		waitforbrtxt(Driver);
		//Thread.sleep(20000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		BRSaveRet(Driver);

		String errMsg = pageFactAS3.invalidOfseterroMsg();
		if (pageFactAS3
				.invalidOfseterroMsg()
				.contains(
						"No Account or Facility has been setup for your team within COGS Facilities 3338")) {
			System.out.println("Error message displaying is: " + errMsg);
			extentTest.log(LogStatus.INFO, "Error message displaying is: "
					+ errMsg);
		} else {
			System.out.println("Error message displaying is: " + errMsg);
			extentTest.log(LogStatus.INFO, "Error message displaying is: "
					+ errMsg);
		}
		
		}catch(Exception e){
			System.out.println("No error message displayed");
			extentTest.log(LogStatus.INFO, "No error message displayed");
			
		}
		return null;
	}

	public String ofsetTeraDbcase(WebDriver Driver)
			throws InterruptedException, BiffException, IOException,
			ParseException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactV.postAuditt(Driver);
		Thread.sleep(2000);

		COGSAlwnceBRnoOfsetII(Driver);

		return null;
	}

	public String WaitForSearchTxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(pageFactV.srchTxt));
		return null;
	}

	public String searchBtnClk(WebDriver Driver) {

		pageFactV.srchBilRcrdd(Driver);
		return null;
	}

	public String teamXternal(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(2000);
		pageFactVI.xternall(Driver);

		pageFactV.srchBilRcrdd(Driver);
		WaitForSearchTxt(Driver);
		pageFactV.firstBrSearchh(Driver);
		waitforbrtxt(Driver);
		Thread.sleep(5000);

		ofsetNum(Driver);

		return null;
	}

	public String SearchchangeTeam(WebDriver Driver)
			throws InterruptedException {

		Thread.sleep(3000);
		pageFactV.teamDrpp(Driver);
		Thread.sleep(3000);
		pageFactV.billingDrpp(Driver);
		Thread.sleep(3000);
		pageFactV.srchBilRcrdd(Driver);
		Thread.sleep(3000);

		return null;
	}

	public String bRTypeCOGSItemized(WebDriver Driver) throws IOException,
			InterruptedException {

		SearchchangeTeam(Driver);
		waitforBlngbtn(Driver);
		Thread.sleep(2000);
		pageFact.creatBillng();
		Thread.sleep(5000);
		pageFact.blngrcrdDrp();
		Thread.sleep(5000);
		waitforAlwncType(Driver);
		Thread.sleep(5000);

		if (pageFactVI.cogsType.isDisplayed()) {

			System.out
					.println("Able to see Allowance type in the Billing Record Type Dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Able to see Allowance type in the Billing Record Type Dropdown");
		} else {

			System.out
					.println("Not able to see Allowance type in the Billing Record Type Dropdown");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"Not able to see Allowance type in the Billing Record Type Dropdown");
		}

		pageFactVI.cogsTypee(Driver);
		Thread.sleep(5000);

		if (pageFactVI.itemAlwType().equals("Allowance Type")) {
			System.out
					.println("Allowance type label is displayed under ITEMIZED section");
			extentTest.log(LogStatus.INFO,
					"Allowance type label is displayed under ITEMIZED section");
		} else {
			System.out
					.println("Allowance type label is not displayed under ITEMIZED section");
		//	File source = aftermthd(Driver);
			//byte[] fileContent = FileUtils.readFileToByteArray(source);
			//String Base64StringofScreenshot = "data:image/png;base64,"
				//	+ Base64.getEncoder().encodeToString(fileContent);

		//	extentTest
				//	.log(LogStatus.FAIL,
						//	"Allowance type label is not displayed under ITEMIZED section"
								//	+ extentTest
											//.addScreenCapture(Base64StringofScreenshot));
		}

		if (pageFact.itemPerf1().equals("Performance 1")) {
			System.out
					.println("Performance 1 label is displayed under ITEMIZED section");
			extentTest.log(LogStatus.INFO,
					"Performance 1 label is displayed under ITEMIZED section");
		} else {
			System.out
					.println("Performance 1 label is not displayed under ITEMIZED section");

		//	File source = aftermthd(Driver);
		//	byte[] fileContent = FileUtils.readFileToByteArray(source);
		//	String Base64StringofScreenshot = "data:image/png;base64,"
		//			+ Base64.getEncoder().encodeToString(fileContent);

		//	extentTest
				//	.log(LogStatus.FAIL,
						//	"Performance 1 label is not displayed under ITEMIZED section"
								//	+ extentTest
										//	.addScreenCapture(Base64StringofScreenshot));

		}

		if (pageFact.itemPerf2().equals("Performance 2")) {
			System.out
					.println("Performance 2 label is displayed under ITEMIZED section");
			extentTest.log(LogStatus.INFO,
					"Performance 2 label is displayed under ITEMIZED section");
		} else {
			System.out
					.println("Performance 2 label is not displayed under ITEMIZED section");

		//	File source = aftermthd(Driver);
		//	byte[] fileContent = FileUtils.readFileToByteArray(source);
		//	String Base64StringofScreenshot = "data:image/png;base64,"
			//		+ Base64.getEncoder().encodeToString(fileContent);

			//extentTest
				//	.log(LogStatus.FAIL,
						//	"Performance 2 label is not displayed under ITEMIZED section"
								//	+ extentTest
										//	.addScreenCapture(Base64StringofScreenshot));
		}

		if (pageFactVI.allwtypeCOGS() == true) {
			System.out
					.println("Allowance Type drop down under ITEMIZED section is showing valid values");
			extentTest
					.log(LogStatus.INFO,
							"Allowance Type drop down under ITEMIZED section is showing valid values");
		} else {
			System.out
					.println("Allowance Type drop down under ITEMIZED section is not showing valid values");

		//	File source = aftermthd(Driver);
		//	byte[] fileContent = FileUtils.readFileToByteArray(source);
		//	String Base64StringofScreenshot = "data:image/png;base64,"
			//		+ Base64.getEncoder().encodeToString(fileContent);

		//	extentTest
				//	.log(LogStatus.FAIL,
							//"Allowance Type drop down under ITEMIZED section is not showing valid values"
									//+ extentTest
											//.addScreenCapture(Base64StringofScreenshot));
		}
		return null;
	}

	public Boolean allwTypeC(WebDriver Driver) throws InterruptedException,
			IOException, AWTException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		if (pageFactVI.allwTP1P2() == true) {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"C\" is having valid values");
			extentTest
					.log(LogStatus.INFO,
							"Performance 1 & Performance 2 for Allowance Type \"C\" is having valid values");
		} else {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"C\" is not having valid values");

		//	File source = aftermthd(Driver);
		//	byte[] fileContent = FileUtils.readFileToByteArray(source);
		//	String Base64StringofScreenshot = "data:image/png;base64,"
			//		+ Base64.getEncoder().encodeToString(fileContent);

		//	extentTest
				//	.log(LogStatus.FAIL,
							//"Performance 1 & Performance 2 for Allowance Type \"C\" is not having valid values"
								//	+ extentTest
										//	.addScreenCapture(Base64StringofScreenshot));

		}
		return null;
	}

	public Boolean allwTypeA(WebDriver Driver) throws InterruptedException,
			IOException, AWTException {

		if (pageFactVI.allwSP1P2() == true) {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"A\" is having valid values");
			extentTest
					.log(LogStatus.INFO,
							"Performance 1 & Performance 2 for Allowance Type \"A\" is having valid values");
		} else {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"A\" is not having valid values");

		//	File source = aftermthd(Driver);
		//	byte[] fileContent = FileUtils.readFileToByteArray(source);
		//	String Base64StringofScreenshot = "data:image/png;base64,"
			//		+ Base64.getEncoder().encodeToString(fileContent);

		//	extentTest
				//	.log(LogStatus.FAIL,
						//	"Performance 1 & Performance 2 for Allowance Type \"A\" is not having valid values"
								//	+ extentTest
											//.addScreenCapture(Base64StringofScreenshot));

		}
		Thread.sleep(5000);
		//pageFactVI.closeBtnn(Driver);
		return null;
	}

	public String ot(WebDriver Driver) throws InterruptedException {

		waitforIncomeBtn(Driver);
		pageFactVI.notesTabFlatAmt(Driver);
		waitforIncmWarning(Driver);
		pageFactVI.incomeWarningg(Driver);
		Thread.sleep(2500);
		//String warngMsg = pageFactVI.WarningMsgg(Driver);
		
		if(pageFactVI.warningM.isDisplayed()){
			
			System.out.println("OT Limit exceeds, showing warning message properly");
			extentTest.log(LogStatus.INFO,
					"OT Limit exceeds, showing warning message properly");
		}else{		
			System.out
			.println("OT Limit exceeds not showing any warning messages");
	extentTest.log(LogStatus.FAIL,
			"OT Limit exceeds not showing any warning messages");			
		}

		//		if (pageFactVI.WarningMsgg(Driver).contains(
//				"Income will be sent for approval")) {
//			System.out.println("OT Limit exceeds, showing warning message: "
//					+ warngMsg);
//			extentTest.log(LogStatus.INFO,
//					"OT Limit exceeds, showing warning message: " + warngMsg);
//		} else {
//			System.out
//					.println("OT Limit exceeds not showing any warning messages");
//			extentTest.log(LogStatus.FAIL,
//					"OT Limit exceeds not showing any warning messages");
//		}

		Thread.sleep(5000);

		// Warning vanish function START
		pageFactVI.notesFlatAmntClear(Driver);
		Thread.sleep(5000);

		try {
			if (pageFactVI.incomeWarning.isDisplayed()) {

				System.out
						.println("Warning message still displaying even after giving value lesser than the OT limit");
				extentTest
						.log(LogStatus.FAIL,
								"Warning message still displaying even after giving value lesser than the OT limit");

			} else {
				System.out
						.println("Warning message vanished after giving value lesser than the OT limit");
				extentTest
						.log(LogStatus.INFO,
								"Warning message vanished after giving value lesser than the OT limit");

			}
		} catch (Exception e) {

			System.out
					.println("Warning message vanished after giving value lesser than the OT limit");
			extentTest
					.log(LogStatus.INFO,
							"Warning message vanished after giving value lesser than the OT limit");
		}
		// Warning vanish function END
		Thread.sleep(3000);

		pageFactIV.incSubmt(Driver);
		System.out.println("Clicked on Income Submit button");
		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");

		Thread.sleep(5000);

		try {
			if (pageFactIV.warngYes.isDisplayed()) {

				System.out.println("Flat Amount Exceeds pop up displayed");
				extentTest.log(LogStatus.INFO,
						"Flat Amount Exceeds pop up displayed");

				pageFactIV.warngYess(Driver);

				System.out
						.println("Clicked on Yes button from the pop up, Income Submitted");
				extentTest
						.log(LogStatus.INFO,
								"Clicked on Yes button from the pop up, Income Submitted");
			}
		} catch (Exception e) {

			System.out
					.println("Flat Amount Exceeds pop up not displayed, Income submitted");
			extentTest
					.log(LogStatus.INFO,
							"Flat Amount Exceeds pop up not displayed, Income submitted");
		}

		Thread.sleep(3000);

		try {
			if (pageFactIV.warngYes.isDisplayed()) {

				System.out
						.println("'You have not entered a quantity for 1 item' pop up displayed");
				extentTest
						.log(LogStatus.INFO,
								"'You have not entered a quantity for 1 item' pop up displayed");

				pageFactIV.warngYess(Driver);

				System.out
						.println("Clicked on Yes button from the pop up, Income Submitted");
				extentTest
						.log(LogStatus.INFO,
								"Clicked on Yes button from the pop up, Income Submitted");
			}
		} catch (Exception e) {

			System.out
					.println("'You have not entered a quantity for 1 item' pop up not displayed, Income submitted");
			extentTest
					.log(LogStatus.INFO,
							"'You have not entered a quantity for 1 item' pop up not displayed, Income submitted");
		}

		return null;
	}

	public String otII(WebDriver Driver) throws InterruptedException {

		try{
		
		waitforIncomeBtn(Driver);
		pageFactVI.notesTabFlatAmtII(Driver);
		waitforIncmWarning(Driver);
		pageFactVI.incomeWarningg(Driver);
		Thread.sleep(2500);
		String warngMsg = pageFactVI.WarningMsgg(Driver);

		if (pageFactVI.WarningMsgg(Driver).contains(
				"Income will be sent for approval")) {
			System.out.println("OT Limit exceeds, showing warning message: "
					+ warngMsg);
			extentTest.log(LogStatus.INFO,
					"OT Limit exceeds, showing warning message: " + warngMsg);
		} else {
			System.out
					.println("OT Limit exceeds not showing any warning messages");
			extentTest.log(LogStatus.FAIL,
					"OT Limit exceeds not showing any warning messages");
		}

		pageFactIV.incSubmt(Driver);
		System.out.println("Clicked on Income Submit button");
		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");

		Thread.sleep(5000);

		try {
			if (pageFactIV.warngYes.isDisplayed()) {

				System.out.println("Flat Amount Exceeds pop up displayed");
				extentTest.log(LogStatus.INFO,
						"Flat Amount Exceeds pop up displayed");

				pageFactIV.warngYess(Driver);

				System.out
						.println("Clicked on Yes button from the pop up, Income Submitted");
				extentTest
						.log(LogStatus.INFO,
								"Clicked on Yes button from the pop up, Income Submitted");
			}
		} catch (Exception e) {

			System.out
					.println("Flat Amount Exceeds pop up not displayed, Income submitted");
			extentTest
					.log(LogStatus.INFO,
							"Flat Amount Exceeds pop up not displayed, Income submitted");
		}

		Thread.sleep(3000);

		try {
			if (pageFactIV.warngYes.isDisplayed()) {

				System.out
						.println("'You have not entered a quantity for 1 item' pop up displayed");
				extentTest
						.log(LogStatus.INFO,
								"'You have not entered a quantity for 1 item' pop up displayed");

				pageFactIV.warngYess(Driver);

				System.out
						.println("Clicked on Yes button from the pop up, Income Submitted");
				extentTest
						.log(LogStatus.INFO,
								"Clicked on Yes button from the pop up, Income Submitted");
			}
		} catch (Exception e) {

			System.out
					.println("'You have not entered a quantity for 1 item' pop up not displayed, Income submitted");
			extentTest
					.log(LogStatus.INFO,
							"'You have not entered a quantity for 1 item' pop up not displayed, Income submitted");
		}

		}catch (Exception e){
			
			System.out
			.println("'You have not entered a quantity for 1 item' pop up not displayed, Income submitted");
	extentTest
			.log(LogStatus.INFO,
					"'You have not entered a quantity for 1 item' pop up not displayed, Income submitted");
			
		}
		
		return null;
	}

	public String acrueClk(WebDriver Driver) {

		pageFactVI.acruelabll(Driver);
		System.out.println("Clicked on Accrue Radio Button");
		extentTest.log(LogStatus.INFO, "Clicked on Accrue Radio Button");

		return null;
	}

	public String acrueClkMisc(WebDriver Driver) {

		pageFactVI.acruelablMiscc(Driver);
		System.out.println("Clicked on Accrue Radio Button");
		extentTest.log(LogStatus.INFO, "Clicked on Accrue Radio Button");

		return null;
	}

	public String BilacrueClkMisc(WebDriver Driver) {

		pageFactVI.bilNdAcruMiscc(Driver);
		System.out.println("Clicked on Accrue Radio Button");
		extentTest.log(LogStatus.INFO, "Clicked on Accrue Radio Button");

		return null;
	}

	public String bilNdacruClk(WebDriver Driver) {

		pageFactVI.bilNdacruu(Driver);
		System.out.println("Clicked on Bill and Accrue Radio Button");
		extentTest.log(LogStatus.INFO,
				"Clicked on Bill and Accrue Radio Button");

		return null;
	}

	public String otMisc(WebDriver Driver) throws InterruptedException,
			IOException {

		Thread.sleep(2000);
		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		Thread.sleep(5000);
		pageFactVI.incAmntt(Driver);

		// waitforMiscIncmWarning(Driver);
		Thread.sleep(5000);

		try {
			if (pageFactVI.miscIncomeWarn.isDisplayed()) {

				System.out.println("OT Warning message displayed");
				extentTest.log(LogStatus.INFO, "OT Warning message displayed");

				pageFactVI.miscIncomeWarnn(Driver);
				Thread.sleep(2500);
				String warngMsg = pageFactVI.miscWarningMsgg(Driver);

				if (pageFactVI.miscWarningMsgg(Driver).contains(
						"Income will be sent for approval")) {
					System.out
							.println("Misc OT Limit exceeds, showing warning message: "
									+ warngMsg);
					extentTest.log(LogStatus.INFO,
							"Misc OT Limit exceeds, showing warning message: "
									+ warngMsg);
				} else {
					System.out
							.println("Misc OT Limit exceeds not showing any warning messages");
					extentTest
							.log(LogStatus.FAIL,
									"Misc OT Limit exceeds not showing any warning messages");
				}
				pageFactVI.addIncomeMiscc(Driver);

				System.out.println("Clicked on Income Submit button");
				extentTest.log(LogStatus.INFO,
						"Clicked on Income Submit button");

			}
		} catch (Exception e) {
			//
			// System.out.println("OT Warning message not displayed");
			//
			// // SCREENSHOT CODE
			// File source = aftermthd(Driver);
			// byte[] fileContent = FileUtils.readFileToByteArray(source);
			// String Base64StringofScreenshot = "data:image/png;base64,"
			// + Base64.getEncoder().encodeToString(fileContent);
			//
			// extentTest.log(LogStatus.FAIL, "OT Warning message not displayed"
			// + extentTest.addScreenCapture(Base64StringofScreenshot));
		}

		return null;
	}

	public String otMiscII(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2000);
		pageFactAS3.comentTxtBox(Driver);
		pageFactAS3.descripTxtBo(Driver);
		Thread.sleep(5000);
		pageFactVI.incAmntt(Driver);
		Thread.sleep(5000);
		if (pageFactVI.miscIncomeWarn.isDisplayed()) {

			System.out.println("OT Warning message displayed");
			extentTest.log(LogStatus.INFO, "OT Warning message displayed");
		} else {

			System.out.println("OT Warning message NOT displayed");
			extentTest.log(LogStatus.INFO, "OT Warning message NOT displayed");
		}

		pageFactVI.miscIncomeWarnn(Driver);
		Thread.sleep(5000);
//		String warngMsg = pageFactVI.warngMsgMiscc(Driver);
//
//		if (pageFactVI.miscWarningMsgIIg(Driver).contains(
//				"Income will be sent for approval")) {
//			System.out
//					.println("Misc OT Limit exceeds, showing warning message: "
//							+ warngMsg);
//			extentTest.log(LogStatus.INFO,
//					"Misc OT Limit exceeds, showing warning message: "
//							+ warngMsg);
//		} else {
//			System.out
//					.println("Misc OT Limit exceeds not showing any warning messages");
//			extentTest.log(LogStatus.FAIL,
//					"Misc OT Limit exceeds not showing any warning messages");
//		}

		pageFactVI.addIncomeMiscc(Driver);

		System.out.println("Clicked on Income Submit button");
		extentTest.log(LogStatus.INFO, "Clicked on Income Submit button");

		return null;
	}

	public String addIncomeCollapseCase(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFactAS3.incmbtnclk();
		System.out.println("Clicked income button MISC");
		Thread.sleep(2500);

		try {
			if (pageFactAS3.incmSubmt.isDisplayed()) {

				otMisc(Driver);
				System.out.println("reached try");
			} else {

				pageFactAS3.incmbtnclk();
				System.out.println("reached catch");
				Thread.sleep(2500);
				otMisc(Driver);
			}
		} catch (Exception e) {

			pageFactAS3.incmbtnclk();
			System.out.println("reached catch");
			Thread.sleep(2500);
			otMisc(Driver);
		}

		return null;
	}

	public String newBRpage(WebDriver Driver) throws InterruptedException {

		waitforbrtxt(Driver);
		waitForSpinnerToBeGone(Driver);
		Thread.sleep(3000);

		if (pageFact.BRtxt.isDisplayed()) {

			System.out
					.println("Able to see New BR page after giving valid CIC value");
			extentTest
					.log(LogStatus.INFO,
							"TESTCASE PASSED:  Able to see New BR page after giving valid CIC value");
		} else {

			System.out
					.println("Not able to see the New BR page even after giving the valid CIC value");

			// SCREENSHOT CODE

			// SCREENSHOT CODE
			extentTest
					.log(LogStatus.FAIL,
							"TESTCASE FAILED:  Not able to see the New BR page even after giving the valid CIC value");
		}

		Thread.sleep(5000);

		return null;
	}

	public String AlwnceBR(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		waitForSpinnerToBeGone(Driver);
		// Thread.sleep(20000);
		Thread.sleep(2500);

		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(4500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(4500);
		pageFactVI.bRTypeRetailFieldLeadCIC942();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(4500);
		pageFact.itemAlwType();
		// pageFact.allwtype();
		// pageFact.allwTP1P2();
		// pageFact.p2AlwT0.click();
		Thread.sleep(4500);

		pageFact.brSubmit.click();

		return null;

	}
	
		public String AlwnceBRII(WebDriver Driver) throws IOException, InterruptedException,
			ParseException, BiffException {

		
		waitforBlngbtn(Driver);
		//Thread.sleep(20000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
				
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		pageFact.retailalw();
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldOffNo();	
		Thread.sleep(3500);
		pageFactVI.bRTypeRetailFieldLeadCIC942();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		Thread.sleep(3500);
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(3500);
		pageFact.itemAlwType();
		// pageFact.allwtype();
		// pageFact.allwTP1P2();
		// pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBRinvalid(WebDriver Driver) throws IOException,
			InterruptedException, ParseException, BiffException {

		try {
			// waitforBlngbtn(Driver);
			pageFact.creatBillng();
			Thread.sleep(1500);
			pageFact.blngrcrdDrp();
			Thread.sleep(3500);
			pageFact.retailalw();
			Thread.sleep(1500);

			pageFact.bRTypeRetailFieldAccValue();
			pageFact.bRTypeRetailFieldOffNo();
			pageFactVI.bRTypeRetailFieldLeadCIC942invalid();
			pageFact.bRTypeRetailFieldStartDt();
			pageFact.bRTypeRetailFieldEndDt();
			pageFact.headerFlatAmtGrtZero();
			pageFact.itemAlwType();
			pageFact.allwtype();
			pageFact.allwTP1P2();
			pageFact.p2AlwT0.click();
			Thread.sleep(2500);

			// offer= pageFact.offnum.getAttribute("value");
			// offer = pageFact.offrno.getAttribute("value");
			// lead = pageFact.LCIC.getAttribute("value");
			// dtFrm = pageFact.billDateFrom.getAttribute("value");
			// dtTo = pageFact.billDateTo.getAttribute("value");
			// ftAmt = pageFact.amtTxtBox1.getAttribute("value");
			// ftCode = pageFact.flatCodeBox.findElement(
			// By.className("ng-value-label")).getText();
			// allwTyp =
			// Driver.findElement(By.xpath("//*[@id=\"allowanceType\"]"))
			// .getText();
			// perf1 =
			// Driver.findElement(By.xpath("//*[@id=\"performanceCode1\"]"))
			// .getText();
			// perf2 =
			// Driver.findElement(By.xpath("//*[@id=\"performanceCode2\"]"))
			// .getText();
			//
			// System.out.println(offer + lead + dtFrm + dtTo + ftAmt + ftCode);
			// System.out.println("Allw type" + allwTyp);
			// System.out.println("P1" + perf1);
			// System.out.println("P2" + perf2);

			pageFact.brSubmit.click();

			Thread.sleep(2000);
			waitforErrPopup(Driver);
			Thread.sleep(2000);
			String ErrMsg = pageFactVI.errMsgg(Driver);

			if (pageFactVI
					.errMsgg(Driver)
					.contains(
							"This item is not valid in this billing record's location and time frame")) {
				System.out
						.println("Error message displaying when giving invalid CIC id is: "
								+ ErrMsg);
				extentTest.log(LogStatus.INFO,
						"Error message displaying when giving invalid CIC id is: "
								+ ErrMsg);
			} else {
				System.out
						.println("Error message displaying when giving invalid CIC id is: "
								+ ErrMsg);
				extentTest.log(LogStatus.FAIL,
						"Error message displaying when giving invalid CIC id is: "
								+ ErrMsg);
			}

		} catch (Exception e) {
		 
			System.out
					.println("Error message displaying properly when giving invalid CIC id");
			extentTest.log(LogStatus.INFO,
					"TESTCASE PASSED:  Error message displaying properly when giving invalid CIC id");
		}

	//	pageFactVI.closeBtnn(Driver);

		return null;

	}

	public String incomeHistory(WebDriver Driver) throws InterruptedException {

		//waitForSpinnerToBeGone(Driver);
		//The above wait not applicable here
		Thread.sleep(55000);
		bilNdacruClk(Driver);
		Thread.sleep(2500);
		AddIncAlwncClk(Driver);
		Thread.sleep(2500);
		ot(Driver);

		Thread.sleep(55000);
		pageFactVI.incmHistoryy(Driver);
		System.out.println("Clicked on Income History '+' icon");
		extentTest.log(LogStatus.INFO, "Clicked on Income History '+' icon");

		Thread.sleep(2500);

		if (pageFactVI.incHistCancel.isDisplayed()) {

			System.out.println("Income History section expanded");
			extentTest.log(LogStatus.INFO, "Income History section expanded");

		} else {
			System.out.println("Income History section not expanded");
			extentTest.log(LogStatus.INFO,
					"Income History section not expanded");
		}
		Thread.sleep(2500);

		String incAmnt = pageFactVI.amntincHistoryy(Driver);

		System.out
				.println("Income Record Amount displaying in the Income History section is: "
						+ incAmnt);
		extentTest.log(LogStatus.INFO,
				"Income Record Amount displaying in the Income History section is: "
						+ incAmnt);

		String alwncHist = pageFactVI.alwnceHistoryy(Driver);

		System.out
				.println("Allowance displaying in the Income History section is: "
						+ alwncHist);
		extentTest.log(LogStatus.INFO,
				"Allowance displaying in the Income History section is: "
						+ alwncHist);

		String frmHistt = pageFactVI.frmHistt(Driver);
		System.out
				.println("From Date displaying in the Income History section is: "
						+ frmHistt);
		extentTest.log(LogStatus.INFO,
				"From Date displaying in the Income History section is: "
						+ frmHistt);

		// String ToHistt = pageFactVI.toHistt(Driver);
		// System.out
		// .println("To Date displaying in the Income History section is: "
		// + ToHistt);
		// extentTest.log(LogStatus.INFO,
		// "To Date displaying in the Income History section is: "
		// + ToHistt);

		String usrHist = pageFactVI.usrIDHistt(Driver);
		System.out
				.println("User ID displaying in the Income History section is: "
						+ usrHist);
		extentTest.log(LogStatus.INFO,
				"User ID displaying in the Income History section is: "
						+ usrHist);

		String incStatus = pageFactVI.statusHistt(Driver);
		System.out
				.println("Income Status displaying in the Income History section is: "
						+ incStatus);
		extentTest.log(LogStatus.INFO,
				"Income Status displaying in the Income History section is: "
						+ incStatus);

		return null;
	}

	public String incomeHistoryBilNdAcrue(WebDriver Driver)
			throws InterruptedException {

		waitforIncomeBtn(Driver);
		Thread.sleep(2500);
		// bilNdacruClk(Driver);
		Thread.sleep(2500);
		AddIncAlwncClk(Driver);
		Thread.sleep(2500);

		ot(Driver);

		Thread.sleep(2500);

		if (pageFactVI.incHistCancel.isDisplayed()) {

			System.out.println("Income History section expanded");
			extentTest.log(LogStatus.INFO, "Income History section expanded");

		} else {
			System.out.println("Income History section not expanded");
			extentTest.log(LogStatus.INFO,
					"Income History section not expanded");
		}
		Thread.sleep(2500);

//		String ThrdHist = pageFactVI.invHist3t(Driver);
//
//		System.out
//				.println("Invoice value displaying in the Income History through Bill And Accrue submission "
//						+ ThrdHist);
//		extentTest
//				.log(LogStatus.INFO,
//						"Invoice value displaying in the Income History through Bill And Accrue submission "
//								+ ThrdHist);

		return null;
	}

	public String incomeHistoryAcrue(WebDriver Driver)
			throws InterruptedException {

		waitforIncomeBtn(Driver);
		Thread.sleep(2500);
		acrueClk(Driver);
		Thread.sleep(2500);
		AddIncAlwncClk(Driver);
		Thread.sleep(2500);
		ot(Driver);

		Thread.sleep(2500);

		if (pageFactVI.incHistCancel.isDisplayed()) {

			System.out.println("Income History section expanded");
			extentTest.log(LogStatus.INFO, "Income History section expanded");

		} else {
			System.out.println("Income History section not expanded");
			extentTest.log(LogStatus.INFO,
					"Income History section not expanded");
		}
		Thread.sleep(2500);

//		String FourthHist = pageFactVI.invHist4t(Driver);
//
//		System.out
//				.println("Invoice value displaying in the Income History through Accrue submission "
//						+ FourthHist);
//		extentTest.log(LogStatus.INFO,
//				"Invoice value displaying in the Income History through Accrue submission "
//						+ FourthHist);

		return null;
	}

	public String ascndingHistory(WebDriver Driver) throws InterruptedException {

		AddIncAlwncClk(Driver);
		Thread.sleep(2000);
		ot(Driver);

		Thread.sleep(5000);

		String FirstHist = pageFactVI.invHist1t(Driver);
		String SecondHist = pageFactVI.invHist2t(Driver);

		if (pageFactVI.invHist1t(Driver).equals("Accrual")) {

			System.out.println("First Invoice Value is: " + FirstHist);
			extentTest.log(LogStatus.INFO, "First Invoice Value  is: "
					+ FirstHist);

			System.out.println("Second Invoice Value is: " + SecondHist);
			extentTest.log(LogStatus.INFO, "Second Invoice Value is: "
					+ SecondHist);

			System.out
					.println("Invoice values in Income History displaying in ascending order, also Accrual value coming first");
			extentTest
					.log(LogStatus.INFO,
							"Invoice values in Income History displaying in ascending order, also Accrual value coming first");

		} else {

			System.out.println("First Invoice Value is: " + FirstHist);
			extentTest.log(LogStatus.INFO, "First Invoice Value  is: "
					+ FirstHist);

			System.out.println("Second Invoice Value is: " + SecondHist);
			extentTest.log(LogStatus.INFO, "Second Invoice Value is: "
					+ SecondHist);

			System.out
					.println("Invoice values in Income History NOT displaying in ascending order");
			extentTest
					.log(LogStatus.FAIL,
							"Invoice values in Income History NOT displaying in ascending order");
		}

		return null;
	}

	public String otWorklist(WebDriver Driver) throws InterruptedException {

		Thread.sleep(55000);
		pageFactVI.OTWorklistLeftt(Driver);
		System.out
				.println("Clicked on Over Tolerance Worklist link button from the left panel");
		extentTest
				.log(LogStatus.INFO,
						"Clicked on Over Tolerance Worklist link button from the left panel");

		Thread.sleep(2500);

		if (pageFactVI.OTWorklistData.isDisplayed()) {

			System.out
					.println("Billing records with Income records are displaying in the OT Worklist section");
			extentTest
					.log(LogStatus.INFO,
							"Billing records with Income records are displaying in the OT Worklist section");

		} else {

			System.out
					.println("Billing records with Income records are NOT displaying in the OT Worklist section");
			extentTest
					.log(LogStatus.FAIL,
							"Billing records with Income records are NOT displaying in the OT Worklist section");

		}

		String FirstBil = pageFactVI.OTWorklistDataa(Driver);
		String SecondBil = pageFactVI.OTWorklistData2a(Driver);

		System.out.println("FirstBil Rcrd is " + FirstBil);
		System.out.println("Scnd Bil Rcrd  is " + SecondBil);

		int value1 = Integer.parseInt(FirstBil);
		int value2 = Integer.parseInt(SecondBil);

		System.out.println("Firstval is " + value1);
		System.out.println("Scndtval is " + value2);
		// boolean ascc = value1 > value2;
		if (value1 <= value2) {

			System.out.println("sorted acdng");

			extentTest.log(LogStatus.INFO,
					"Billing Record displaying in the ascending order");
		} else {

			System.out.println("Not sorted");
			extentTest.log(LogStatus.FAIL,
					"Billing Record not displaying in the ascending order");
		}

		return null;
	}
	public String OTWorklistLeftClk(WebDriver Driver) {

		pageFactVI.OTWorklistLeftt(Driver);
		return null;
	}

	public String otWorklistMisc(WebDriver Driver) throws InterruptedException {

		pageFactVI.OTWorklistLeftt(Driver);
		System.out
				.println("Clicked on Over Tolerance Worklist link button from the left panel");
		extentTest
				.log(LogStatus.INFO,
						"Clicked on Over Tolerance Worklist link button from the left panel");

		Thread.sleep(2500);

		if (pageFactVI.OTWorklistData.isDisplayed()) {

			System.out
					.println("Billing records with Income records are displaying in the OT Worklist section");
			extentTest
					.log(LogStatus.INFO,
							"Billing records with Income records are displaying in the OT Worklist section");

		} else {

			System.out
					.println("Billing records with Income records are NOT displaying in the OT Worklist section");
			extentTest
					.log(LogStatus.FAIL,
							"Billing records with Income records are NOT displaying in the OT Worklist section");

		}

		pageFactVI.paginationTopp(Driver);
		Thread.sleep(5000);

		System.out.println("Clicked on Over Tolerance Worklist BR pagination");
		extentTest.log(LogStatus.INFO,
				"Clicked on Over Tolerance Worklist BR pagination");

		String FirstBil = pageFactVI.OTWorklistDataa(Driver);
		String SecondBil = pageFactVI.OTWorklistData2a(Driver);

		System.out.println("FirstBil Rcrd is " + FirstBil);
		System.out.println("Scnd Bil Rcrd  is " + SecondBil);

		int value1 = Integer.parseInt(FirstBil);
		int value2 = Integer.parseInt(SecondBil);

		System.out.println("Firstval is " + value1);
		System.out.println("Scndtval is " + value2);
		// boolean ascc = value1 > value2;
		if (value1 >= value2) {

			System.out.println("sorted acdng");

			extentTest
					.log(LogStatus.INFO,
							"Billing Record displaying in the ascending order/descending order from the last page of the pagination");
		} else {

			System.out.println("Not sorted");
			extentTest
					.log(LogStatus.FAIL,
							"Billing Record displaying in the ascending order/descending order from the last page of the pagination");
		}

		return null;
	}

	public String OTDatacheck(WebDriver Driver) throws InterruptedException {

		String brNum = pageFactVI.OTWorklistDataa(Driver);
		System.out
				.println("BR Number displaying in the OT Worklist section is:  "
						+ brNum);
		extentTest
				.log(LogStatus.INFO,
						"BR Number displaying in the OT Worklist section is:  "
								+ brNum);

		String blngName = pageFactVI.blngNamee(Driver);
		System.out
				.println("Billing Name displaying in the OT Worklist section is:  "
						+ blngName);
		extentTest.log(LogStatus.INFO,
				"Billing Name displaying in the OT Worklist section is:  "
						+ blngName);

		String incMType = pageFactVI.incmTypee(Driver);
		System.out
				.println("Income Type displaying in the OT Worklist section is:  "
						+ incMType);
		extentTest.log(LogStatus.INFO,
				"Income Type displaying in the OT Worklist section is:  "
						+ incMType);

		String Area = pageFactVI.areaa1(Driver);
		System.out.println("Area displaying in the OT Worklist section is:  "
				+ Area);
		extentTest.log(LogStatus.INFO,
				"Area displaying in the OT Worklist section is:  " + Area);

		String sectionn = pageFactVI.sectionn(Driver);
		System.out
				.println("Section ID displaying in the OT Worklist section is:  "
						+ sectionn);
		extentTest.log(LogStatus.INFO,
				"Section ID displaying in the OT Worklist section is:  "
						+ sectionn);

		String alwncee = pageFactVI.alwncee(Driver);
		System.out
				.println("Allowance Number displaying in double decker format in the OT Worklist section is:  "
						+ alwncee);
		extentTest
				.log(LogStatus.INFO,
						"Allowance Number displaying in double decker format in the OT Worklist section is:  "
								+ alwncee);

		String offerr = pageFactVI.offerr(Driver);
		System.out
				.println("Offer Number displaying in the OT Worklist section is:  "
						+ offerr);
		extentTest.log(LogStatus.INFO,
				"Offer Number displaying in the OT Worklist section is:  "
						+ offerr);

		String amntt = pageFactVI.amntt(Driver);
		System.out.println("Amount displaying in the OT Worklist section is:  "
				+ amntt);
		extentTest.log(LogStatus.INFO,
				"Amount displaying in the OT Worklist section is:  " + amntt);

		pageFactVI.OTWorklistDataaClk(Driver);
		System.out
				.println("Clicked on BR Number hyperlink from the OT Worklist page");
		extentTest.log(LogStatus.INFO,
				"Clicked on BR Number hyperlink from the OT Worklist page");

		waitforbrtxt(Driver);
		Thread.sleep(2500);

		if (pageFact.BRtxt.isDisplayed()) {

			System.out
					.println("Able to see New BR page by clicking on the BR ID hyperlink from  OT Worklist");
			extentTest
					.log(LogStatus.INFO,
							"Able to see New BR page by clicking on the BR ID hyperlink from  OT Worklist");
		} else {

			System.out
					.println("NOT able to see New BR page by clicking on the BR ID hyperlink from  OT Worklist");

			extentTest
					.log(LogStatus.FAIL,
							"NOT able to see New BR page by clicking on the BR ID hyperlink from  OT Worklist");
		}

		return null;
	}

	public String diffUserOT(WebDriver Driver) throws InterruptedException {

		
		OTWorklistLeftClk(Driver);
		Thread.sleep(5000);
		String otwRkCount1 = pageFactVI.OTWorklistLeftTxt(Driver);

		System.out
				.println("OT Worklist count showing for a logged in  user is:  "
						+ otwRkCount1);		
		extentTest
		.log(LogStatus.INFO,
				"OT Worklist count showing for a logged in  user is:  "
						+ otwRkCount1);
		
		pageFactVI.smartDrpdwnn(Driver);
		Thread.sleep(2500);
		pageFactVI.valueClkk(Driver);

		String otwRkCount = pageFactVI.OTWorklistLeftTxt(Driver);

		System.out
				.println("OT Worklist count showing for a differnt user is:  "
						+ otwRkCount);		
		extentTest
		.log(LogStatus.INFO,
				"OT Worklist count showing for a differnt user is:  "
						+ otwRkCount);
		
		

		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactV = new GenericFactoryV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFact = new GenericFactory(Driver);
		pageFactVI = new GenericFactoryVI(Driver);

	}

}
