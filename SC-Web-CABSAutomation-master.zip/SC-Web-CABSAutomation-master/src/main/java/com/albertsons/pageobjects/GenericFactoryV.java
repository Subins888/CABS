package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GenericFactoryV {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */

	WebDriver Driver;

	@FindBy(xpath = "//*[@id='undefined']")
	public WebElement txtDescr;

	@FindBy(id = "label")
	public WebElement blngRcrdLabel;
	// *[@id="maincontainer"]/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[1]/div[1]/div/div[2]/div/label
	// *[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[1]/div[1]/div/div[2]/div/label
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[1]/div[1]/div/div[2]/div/label")
	public WebElement lastDate;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[1]/div[3]/div/label")
	public WebElement brStatus;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[1]/div[4]/div/label")
	public WebElement assignTo;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[1]/div/div[1]/div/label")
	public WebElement AcntLukUp;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[1]/div/div[3]/label")
	public WebElement ofsetNum;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[3]/div/div[1]/label")
	public WebElement deductInv;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[4]/div/label")
	public WebElement blngName;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[3]/div/div/div/cabs-textarea/div/label")
	public WebElement internalNotes;

	@FindBy(xpath = "//*[@id=\"allow-tab\"]/div[1]/i-feather")
	public WebElement alwplus;

	@FindBy(xpath = "//*[@id=\"item-tab\"]/div[1]/i-feather")
	public WebElement itemTab;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[1]/nav/label")
	public WebElement srchTxtII;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[1]/nav/ol/li")
	public WebElement BRtxt;

	@FindBy(xpath = "//*[@id='accLookUpType']/div/span")
	public WebElement retDivDrp;

	@FindBy(id = "ta-accLookUpType-0")
	public WebElement retDiv;

	@FindBy(xpath = "//*[@id='accLookUpValue']/div/span")
	public WebElement retDivVal;

	@FindBy(id = "ta-accLookUpValue-1")
	public WebElement retValu;

	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	public WebElement brSavebtn;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement brSavebtnII;

	@FindBy(xpath = "//*[@id='search']/li/a")
	public WebElement srchBilRcrd;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[10]/div/div/span")
	public WebElement srchTxt;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement firstBrSearch;

	@FindBy(id = "billingRecordId")
	public WebElement blngRcrdid;

	@FindBy(id = "offsetAccountNumber")
	public WebElement offsetAccountNumber;

	@FindBy(id = "offsetFacilityNumber")
	public WebElement offsetFacilityNumber;

	@FindBy(id = "offsetSectionNumber")
	public WebElement offsetSectionNumber;
					 
	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[3]/a")
	public WebElement postAudit;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[3]/a")
	public WebElement preAudit;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[1]/a")
	public WebElement billingDrp;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
	WebElement createBillrcrd;

	@FindBy(xpath = "//*[@id='accountLookupType']/div/span")
	WebElement RetailDiv;

	@FindBy(id = "ta-accountLookupType-0")
	WebElement RetailDivValue;

	@FindBy(id = "ta-accountLookupValue-3")
	WebElement RetailDivVal3;

	@FindBy(id = "ta-accountLookupValue-0")
	public WebElement RetailDivVal;

	@FindBy(xpath = "//*[@id='accountLookupValue']/div/span")
	public WebElement lukuP;

	@FindBy(xpath = "//*[@id='teamDropdown']/span[2]/fa/i")
	public WebElement teamDrp;

	@FindBy(xpath = "//*[@id='assignTo']/div/span")
	public WebElement asignTo;

	@FindBy(id = "ta-assignTo-1")
	public WebElement asignTo1;

	@FindBy(id = "ta-assignTo-3")
	public WebElement asignTo3;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement brSaveBtn;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/plain-button/button")
	public WebElement cancelBtn;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[1]/div/i-feather")
	public WebElement cicItemColaps;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[1]/div/i-feather")
	public WebElement cicItemDetails;

	@FindBy(xpath = "//*[@id='undefined']/input")
	public WebElement itemDetailsAmnt;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;

	@FindBy(xpath = "//*[@id='brStatus']/div/span")
	public WebElement brStatusDrp;

	@FindBy(id = "ta-brStatus-1")
	public WebElement brStatusDrpVal1;

	@FindBy(xpath = "//*[@id='income-tab']/div[4]/button")
	public WebElement incomeBtnNonAlw;

	@FindBy(xpath = "//*[@id='allow-income-tab']/div[4]/button")
	public WebElement incmeButtonAdd;

	@FindBy(xpath = "//*[@id='flatAmount']/input")
	public WebElement fltAmnt;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[1]")
	public WebElement incmSave;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement incmWarnYes;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[13]/div/i-feather")
	public WebElement trash;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	public WebElement trashNo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement trashYes;

	@FindBy(xpath = "//*[@id='allowIncomeCollapse']/div/div/cabs-itemized/div[2]/div/cabs-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement incomeScndLine;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement incomeNewLine;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[1]/div[3]/cabs-textbox/div/input")
	public WebElement leadCICItem;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[1]/div[3]/ng-select/div/div/div[2]/input")
	public WebElement leadUPCItem;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[1]/div[4]/primary-button/button")
	public WebElement CICAdditem;

	@FindBy(xpath = "//*[@id='item-tab']/div[4]/span/button/span")
	public WebElement errorIcon;

	@FindBy(xpath = "//*[@id='ngb-popover-5']/div[2]")
	public WebElement errMsg;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
	public WebElement FirstUPC;
	
	@FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/span")
public WebElement SecondUPC;
	
	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span")
	public WebElement FirstCIC;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[5]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement datFrom;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/cabs-datepicker/form/div/div/input")
	public WebElement datTo;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[8]/div/div/span")
	public WebElement cost;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[9]/div/div/span")
	public WebElement decrip;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[10]/div/div/span")
	public WebElement pack;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[2]/tree-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[11]/div/div/span")
	public WebElement disp;

	// @FindBy(id="a4e24951dffd-0")
	@FindBy(xpath = "/html/body/app-root/cabs-container/div/div[2]/div[2]/br-details/div/cabs-item-details/section/div/div[2]/div/div/div[1]/div[3]/ng-select/ng-dropdown-panel/div[2]/div[2]/div")
	public WebElement upcItem1;

	// @FindBy(id="item-upc")
	// @FindBy(xpath="/html/body/app-root/cabs-container/div/div[2]/div[2]/br-details/div/cabs-item-details/section/div/div[2]/div/div/div[1]/div[2]/div[2]/input")
	// @FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[1]/div[2]/div[2]/input")
	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[1]/div[2]/div[2]/label")
	public WebElement upcRadio;

	@FindBy(xpath = "//*[@id='afd128fa8c69']/div/div[2]/div")
	public WebElement noItemFound;

	@FindBy(xpath = "//*[@id='afd128fa8c69']/div[3]/primary-button/button")
	public WebElement doneBtn;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[2]/div/span[1]/label")
	public WebElement brlabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[3]/div/span[1]/label")
	public WebElement blngNameLabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[4]/div/span[1]/label")
	public WebElement brStatusLabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[5]/div/span[1]/label")
	public WebElement areaLabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[6]/div/span[1]/label")
	public WebElement sectionLabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[7]/div/span[1]/label")
	public WebElement allowanceLabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[8]/div/span[1]/label")
	public WebElement offerLabel;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[9]/div/span[1]/label")
	public WebElement fltAmntLabel;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[10]/div/span[1]/label")
	public WebElement asignTOLabel;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-header/div/div[2]/datatable-header-cell[11]/div/span[1]/label")
	public WebElement dialogLabel;
	
	@FindBy(xpath="//*[@id='brStatusSearch']/div/div/div[2]/input")
	public WebElement brStatusSearch;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/action-button/button")
	public WebElement searchApply;
	
	public String dialogLabell(WebDriver Driver) {

		return dialogLabel.getText();

	}

	
	public String asignTOLabell(WebDriver Driver) {

		return asignTOLabel.getText();

	}

	public String fltAmntLabell(WebDriver Driver) {

		return fltAmntLabel.getText();

	}
	
	public String offerLabell(WebDriver Driver) {

		return offerLabel.getText();

	}
	public String allowanceLabell(WebDriver Driver) {

		return allowanceLabel.getText();

	}

	public String sectionLabell(WebDriver Driver) {

		return sectionLabel.getText();

	}

	public String areaLabell(WebDriver Driver) {

		return areaLabel.getText();

	}

	public String brStatusLabell(WebDriver Driver) {

		return brStatusLabel.getText();

	}

	public String blngNameLabell(WebDriver Driver) {

		return blngNameLabel.getText();

	}

	public String brlabell(WebDriver Driver) {

		return brlabel.getText();

	}

	public String doneBtnn(WebDriver Driver) {

		doneBtn.click();
		return null;
	}

	public String upcItemOne(WebDriver Driver) {

		return upcItem1.getText();

	}

	public String upcRadioo(WebDriver Driver) {

		upcRadio.click();
		return null;
	}

	public String dispp(WebDriver Driver) {

		return disp.getText();

	}

	public String packk(WebDriver Driver) {

		return pack.getText();

	}

	public String decripp(WebDriver Driver) {

		return decrip.getText();

	}

	public String costt(WebDriver Driver) {

		return cost.getText();

	}

	public String datToo(WebDriver Driver) {

		return datTo.getText();

	}

	public String datFromm(WebDriver Driver) {

		return datFrom.getText();

	}

	public String FirstCICc(WebDriver Driver) {

		return FirstCIC.getText();

	}

	public String FirstUPCc(WebDriver Driver) {

		return FirstUPC.getText();

	}
	
	public String SecondUPCc(WebDriver Driver) {

		return SecondUPC.getText();

	}

	public String errMsgg(WebDriver Driver) {

		return errMsg.getText();

	}

	public String errorIconn(WebDriver Driver) {

		errorIcon.click();
		return null;
	}

	public String CICAdditemm(WebDriver Driver) {

		CICAdditem.click();
		return null;
	}

	public String UPCClear(WebDriver Driver) {

		leadUPCItem.clear();
		return null;
	}

	public String leadCicClear(WebDriver Driver) {

		leadCICItem.clear();
		return null;
	}

	public String leadCicInvalid(WebDriver Driver) {

		leadCICItem.sendKeys("ABC");
		return null;
	}

	public String leadCICValu(WebDriver Driver) {

		String valueCIC = FirstCICc(Driver);
		leadCICItem.sendKeys(valueCIC);
		return null;
	}

	public String leadUPCValu(WebDriver Driver) throws InterruptedException {

		Thread.sleep(2500);
		String valueCIC = FirstCICc(Driver);
		// leadUPCItem.sendKeys(valueCIC);
		leadUPCItem.sendKeys("121200017186");
		return null;
	}

	public String leadCICItemm(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(4, i).getContents();

				Thread.sleep(3000);

				leadCICItem.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		Thread.sleep(2500);
		CICAdditemm(Driver);
		System.out.println("Add Item button clicked");
		
//		waitForSpinnerToBeGone();
//		Thread.sleep(2500);
		 
		Thread.sleep(41000);
		CICAdditemm(Driver);
		System.out.println("Add Item button clicked again");
		Thread.sleep(2500);
//		CICAdditemm(Driver);
//		System.out.println("Add Item button clicked again and again");

		return null;
	}
	
	public String waitForSpinnerToBeGone() {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}

	public String leadUPCItemm(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();		

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(6, i).getContents();

				Thread.sleep(3000);

				leadUPCItem.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		Thread.sleep(2500);
		CICAdditemm(Driver);
		System.out.println("Add Item button clicked");
		waitForSpinnerToBeGone();
		Thread.sleep(2500);		
				
		return null;
	}

	public String leadCICItemmII(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		// FileInputStream fi = new
		// FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(5, i).getContents();

				Thread.sleep(3000);

				leadCICItem.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		Thread.sleep(2500);
		CICAdditemm(Driver);
		System.out.println("Add Item button clicked II");
		Thread.sleep(2500);
//		CICAdditemm(Driver);
//		System.out.println("Add Item button clicked again II");
		return null;
	}

	public String leadUPCItemmII(WebDriver Driver) throws BiffException,
			IOException, InterruptedException {

		String file = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
	
		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(1);
		String s1 = null;
		try {
			for (int i = 2; i < s.getRows(); i++) {
				// Read data from excel sheet
				s1 = s.getCell(5, i).getContents();

				Thread.sleep(3000);

				leadUPCItem.sendKeys(s1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		Thread.sleep(2500);
		CICAdditemm(Driver);
		System.out.println("Add Item button clicked II");
		waitForSpinnerToBeGone();
		Thread.sleep(2500);

		return null;
	}

	public String trashYess(WebDriver Driver) {

		trashYes.click();
		return null;
	}

	public String trashNoo(WebDriver Driver) {

		trashNo.click();
		return null;
	}

	public String trashh(WebDriver Driver) {

		trash.click();
		return null;
	}

	public String cicItemColapss(WebDriver Driver) {

		cicItemColaps.click();
		return null;
	}

	public String incmWarnS(WebDriver Driver) {

		incmWarnYes.click();
		return null;

	}

	public String incmSavee(WebDriver Driver) {

		incmSave.click();
		return null;

	}

	public String fltAmntt(WebDriver Driver) {

		fltAmnt.sendKeys("1");
		return null;
	}

	public String incmeButtonAddd(WebDriver Driver) {

		incmeButtonAdd.click();
		return null;

	}

	public String incomeBtnNonAlww(WebDriver Driver) {

		incomeBtnNonAlw.click();
		return null;

	}

	public String brStatusDrpValOne(WebDriver Driver) {

		brStatusDrpVal1.click();
		return null;
	}

	public String brStatusDrpp(WebDriver Driver) {

		brStatusDrp.click();
		return null;
	}

	public String itemDetailsAmntt(WebDriver Driver) {

		itemDetailsAmnt.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, "20");
		save.click();
		return null;
	}

	public String savee(WebDriver Driver) {

		save.click();
		return null;
	}

	public String cicItemDetailss(WebDriver Driver) {

		cicItemDetails.click();
		return null;
	}

	public String brSaveBtnn(WebDriver Driver) {

		brSaveBtn.click();
		return null;
	}

	public String asignToOne(WebDriver Driver) {

		asignTo1.click();
		return null;
	}

	public String asignToThre(WebDriver Driver) {

		asignTo3.click();
		return null;
	}

	public String asignToo(WebDriver Driver) {

		asignTo.click();
		return null;
	}

	public String RetailDivVal33(WebDriver Driver) {

		RetailDivVal3.click();
		return null;
	}

	public String teamDrpp(WebDriver Driver) {

		teamDrp.click();
		return null;
	}

	public String lukuPp(WebDriver Driver) {

		lukuP.click();
		return null;
	}

	public String RetailDivValuee(WebDriver Driver) {

		RetailDivValue.click();
		return null;
	}

	public String RetailDivVall(WebDriver Driver) {

		RetailDivVal.click();
		return null;
	}

	public String RetailDivv(WebDriver Driver) {

		RetailDiv.click();
		return null;
	}

	public String preAuditt(WebDriver Driver) {

		preAudit.click();
		return null;
	}

	public String billingDrpp(WebDriver Driver) {

		billingDrp.click();
		return null;
	}

	public String postAuditt(WebDriver Driver) {

		postAudit.click();
		return null;
	}

	public String ofsetNumAcnt(WebDriver Driver) {

		// WebElement elem = offsetAccountNumber.findElement(By
		// .className("AcctNbr"));
		WebElement elem = offsetAccountNumber;
		return elem.getAttribute("value");

	}

	public String ofsetNumFac(WebDriver Driver) {

		// WebElement elem2 = offsetFacilityNumber.findElement(By
		// .className("FactNbr"));

		WebElement elem2 = offsetFacilityNumber;
		return elem2.getAttribute("value");

	}

	public String ofsetNumSec(WebDriver Driver) {

		// WebElement elem3 = offsetSectionNumber.findElement(By
		// .className("SectNbr"));
		WebElement elem3 = offsetSectionNumber;
		return elem3.getAttribute("value");

	}

	public String sectionInput(WebDriver Driver) {

		offsetSectionNumber.sendKeys("333");
		return null;
	}

	public String blngRcrdidd() {

		WebElement elem = blngRcrdid.findElement(By.className("form-control"));
		return elem.getAttribute("value");

	}

	public String firstBrSearchh(WebDriver Driver) {

		firstBrSearch.click();
		return null;
	}

	public String srchBilRcrdd(WebDriver Driver) {

		srchBilRcrd.click();
		return null;
	}

	public String brSavebtnn(WebDriver Driver) {

		brSavebtn.click();
		return null;
	}

	public String elmntIntract(WebDriver Driver) {
		deductnum.findElement(By.className("form-control")).sendKeys("510");
		return null;
	}

	public String elmntIntract2(WebDriver Driver) throws InterruptedException {
		deductnum.findElement(By.className("form-control")).clear();
		Thread.sleep(2000);
		deductnum.findElement(By.className("form-control")).sendKeys("510");
		return null;
	}

	public String elmntIntractIII(WebDriver Driver) throws InterruptedException {
		deductnum.findElement(By.className("form-control")).clear();
		System.out.println("Cleared");
		Thread.sleep(2000);
		return null;
	}

	public String elmntIntractIV(WebDriver Driver) throws InterruptedException {
		deductnum.findElement(By.className("form-control")).sendKeys(
				"1500123456");
		Thread.sleep(2000);
		return null;
	}

	public String elmntIntractV(WebDriver Driver) throws InterruptedException {
		deductnum.findElement(By.className("form-control")).sendKeys(
				"1500123456");
		Thread.sleep(2000);
		return null;
	}

	public String retValuu(WebDriver Driver) {

		retValu.click();
		return null;
	}

	public String retDivVall(WebDriver Driver) {

		retDivVal.click();
		return null;
	}

	public String retDivDrpp(WebDriver Driver) {

		retDivDrp.click();
		return null;
	}

	public String retDivv(WebDriver Driver) {

		retDiv.click();
		return null;
	}

	public String itemTabb(WebDriver Driver) {

		itemTab.click();
		return null;
	}

	public String alwpluss(WebDriver Driver) {

		alwplus.click();
		return null;
	}

	public String internalNotess() {

		return internalNotes.getText();
	}

	public String blngNamee() {

		return blngName.getText();
	}

	public String deductInvv() {

		return deductInv.getText();
	}

	public String ofsetNumm() {

		return ofsetNum.getText();
	}

	public String AcntLukUpp() {

		return AcntLukUp.getText();
	}

	public String assignToo() {

		return assignTo.getText();
	}

	public String blngRcrdLabell() {

		return blngRcrdLabel.getText();
	}

	public String lastDatee() {

		return lastDate.getText();
	}

	public String brStatuss() {

		return brStatus.getText();
	}

	public GenericFactoryV(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String txtAreaa(WebDriver Driver) {
		txtDescr.sendKeys(" Test Automation II");
		return null;
	}

	public String txtAreaa2(WebDriver Driver) {
		txtDescr.sendKeys(" (Edited) Test Automation II");
		return null;
	}

}
