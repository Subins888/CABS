package com.albertsons.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GenericFactorySJVI {
	WebDriver Driver;
	GenericFactorySJVI POJS6;
	@FindBy(xpath = "//*[@id='income-tab']/div[4]/button")
	WebElement nonAlwAddIncome;

	@FindBy(xpath = "//*[@id='commentsId']")
	WebElement nonAlwIncomeComment;

	@FindBy(xpath = "//*[@id='descId0']")
	WebElement nonAlwDesc;

	@FindBy(xpath = "//*[@id='amountId0']/input")
	WebElement nonAlwAmt;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/action-button/button")
	WebElement nonAlwIncmsSubmit;

	@FindBy(xpath = "//*[@id='misc-history-tab']/div[1]/i-feather")
	WebElement nonAlwIncmHistry;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	WebElement nonAlwIncmHistryInv;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	// @FindBy(xpath =
	// "              //*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/a")
	WebElement nonAlwIncmHistryAccrue;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/p")
	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/p")
	WebElement nonAlwIncmHistryDate;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/p")
	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/div/span/p")
	WebElement nonAlwIncmAccrueDate;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/div[2]/i-feather")
	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/i-feather")
	WebElement nonAlwIncmHistryAttchColum;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/div[2]/label")
	WebElement nonAlwIncmHistryAccrAmt;
	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[4]/div/div/div[2]/label")
	WebElement nonAlwIncmHistryBillAmt;

	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span")
	WebElement nonAlwIncmHistryAccUserId;
	@FindBy(xpath = " //*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span")
	WebElement nonAlwIncmHistryBillUserId;
	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span")
	WebElement nonAlwIncmHistryAccStats;
	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span")
	WebElement nonAlwIncmHistryBillStats;

	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p")
	// WebElement nonAlwIncmHistryAccUserId;
	// @FindBy(xpath =
	// " //*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p")
	// WebElement nonAlwIncmHistryBillUserId;
	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p")
	// WebElement nonAlwIncmHistryAccStats;
	// @FindBy(xpath =
	// "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[6]/div/div/div/span/p")
	// WebElement nonAlwIncmHistryBillStats;
	@FindBy(xpath = "//*[@id='misc-history-tab']/div[3]/i-feather")
	WebElement nonAlwIncmCountIcon;
	@FindBy(xpath = "//*[@id='misc-history-tab']/div[3]")
	WebElement nonAlwIncmCount;
	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/plain-button/button")
	WebElement nonAlwAccCnclBtn;
	@FindBy(xpath = "//*[@id='miscIncomeHistoryCollapse']/div/div/div/cabs-income-history-grid/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[2]/datatable-body-row/div[2]/datatable-body-cell[7]/div/div/plain-button/button")
	WebElement nonAlwBillCnclBtn;
	@FindBy(xpath = "//*[@id='income-tab']/div[3]/div[3]/label")
	WebElement nonAlwBillnAccru;
	@FindBy(xpath = "//*[@id='income-tab']/div[3]/div[2]/label")
	WebElement nonAlwAccru;
	@FindBy(xpath = "//*[@id='income-tab']/div[3]/div[1]/label")
	WebElement nonAlwBill;
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog")
	WebElement nonAlwIncomeConf;
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	WebElement nonAlwIncomeConfYes;

	public GenericFactorySJVI(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String nonAlwIncomeClick(WebDriver Driver) {
		nonAlwAddIncome.click();
		return null;
	}

	public String nonAlwIncomeSubmitClick(WebDriver Driver) {
		nonAlwIncmsSubmit.click();
		return null;
	}

	public String nonAlwIncomeHistClick(WebDriver Driver) {
		nonAlwIncmHistry.click();
		return null;
	}

	public String nonAlwAddIncomeComment(WebDriver Driver) {
		nonAlwIncomeComment.sendKeys("Misc Income comment");
		return null;
	}

	public String nonAlwAddDesc(WebDriver Driver) {
		nonAlwDesc.sendKeys("Misc Income Descr");
		return null;
	}

	public String nonAlwAddAmt(WebDriver Driver) {
		nonAlwAmt.sendKeys("2");
		return null;
	}

	public String nonAlwIncmHistryInvNbr() {

		return nonAlwIncmHistryInv.getText();
	}

	public String nonAlwIncmHistryAccrue() {

		return nonAlwIncmHistryAccrue.getText();
	}

	public String nonAlwIncmHistryInvDate() {

		return nonAlwIncmHistryDate.getText();
	}

	public String nonAlwIncmAccrueDate() {

		return nonAlwIncmAccrueDate.getText();
	}

	public String nonAlwIncmHistryAccrAmt() {

		return nonAlwIncmHistryAccrAmt.getText();
	}

	public String nonAlwIncmHistryBillAmt() {

		return nonAlwIncmHistryBillAmt.getText();
	}

	public String nonAlwIncmHistryAccUserId() {

		return nonAlwIncmHistryAccUserId.getText();

	}

	public String nonAlwIncmHistryBillUserId() {

		return nonAlwIncmHistryBillUserId.getText();

	}

	public String nonAlwIncmHistryAccStats() {

		return nonAlwIncmHistryAccStats.getText();
	}

	public String nonAlwIncmHistryBillStats() {

		return nonAlwIncmHistryBillStats.getText();
	}

	public String nonAlwIncmCountVal() {

		return nonAlwIncmCount.getText();
	}

	public String nonAlwBillnAccruSelect(WebDriver Driver) {

		nonAlwBillnAccru.click();
		return null;
	}

	public String nonAlwAccruSelect(WebDriver Driver) {

		nonAlwAccru.click();
		return null;
	}

	public String nonAlwBillSelect(WebDriver Driver) {

		nonAlwBill.click();
		return null;
	}

	public String nonAlwAccCnclBtn() {

		return nonAlwAccCnclBtn.getText();

	}

	public String nonAlwBillCnclBtn() {

		return nonAlwBillCnclBtn.getText();

	}

}
