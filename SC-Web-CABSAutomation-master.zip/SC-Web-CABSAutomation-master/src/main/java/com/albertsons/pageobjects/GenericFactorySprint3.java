package com.albertsons.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GenericFactorySprint3 {
	
	/**
	 *  
	 * 
	 * @author akuma58
	 *
	 */
	
	WebDriver Driver;

	   public WebElement offnum, LCIC; 
	
	@FindBy(id="offsetSectionNumber")
	WebElement offsetSec;
	 
	@FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/plain-button/button")
	WebElement incmCancel;
	
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/plain-button/button")
	WebElement incmCancel2;
	
	
	@FindBy(id="commentsId")
	WebElement commentTxtBox;
	
	@FindBy(id="notesId")
	WebElement notesTxtBox;
	
	@FindBy(id="descId0")
	WebElement descripTxtBox;
	
	@FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	WebElement cancelOk;
	
	@FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/action-button/button")
	WebElement cancelCanBtn;
	
	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/button")
	public WebElement incmdsave;	 
	
	//	@FindBy(xpath="//*[@id='income-tab']/div[4]/span[1]/button")
	@FindBy(xpath="//*[@id='income-tab']/div[4]/span")
	//@FindBy(xpath="//*[@id='income-tab']/div[4]/span/button")
	public WebElement incmErrBtn;
	
	@FindBy(id="ngb-popover-5")
	WebElement warningContent;
	
	//@FindBy(xpath="//*[@id='income-tab']/div[4]/span/button")
	//public WebElement incmErrBtn;
	
	@FindBy(xpath="//*[@id='ngb-popover-5']/div[2]")
	public WebElement incmErrMsg;
	
	 @FindBy(id = "amountId0")
	public WebElement incAmnt;
	 
	 @FindBy(xpath="//*[@id='amountId0']/input")
	 public WebElement incAmntInput;
	
	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/action-button/button")
	public WebElement incmSubmt;
	
	@FindBy(xpath = "//*[@id='income-tab']/div[4]/button")
	public WebElement incombtn;
	
	@FindBy(id = "ta-accLookUpValue-1")
	public WebElement accntRetvalue1;
	
	@FindBy(id = "accLookUpValue")
	public WebElement accntRetnew;
	
	@FindBy(id="offsetAccountNumber")
	public WebElement ofsetAcntNum;
	
	@FindBy(id="offsetFacilityNumber")
	public WebElement ofsetFacNum;
	
	@FindBy(id="offsetSectionNumber")
	public WebElement ofsetSecNum;
	
	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;
	
	@FindBy(id = "billingName")
	public WebElement blngNam;
	
	@FindBy(xpath = "//*[@id='undefined']")
	public WebElement txtDescr;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	public WebElement newBRSav;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
	public WebElement invalidOfseterrMsg;
	
	@FindBy(id="ta-accLookUpValue-3")
	public WebElement aclukupVal3;
	
	
	@FindBy(id="ta-accLookUpValue-3")
	public WebElement accntRetvalue3;
	
	@FindBy(id="ta-accLookUpValue-5")
	public WebElement aclukupVal5;
	
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[1]")
	public WebElement incmeSaveBtn;
	
	@FindBy(xpath="//*[@id='undefined']/input")
	public WebElement itemDetailsAmnt;
	
	@FindBy(xpath ="//*[@id=\"maincontainer\"]/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement save;
	
	@FindBy(xpath="//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/action-button/button")
	public WebElement ready;
	
	@FindBy(xpath="//*[@id='allow-income-tab']/div[4]/button")
	public WebElement addIncmeBtn;
	
	@FindBy(xpath="//*[@id='brStatus']/div/div/div[3]/input")
	public WebElement brStatusdrpvalue;
	
	@FindBy(id="ta-brStatus-0")
	public WebElement newid;
	
	@FindBy(xpath="//*[@id='brStatus']/div/div/div[3]/input")
	public WebElement brStatusdrop;
	
	//@FindBy(xpath="//*[@id='flatAmount']/input")
	@FindBy(xpath="//*[@id=\"allowIncomeCollapse\"]/div/div/allowinc-header-flat/div/div[2]/form/div[4]/cabs-amount/div/div/input")	 
	public WebElement flatAmt;
	
	@FindBy(xpath="//*[@id='allowIncomeCollapse']/div/div/div[2]/div/div[2]/div/button[1]")
	public WebElement incmSaveBtn;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
	WebElement createBillrcrd;
	
	@FindBy(xpath = "//*[@id=\"accountLookupValue\"]")
	public WebElement accLkUpVal;
	
	@FindBy(id="ta-accountLookupValue-4")
	WebElement acntLukupval20;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-allowance-action-bar/div/div/div/primary-button/button")
	public WebElement brSaveBtn;
	
	@FindBy(xpath = "//*[@id=\"leadCIC\"]")
	public WebElement leadCICc;
	
	@FindBy(id="notesId")
	public WebElement notesComment;
	
	public GenericFactorySprint3(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}
	
	
	public String sectiId(WebDriver Driver) {

	//	return blngRcrdid.getText();		
	//	return blngRcrdid.getAttribute("value");			
		String es = offsetSec.getAttribute("value");
		System.out.println("Section ID displaying is " + es);
		
		 return null;
		
//		WebElement elem = offsetSec.findElement(By.className("SectNbr"));		
//		return	elem.getAttribute("value");	
		//return blngRcrdid.getAttribute("value");
	}
	
	public String cancelBtn(WebDriver Driver){
		
		incmCancel.click();
		return null;
	}
	
public String cancelBtn2(WebDriver Driver){
		
		incmCancel2.click();
		return null;
	}

	public String comentTxtBox(WebDriver Driver){
		
		 commentTxtBox.sendKeys("Test Comment");
		 return null;
	}
	
	public String notesTxtBoxx(WebDriver Driver){
		
		notesTxtBox.sendKeys("Test Comment");
		 return null;
	}
	
	public Boolean notesTxtBoxxx(WebDriver Driver){
		
	//	notesTxtBox.sendKeys("Test Comment");
		if (notesTxtBox.getAttribute("value").isEmpty())
		{
			 return true;
		}
		return false;
	}
	
	public Boolean comentTxtBoxx(WebDriver Driver){
		
		//	notesTxtBox.sendKeys("Test Comment");
			if (commentTxtBox.getAttribute("value").isEmpty())
			{
				 return true;
			}
			return false;
		}
	
	
	
	
	public Boolean notesTxtBoxxxx(WebDriver Driver){
		
		//	notesTxtBox.sendKeys("Test Comment");
			if (notesTxtBox.getAttribute("value").contains("Test Comment"))
			{
				 return true;
			}
			return false;
		}
	

	public String descripTxtBo(WebDriver Driver){
		
		descripTxtBox.sendKeys("Test Description");
		 return null;
	}
	
	public String incAmntTxt(WebDriver Driver){
		
		//return incAmnt.getText();	
	//	return incAmnt.findElement(By.className("form-control")).getText();
	//	return incAmnt.getAttribute("value");
	//	System.out.println("value OS" + pageFactAS3.incAmntInput.getAttribute("value"));
		
		return incAmntInput.getAttribute("value");
	 	//return incAmnt.findElement(By.className("form-control")).getAttribute("value");
 
	 
		}
	
public String incAmntt(WebDriver Driver){
		
	incAmnt.findElement(By.className("form-control")).sendKeys("5");
	//incAmnt.sendKeys("1");
		 return null;
	}

public String incAmnttInvald(WebDriver Driver){
	
	incAmnt.findElement(By.className("form-control")).sendKeys("ABC");
		 return null;
	}

public String incAmnttInvald2(WebDriver Driver){
	
	incAmnt.findElement(By.className("form-control")).sendKeys("12.545");
		 return null;
	}

public String incAmnttClear(WebDriver Driver){
	
	incAmnt.clear();
	return null;
	}
	
public String cancelOKbtn(WebDriver Driver){
		
		cancelOk.click();
		 return null;
	}
	
public String cancelCanbtn(WebDriver Driver){
	
	cancelCanBtn.click();
	 return null;
}

public String incmErrBtnn(WebDriver Driver){

incmErrBtn.click();
return null;
}
public String  savee(WebDriver Driver) {

	 save.click();
	return null;
}
public String incmdsavee() {

	incmdsave.click();
	return null;
}

public String incmErrMsgg() {

	return incmErrMsg.getText();
	  
}
public String incmSubmtt() {

	incmSubmt.click();
	return null;
}

public String incmbtnclk() {
	incombtn.click();
	return null;
}

public String newRetvaluee1() {
	accntRetvalue1.click();
	return null;
}

public String newRetvaluee3() {
	accntRetvalue3.click();
	return null;
}

public String accntretNeww(WebDriver Driver) {
	accntRetnew.click();
	return null;
}

public String ofsetAcntNumm(WebDriver Driver){
	
	ofsetAcntNum.sendKeys("123456");
	
	//ofsetAcntNum.findElement(By.className("AcctNbr")).sendKeys("123456");
	 return null;
}

public String ofsetSecNumm(WebDriver Driver){
	
	ofsetSecNum.sendKeys("1234");
//	ofsetSecNum.findElement(By.className("FactNbr")).sendKeys("1234");
	 return null;
}

public String ofsetFacNumm(WebDriver Driver){
	
	 ofsetFacNum.sendKeys("123");
//	ofsetFacNum.findElement(By.className("SectNbr")).sendKeys("123");
	 return null;
}

public String elmntIntract(WebDriver Driver) {
	deductnum.findElement(By.className("form-control")).sendKeys("510");
	return null;
}

public String blngname(WebDriver Driver) {
	blngNam.click();
	return null;
}
public String txtAreaa(WebDriver Driver) {
	// txtArea.sendKeys("Test Automation");
	txtDescr.sendKeys("Test Automation");
	return null;
}

public String txtQty(WebDriver Driver) {
 
	 txtDescr.findElement(By.className("form-control")).sendKeys("5");
	
	//txtDescr.sendKeys("1");
	return null;
}


public String newBRSave(WebDriver Driver) {
	newBRSav.click();
	return null;
}

public String aclukupVall(WebDriver Driver) {
	aclukupVal3.click();
	return null;
}

public String aclukupVall5(WebDriver Driver){
	
	aclukupVal5.click();
	return null;
}

public String itemDetailsAmntt(WebDriver Driver) throws InterruptedException {
	//itemDetailsAmnt.sendKeys("1");
	Thread.sleep(5000);
	//itemDetailsAmnt.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,"20");	
	save.click();
	return null;
}

public String itemDetailsAmnttt(WebDriver Driver) {
	itemDetailsAmnt.sendKeys("1");
	 
	save.click();
	return null;
}



public String readyy(WebDriver Driver){
	
	ready.click();
	return null;
}
public String addIncmeBtnn(WebDriver Driver){
	
	addIncmeBtn.click();
	return null;
}
public String brStatusdrpvaluee() {

	//return brStatusdrpvalue.getText(); 
		return brStatusdrpvalue.getAttribute("value");
	  
}
public String newidd() {

	 return newid.getText();   
}

public String invalidOfseterroMsg() {

	return invalidOfseterrMsg.getText();
}
public String brStatusdropp(WebDriver Driver){
	
	brStatusdrop.click();
	return null;
}

public String notesTabFlatAmt(WebDriver Driver){
	
	notesComment.sendKeys("Test Notes Automation");
	notesComment.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,"1");	
	
	return null;
}

public String flatAmtt(WebDriver Driver) {
	//flatAmt.findElement(By.className("form-control")).sendKeys("5");
	flatAmt.sendKeys("1");
 	
	return null;
}
public String incmSaveBtnn(WebDriver Driver){
	
	incmSaveBtn.click();
	return null;
}

public String retailalw(WebDriver Driver) {

	acntLukupval20.click();
	return null;
}

public boolean bRTypeRetailFieldAccValue(WebDriver Driver) throws InterruptedException {

	accLkUpVal.click();
	Thread.sleep(2000);
	acntLukupval20.click();

	if (accLkUpVal.getText().isEmpty()) {
		return false;
	} else {
		return true;
	}
}
public String brSaveBtnn(WebDriver Driver) {

	brSaveBtn.click();
	return null;
}
public boolean bRTypeRetailFieldLeadCIC() throws BiffException, IOException {
	LCIC = leadCICc.findElement(By.className("form-control"));
	LCIC.click();
	String file = new File(System.getProperty("user.dir"),"TestData.xls").getAbsolutePath();
//	 FileInputStream fi = new
//			 FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");
	
	FileInputStream fi = new FileInputStream(file);
			 
			 Workbook w = Workbook.getWorkbook(fi);
				 Sheet s = w.getSheet(1);
				 String s1 = null;
				 try {
				 for (int i = 2; i < s.getRows(); i++) {
				 // Read data from excel sheet
				 s1 = s.getCell(4, i).getContents();
				
				 Thread.sleep(3000);
				 
				 LCIC.sendKeys(s1);
									 }
				 } catch (Exception e) {
				 System.out.println(e);
				 }
	
	if (LCIC.getAttribute("value").equals(s1)) {
		return true;
	} else {
		return false;
	}
}

}
