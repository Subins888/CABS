package com.albertsons.pageobjects;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;


import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;

import com.albertsons.pageobjects.GenericFactoryJSprint3;

/**
 * 
 * @author U82703
 *
 */
public class pageObjectsJSprint3 extends ExtendBaseClass {

	WebDriver Driver;
	GenericFactory pageFact;
	GenericFactoryJSprint3 pageFactS3;
	PageObjects PO = new PageObjects(Driver);
	Properties prop;

	String extentReportImage353PO_01, extentReportImage353PO_02, extentReportImage353PO_03, extentReportImage353PO_04,extentReportImage353PO_05
	,extentReportImage353PO_06,extentReportImage353PO_07,extentReportImage353PO_08,extentReportImage353PO_09,extentReportImage353PO_10,extentReportImage353PO_11,
	extentReportImage353PO_12,extentReportImage353PO_13,extentReportImage353PO_14,extentReportImage353PO_15,extentReportImage353PO_16,extentReportImage353PO_17,
	extentReportImage353PO_18,extentReportImage353PO_19,extentReportImage353PO_20,extentReportImage353PO_21,extentReportImage353PO_22,extentReportImage353PO_23,
	extentReportImage353PO_24,extentReportImage353PO_25,extentReportImage353PO_26,extentReportImage353PO_27;

	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;

	public pageObjectsJSprint3(WebDriver Driver) {
		this.Driver = Driver;
		
	}

	public String wait_forBRPage(WebDriver Driver) {

		
		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions.visibilityOf(pageFactS3.newBR));
		
		return null;

	}

	public String allwInfoSect(WebDriver Driver)
			throws InterruptedException, AWTException, ParseException, IOException {

		if (pageFactS3.allwTab(Driver).contentEquals("ALLOWANCE INFORMATION")) {
			
			System.out.println("Allowance BR has Allowance information section");
			extentTest.log(LogStatus.INFO, "Allowance BR has Allowance information section");
		} else {
			System.out.println("Allowance BR doesn't have Allowance information section");
			extentReportImage353PO_01 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_01.png";
			File source =aftermthd(Driver);
			File destination = new File(extentReportImage353PO_01);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance BR doesn't have Allowance information section"
					+ extentTest.addScreenCapture(extentReportImage353PO_01));
		}
		return null;
	}

	public String allwInfoSectFields(WebDriver Driver) throws IOException {

		if (pageFactS3.allwTabOffNo(Driver).contentEquals("Offer Number")) {

			System.out.println("Allowance information section has Offer Number");
			extentTest.log(LogStatus.INFO, "Allowance information section has Offer Number");
		} else {
			System.out.println("Allowance information section doesn't have Offer Number");
			extentReportImage353PO_02 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_02.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_02);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Offer Number"
					+ extentTest.addScreenCapture(extentReportImage353PO_02));
		}

		if (pageFactS3.allwTabSect(Driver).contentEquals("Section")) {

			System.out.println("Allowance information section has Section");
			extentTest.log(LogStatus.INFO, "Allowance information section has Section");
		} else {
			System.out.println("Allowance information section doesn't have Section");
			extentReportImage353PO_03 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_03.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_03);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Section"
					+ extentTest.addScreenCapture(extentReportImage353PO_03));
		}
		
		if (pageFactS3.allwTabBillDtFrm(Driver).contentEquals("Bill Date From")) {

			System.out.println("Allowance information section has Bill Date from");
			extentTest.log(LogStatus.INFO, "Allowance information section has Bill Date from");
		} else {
			System.out.println("Allowance information section doesn't have Bill Date from");
			extentReportImage353PO_04 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_04.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_04);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Bill Date from"
					+ extentTest.addScreenCapture(extentReportImage353PO_04));
		}
		

		if (pageFactS3.allwTabBillDtTo(Driver).contentEquals("Bill Date To")) {

			System.out.println("Allowance information section has Bill Date to");
			extentTest.log(LogStatus.INFO, "Allowance information section has Bill Date to");
		} else {
			System.out.println("Allowance information section doesn't have Bill Date to");
			extentReportImage353PO_05 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_05.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_05);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Bill Date to"
					+ extentTest.addScreenCapture(extentReportImage353PO_05));
		}
		
		if (pageFactS3.allwTabPerfDtFrm(Driver).contentEquals("Perf Date From")) {

			System.out.println("Allowance information section has Perf Date from");
			extentTest.log(LogStatus.INFO, "Allowance information section has Perf Date from");
		} else {
			System.out.println("Allowance information section doesn't have Perf Date from");
			extentReportImage353PO_06 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_06.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_06);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Perf Date from"
					+ extentTest.addScreenCapture(extentReportImage353PO_06));
		}
		
		if (pageFactS3.allwTabPerfDtTo(Driver).contentEquals("Perf Date To")) {

			System.out.println("Allowance information section has Perf Date to");
			extentTest.log(LogStatus.INFO, "Allowance information section has Perf Date to");
		} else {
			System.out.println("Allowance information section doesn't have Perf Date to");
			extentReportImage353PO_07 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_07.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_07);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Perf Date to"
					+ extentTest.addScreenCapture(extentReportImage353PO_07));
		}
		
		if (pageFactS3.allwTabHdr(Driver).contentEquals("HEADER")) {

			System.out.println("Allowance information section has HEADER");
			extentTest.log(LogStatus.INFO, "Allowance information section has HEADER");
		} else {
			System.out.println("Allowance information section doesn't have HEADER");
			extentReportImage353PO_08 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_08.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_08);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have HEADER"
					+ extentTest.addScreenCapture(extentReportImage353PO_08));
		}
		
		if (pageFactS3.allwTabFltAmt(Driver).contains("Flat Amount")) {

			System.out.println("Allowance information section has Flat Amount");
			extentTest.log(LogStatus.INFO, "Allowance information section has Flat Amount");
		} else {
			System.out.println("Allowance information section doesn't have Flat Amount");
			extentReportImage353PO_09 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_09.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_09);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Flat Amount"
					+ extentTest.addScreenCapture(extentReportImage353PO_09));
		}
		
		if (pageFactS3.allwTabFltcode(Driver).contentEquals("Flat Code")) {

			System.out.println("Allowance information section has Flat Code");
			extentTest.log(LogStatus.INFO, "Allowance information section has Flat Code");
		} else {
			System.out.println("Allowance information section doesn't have Flat Code");
			extentReportImage353PO_10 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_10.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_10);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Flat Code"
					+ extentTest.addScreenCapture(extentReportImage353PO_10));
		}
		
		if (pageFactS3.allwTabItemized(Driver).contentEquals("ITEMIZED")) {

			System.out.println("Allowance information section has ITEMIZED");
			extentTest.log(LogStatus.INFO, "Allowance information section has ITEMIZED");
		} else {
			System.out.println("Allowance information section doesn't have ITEMIZED");
			extentReportImage353PO_11 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_11.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_11);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have ITEMIZED"
					+ extentTest.addScreenCapture(extentReportImage353PO_11));
		}
		
		if (pageFactS3.allwTabAlwTyp(Driver).contentEquals("Allowance Type")) {

			System.out.println("Allowance information section has Allowance type");
			extentTest.log(LogStatus.INFO, "Allowance information section has Allowance type");
		} else {
			System.out.println("Allowance information section doesn't have Allowance type");
			extentReportImage353PO_12 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_12.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_12);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Allowance type"
					+ extentTest.addScreenCapture(extentReportImage353PO_12));
		}
		
		if (pageFactS3.allwTabPerf1(Driver).contentEquals("Performance 1")) {

			System.out.println("Allowance information section has Performance 1");
			extentTest.log(LogStatus.INFO, "Allowance information section has Performance 1");
		} else {
			System.out.println("Allowance information section doesn't have Performance 1");
			extentReportImage353PO_13 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_13.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_13);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Performance 1"
					+ extentTest.addScreenCapture(extentReportImage353PO_13));
		}
		
		if (pageFactS3.allwTabPerf2(Driver).contentEquals("Performance 2")) {

			System.out.println("Allowance information section has Performance 2");
			extentTest.log(LogStatus.INFO, "Allowance information section has Performance 2");
		} else {
			System.out.println("Allowance information section doesn't have Performance 2");
			extentReportImage353PO_14 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_14.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_14);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Performance 2"
					+ extentTest.addScreenCapture(extentReportImage353PO_14));
		}
		
		if (pageFactS3.allwTabOverlaps(Driver).contentEquals("Overlaps")) {

			System.out.println("Allowance information section has Overlaps");
			extentTest.log(LogStatus.INFO, "Allowance information section has Overlaps");
		} else {
			System.out.println("Allowance information section doesn't have Overlaps");
			extentReportImage353PO_15 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_15.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_15);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance information section doesn't have Overlaps"
					+ extentTest.addScreenCapture(extentReportImage353PO_15));
		}
		
		if (pageFactS3.allwTabOfferVal(Driver)==true) {

			System.out.println("Offer number field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Offer number field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Offer number field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_16 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_16.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_16);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Offer number field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_16));
		}
		
		if (pageFactS3.allwTabBillDtFrmVal(Driver)==true) {

			System.out.println("Bill Date From field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Bill Date From field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Bill Date From field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_17 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_17.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_17);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Bill Date From field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_17));
		}
		
		if (pageFactS3.allwTabBillDtToVal(Driver)==true) {

			System.out.println("Bill Date To field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Bill Date To field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Bill Date To field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_18 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_18.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_18);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Bill Date To field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_18));
		}
		
		if (pageFactS3.allwTabPerDtFrmVal(Driver)==true) {

			System.out.println("Perf Date From field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Perf Date From field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Perf Date From field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_19 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_19.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_19);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Perf Date From field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_19));
		}
		
		if (pageFactS3.allwTabPerDtToVal(Driver)==true) {

			System.out.println("Perf Date To field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Perf Date To field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Perf Date To field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_20 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_20.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_20);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Perf Date To field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_20));
		}
		
		if (pageFactS3.allwTabFlatAmtVal(Driver)==true) {

			System.out.println("Flat Amount field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Flat Amount field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Flat Amount field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_21 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_21.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_21);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Flat Amount field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_21));
		}
		
		if (pageFactS3.allwTabFlatCodeVal(Driver)==true) {

			System.out.println("Flat Code field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Flat Code field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Flat Code field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_22 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_22.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_22);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Flat Code field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_22));
		}
		
		if (pageFactS3.allwTabAlwTypVal(Driver)==true) {

			System.out.println("Allowance Type field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Allowance Type field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Allowance Type field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_23 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_23.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_23);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Allowance Type field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_23));
		}
		
		if (pageFactS3.allwTabPerf1Val(Driver)==true) {

			System.out.println("Performance1 field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Performance1 field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Performance1 field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_24 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_24.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_24);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Performance1 field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_24));
		}
		
		if (pageFactS3.allwTabPerf2Val(Driver)==true) {

			System.out.println("Performance2 field in Allowance information section have same data as it is given in BR modal pop up");
			extentTest.log(LogStatus.INFO, "Performance2 field in Allowance information section have same data as it is given in BR modal pop up");
		} else {
			System.out.println("Performance2 field in Allowance information section doesn't have same data as it is given in BR modal pop up");
			extentReportImage353PO_25 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_25.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_25);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Performance2 field in Allowance information section doesn't have same data as it is given in BR modal pop up"
					+ extentTest.addScreenCapture(extentReportImage353PO_25));
		}
		return null;
	}

	public Boolean NoHeadItem(WebDriver Driver) throws IOException, InterruptedException {
		Thread.sleep(2500);
		if(pageFactS3.NoHeadItemSub(Driver)==true) {
			System.out.println("User is getting error message either one is required Header/Itemized in Allowance information section");
			extentTest.log(LogStatus.INFO, "User is getting error message either one is required Header/Itemized in Allowance information section");
		} else {
			System.out.println("User is not getting error message either one is required Header/Itemized in Allowance information section");
			extentReportImage353PO_26 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_26.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_26);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "User is not getting error message either one is required Header/Itemized in Allowance information section"
					+ extentTest.addScreenCapture(extentReportImage353PO_26));
		}
		
		return null;
	}
	
	public Boolean FltAmtCode(WebDriver Driver) throws IOException, InterruptedException {
		Thread.sleep(5000);
		if(pageFactS3.FlatAmtNoCode(Driver)==true) {
			System.out.println("User is getting error message if Flat Code is not entered when Flat Amount is > 0 ");
			extentTest.log(LogStatus.INFO, "User is getting error message if Flat Code is not entered when Flat Amount is > 0");
		} else {
			System.out.println("User is not getting error message if Flat Code is not entered when Flat Amount is > 0");
			extentReportImage353PO_27 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_27.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_27);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "User is not getting error message if Flat Code is not entered when Flat Amount is > 0"
					+ extentTest.addScreenCapture(extentReportImage353PO_27));
		}
		
		return null;
	}
	
	public Boolean AlwPerf1(WebDriver Driver) throws IOException, InterruptedException {
		Thread.sleep(5000);
		if(pageFactS3.AlwNoPerf1(Driver)==true) {
			System.out.println("User is getting error message if Performance Code 1 is not entered when Allowance Type is given ");
			extentTest.log(LogStatus.INFO, "User is getting error message if Performance Code 1 is not entered when Allowance Type is given");
		} else {
			System.out.println("User is not getting error message if Performance Code 1 is not entered when Allowance Type is given");
			extentReportImage353PO_27 = System.getProperty("user.dir") + "\\picture"
					+ "\\extentReportImage353PO_27.png";
			File source = aftermthd(Driver);
			File destination = new File(extentReportImage353PO_27);
			FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "User is not getting error message if Performance Code 1 is not entered when Allowance Type is given"
					+ extentTest.addScreenCapture(extentReportImage353PO_27));
		}
		
		return null;
	}
	
	public File aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		File source = ts.getScreenshotAs(OutputType.FILE);

		return source;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) throws InterruptedException {

		pageFactS3 = new GenericFactoryJSprint3(Driver);

	}

}
