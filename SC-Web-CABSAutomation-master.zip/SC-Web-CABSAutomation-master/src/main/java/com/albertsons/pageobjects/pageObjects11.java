package com.albertsons.pageobjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


import jxl.read.biff.BiffException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class pageObjects11 extends ExtendBaseClass {

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	GenericFactoryIV pageFactIV;
	GenericFactoryVI pageFactVI;
	GenericFactoryVII pageFactVII;
	GenericFactoryVIII pageFactVIII;
	GenericFactoryV pageFactV;
	GenericFactorySprint3 pageFactAS3;
	GenericFactoryJSprint3 pageFactJS3;
	GenericFactoryIX pageFactIX;
	GenericFactoryX pageFactX;
	GenericFactory11 pageFact11;
	PageObjectsVIII POVIII;

	public WebElement LCIC;
	static String billingId;

	public pageObjects11(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforBlngbtn(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactV.createBillrcrd));
		return null;
	}

	public String waitforbrtxt(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String waitforSearchItem(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVIII.searchFirstItem));
		return null;
	}

	public String waitforAlwncType(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 90);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVI.cogsType));
		return null;
	}

	public String waitforSuccessMsgBr(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFactVIII.succesMsg));
		return null;
	}

	public String dialog(WebDriver Driver) throws InterruptedException, IOException {

		pageFact11.addDialog.click();
		Thread.sleep(1500);
		extentTest.log(LogStatus.INFO, "Clicked on Add Dialog button");

		String activ = pageFact11.active.getText();
		String resolvd = pageFact11.resolved.getText();
		String realted = pageFact11.related.getText();
		String all = pageFact11.all.getText();

		if (pageFact11.subject.isDisplayed()) {

			System.out.println("Add Dialog button click expands the Dialog Trial section");
			extentTest.log(LogStatus.INFO, "Add Dialog button click expands the Dialog Trial section");

		} else {

			String source = aftermthd(Driver);
			System.out.println("The Dialog Trial section NOT expanded");
			extentTest.log(LogStatus.FAIL, "The Dialog Trial section NOT expanded"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		if (pageFact11.active.isDisplayed() && pageFact11.active.isDisplayed() && pageFact11.active.isDisplayed()
				&& pageFact11.active.isDisplayed()) {

			System.out.println("The first TAB displaying is : " + activ);
			extentTest.log(LogStatus.INFO, "The first TAB displaying is : " + activ);

			System.out.println("The second TAB displaying is : " + resolvd);
			extentTest.log(LogStatus.INFO, "The second TAB displaying is : " + resolvd);

			System.out.println("The third TAB displaying is : " + realted);
			extentTest.log(LogStatus.INFO, "The third TAB displaying is : " + realted);

			System.out.println("The fourth TAB displaying is : " + all);
			extentTest.log(LogStatus.INFO, "The fourth TAB displaying is : " + all);

		} else {

			String source = aftermthd(Driver);
			System.out.println("No tabs are displaying");
			extentTest.log(LogStatus.FAIL,
					"No tabs are displaying" + extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		Thread.sleep(2500);
		scroldownII(Driver);
		Thread.sleep(2500);

		pageFact11.subjectDrpMisc.click();
		Thread.sleep(2500);
		pageFact11.subjectVal.click();
		System.out.println("Selected Miscellaneous Issue");
		extentTest.log(LogStatus.INFO, "Selected Miscellaneous Issue");

		pageFact11.statusDrp.click();
		Thread.sleep(2500);
		pageFact11.StatusList.click();
		System.out.println("Selected Active Status");
		extentTest.log(LogStatus.INFO, "Selected Active Status");

		pageFact11.assignToDrpMisc.click();
		Thread.sleep(2500);
		pageFact11.assindUsers.click();
		System.out.println("Selected Assigned to User");
		extentTest.log(LogStatus.INFO, "Selected Assigned to User");

		pageFact11.reasonTxt.sendKeys("Test Automation");

		pageFact11.commentSave.click();
		System.out.println("Clicked on Save button");
		extentTest.log(LogStatus.INFO, "Clicked on Save button");

		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(55000);

		pageFact11.commentXpand.click();
		Thread.sleep(2500);

		if (pageFact11.addComment.isDisplayed()) {

			System.out.println("Add comment button displaying on clicking the '+' button");
			extentTest.log(LogStatus.INFO, "Add comment button displaying on clicking the '+' button");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Add comment button NOT displaying on clicking the '+' button");
			extentTest.log(LogStatus.FAIL, "Add comment button NOT displaying on clicking the '+' button"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		pageFact11.addComment.click();

		if (pageFact11.commentLabel.isDisplayed()) {

			System.out.println("Comment box opened on clicking Add Comment button");
			extentTest.log(LogStatus.INFO, "Comment box opened on clicking Add Comment button");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Comment box NOT opened on clicking Add Comment button");
			extentTest.log(LogStatus.FAIL, "Comment box NOT opened on clicking Add Comment button"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		pageFact11.commentText.sendKeys("Test Automation Comment");
		extentTest.log(LogStatus.INFO, "Entered Comment");

		pageFact11.commentSave.click();
		extentTest.log(LogStatus.INFO, "Clicked on Save button after giving Comment");

		return null;
	}

	public String dialogModify(WebDriver Driver) throws InterruptedException, IOException {

		String resolvd = pageFact11.resolved.getText();
		System.out.println("Dialog is" + resolvd);

		// -- Edit (Modify Dialog)
		Thread.sleep(55000);

		pageFact11.statusDrp.click();
		pageFact11.statusVal2.click();
		pageFact11.commentSave.click();

		Thread.sleep(55000);
		System.out.println("Dialog is" + resolvd);
		if (resolvd.contains("1")) {

			System.out.println("Dialog successfully modified");
			extentTest.log(LogStatus.INFO, "Dialog successfully modified");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Error in modifying dialog");
			extentTest.log(LogStatus.FAIL,
					"Error in modifying dialog" + extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;
	}

	public String dialogMisc(WebDriver Driver) throws InterruptedException, IOException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact11.addDialog.click();
		Thread.sleep(1500);
		extentTest.log(LogStatus.INFO, "Clicked on Add Dialog button");

		String activ = pageFact11.active.getText();
		String resolvd = pageFact11.resolved.getText();
		String all = pageFact11.all.getText();

		if (pageFact11.subject.isDisplayed()) {

			System.out.println("Add Dialog button click expands the Dialog Trial section");
			extentTest.log(LogStatus.INFO, "Add Dialog button click expands the Dialog Trial section");

		} else {

			String source = aftermthd(Driver);
			System.out.println("The Dialog Trial section NOT expanded");
			extentTest.log(LogStatus.FAIL, "The Dialog Trial section NOT expanded"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		if (pageFact11.active.isDisplayed() && pageFact11.active.isDisplayed() && pageFact11.active.isDisplayed()
				&& pageFact11.active.isDisplayed()) {

			System.out.println("The first TAB displaying is : " + activ);
			extentTest.log(LogStatus.INFO, "The first TAB displaying is : " + activ);

			System.out.println("The second TAB displaying is : " + resolvd);
			extentTest.log(LogStatus.INFO, "The second TAB displaying is : " + resolvd);

			System.out.println("The fourth TAB displaying is : " + all);
			extentTest.log(LogStatus.INFO, "The fourth TAB displaying is : " + all);

		} else {

			String source = aftermthd(Driver);
			System.out.println("No tabs are displaying");
			extentTest.log(LogStatus.FAIL,
					"No tabs are displaying" + extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		// ---------

		Thread.sleep(2500);
		scroldownII(Driver);
		Thread.sleep(2500);

		pageFact11.subjectDrpMisc.click();
		Thread.sleep(2500);
		pageFact11.subjectVal.click();
		System.out.println("Selected Miscellaneous Issue");
		extentTest.log(LogStatus.INFO, "Selected Miscellaneous Issue");

		pageFact11.statusDrp.click();
		Thread.sleep(2500);
		pageFact11.StatusList.click();
		System.out.println("Selected Active Status");
		extentTest.log(LogStatus.INFO, "Selected Active Status");

		pageFact11.assignToDrpMisc.click();
		Thread.sleep(2500);
		pageFact11.assindUsers.click();
		System.out.println("Selected Assigned to User");
		extentTest.log(LogStatus.INFO, "Selected Assigned to User");

		pageFact11.reasonTxt.sendKeys("Test Automation");

		pageFact11.commentSave.click();
		System.out.println("Clicked on Save button");
		extentTest.log(LogStatus.INFO, "Clicked on Save button");

		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(63000);

		pageFact11.commentXpand.click();
		Thread.sleep(2500);

		if (pageFact11.addComment.isDisplayed()) {

			System.out.println("Add comment button displaying on clicking the '+' button");
			extentTest.log(LogStatus.INFO, "Add comment button displaying on clicking the '+' button");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Add comment button NOT displaying on clicking the '+' button");
			extentTest.log(LogStatus.FAIL, "Add comment button NOT displaying on clicking the '+' button"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		pageFact11.addComment.click();

		if (pageFact11.commentLabel.isDisplayed()) {

			System.out.println("Comment box opened on clicking Add Comment button");
			extentTest.log(LogStatus.INFO, "Comment box opened on clicking Add Comment button");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Comment box NOT opened on clicking Add Comment button");
			extentTest.log(LogStatus.FAIL, "Comment box NOT opened on clicking Add Comment button"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));
		}

		pageFact11.commentText.sendKeys("Test Automation Comment");
		extentTest.log(LogStatus.INFO, "Entered Comment");

		pageFact11.commentSave.click();
		extentTest.log(LogStatus.INFO, "Clicked on Save button after giving Comment");

		return null;
	}

	public String warningYesClk(WebDriver Driver) {
		pageFact11.warningYes.click();

		return null;
	}

	public String DialogDrpValue(WebDriver Driver) throws InterruptedException {

		// pageFact.waitForSpinnerToBeGone();
		Thread.sleep(55000);

		pageFact11.subjectDrp.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues = pageFact11.subjectDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues = new ArrayList<String>();
		for (WebElement value : dropDownvalues) {

			listValues.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues);

		extentTest.log(LogStatus.INFO, "Subjects dropdown values obtained from UI are:  " + listValues);

		// --------------
		pageFact11.statusDrp.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues2 = pageFact11.statusDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues2 = new ArrayList<String>();
		for (WebElement value : dropDownvalues2) {

			listValues2.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues2);

		extentTest.log(LogStatus.INFO, "Status dropdown values obtained from UI are:  " + listValues2);

		// --------------
		pageFact11.assignToDrp.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues3 = pageFact11.assignToDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues3 = new ArrayList<String>();
		for (WebElement value : dropDownvalues3) {

			listValues3.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues3);

		extentTest.log(LogStatus.INFO, "Assigned To dropdown values obtained from UI are:  " + listValues3);
		// --------------
		Thread.sleep(2500);
		pageFact11.notifyDrp.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues4 = pageFact11.notifyDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues4 = new ArrayList<String>();
		for (WebElement value : dropDownvalues4) {

			listValues4.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues4);

		extentTest.log(LogStatus.INFO, "Notify dropdown values obtained from UI are:  " + listValues4);

		return null;
	}

	public String DialogDrpValueMisc(WebDriver Driver) throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact11.subjectDrpMisc.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues = pageFact11.subjectDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues = new ArrayList<String>();
		for (WebElement value : dropDownvalues) {

			listValues.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues);

		extentTest.log(LogStatus.INFO, "Subjects dropdown values obtained from UI are:  " + listValues);

		// --------------
		pageFact11.statusDrp.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues2 = pageFact11.statusDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues2 = new ArrayList<String>();
		for (WebElement value : dropDownvalues2) {

			listValues2.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues2);

		extentTest.log(LogStatus.INFO, "Status dropdown values obtained from UI are:  " + listValues2);

		// --------------
		pageFact11.assignToDrpMisc.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues3 = pageFact11.assignToDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues3 = new ArrayList<String>();
		for (WebElement value : dropDownvalues3) {

			listValues3.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues3);

		extentTest.log(LogStatus.INFO, "Assigned To dropdown values obtained from UI are:  " + listValues3);
		// --------------
		Thread.sleep(2500);
		pageFact11.notifyDrp.click();
		Thread.sleep(2500);

		List<WebElement> dropDownvalues4 = pageFact11.notifyDrp2.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValues4 = new ArrayList<String>();
		for (WebElement value : dropDownvalues4) {

			listValues4.add(value.getText());

		}

		System.out.println("Values obtained from UI are " + listValues4);

		extentTest.log(LogStatus.INFO, "Notify dropdown values obtained from UI are:  " + listValues4);

		return null;
	}

	public String readyBtnClk(WebDriver Driver) {

		pageFactVIII.readyClk(Driver);
		System.out.println("Clicked on Ready Button");
		extentTest.log(LogStatus.INFO, "Clicked on Ready Button");
		return null;
	}

	public String scroldown(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);

		act.moveToElement(pageFactAS3.addIncmeBtn).perform();

		return null;
	}

	public String scroldownII(WebDriver Driver) {

		// pageFactJS3.allwTab(Driver);

		Actions act = new Actions(Driver);

		act.moveToElement(pageFact11.commentSave).perform();

		return null;
	}

	public String scroldownIII(WebDriver Driver) {

		Actions act = new Actions(Driver);

		act.moveToElement(pageFact11.addDialog).perform();

		return null;
	}

	public String BRSave(WebDriver Driver) throws InterruptedException, IOException {

		waitforbrtxt(Driver);

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		pageFact11.elmntIntract(Driver);
		Thread.sleep(3000);
		pageFactAS3.txtAreaa(Driver);

		readyBtnClk(Driver);
		Thread.sleep(36000);

		if (pageFactVIII.succesMsg.getText().equals("Billing Record has been saved")) {

			System.out.println("Billing record successfully saved by giving valid AP number from Lawson");
			extentTest.log(LogStatus.INFO, "Billing record successfully saved by giving valid AP number from Lawson");

		} else {

			System.out.println("Billing record not successfully saved even after giving valid AP number from Lawson");
			extentTest.log(LogStatus.INFO,
					"Billing record not successfully saved even after giving valid AP number from Lawson");

		}

		return null;
	}

	public String invalidAPAR(WebDriver Driver) throws InterruptedException {

		pageFact11.elmntIntractInvalid(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(1500);
		waitforSuccessMsgBr(Driver);

		String msg = pageFactVIII.succesMsg.getText();

		if (pageFactVIII.succesMsg.getText().contains("GL system")) {

			System.out.println(
					"The given AP number not matching with the one from Lawson.  The error message showing is:  "
							+ msg);
			extentTest.log(LogStatus.INFO,
					"The given AP number not matching with the one from Lawson.  The error message showing is:  "
							+ msg);

		} else {

			System.out.println("'Lawson' related error message not showing even after giving invalid AP number");
			extentTest.log(LogStatus.FAIL,
					"'Lawson' related error message not showing even after giving invalid AP number");

		}

		return null;
	}

	public String AR(WebDriver Driver) throws InterruptedException {

		pageFact11.ARNum.click();
		pageFact11.elmntIntractAR(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFact11.brSave.click();
		Thread.sleep(36000);

		if (pageFactVIII.succesMsg.getText().equals("Billing Record has been saved")) {

			System.out.println("Billing record successfully saved by giving valid AR number from Lawson");
			extentTest.log(LogStatus.INFO, "Billing record successfully saved by giving valid AR number from Lawson");

		} else {

			System.out.println("Billing record not successfully saved even after giving valid AR number from Lawson");
			extentTest.log(LogStatus.INFO,
					"Billing record not successfully saved even after giving valid AR number from Lawson");

		}

		return null;
	}

	public String ARMisc(WebDriver Driver) throws InterruptedException {

		pageFact11.ARNum.click();
		pageFact11.elmntIntractAR(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFact11.brSaveMisc.click();
		Thread.sleep(36000);

		if (pageFactVIII.succesMsg.getText().equals("Billing Record has been saved")) {

			System.out.println("Billing record successfully saved by giving valid AR number from Lawson");
			extentTest.log(LogStatus.INFO, "Billing record successfully saved by giving valid AR number from Lawson");

		} else {

			System.out.println("Billing record not successfully saved even after giving valid AR number from Lawson");
			extentTest.log(LogStatus.INFO,
					"Billing record not successfully saved even after giving valid AR number from Lawson");

		}

		return null;
	}

	public String brSaveMisc(WebDriver Driver) throws InterruptedException,

			BiffException, IOException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact11.accountLookUpDrpMisc.click();
		Thread.sleep(1000);
		pageFact11.retailDiv.click();
		Thread.sleep(5000);

		pageFact11.accountLukUpValue.click();
		Thread.sleep(1000);
		pageFact11.accountLukUpValueVal.click();
		Thread.sleep(5000);

		pageFactV.elmntIntract(Driver);
		pageFactV.txtAreaa(Driver);
		Thread.sleep(7000);
		pageFactV.brSavebtnn(Driver);

		// pageFact.waitForSpinnerToBeGone();
		// pageFact.waitForSpinnerToBeGoneII();
		Thread.sleep(32000);

		if (pageFactVIII.succesMsg.getText().equals("Billing Record has been saved")) {

			System.out.println("Billing record successfully saved by giving valid AP number from Lawson");
			extentTest.log(LogStatus.INFO, "Billing record successfully saved by giving valid AP number from Lawson");

		} else {

			System.out.println("Billing record not successfully saved even after giving valid AP number from Lawson");
			extentTest.log(LogStatus.INFO,
					"Billing record not successfully saved even after giving valid AP number from Lawson");

		}

		return null;

	}

	public String searchFirstItemClk(WebDriver Driver) throws InterruptedException {

		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		return null;
	}

	public String incomeMsg(WebDriver Driver) throws InterruptedException {

		scroldown(Driver);
		Thread.sleep(4500);
		// pageFactV.incmeButtonAdd.click();
		System.out.println("Clicked on Add Income button");
		extentTest.log(LogStatus.INFO, "Clicked on Add Income button");
		// Thread.sleep(1500);
		// pageFactV.incmeButtonAdd.click();
		// System.out
		// .println("Clicked on Add Income button AGAIN");
		Thread.sleep(7000);
		scroldown(Driver);
		Thread.sleep(4500);

		pageFactVI.notesFlatAmntClear(Driver);
		Thread.sleep(1500);
		pageFact11.incomeSubmit.click();
		Thread.sleep(4500);

		pageFact11.warningYes.click();
		Thread.sleep(5500);

		// String popup = pageFact11.incomeMsgPopup.getText();

		try {
			if (pageFact11.incomeMsgPopup.getText()
					.contains("have already been billed in this billing record for one or more of these days")) {

				System.out.println("User is warned if trying to double bill for certain dates");

				extentTest.log(LogStatus.INFO, "User is warned if trying to double bill for certain dates");

			} else {
				System.out.println("User got a different warning message: ");

				extentTest.log(LogStatus.INFO, "User got a different warning message: ");
			}

			pageFact11.incomeMsgPopupNo.click();
			Thread.sleep(1500);
			warningYesClk(Driver);
			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(2500);

			pageFactVII.advSearch.click();
			Thread.sleep(1500);

			pageFactVII.searchBillId.findElement(By.className("form-control")).sendKeys("10005634");

			// pageFactVII.searchBillIdd(Driver);
			Thread.sleep(3000);
			pageFactVII.searchApplyy(Driver);
			waitforSearchItem(Driver);

			searchFirstItemClk(Driver);

			pageFactV.incmeButtonAdd.click();
			Thread.sleep(7000);

			pageFact11.notesFlatAmntClear(Driver);
			Thread.sleep(1500);
			pageFact11.incomeSubmit.click();
			Thread.sleep(4500);

			if (pageFact11.incomeMsgPopup.getText()
					.contains("of these CICs are not being billed for the expected amount")) {

				System.out.println("User is warned if trying to double bill for certain dates");

				extentTest.log(LogStatus.INFO, "User is warned if trying to double bill for certain dates");

			} else {

				String source = aftermthd(Driver);
				System.out.println("No warning message showing or error message showing is wrong");

				extentTest.log(LogStatus.FAIL, "No warning message showing or error message showing is wrong"
						+ extentTest.addScreenCapture("data:image/png;base64," + source));
			}

		} catch (Exception e) {

			System.out.println("Income submitted without showing any warning message");

			extentTest.log(LogStatus.INFO, "Income submitted without showing any warning message");
		}

		return null;
	}

	public String dialogAttachFields(WebDriver Driver) throws IOException, InterruptedException {

		pageFact11.attachmentClip.click();
		Thread.sleep(3000);

		pageFact11.incomeAttachmentsTitle.getText();

		if (pageFact11.incomeAttachmentsTitle.getText().contains("Income Attachments")
				&& pageFact11.FileNameTxt.getText().equals("File Name")
				&& pageFact11.FileTypeTxt.getText().equals("File Type")
				&& pageFact11.FileSizeTxt.getText().equals("File Size")
				&& pageFact11.dateTimeTxt.getText().contains("Date/Time")
				&& pageFact11.uploadbyTxt.getText().equals("Uploaded By")
				&& pageFact11.rejectTxt.getText().equals("Reject")
				&& pageFactVIII.addFileBtn.getText().equals("Add File")
				&& pageFactVIII.doneBtn.getText().equals("Done")) {

			System.out.println("Text layout of attachment pop up contains valid texts/messages");
			extentTest.log(LogStatus.INFO, "Text layout of attachment pop up contains valid texts/messages");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Text message displaying is wrong");
			extentTest.log(LogStatus.FAIL, "Text message displaying is wrong"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;
	}

	public String dialogAttachFieldsMisc(WebDriver Driver) throws IOException, InterruptedException {

		pageFact11.attachmentClipMisc.click();
		Thread.sleep(3000);

		pageFact11.incomeAttachmentsTitle.getText();

		if (pageFact11.incomeAttachmentsTitle.getText().contains("Income Attachments")
				&& pageFact11.FileNameTxt.getText().equals("File Name")
				&& pageFact11.FileTypeTxt.getText().equals("File Type")
				&& pageFact11.FileSizeTxt.getText().equals("File Size")
				&& pageFact11.dateTimeTxt.getText().contains("Date/Time")
				&& pageFact11.uploadbyTxt.getText().equals("Uploaded By")
				&& pageFact11.rejectTxt.getText().equals("Reject")
				&& pageFactVIII.addFileBtn.getText().equals("Add File")
				&& pageFactVIII.doneBtn.getText().equals("Done")) {

			System.out.println("Text layout of attachment pop up contains valid texts/messages");
			extentTest.log(LogStatus.INFO, "Text layout of attachment pop up contains valid texts/messages");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Text message displaying is wrong");
			extentTest.log(LogStatus.FAIL, "Text message displaying is wrong"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;
	}

	public String reject(WebDriver Driver) throws IOException, InterruptedException {

		if (pageFact11.rejectCheckBox.isDisplayed()) {

			System.out.println("Reject checkbox displaying properly in the UI");
			extentTest.log(LogStatus.INFO, "Reject checkbox displaying properly in the UI");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Reject checkbox not displaying in the Attachment pop up");
			extentTest.log(LogStatus.FAIL, "Reject checkbox not displaying in the Attachment pop up"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		pageFact11.rejectCheckBox.click();

		System.out.println("Clicked on Reject check box");
		extentTest.log(LogStatus.INFO, "Clicked on Reject check box");

		Thread.sleep(1500);

		if (pageFact11.rejectTextArea.isDisplayed()) {

			System.out.println("Reason for Reject text area displayed");
			extentTest.log(LogStatus.INFO, "Reason for Reject text area displayed");
		} else {

			String source = aftermthd(Driver);
			System.out.println("Reason for Reject text area NOT displayed");
			extentTest.log(LogStatus.FAIL, "Reason for Reject text area NOT displayed"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		pageFact11.reasonCancelBtn.click();
		System.out.println("Clicked on Reject Reason cancel button");
		extentTest.log(LogStatus.INFO, "Clicked on Reject Reason cancel button");
		Thread.sleep(1500);

		if (pageFact11.rejectCheckBox.isDisplayed()) {

			System.out.println("Cancel button click from the Reject Reason section working properly");
			extentTest.log(LogStatus.INFO, "Cancel button click from the Reject Reason section working properly");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Cancel button click from the Reject Reason section NOT working properly");
			extentTest.log(LogStatus.FAIL, "Cancel button click from the Reject Reason section NOT working properly"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		pageFact11.rejectCheckBox.click();

		System.out.println("Clicked on Reject check box");
		extentTest.log(LogStatus.INFO, "Clicked on Reject check box");

		Thread.sleep(1500);

		// pageFact11.reasonClose.sendKeys(Keys.TAB,"Test Automation");
		// pageFact11.rejectReasonTitle.sendKeys(Keys.TAB,Keys.TAB,"Test Automation");
		// pageFact11.rejectTextArea.sendKeys("Test Automation");

		Actions action = new Actions(Driver);

		action.sendKeys(Keys.TAB).sendKeys("Test Automation").perform();
		Thread.sleep(3000);

		System.out.println("Entered 'Reason' for Rejection");
		extentTest.log(LogStatus.INFO, "Entered 'Reason' for Rejection");

		pageFact11.reasonOKBtn.click();

		System.out.println("Clicked on OK button from the Reject Reason section");
		extentTest.log(LogStatus.INFO, "Clicked on OK button from the Reject Reason section");

		Thread.sleep(1500);

		if (pageFact11.rejectIndication.isDisplayed()) {

			System.out.println("Successfully rejected");
			extentTest.log(LogStatus.INFO, "Successfully rejected");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Reject not working");
			extentTest.log(LogStatus.FAIL,
					"Reject not working" + extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		pageFact11.reasonClose.click();

		System.out.println("Clicked on 'X' button from attachments pop up");
		extentTest.log(LogStatus.INFO, "Clicked on 'X' button from attachments pop up");

		return null;
	}

	public String dialogAttach(WebDriver Driver) throws IOException, InterruptedException, AWTException {

		Robot robot2 = new Robot();

		if (pageFact11.attachmentClip.isDisplayed()) {

			System.out.println("Attachment clip icon displaying properly in the UI");
			extentTest.log(LogStatus.INFO, "Attachment clip icon displaying properly in the UI");

		} else {
			String source = aftermthd(Driver);
			System.out.println("Attachment clip icon NOT displaying in the UI");

			extentTest.log(LogStatus.FAIL, "Attachment clip icon NOT displaying in the UI"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		pageFact.waitForSpinnerToBeGone();
		pageFact11.attachmentClip.click();
		System.out.println("Clicked on attachment clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on attachment clip icon");
		Thread.sleep(2500);

		pageFact11.waitforAddFile(Driver);

		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\" + "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(3000);

		String attachCount = pageFact11.attachCount.getText();
		if (pageFact11.attachCount.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Attachment Count displaying is : " + attachCount);

		} else {
			String source = aftermthd(Driver);
			System.out.println("Error in displaying the count");

			extentTest.log(LogStatus.FAIL, "Error in search result"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;
	}

	public String dialogAttachMisc(WebDriver Driver) throws InterruptedException, AWTException, IOException {

		Robot robot2 = new Robot();

		pageFact11.addDialog.click();
		Thread.sleep(1500);
		extentTest.log(LogStatus.INFO, "Clicked on Add Dialog button");

		if (pageFact11.attachmentClipMisc.isDisplayed()) {

			System.out.println("Attachment clip icon displaying properly in the UI");
			extentTest.log(LogStatus.INFO, "Attachment clip icon displaying properly in the UI");

		} else {
			String source = aftermthd(Driver);
			System.out.println("Attachment clip icon NOT displaying in the UI");

			extentTest.log(LogStatus.FAIL, "Attachment clip icon NOT displaying in the UI"
					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		pageFact.waitForSpinnerToBeGone();
		pageFact11.attachmentClipMisc.click();
		System.out.println("Clicked on attachment clip icon");
		extentTest.log(LogStatus.INFO, "Clicked on attachment clip icon");
		Thread.sleep(2500);

		pageFact11.waitforAddFile(Driver);

		robot2.keyPress(KeyEvent.VK_ESCAPE);
		pageFactVIII.addFileBtnn(Driver);

		System.out.println("Clicked on Add File button");
		extentTest.log(LogStatus.INFO, "Clicked on Add File button");

		try {
			Thread.sleep(3000);
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		String fileLocation = System.getProperty("user.dir") + "\\TestData\\" + "txt.txt";

		StringSelection filepath = new StringSelection(fileLocation);

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filepath, null);

		try {

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		Thread.sleep(7000);
		pageFactVIII.doneBtnn(Driver);
		System.out.println("Clicked on Done button");
		extentTest.log(LogStatus.INFO, "Clicked on Done button");
		Thread.sleep(3000);

		String attachCount = pageFact11.attachCountMisc.getText();
		if (pageFact11.attachCountMisc.isDisplayed()) {
			System.out.println("Count displaying is : " + attachCount);
			extentTest.log(LogStatus.INFO, "Attachment Count displaying is : " + attachCount);

		} else {
			String source = aftermthd(Driver);
			System.out.println("Error in displaying the count");

			extentTest.log(LogStatus.FAIL, "Error in search result"

					+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		return null;
	}

	public String dates(WebDriver Driver) throws InterruptedException, IOException {

		waitforbrtxt(Driver);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		String dateVal = pageFact11.dateTxtFrm.getAttribute("value");
		System.out.println("Date value is dateVal : " + dateVal);
		// extentTest.log(LogStatus.INFO, "Bill Date From value is : " + dateVal);

		String dateVal2 = pageFact11.dateTxtTo.getAttribute("value");
		System.out.println("Date value is dateVal2: " + dateVal2);
		// extentTest.log(LogStatus.INFO, "Bill Date To value is : " + dateVal2);

		String dateVal3 = pageFact11.dateTxtFrm2.getAttribute("value");
		System.out.println("Date value is dateVal3 : " + dateVal3);

		String dateVal4 = pageFact11.dateTxtTo2.getAttribute("value");
		System.out.println("Date value is dateVal4: " + dateVal4);

		if (dateVal.equals(dateVal3)) {

			System.out.println(
					"Bill Date From date showing in Allowance information and Item details are same : " + dateVal);
			extentTest.log(LogStatus.INFO,
					"Bill Date From date showing in Allowance information and Item details are same : " + dateVal);

		} else {

			String source = aftermthd(Driver);
			System.out.println(
					"Bill Date From date showing in Allowance information and Item details are different: " + dateVal);

			extentTest.log(LogStatus.FAIL,
					"Bill Date From date showing in Allowance information and Item details are different: " + dateVal

							+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

		if (dateVal2.equals(dateVal4)) {

			System.out.println(
					"Bill Date To date showing in Allowance information and Item details are same : " + dateVal3);
			extentTest.log(LogStatus.INFO,
					"Bill Date To date showing in Allowance information and Item details are same : " + dateVal3);

		} else {

			String source = aftermthd(Driver);
			System.out.println(
					"Bill Date To date showing in Allowance information and Item details are different: " + dateVal3);

			extentTest.log(LogStatus.FAIL,
					"Bill Date To date showing in Allowance information and Item details are different: " + dateVal3

							+ extentTest.addScreenCapture("data:image/png;base64," + source));

		}

	 

		pageFact11.dateTxtFrm2.click();
		Thread.sleep(1500);

		try {

			if (pageFact11.disabledDate1.isSelected()) {

				System.out.println("Previous Bill From dates other than dates from Allowance info are enabled in Item details");
				extentTest.log(LogStatus.FAIL,
						"Previous Bill From dates other than dates from Allowance info are enabled in Item details");

			} else {
				System.out.println(
						"Previous Bill From dates other than dates from Allowance info are disabled in Item details");
				extentTest.log(LogStatus.INFO,
						"Previous Bill From dates other than dates from Allowance info are disabled in Item details");
			}
		} catch (Exception e) {
			System.out.println(
					"Previous Bill From dates other than dates from Allowance info are disabled in Item details");
			extentTest.log(LogStatus.INFO,
					"Previous Bill From dates other than dates from Allowance info are disabled in Item details");
		}

		pageFact11.dateTxtTo2.click();
		Thread.sleep(1500);

		try {
			if (pageFact11.disabledDate2.isSelected()) {

				System.out.println(
						"Previous Bill To dates other than dates from Allowance info are enabled in Item details");
				extentTest.log(LogStatus.FAIL,
						"Previous Bill To dates other than dates from Allowance info are enabled in Item details");

			} else {
				System.out.println(
						"Previous Bill To dates other than dates from Allowance info are disabled in Item details");
				extentTest.log(LogStatus.INFO,
						"Previous Bill To dates other than dates from Allowance info are disabled in Item details");
			}
		} catch (Exception e) {
			System.out.println(
					"Previous Bill To dates other than dates from Allowance info are disabled in Item details");
			extentTest.log(LogStatus.INFO,
					"Previous Bill To dates other than dates from Allowance info are disabled in Item details");

		}

		return null;
	}
	
	public String backButtonClick(WebDriver Driver)
			throws InterruptedException, IOException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactVII.searchh(Driver);
		System.out.println("Clicked on Search button from the left panel");
		extentTest.log(LogStatus.INFO,
				"Clicked on Search button from the left panel");

		Thread.sleep(2500);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact11.assignTo.sendKeys("Test");
		pageFact11.assignToVal.click();

		pageFact11.searchApply.click();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		waitforSearchItem(Driver);

		Thread.sleep(3000);
		pageFactVIII.searchFirstItemClk(Driver);

		waitforbrtxt(Driver);

		Driver.navigate().back();
		System.out.println("Clicked on Browser Back button");
		extentTest.log(LogStatus.INFO, "Clicked on Browser Back button");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		if (pageFact11.assignToSearchVal.getText().contains("Automation")) {
			System.out
					.println("Back button click retains the search filter and search result");
			extentTest
					.log(LogStatus.INFO,
							"Back button click retains the search filter and search result");

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Back button click not retains the search filter and search result");
			extentTest.log(
					LogStatus.FAIL,
					"Back button click not retains the search filter and search result"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFact11.paginationSearch.click();
		System.out.println("Clicked on pagination 2nd page");
		extentTest.log(LogStatus.INFO, "Clicked on pagination 2nd page");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		String firstItem = pageFactVIII.searchFirstItemm(Driver);
		System.out.println(firstItem);

		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);

		Driver.navigate().back();
		System.out.println("Clicked on Browser Back button");
		extentTest.log(LogStatus.INFO, "Clicked on Browser Back button");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		// if (pageFact11.paginationSearch.isSelected()) {
		if (firstItem.equals(firstItem)) {
			System.out.println("Back button click retains the pagination");
			extentTest.log(LogStatus.INFO,
					"Back button click retains the pagination");

		} else {

			String source = aftermthd(Driver);
			System.out.println("Back button click not retains the pagination");
			extentTest.log(
					LogStatus.FAIL,
					"Back button click not retains the pagination"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		pageFactVII.advSearch.click();
		Thread.sleep(1500);
		System.out.println("Clicked on Advanced Search button");
		extentTest.log(LogStatus.INFO, "Clicked on Advanced Search button");

		pageFact11.accountLookupSearch.sendKeys("COGS");
		pageFact11.accountLookupSearchVal.click();
		System.out.println("Selected Account Lookup Type COGS");
		extentTest.log(LogStatus.INFO, "Selected Account Lookup Type COGS");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(7500);

		pageFact11.searchApply.click();
		System.out.println("Clicked on Search Apply Button");
		extentTest.log(LogStatus.INFO, "Clicked on Search Apply Button");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFactVIII.searchFirstItemClk(Driver);
		waitforbrtxt(Driver);

		Driver.navigate().back();
		System.out.println("Clicked on Browser Back button");
		extentTest.log(LogStatus.INFO, "Clicked on Browser Back button");

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		// String val = pageFact11.accountLookupDropdown.getText();
		String val = pageFact11.accountLookupDropdown.getAttribute("value");

		//	if (val.contains("COGS")) {
		if(pageFact11.dollarFlatAmnt.isDisplayed()) {
			System.out.println("Back button click retains the Search filter");
			extentTest.log(LogStatus.INFO,
					"Back button click retains the Search filter");

		} else {

			String source = aftermthd(Driver);
			System.out
					.println("Back button click not retains the Search filter");
			extentTest.log(
					LogStatus.FAIL,
					"Back button click not retains the Search filter"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}

		return null;
	}

	public String dollar(WebDriver Driver) throws IOException {

		String doll = pageFact11.dollarFlatAmnt.getText();

		if (doll.equals("$")) {

			System.out
					.println("'$' sign included with the Flat Amount text box");
			extentTest.log(LogStatus.INFO,
					"'$' sign included with the Flat Amount text box");

		} else {
			String source = aftermthd(Driver);
			System.out
					.println("'$' sign NOT included with the Flat Amount text box");
			extentTest.log(
					LogStatus.FAIL,
					"'$' sign NOT included with the Flat Amount text box"
							+ extentTest
									.addScreenCapture("data:image/png;base64,"
											+ source));

		}
		return null;
	}

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		pageFactIV = new GenericFactoryIV(Driver);
		pageFactV = new GenericFactoryV(Driver);
		pageFactAS3 = new GenericFactorySprint3(Driver);
		pageFactJS3 = new GenericFactoryJSprint3(Driver);
		pageFact = new GenericFactory(Driver);
		pageFactVI = new GenericFactoryVI(Driver);
		pageFactVII = new GenericFactoryVII(Driver);
		pageFactVIII = new GenericFactoryVIII(Driver);
		pageFactIX = new GenericFactoryIX(Driver);
		pageFactX = new GenericFactoryX(Driver);
		pageFact11 = new GenericFactory11(Driver);
		POVIII = new PageObjectsVIII(Driver);

	}

}
