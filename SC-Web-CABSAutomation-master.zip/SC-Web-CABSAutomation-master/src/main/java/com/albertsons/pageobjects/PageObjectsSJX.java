package com.albertsons.pageobjects;

import java.util.List;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.Color;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class PageObjectsSJX extends ExtendBaseClass {
              WebDriver Driver;
              GenericFactory pageFact;
              Properties prop;
              GenericFactorySJIX pageFactSJIX;
              GenericFactorySJX pageFactSJX;
              GenericFactorySJVIII pageFactSJVIII;
              GenericFactorySJVI pageFactSJVI;
              static String brVal;

              public PageObjectsSJX(WebDriver Driver) {
                             this.Driver = Driver;
                             PageFactory.initElements(Driver, this);
              }

              public String aftermthd(WebDriver Driver) throws IOException {

                             TakesScreenshot ts = (TakesScreenshot) Driver;
                             // File source = ts.getScreenshotAs(OutputType.FILE);
                             String source1 = ts.getScreenshotAs(OutputType.BASE64);
                             return source1;

              }

              @Test
              public String BRCancel(WebDriver Driver, String Type)
                                           throws InterruptedException, IOException {
                             scrollDown(Driver);
                             Thread.sleep(3000);
                             pageFactSJX.brCancel.click();
                             System.out.println("Clicked On Cancel button");
                             extentTest.log(LogStatus.INFO, "Clicked On Cancel button");
                             Thread.sleep(2000);
                             if (pageFactSJX.warnDialog.isDisplayed()) {
                                           String WarnHeader = pageFactSJX.WarningHeader(Driver);
                                           String WarnBody = pageFactSJX.WarningBody(Driver);
                                           System.out.println("Warning Header is :" + WarnHeader);
                                           System.out.println("Warning Body is :" + WarnBody);
                                           String WarnYes = pageFactSJX.warnYes.getText();
                                           String WarnNo = pageFactSJX.warnNo.getText();
                                           System.out.println("Warning Button Yes :" + WarnYes);
                                           System.out.println("Warning Button No :" + WarnNo);

                                           if ((WarnHeader.equals("Warning"))
                                                                        && (WarnBody
                                                                                                     .equals("Are you sure you want to cancel the changes?"))
                                                                        && (WarnYes.equals("Yes")) && (WarnNo.equals("No")))
                                                          System.out
                                                                                      .println("app shows warning message Are you sure you want to cancel the changes? with Yes/No buttons");
                                           extentTest
                                                                        .log(LogStatus.INFO,
                                                                                                     "app shows warning message Are you sure you want to cancel the changes? with Yes/No buttons");
                             } else {
                                           String source = aftermthd(Driver);
                                           System.out.println("App doesnt show any warning message");
                                           extentTest.log(
                                                                        LogStatus.FAIL,
                                                                        "App doesnt any show warning message"
                                                                                                     + extentTest
                                                                                                                                 .addScreenCapture("data:image/png;base64,"
                                                                                                                                                               + source));
                             }

                             pageFactSJX.warnNo.click();
                             System.out.println("Clicked on No");
                             extentTest.log(LogStatus.INFO, "Clicked on No");
                             Thread.sleep(3000);
                             scrollUp(Driver);
                             Thread.sleep(3000);
                             pageFactSJIX.txtDescr.sendKeys("Test Automation-first");
                             Thread.sleep(2000);
                             System.out.println("Edited Internal Notes to 'Test Automation-first'");
                             extentTest.log(LogStatus.INFO,
                                                          "Edited Internal Notes to 'Test Automation-first");
                             System.out
                                                          .println("App is allowing the user to continue with edit after Clicking No");
                             extentTest
                                                          .log(LogStatus.INFO,
                                                                                      "App is allowing the user to continue with edit after Clicking No");
                             Thread.sleep(2000);
                             pageFactSJX.brCancel.click();
                             Thread.sleep(2000);
                             System.out.println("Clicked On Cancel button again");
                             extentTest.log(LogStatus.INFO, "Clicked On Cancel button again");
                            pageFactSJX.warnYes.click();
                             System.out.println("Clicked on Yes");
                             extentTest.log(LogStatus.INFO, "Clicked on Yes");
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             // Thread.sleep(10000);
                             // System.out.println("Redirected page after clicking Yes "
                             // +pageFactSJX.homePage.getText());

                             if (Type.equals("Create")) {
                                           if (pageFactSJX.homePage.getText().equals("Home")) {
                                                          System.out
                                                                                      .println("App takes the user to home page and doest not save changes to back-end , if user was creating the billing record.");
                                                          extentTest
                                                                                      .log(LogStatus.INFO,
                                                                                                                   "App takes the user to home page and doest not save changes to back-end , if user was creating the billing record.");
                                           }

                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("App doesnt take the user to home page after Clicking Yes, when user was creating the billing record ");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "App doesnt take the user to home page after Clicking Yes when  user was creating the billing record "
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                           }
                             } else if (Type.equals("Edit"))

                             {

                                           scrollUp(Driver);
                                           String InternalNotes = pageFactSJIX.txtDescr.getAttribute("value");
                                           System.out.println("Internal Notes after cancel is  "
                                                                        + InternalNotes);
                                           System.out
                                                                        .println("App did not save changes to back-end and re-load the page with previously saved state of the billing record if user was editing the BR");
                                           extentTest
                                                                        .log(LogStatus.INFO,
                                                                                                     "App did not save changes to back-end and re-load the page with previously saved state of the billing record if user was editing the BR");

                             }

                             return null;
              }

              public String scrollUp(WebDriver Driver) {

                             // pageFactJS3.allwTab(Driver);

                             Actions act = new Actions(Driver);
                             act.moveToElement(pageFactSJIX.clickLastUpdate).perform();
                             return null;
              }
              
              public String brIncomeSave(WebDriver Driver) throws InterruptedException {
                             pageFact.waitForSpinnerToBeGone();
        Thread.sleep(5000);
              System.out.println("Created and saved a MISC BR for validating BRs with status other than 'Ready for Income' should not be shown in income worklist ");
                             extentTest.log(LogStatus.INFO, "Created and saved a MISC BR for validating BRs with status other than 'Ready for Income' should not be shown in income worklist");  
                             pageFactSJVI.nonAlwAddIncome.click();
                             pageFact.waitForSpinnerToBeGone();
        Thread.sleep(5000);
                             System.out.println("Clicked on Add Income");
                             extentTest.log(LogStatus.INFO, "Clicked on Add Income");     
                             pageFactSJVI.nonAlwBillnAccru.click();
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);
                             System.out.println("Clicked on Bill and Accrue");
                             extentTest.log(LogStatus.INFO, "Clicked on Bill and Accrue");
                             pageFactSJVI.nonAlwIncomeComment.sendKeys("Misc Income comment");
                             Thread.sleep(3500);
                             System.out.println("Income Comments Added");
        extentTest.log(LogStatus.INFO,
          "Income Comments Added");
        pageFactSJVI.nonAlwDesc.sendKeys("Misc Income Descr");      
        System.out.println("Description Added");
        extentTest.log(LogStatus.INFO,
                                                  "Description Added");
        
        Thread.sleep(3500);  
        pageFactSJVI.nonAlwAmt.sendKeys("2");
        System.out.println("Allowance Amount Added");
        extentTest.log(LogStatus.INFO,
                                                  "Allowance Amount Added");
        Thread.sleep(3500);  
      
        pageFactSJX.miscIncSave.click();
        pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);

                             return null;
              }

              public String waitForSpinnerToBeGone() {

                             By loadingImage = By
                                                          .xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

                             WebDriverWait wait = new WebDriverWait(Driver, 60);
                             wait.until(ExpectedConditions
                                                          .invisibilityOfElementLocated(loadingImage));
                             return null;
              }

              public String RetBRVal(WebDriver Driver) {
                             String brValue = pageFactSJX.RetrieveBR(Driver);
                             return brValue;
              }
              
              public String AdvSearchAcct(WebDriver Driver) throws InterruptedException, IOException {
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             pageFactSJVIII.SearchBRMenu(Driver);
                             Thread.sleep(3000);
                             System.out.println("Clicked on Search BR");
                             extentTest.log(LogStatus.INFO, "Clicked on Search BR");
                             Thread.sleep(3000);
                             pageFactSJX.advSearch.click();
                             Thread.sleep(3500);
                             System.out.println("Clicked on Advanced Search");
                             extentTest.log(LogStatus.INFO, "Clicked on Advanced Search");
                             pageFactSJX.acctLkUpTypeClick.click();
                             Thread.sleep(3500);
                             pageFactSJX.acctLkUpTypeCogs.click();
                             Thread.sleep(3500);
                             System.out.println("Selected Acct Lkup Type-Cogs");
                             extentTest.log(LogStatus.INFO, "Selected Acct Lkup Type-Cogs");
                             pageFactSJVIII.SearchBRApply(Driver);
                             Thread.sleep(5000);
                             System.out.println("Selected Apply Button ");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");              
                             AdvSearchCogsVal(Driver);
                             pageFactSJX.acctLkUpTypeCogsClear.click();
                             Thread.sleep(3500);
                             System.out.println("Cleared cogs ");
                             
                             pageFactSJX.acctLkUpTypeClick.click();
                             Thread.sleep(3500);                                                  
                             pageFactSJX.acctLkUpTypeRetail.click();
                             Thread.sleep(3500);
                             System.out.println("Selected Acct Lkup Type- Retail ");
                             extentTest.log(LogStatus.INFO, "Selected Acct Lkup Type - Retail");
                             pageFactSJX.acctLkUpValClick.click();
                             Thread.sleep(3500);
                             pageFactSJX.acctLkUpValRetail.click();
                             Thread.sleep(3500);       
                             System.out.println("Selected Acct Lkup value  -05" );
                             extentTest.log(LogStatus.INFO, "Selected Acct Lkup Val -05 ");              
                             Thread.sleep(3500);
                             pageFactSJVIII.SearchBRApply(Driver);
                             Thread.sleep(5000);
                             System.out.println("Selected Apply Button ");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");              
                             
                             return null;
                             
              }
              
              public String AdvSearchCogsVal(WebDriver Driver) throws IOException
              {
                             
                             List<WebElement> elements = pageFactSJX.acctLkUpTypeCogsRes.findElements(By.className("overflow-doubledecker"));
                             System.out.println("result text size  " +elements.size() );
                             for (int i=0; i<elements.size();i++)
                             {
         System.out.println("Elements are " + elements.get(i).getText());
                             

                             //String cogsRes=pageFactSJX.acctLkUpTypeCogsRes.findElement(By.className("overflow-doubledecker")).getAttribute("title");
                             //String actRes=pageFactSJX.acctLkUpTypeCogsRes.findElement(By.className("overflow-doubledecker")).getText();
                             //System.out.println("Cogs Result  " +cogsRes);
                             if (elements.get(0).getText().equals("COGS Facilities")) {
                                           System.out.println("Search Results shows COGS BR ");
                                           extentTest.log(LogStatus.INFO, "Search Results shows COGS BR"   );                                                 
                                           break;                 
                                                          }
                             
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt COGS BR");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show COGS BR"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                                          break;   
                                           
                                           
                                                          }
                             }
                             
                             return null;
              }
              
              
              public String AdvSearchSection(WebDriver Driver) throws InterruptedException {
                             pageFactSJX.sectionClick.click();
                             Thread.sleep(3500);       
                             System.out.println("Selected Section 301");
                             extentTest.log(LogStatus.INFO, "Selected section 301");
                             pageFactSJX.sectionVal.click();                 
                             Thread.sleep(3500);       
                             pageFactSJVIII.SearchBRApply(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("Selected Apply Button ");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");              
                             
                             
                             return null;
                             
              }
              
              public String AdvSearchAlwnc(WebDriver Driver) throws InterruptedException {
                             pageFactSJX.alwTypeClick.click();
                             Thread.sleep(3500);       
                             pageFactSJX.alwTypeVal.click();
                             Thread.sleep(3500);       
                             System.out.println("Selected Allowance Type  T");
                             extentTest.log(LogStatus.INFO, "Selected Allowance Type T");
                             pageFactSJX.alwPerf1Click.click();                          
                             Thread.sleep(3500);       
                             pageFactSJX.alwPerf1Val.click();              
                             Thread.sleep(3500);       
                             System.out.println("Selected Perf1 Value  05");
                             extentTest.log(LogStatus.INFO, "Selected Perf1 Value  05");
                             pageFactSJX.alwPerf2Click.click();                          
                             Thread.sleep(3500);       
                             pageFactSJX.alwPerf2Val.click();              
                             Thread.sleep(3500);       
                             System.out.println("Selected Perf2 Value 01");
                             extentTest.log(LogStatus.INFO, "Selected Perf2 Value 01");
                             pageFactSJVIII.SearchBRApply(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("Selected Apply Button ");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");              
                             
                             
                             return null;
                             
              }
              
              
              public String AdvSearchFlatAmt(WebDriver Driver) throws InterruptedException {
                             pageFactSJX.fltAmtFromVal.sendKeys("1.00");
                             Thread.sleep(3500);       
                             System.out.println("Selected Flat from Amount as  1.00");
                             extentTest.log(LogStatus.INFO, "Selected Flat from Amount as  1.00");
                             pageFactSJX.fltAmtToVal.sendKeys("100.00");
                             Thread.sleep(3500);       
                             pageFactSJVIII.SearchBRApply(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("selected Apply button");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");              
                             
                             
                             return null;
                             
              }
              

              public String AdvSearchMultipleFilter(WebDriver Driver) throws InterruptedException, IOException {
                             System.out.println("Selected Multiple Filters Account Look up Type -Retail Div ,Account Look up Val -05, section -301,Allowance Type -T,Perf 1-05,Perf 2-01,"
                                                          + "Flat Amt From - 1,Flat amt To - 100 "
                                                          );
                             extentTest.log(LogStatus.INFO, "Selected Multiple Filters Account Look up Type -Retail Div ,Account Look up Val -05, section -301,Allowance Type -T,Perf 1-05,Perf 2-01,"
                                                          + "Flat Amt From - 1,Flat amt To - 100 ");
                             
                             if ((pageFactSJX.area_Multiple_lkTy.getText().equals("Retail Div")) && (pageFactSJX.area_Multiple_lkTyVal.getText().equals("05")) && (pageFactSJX.section_Multiple.getText().equals("301"))
                                                          && (pageFactSJX.alw_Multiple.getText().equals("T - 05 - 01")))  {
                                           System.out.println("Search Results shows results of multiple filters applied  "  );
                                           extentTest.log(LogStatus.INFO, "Search Results shows results of multiple filters applied   " );     
                                                                        
                             }
                             
                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Search Results doesnt show results of multiple filters applied");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Search Results doesnt show results of multiple filters applied"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }
                             
                             
                             return null;
                             
              }
              
              public String dialogFilter(WebDriver Driver) throws InterruptedException, IOException 
              {
                             pageFactSJX.sectionSelected.click();
                             System.out.println("Cleared section");
                             Thread.sleep(3000);
                             pageFactSJX.dialogClick.click();
                             Thread.sleep(3000);
                             pageFactSJX.dialogActive.click();
                             Thread.sleep(3000);
                             System.out.println("selected Active - Dialog Filter ");
                             extentTest.log(LogStatus.INFO, "selected Active - Dialog Filter"); 
                             pageFactSJVIII.SearchBRApply(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("selected Apply button");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");
                             
                             System.out.println("Validating Active dialog filter");
                             extentTest.log(LogStatus.INFO, "Validating dialog filter ");
                            //WebElement actRes=pageFactSJX.activeResult.findElement(By.className("overflow"));
                             String actRes=pageFactSJX.activeResult.findElement(By.className("overflow")).getText();
                             System.out.println("Act Result  " +actRes);
                             if (actRes.equals("Active")) {
                                           System.out.println("Search Results shows BR with dialogs -'Active' ");
                                           extentTest.log(LogStatus.INFO, "Search Results shows BR with dialogs -'Active'  "   );                                                 
                                                                        
                             }
                             
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt show BR with dialogs -'Active'");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show doesnt show BR with dialogs -'Active'"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                           
                                           
                             }
                             
                             
                             System.out.println("Validating Resolved dialog ");
                             extentTest.log(LogStatus.INFO, "Validating Resolved dialog ");
                             
                             Thread.sleep(3000);
                             pageFactSJX.activeClear.click();
                             Thread.sleep(3000);
                            pageFactSJX.dialogClick.click();
                             Thread.sleep(3000);
                             pageFactSJX.dialogResolved.click();
                             System.out.println("Selected Resolved  Dialog");
                             extentTest.log(LogStatus.INFO, "Selected Resolved  Dialog");              
                             Thread.sleep(3000);
                             pageFactSJVIII.SearchBRApply(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("selected Apply button");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");
                             
                             System.out.println("Validating Resolved dialog filter");
                             extentTest.log(LogStatus.INFO, "Resolved dialog filter ");
                             //WebElement actRes=pageFactSJX.activeResult.findElement(By.className("overflow"));
                             String resRes=pageFactSJX.ResolvedResult.findElement(By.className("overflow")).getText();
                             System.out.println("Resolved Result  " +resRes);
                             if (resRes.equals("Resolved")) {
                                           System.out.println("Search Results shows BR with dialogs -'Resolved' ");
                                           extentTest.log(LogStatus.INFO, "Search Results shows BR with dialogs -'Resolved'  "   );                                            
                                                                        
                             }
                             
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt show BR with dialogs -'Resolved'");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show doesnt show BR with dialogs -'Resolved'"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                           
                                           
                             }
                             
                                                          
                                                                                      
                             return null;
              }
              
              
              public String dialogFilterMisc(WebDriver Driver) throws InterruptedException, IOException {
                             pageFactSJX.search_clear.click();
                             System.out.println("Cleared filters");
                             pageFactSJX.advSearch.click();
                             Thread.sleep(3000);
                             System.out.println("Validating MISC-Active dialog search");
                             extentTest.log(LogStatus.INFO, "Validating MISC-Active dialog search");
                             pageFactSJVIII.EnterBR.findElement(By.className("form-control")).sendKeys("10007190");
                             Thread.sleep(3000);
                             System.out.println("Entered MISC BR nbr in Search BR");
                             pageFactSJX.dialogClick.click();
                             Thread.sleep(3000);
                             pageFactSJX.dialogActive.click();
                             Thread.sleep(3000);
                             System.out.println("selected MISC Active - Dialog Filter ");
                             extentTest.log(LogStatus.INFO, "selected MISC Active - Dialog Filter");                              
                             pageFactSJVIII.SearchBRApply(Driver);
                             System.out.println("selected Apply button");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");
                             System.out.println("Validating Active dialog filter");
                             extentTest.log(LogStatus.INFO, "Validating dialog filter ");
                             //WebElement actRes=pageFactSJX.activeResult.findElement(By.className("overflow"));
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);
                             String actRes=pageFactSJX.activeResultMisc.findElement(By.className("overflow")).getText();
                             System.out.println("Act Result  " +actRes);
                             if (actRes.equals("Active")) {
                                           System.out.println("Search Results shows BR with dialogs -'Active' ");
                                           extentTest.log(LogStatus.INFO, "Search Results shows BR with dialogs -'Active'  "   );                                                 
                                                                        
                             }
                             
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt show BR with dialogs -'Active'");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show doesnt show BR with dialogs -'Active'"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                           
                                           
                             }
                             
                             
                             System.out.println("Validating Resolved dialog ");
                             extentTest.log(LogStatus.INFO, "Validating Resolved dialog ");
                             
                             pageFactSJVIII.EnterBR.findElement(By.className("form-control")).sendKeys(Keys.CONTROL + "a");
                             Thread.sleep(3000);
                             System.out.println("Cleared BR");           
                             pageFactSJVIII.EnterBR.findElement(By.className("form-control")).sendKeys("10007193");
                             System.out.println("Entered MISC BR nbr in Search BR");
                             
                             Thread.sleep(3000);
                             pageFactSJX.activeClear.click();
                             Thread.sleep(3000);
                             pageFactSJX.dialogClick.click();
                             Thread.sleep(3000);
                             pageFactSJX.dialogResolved.click();
                             System.out.println("Selected MISC-Resolved  Dialog");
                             extentTest.log(LogStatus.INFO, "Selected MISC-Resolved  Dialog");             
                             Thread.sleep(3000);
                             pageFactSJVIII.SearchBRApply(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("selected Apply button");
                             extentTest.log(LogStatus.INFO, "Selected Apply Button ");
                             
                             System.out.println("Validating Resolved dialog filter");
                             extentTest.log(LogStatus.INFO, "Resolved dialog filter ");
                             //WebElement actRes=pageFactSJX.activeResult.findElement(By.className("overflow"));
                             String resRes=pageFactSJX.ResolvedResult.findElement(By.className("overflow")).getText();
                             System.out.println("Resolved Result  " +resRes);
                             if (resRes.equals("Resolved")) {
                                           System.out.println("Search Results shows BR with dialogs -'Resolved' ");
                                           extentTest.log(LogStatus.INFO, "Search Results shows BR with dialogs -'Resolved'  "   );                                            
                                                                        
                             }
                             
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt show BR with dialogs -'Resolved'");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show doesnt show BR with dialogs -'Resolved'"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                           
                                           
                             }
                             
                             
                             
                             
                             return null;
              }
              
              public String ValResultArea (WebDriver Driver) throws IOException{
                             System.out.println("Validating Search Results after  Acct LookupType is filtered");
                             extentTest.log(LogStatus.INFO, "Validating Search Results after  Acct LookupType is filtered ");
                             List<WebElement> elementsRetail = pageFactSJX.areaResult.findElements(By.className("overflow-doubledecker"));
                             System.out.println("result text size  " +elementsRetail.size() );
                             //System.out.println ("List is " +elements);
                             for (int i=0; i<elementsRetail.size();i++){
                                           System.out.println("Elements are " + elementsRetail.get(i).getText());
                                           
                                           if ((elementsRetail.get(0).getText().equals("Retail Div")) && (elementsRetail.get(1).getText().equals("05"))  ) {
                                                          System.out.println("Search Results shows Area fields as  " +pageFactSJX.area_lkupType.getText()+ " " +pageFactSJX.area_lkupVal.getText() );
                                                          extentTest.log(LogStatus.INFO, "Search Results shows Area fields as  " +pageFactSJX.area_lkupType.getText()+ " " +pageFactSJX.area_lkupVal.getText() );  
                                                                                      
                                           }
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt show Area fields Retail Div -05");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show  Area fields Retail Div -05"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                           }
                                           
                                           
                             }
                             //System.out.println("acct lkyp type is  "+pageFactSJX.area_lkupType.getText());             
                             //System.out.println("acct lkyp val is  "+pageFactSJX.area_lkupVal.getText());
              /*          if ((pageFactSJX.area_lkupType.getText().equals("Retail Div")) && (pageFactSJX.area_lkupVal.getText().equals("05"))  ) {
                                           System.out.println("Search Results shows Area fields as  " +pageFactSJX.area_lkupType.getText()+ " " +pageFactSJX.area_lkupVal.getText() );
                                           extentTest.log(LogStatus.INFO, "Search Results shows Area fields as  " +pageFactSJX.area_lkupType.getText()+ " " +pageFactSJX.area_lkupVal.getText() );  
                                                                        
                             }
                             
                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Search Results doesnt show Area fields Retail Div -05");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Search Results doesnt show  Area fields Retail Div -05"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }*/
                             
                             
                             
                             
                             return null;
              }
                             
                             
              public String ValResultSection (WebDriver Driver) throws IOException{
                             System.out.println("Validating Search Results after  section is filtered");
                             extentTest.log(LogStatus.INFO, "Validating Search Results after  section is filtered ");
                             List<WebElement> elementsSection = pageFactSJX.sectionAll.findElements(By.className("overflow"));
                             System.out.println("result text size  " +elementsSection.size() );
                             //System.out.println ("List is " +elements);
                             for (int i=0; i<elementsSection.size();i++){
                                           System.out.println("Elements are " + elementsSection.get(i).getText());
                             
                             //System.out.println("Section selected  is  "+pageFactSJX.sectionResult.getText()); 
                             if ((elementsSection.get(0).getText().equals("301"))  ) {
                                           System.out.println("Search Results shows section fields as  " +pageFactSJX.sectionResult.getText() );
                                           extentTest.log(LogStatus.INFO, "Search Results shows section fields as  " +pageFactSJX.sectionResult.getText() );            
                                                                        
                             }
                             
                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Search Results doesnt show section fields as  301");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Search Results doesnt show section fields as  301"
                                                                                                                                  + extentTest
                                                                                                                                                              .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                                           }
                             }
                             
                             return null;
              }
                             
              
              public String ValResultAlwnc(WebDriver Driver) throws IOException{
                             System.out.println("Validating Search Results after  Alwnc Type is filtered");
                             extentTest.log(LogStatus.INFO, "Validating Search Results after Alwnc Type is filtered ");
                             //System.out.println("Alwnc Type selected  is  "+pageFactSJX.alwncVal.getText());         
                             List<WebElement> elementsAlw = pageFactSJX.alwResult.findElements(By.className("overflow"));
                             List<WebElement> elementsAlwdouble = pageFactSJX.alwResult.findElements(By.className("overflow-doubledecker"));
                             System.out.println("result text size  " +elementsAlw.size() );
                             System.out.println("result text size  " +elementsAlwdouble.size() );
                             
                             if (elementsAlw.size()>0)
                             {
                             //System.out.println ("List is " +elements);
                             for (int i=0; i<elementsAlw.size();i++){
                                           System.out.println("Elements are " + elementsAlw.get(i).getText());
                             
                             if ((elementsAlw.get(0).getText().equals("T - 05 - 01"))  ) {
                                           System.out.println("Search Results shows Allowance Type fields as  " +pageFactSJX.alwncVal.getText() );
                                           extentTest.log(LogStatus.INFO, "Search Results shows Allowance Type fields as  " +pageFactSJX.alwncVal.getText() );     
                                                                        
                             }
                            
                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Search Results doesnt show Allowance Type fields");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Search Results doesnt show Allowance Type fields"
                                                                                                                                  + extentTest
                                                                                                                                                              .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                                                          }
                                           }
                             
                             }
                             
                             else
                             {
                                           for (int i=0; i<elementsAlwdouble.size();i++){
                                                          System.out.println("Elements are " + elementsAlwdouble.get(i).getText());
                                           
                                           if ((elementsAlwdouble.get(0).getText().equals("T - 05 - 01"))  ) {
                                                          System.out.println("Search Results shows Allowance Type fields as  " +pageFactSJX.alwncVal.getText() );
                                                          extentTest.log(LogStatus.INFO, "Search Results shows Allowance Type fields as  " +pageFactSJX.alwncVal.getText() );              
                                                                                      
                                           }
                                           
                                           else {
                                                          String source = aftermthd(Driver);
                                                          System.out
                                                                                      .println("Search Results doesnt show Allowance Type fields");
                                                          extentTest
                                                                                      .log(LogStatus.FAIL,
                                                                                                                   "Search Results doesnt show Allowance Type fields"
                                                                                                                                                + extentTest
                                                                                                                                                                             .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                          + source));
                                                                        }
                                                          }
                                           
                             }
                             
                             return null;
              }
              
              
              public String ValResulFlatAmt (WebDriver Driver) throws IOException, InterruptedException{
                             System.out.println("Validating Search Results after Flat amt range is applied");
                             extentTest.log(LogStatus.INFO, "Validating Search Results after  Flat amt range is applied");
                             System.out.println("Flat amount range  is   between  1-100");              
                             pageFactSJX.flatamtSort.click();
                             Thread.sleep(5000);
                             System.out.println("Sorted flat amount by asc");              
                             extentTest.log(LogStatus.INFO, "Sorted flat amount by asc");
                             System.out.println("Asc " +pageFactSJX.flatamtVal.getText().replaceAll("\\D+", ""));
                             String st1=pageFactSJX.flatamtVal.getText().replaceAll("\\D+", "");
                             int int1 = (int)(Integer.parseInt(st1));
                             int int2=int1/100;
                             int FlatAmt1,FlatAmt2;
                             
                             // if((Integer.parseInt(pageFactSJX.flatamtVal.getText().replaceAll("\\D+", "").toString()) )<=1){
                             if( int2 <=1){
                                             FlatAmt1=1;
                                             
                                             
                             }
                             else {
                                           FlatAmt1=0;
                                           
                                            
                              }
                             pageFactSJX.flatamtSort.click();
                             pageFact.waitForSpinnerToBeGone();
                                           Thread.sleep(5000);
                                           System.out.println("Sorted flat amount by desc");              
                                           extentTest.log(LogStatus.INFO, "Sorted flat amount by des");
                                           System.out.println("DESC " +pageFactSJX.flatamtVal.getText().replaceAll("\\D+", ""));
                                           String st2=pageFactSJX.flatamtVal.getText().replaceAll("\\D+", "");
                                           int ints1 = (int)(Integer.parseInt(st2));
                                           int ints2=ints1/100;
                                           
                                           if( ints2 <=100){
                                                            FlatAmt2=1;
                                                            
                                                          
                                                          
                                           }
                                           else {
                                                          FlatAmt2=0;
                                                          
                                           }
                             
                                           
                             if ( (FlatAmt1 == 1) && FlatAmt2 ==1 ) {
                                           System.out.println("Search Results shows BR with in flat amount range 1-100 given  " );
                                           extentTest.log(LogStatus.INFO, "Search Results shows BR with in flat amount range 1-100 given" );        
                                                                        
                             }
                             
                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Search Results  doesnt show BR with in flat amount range 1-100 given");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Search Results  doesnt show BR with in flat amount range 1-100 given"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }
                             
                             return null;
              }

              public String EnterBRVal(WebDriver Driver) throws InterruptedException {
                             Thread.sleep(2000);
                             scrollUp(Driver);
                             String brVal = pageFactSJX.RetrieveBR(Driver);
                             Thread.sleep(2000);
                             System.out.println("BR saved is " + brVal);
                             pageFactSJVIII.SearchBRMenu(Driver);
                             Thread.sleep(3000);
                             pageFactSJX.warnYes.click();
                             Thread.sleep(7000);
                             System.out.println("Clicked on Search BR");
                             extentTest.log(LogStatus.INFO, "Clicked on Search BR");
                             Thread.sleep(3000);
                             pageFactSJX.advSearch.click();
                             System.out.println("Clicked on Advanced Search");
                             extentTest.log(LogStatus.INFO, "Clicked on Advanced Search");
                             pageFactSJVIII.EnterBR.findElement(By.className("form-control"))
                                                          .sendKeys(brVal);
                             Thread.sleep(3000);
                             System.out.println("Entered the BR nbr in Search BR");
                             extentTest.log(LogStatus.INFO, "Entered the BR nbr in Search BR");
                             pageFactSJVIII.SearchBRApply(Driver);
                             Thread.sleep(5000);
                             pageFactSJVIII.SelectBRVal(Driver);
                             Thread.sleep(3000);

                             return null;
              }

              public String brCanclVal(WebDriver Driver) throws InterruptedException,
                                           IOException {
                             Thread.sleep(3000);
                             System.out.println("Validating Cancel button..");

                             if (pageFactSJX.brCancel.isEnabled()) {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Cancel button is enabled when user doesn't make any edits on the billing record fields");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Cancel button is enabled when user doesn't make any edits on the billing record fields"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }

                             else {
                                           System.out
                                                                        .println("Cancel button is  disabled when user doesn't make any edits on the billing record fields");
                                           extentTest
                                                                        .log(LogStatus.INFO,
                                                                                                     "Cancel button is  disabled when user doesn't make any edits on the billing record fields");
                             }
                             Thread.sleep(2000);

                             scrollUp(Driver);
                             Thread.sleep(7000);
                             pageFactSJX.alwTab.click();
                             Thread.sleep(3000);
                             pageFactSJIX.FlatAmt.sendKeys(Keys.CONTROL + "a");
                             pageFactSJIX.FlatAmt.sendKeys("10.55");
                             Thread.sleep(2000);
                             System.out.println("Edited Flat amount");
                             extentTest.log(LogStatus.INFO, "Edited Flat amount");
                             Thread.sleep(2000);
                             scrollDown(Driver);
                             if (pageFactSJX.brCancel.isEnabled()) {
                                           System.out
                                                                        .println("Cancel button is enabled when user  made any edits on the billing record fields");
                                           extentTest.log(LogStatus.INFO,
                                                                        "Cancel button is enabled when user  made any edits");
                             }

                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Cancel button is not enabled when user  made any edits on the billing record fields");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Cancel button is not  disabled when user doesn't make any edits on the billing record fields"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }

                             Thread.sleep(2000);

                             return null;
              }

              public String CancelEdit(WebDriver Driver) throws InterruptedException,
                                           IOException {
                             scrollDown(Driver);
                             Thread.sleep(3000);
                             if (pageFactSJX.brCancel.isEnabled()) {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Cancel button is enabled when user doesn't make any edits on the billing record fields");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Cancel button is enabled when user doesn't make any edits on the billing record fields"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }

                             else {
                                           System.out
                                                                        .println("Cancel button is  disabled when user doesn't make any edits on the billing record fields");
                                           extentTest
                                                                        .log(LogStatus.INFO,
                                                                                                     "Cancel button is  disabled when user doesn't make any edits on the billing record fields");
                             }

                             Thread.sleep(2000);
                             pageFactSJIX.FlatAmt.sendKeys(Keys.CONTROL + "a");
                             pageFactSJIX.FlatAmt.sendKeys("20.34");
                             System.out.println("Edited Flat Amount");
                             extentTest.log(LogStatus.INFO, "Edited Flat amount");
                             Thread.sleep(2000);
                             if (pageFactSJX.brCancel.isEnabled()) {
                                           System.out
                                                                        .println("Cancel button is enabled when user  made any edits on the billing record fields");
                                           extentTest.log(LogStatus.INFO,
                                                                        "Cancel button is enabled when user  made any edits");
                             }

                             else {
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Cancel button is not enabled when user  made any edits on the billing record fields");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Cancel button is not  disabled when user doesn't make any edits on the billing record fields"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             }

                             Thread.sleep(2000);

                             return null;
              }

              public String itemTabClick(WebDriver Driver) throws InterruptedException {
                             Thread.sleep(2000);
                             pageFactSJIX.Itemtab.click();
                             Thread.sleep(2000);

                             return null;
              }

              public String scrollDown(WebDriver Driver) throws InterruptedException {
                             Actions act = new Actions(Driver);
                             act.moveToElement(pageFactSJX.brCancel).perform();
                             Thread.sleep(7000);
                             return null;
              }

              public String AllwncBRSaveforFlat(WebDriver Driver)
                                           throws InterruptedException {

                             waitforbrtxt(Driver);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3000);
                             pageFactSJIX.BillingName(Driver);
                             Thread.sleep(3000);
                             pageFactSJIX.txtArea(Driver);
                             Thread.sleep(3000);
                             pageFactSJIX.save.click();
                             Thread.sleep(5000);

                             return null;
              }
              
              public String saveIncomeVal(WebDriver Driver) throws InterruptedException {
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);
                             pageFactSJX.incomeWorkList.click();
                             System.out.println("Clicked on Income Worklist");
                             extentTest.log(LogStatus.INFO, "Clicked on Income Worklist");
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);
                             String IncomeWListcount=pageFactSJX.incomeWorkList.getText().replaceAll("\\D+", "");
                             System.out.println("Count on Income WorkList increased  " +IncomeWListcount);
                             extentTest.log(LogStatus.INFO, "Count on Income Worklist increased  " +IncomeWListcount);
                             pageFactSJX.incomeWorkListBR.click();
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             pageFact.waitForSpinnerToBeGone();
                             System.out.println("BR sorted");
                             
                                           System.out.println("BR field shows  Billing record ID " +pageFactSJX.incomeWorkListBRVal.getText() );
                                           extentTest.log(LogStatus.INFO, "BR field shows  Billing record ID " +pageFactSJX.incomeWorkListBRVal.getText()) ;                                                                                  
                             
              


              
                             
                             return null;
              }
              
              public String WorkListForDropDown(WebDriver Driver) throws InterruptedException, IOException {
                             pageFact.waitForSpinnerToBeGone();

                             Thread.sleep(3500);
                             pageFactSJX.incomeWorkListDropDown.click();
                             Thread.sleep(3500);
                             System.out.println("Worklist Drop Down userid " +pageFactSJX.incomeWorkListDropDownVal.getText());
                             
                             if (pageFactSJX.incomeWorkListDropDownVal.getText().contains("Test")) {
                                           System.out.println("Selected Test Id as user in Worklist for Drop Down");
                                           extentTest.log(LogStatus.INFO, "Selected Test Id as user in Worklist forDrop Down");                                                                      
                                           
                             }
                             
                             else
                             {
                             
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("Not Selected TestId as user in Drop Down");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "Not Selected TestId as user in Drop Down"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                                           
                             }
                             
                             pageFactSJX.testIdSelected.click();
                             
                             return null;
              }
              
              public String IncomeWorkListMenuClick(WebDriver Driver) throws InterruptedException, IOException {

                             pageFact.waitForSpinnerToBeGone();

                             Thread.sleep(3500);

                             pageFactSJX.incomeWorkList.click();
                             System.out.println("Clicked on Income Worklist");
                             extentTest.log(LogStatus.INFO, "Clicked on Income Worklist");
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);

                             IncomeWorkListHyperLinkVal(Driver);
                             String IncomeWListcount=pageFactSJX.incomeWorkList.getText().replaceAll("\\D+", "");
                             System.out.println("Count on Income WorkList is  " +IncomeWListcount);
                             extentTest.log(LogStatus.INFO, "Count on Income Worklist is  " +IncomeWListcount);

                             return null;

              }
              
              
              public String miscBRVal(WebDriver Driver) throws InterruptedException, IOException {
                             
        Thread.sleep(5000);
                             WebElement elem =pageFactSJX.billRecId.findElement(By.className("form-control"));
                             String brId=elem.getAttribute("value");
                             System.out.println("Saved  BR nbr is " +brId);
                             extentTest.log(LogStatus.INFO, "Saved BR nbr is " +brId);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             pageFactSJX.miscBrStatusClick.click();
                             Thread.sleep(3500);                     
                             String brStat=pageFactSJX.miscBrStatus.getText();
                             System.out.println("Saved  BR nbr status is in  " +brStat);
                             extentTest.log(LogStatus.INFO, "Saved BR nbr status is in " +brStat);
                             Thread.sleep(3500);
                             pageFactSJX.incomeWorkList.click();
                             System.out.println("Clicked on Income Worklist");
                             extentTest.log(LogStatus.INFO, "Clicked on Income Worklist");
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);
                             String IncomeWListcount=pageFactSJX.incomeWorkList.getText().replaceAll("\\D+", "");
                             System.out.println("Count on Income WorkList increased  " +IncomeWListcount);
                             extentTest.log(LogStatus.INFO, "Count on Income Worklist increased  " +IncomeWListcount);
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(3500);
                             pageFactSJX.incomeWorkListBR.click();
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             pageFact.waitForSpinnerToBeGone();
                             System.out.println("BR sorted  in descending order");
                             String incBR=pageFactSJX.incomeWorkListBRVal.getText();
                             System.out.println("BR in income worlist is " +incBR);
                             
                                                          if (incBR.equals(brId)) {
                                                                        System.out.println("Income in Ready for status is shown in income worklist "  );
                                                                        extentTest.log(LogStatus.INFO, "Income in Ready for status is shown in income worklist " ) ;                                                                                
                                                                                                                   }
                             
                                                          else       {
                                           
                                                                        String source = aftermthd(Driver);
                                                                        System.out.println("Income in Ready for status is  not shown in income worklist ");
                                                                        extentTest.log(LogStatus.FAIL,
                                                                                                     "Income in Ready for status is  not shown in income worklist "
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                             
                             
                                                                                                     }
                                                          
                                                          Thread.sleep(3000);
                                                          String IncomeStatVal              =pageFactSJX.incomeWorkListIncomeStatVal.getAttribute("title");
                                                          
                                                          if (IncomeStatVal.equals("Saved")) {
                                                          System.out.println("Income Status field shows  " +IncomeStatVal + " "+"status for saved  Bill incomes");
                                                          extentTest.log(LogStatus.INFO, "Income Status field shows  " +IncomeStatVal  + " "+"status for saved Bill incomes" );                     
                                                          }
                                                          
                                                          else
                                                          {
                                                                        System.out.println("Income Status field  doesnt show 'Saved' status for saved  Bill incomes");
                                                                        extentTest.log(LogStatus.INFO, "Income Status field show  'Saved' status for saved Bill incomes" );                         
                                                                                                                                                
                                                          }
                                                          
                                                          Thread.sleep(3000);
                                                          pageFactSJX.incomeWorkListBRVal.click();
                                                          System.out.println("Clicked on BR in income worklist "  );
                                                          extentTest.log(LogStatus.INFO, "Clicked on BR in income worklist  " ) ;  
                                                          pageFact.waitForSpinnerToBeGone();
                                                          Thread.sleep(5000);
                                                          waitforbrtxt(Driver);
                                                          
                                                          if (pageFactSJX.miscIncSave.isEnabled()){
                                                                        System.out.println("Upon clicking the Billing Record ID, user is taken to billing page - income section "  );
                                                                        extentTest.log(LogStatus.INFO, "Upon clicking the Billing Record ID, user is taken to billing page - income section  " ) ;                                                                                                                                                                                                                                                                                                 
                                                          }
                                                          
                                                          else
                                                                                      {
                                                                        String source = aftermthd(Driver);
                                                                        System.out
                                                                                                     .println("Upon clicking the Billing Record ID, user is not taken to billing page - income section");
                                                                        extentTest
                                                                                                     .log(LogStatus.FAIL,
                                                                                                                                  "Upon clicking the Billing Record ID, user is  not taken to billing page - income section"
                                                                                                                                                               + extentTest
                                                                                                                                                                                            .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                                        + source));                                                                   
                                                                                      }
                                                          
                                                          System.out.println("Changing BR status");
                                                          extentTest.log(LogStatus.INFO, "Changing BR status" ) ;                                                                     
                                                          scrollUp(Driver);
                                                          Thread.sleep(5000);
                                                          pageFactSJX.miscBrStatusClick.click();
                                                          Thread.sleep(5000);
                                                          pageFactSJX.miscBrStatusEnd.click();
                                                          Thread.sleep(3000);
                                                          pageFactSJX.miscBrSave.click();
                                                          pageFact.waitForSpinnerToBeGone();
                                                          Thread.sleep(5000);                                   
                                                          System.out.println("Saved the BR status to 'Ended' "  );
                                                          extentTest.log(LogStatus.INFO, "Saved the BR status to 'Ended' " ) ;      
                                                          pageFact.waitForSpinnerToBeGone();
                                                          Thread.sleep(5000);                                   
                                                          waitforbrtxt(Driver);                                                 
                                                          pageFactSJX.incomeWorkList.click();
                                                          System.out.println("Clicked on Income Worklist");
                                                          extentTest.log(LogStatus.INFO, "Clicked on Income Worklist");
                                                          pageFact.waitForSpinnerToBeGone();
                                                          Thread.sleep(5000);
                                                          String IncomeWListcount1=pageFactSJX.incomeWorkList.getText().replaceAll("\\D+", "");
                                                          System.out.println("Count on Income WorkList decreased  " +IncomeWListcount1);
                                                          extentTest.log(LogStatus.INFO, "Count on Income Worklist decreased  " +IncomeWListcount1);
                                                          pageFact.waitForSpinnerToBeGone();
                                                          Thread.sleep(5000);
                                                          pageFactSJX.incomeWorkListBR.click();
                                                          pageFact.waitForSpinnerToBeGone();
                                                          Thread.sleep(5000);
                                                          pageFact.waitForSpinnerToBeGone();
                                                          System.out.println("BR sorted");
                                                          String incBR1=pageFactSJX.incomeWorkListBRVal.getText();
                                                          System.out.println("BR in income worlist is " +incBR1);            
                                                          System.out.println("prev BR in income worlist is " +brId);          
                                                          
                                                                                      if (incBR1.equals(brId)){                                                           
                                                                                                     String source = aftermthd(Driver);
                                                                                                    System.out.println("Income in Ended Status(BR status Other than Ready for income) is shown in income worklist ");
                                                                                                    extentTest.log(LogStatus.FAIL,
                                                                                                                                 "Income in Ended Status is shown in income worklist "
                                                                                                                                                               + extentTest
                                                                                                                                                                                            .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                                                        + source));                                                                                                              
                                                                                                                                  }
                                                                                      else                                                                               
                                                                                                                  {
                                                                                                    System.out.println("Income in Ended Status(BR status Other than Ready for income) is  not shown in income worklist "  );
                                                                                                    extentTest.log(LogStatus.INFO, "Income in Ended Status is not shown in income worklist " ) ;                                                                           
                                                                                                                  }                                                        
                             return null;
                             
              }
              public String IncomeWorkListHyperLinkVal(WebDriver Driver) throws InterruptedException, IOException {
                             String colorString = pageFactSJX.incomeWorkList.getCssValue("color");
                             System.out.println("RGB_Color: " + colorString);
              
                             //  RGB to HEX   
                              String actual_hex = Color.fromString(colorString).asHex();
                             // String actual_hex = String.format("#%02x%02x%02x", Integer.parseInt(color_hex[0].trim()), Integer.parseInt(color_hex[1].trim()), Integer.parseInt(color_hex[2].trim())); 
                              System.out.println("Actual Hex  " +actual_hex); 
                              String[] arrColor = actual_hex.split("#");
                             //System.out.println("arrColor   " +arrColor); 
                             if (actual_hex.contains("00a0e0")) {
                                           System.out.println("When income worklist is clicked, the menu on side bar is in blue color");
                                           extentTest.log(LogStatus.INFO, "When income worklist is clicked, the menu on side bar is in blue color");
                                                                        
                             }
                             else {
                                           
                                           String source = aftermthd(Driver);
                                           System.out
                                                                        .println("When income worklist is clicked, the menu on side bar  is not in blue color");
                                           extentTest
                                                                        .log(LogStatus.FAIL,
                                                                                                     "When income worklist is clicked, the menu on side bar  is not in blue color"
                                                                                                                                  + extentTest
                                                                                                                                                               .addScreenCapture("data:image/png;base64,"
                                                                                                                                                                                            + source));
                                           
                                           
                             }
                             
                             
                             return null;
              }

              public String IncomeWorkListFields(WebDriver Driver) throws IOException, InterruptedException {
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             System.out.println("Validating Fields in Income Worklist  ");
                             extentTest.log(LogStatus.INFO, "Validating Fields in Income Worklist");

                             String BRList = pageFactSJX.incomeWorkListBR.getText().replaceAll("\\W+", "");
                             System.out.println("first field is  " +BRList);

                             if (BRList.contains("BR")) {

                                           System.out.println("PASS:  BR Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "BR Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL:  BR Field is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "BR Field is not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(2000);
                             
                             if (pageFactSJX.incomeWorkListBillName.getText().equals("Billing Name")) {

                                           System.out.println("PASS:  Billing Name is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Billing Name is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL: Billing Name is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Billing Name is not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(2000);

                             if (pageFactSJX.incomeWorkListIncomeType.getText().equals("Income Type")) {

                                           System.out.println("PASS:  Income Type Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Income Type Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL:  Income Type Field is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Income Type Field is not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(5000);

                             if (pageFactSJX.incomeWorkListIncomeStat.getText().equals("Income Status")) {

                                           System.out.println("PASS:  Income Status is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Income Status is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL:  Income Status is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Income Status is not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(2000);

                             if (pageFactSJX.incomeWorkListArea.getText().equals("Area")) {

                                           System.out.println("PASS:  Area Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Area Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL:  Area Field is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Area Field is  not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(2000);

                             if (pageFactSJX.incomeWorkListSection.getText().equals("Section")) {

                                           System.out.println("PASS:  Section Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Section Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL:  Section Field is  not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Section Field is not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(2000);

                             if (pageFactSJX.incomeWorkListAlw.getText().equals("Allowance")) {

                                           System.out.println("PASS: Allowance Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Allowance Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL: Allowance Field is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Allowance Field is  not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             Thread.sleep(2000);

                             if (pageFactSJX.incomeWorkListOffer.getText().equals("Offer")) {

                                           System.out.println("PASS: Offer Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Offer Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL:  Offer Field is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Offer Field is not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }
                             
                             
                             if (pageFactSJX.incomeWorkListFlatRemain.getText().equals("Flat Remaining")) {

                                           System.out.println("PASS: Flat Remaining is displayed in Income WorkList table");
                                           extentTest.log(LogStatus.INFO, "Flat Remaining Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);
                                           System.out.println("FAIL: Flat Remaining Field is not displayed in Income WorkList table");
                                           extentTest.log(LogStatus.FAIL, "Flat Remaining Field is  not displayed in Income WorkList table"
                                                          + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }

                             
                             if (pageFactSJX.incomeWorkListDialog.getText().equals("Dialog")) {

                                           System.out.println("PASS: Dialog Field is displayed in Income WorkList table");

                                           extentTest.log(LogStatus.INFO, "Dialog Field is displayed in Income WorkList table");

                             } else {

                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL: Dialog Field is not displayed in Income WorkList table");

                                           extentTest.log(LogStatus.FAIL, "Dialog Field is  not displayed in Income WorkList table"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));

                             }
                             
                             IncomeWorkListFieldValues(Driver);       
                             return null;
              }
              
              public String IncomeWorkListFieldValues(WebDriver Driver) throws IOException, InterruptedException {
                             pageFactSJX.incomeWorkListBR.click();
                             pageFact.waitForSpinnerToBeGone();
                             Thread.sleep(5000);
                             pageFact.waitForSpinnerToBeGone();
                             System.out.println("BR sorted");
                             System.out.println("Validating Income worklist field values "  );
                             extentTest.log(LogStatus.INFO, "Validating Income worklist field values " ) ;                                                                         

                             if ( Integer.parseInt(pageFactSJX.incomeWorkListBRVal.getText()) >0  ) {
                                           System.out.println("BR field shows  Billing record ID " +pageFactSJX.incomeWorkListBRVal.getText() );
                                           extentTest.log(LogStatus.INFO, "BR field shows  Billing record ID " +pageFactSJX.incomeWorkListBRVal.getText()) ;                                                                                  
                             }
                             else {

                                           String source = aftermthd(Driver);
                                           System.out.println("FAIL: BR field  doesnt show  Billing record ID");
                                           extentTest.log(LogStatus.FAIL, "BR field  doesnt show  Billing record ID"
                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));
                                           }                           
  //Validating Bill Name
                             String BillName=pageFactSJX.incomeWorkListBillNameVal.getAttribute("title");
                             System.out.println("Billing Name field shows  " +BillName );
                             extentTest.log(LogStatus.INFO, "BR field shows  " +BillName );                                                                        
//Validating Income Type                          
                             String IncomeTypeVal=pageFactSJX.incomeWorkListIncomeTypeVal.getAttribute("title");
                             if ( IncomeTypeVal.equals("Bill"))
                             {
                             System.out.println("Income Type field shows  " +IncomeTypeVal );
                             extentTest.log(LogStatus.INFO, "Income Type field shows  " +IncomeTypeVal );
                             }
                             else
                             {
                                           String source = aftermthd(Driver);

                                           System.out.println("FAIL: Income Type field  doesnt show -BILL");

                                           extentTest.log(LogStatus.FAIL, "Income Type field  doesnt show -BILL"

                                                                        + extentTest.addScreenCapture("data:image/png;base64," + source));                                    
                             }                           
//Validating Income Status                        
                             String IncomeStatVal              =pageFactSJX.incomeWorkListIncomeStatVal.getAttribute("title");
                             System.out.println("Income Status field shows  " +IncomeStatVal );
                             extentTest.log(LogStatus.INFO, "Income Status field shows  " +IncomeStatVal );                                                       
//Validating Area
                             List<WebElement> incomeAreaVal = pageFactSJX.incomeWorkListAreaVal.findElements(By.className("overflow-doubledecker"));
                             List<WebElement> incomeAreaVal2 = pageFactSJX.incomeWorkListAreaVal.findElements(By.className("overflow"));
                             
                             System.out.println("result Area1 size  " +incomeAreaVal.size() );
                             System.out.println("result Area2 size  " +incomeAreaVal2.size() );
                             if (incomeAreaVal2.size()>0) {
                             for (int i=0; i<incomeAreaVal2.size();i++)
                                           {
        
                                           System.out.println("Area 0  " + incomeAreaVal2.get(0).getText());
                                           //System.out.println("Area 1  " + incomeAreaVal2.get(1).getText());
                                           
                             System.out.println("Income WorkList Area field shows  " +incomeAreaVal2.get(0).getText() );
                             extentTest.log(LogStatus.INFO, "Income WorkList Area field shows  " +incomeAreaVal2.get(0).getText());
                             break;
                                           }
                             }
                             
                             else {
                                           for (int i=0; i<incomeAreaVal.size();i++)
                                           {
        
                                           System.out.println("Area 0 " + incomeAreaVal.get(0).getText());
                                           System.out.println("Area 1 " + incomeAreaVal.get(1).getText());
                             System.out.println("Income WorkList Area field shows  " +incomeAreaVal.get(0).getText()+" "+ incomeAreaVal.get(1).getText());
                             extentTest.log(LogStatus.INFO, "Income WorkList Area field shows  " +incomeAreaVal.get(0).getText()+" "+ incomeAreaVal.get(1).getText() );            
                             break;
                                           }
                             }
                                           
                             
//Validating Section        
                             String incomeSectionVal              =pageFactSJX.incomeWorkListSectionVal.getText();
                             if (!incomeSectionVal.isEmpty()) {
                             System.out.println("Income WorkList Section field shows  " +incomeSectionVal );
                             extentTest.log(LogStatus.INFO, "Income WorkList Section field shows  " +incomeSectionVal );    
                             }
                             
                             else {
                                           System.out.println("Income WorkList Section field shows blank  " +incomeSectionVal );
                                           extentTest.log(LogStatus.INFO, "Income WorkList Section field shows blank  " +incomeSectionVal );             
                             
                             }
//Validating Allowance
                             List<WebElement> incomeAlwVal = pageFactSJX.incomeWorkListAlwVal.findElements(By.className("overflow-doubledecker"));
                             List<WebElement> incomeAlwVal2 = pageFactSJX.incomeWorkListAlwVal.findElements(By.className("overflow"));
                             
                             System.out.println("result alw1 size  " +incomeAlwVal.size() );
                             System.out.println("result alw2 size  " +incomeAlwVal2.size() );
                             if (incomeAlwVal2.size()>0) {
                                           System.out.println ("Inside first if");
                             for (int i=0; i<incomeAlwVal2.size();i++)
                                           {
        
                                           System.out.println("Alw Type   " + incomeAlwVal2.get(0).getText());
                                           //System.out.println("Area 1  " + incomeAlwVal2.get(1).getText());
                                           
                             System.out.println("Income WorkList Allowance field shows  " +incomeAlwVal2.get(0).getText());
                             extentTest.log(LogStatus.INFO, "Income WorkList Allowance field shows  " +incomeAlwVal2.get(0).getText());
                             break;
                                           }
                             }
                             
                             else if (incomeAlwVal.size()>0) {
                                           System.out.println ("Inside second if");
                                           for (int i=0; i<incomeAlwVal.size();i++)
                                           {
        
                                           System.out.println("Itemized section " + incomeAlwVal.get(0).getText());
                                           System.out.println("Header Section " + incomeAlwVal.get(1).getText());
                             System.out.println("Income WorkList Allowance field shows  " +incomeAlwVal.get(0).getText()+" "+ incomeAlwVal.get(1).getText());
                             extentTest.log(LogStatus.INFO, "Income WorkList Allowance field shows  " +incomeAlwVal.get(0).getText()+" "+ incomeAlwVal.get(1).getText() );              
                             break;
                                           }
                             }
                             
                             else
                             {
                                           System.out.println("Income WorkList Allowance field shows Blank " );
                                           extentTest.log(LogStatus.INFO, "Income WorkList Allowance field shows Blank  " );              
                             
                             }
                             //String incomeAlwVal              =pageFactSJX.incomeWorkListAlwVal.getText();
                             //System.out.println("Income WorkList Allowance field shows  " +incomeAlwVal );
                             //extentTest.log(LogStatus.INFO, "Income WorkList Allowance field shows  " +incomeAlwVal ); 
//Validating Offer                          
                             String incomeofferVal              =pageFactSJX.incomeWorkListOfferVal.getText();
                             if (!incomeofferVal.isEmpty()) {
                             System.out.println("Income WorkList offer field shows  " +incomeofferVal );
                             extentTest.log(LogStatus.INFO, "Income WorkList offer field shows  " +incomeofferVal );        
                             }
                             else
                             {
                                           System.out.println("Income WorkList offer field shows blank  " +incomeofferVal );
                                           extentTest.log(LogStatus.INFO, "Income WorkList offer field shows blank  " +incomeofferVal );   
                             
                             }
//Validating Flat Remaining 
                             String incomeFlatRemainVal=              pageFactSJX.incomeWorkListFlatRemainVal.getText();
                                           if (!incomeFlatRemainVal.isEmpty()) {
                             System.out.println("Income WorkList Flat remaining field shows  " +incomeFlatRemainVal );
                             extentTest.log(LogStatus.INFO, "Income WorkList remaining field shows  " +incomeFlatRemainVal );
                             }
                             else {
                                           System.out.println("Income WorkList Flat remaining field shows  blank "  );
                                           extentTest.log(LogStatus.INFO, "Income WorkList remaining field shows blank  "  );
                             
                             }
              
//Validating Dialog                        
                             String incomeDialogVal =pageFactSJX.incomeWorkListDialogVal.getText();
                             System.out.println("Income WorkList Dialog field shows  " +incomeDialogVal );
                             extentTest.log(LogStatus.INFO, "Income WorkList Dialog field shows  " +incomeDialogVal );                    
                             return null;
              }


              public String scrollDownReady(WebDriver Driver) {

                             // pageFactJS3.allwTab(Driver);

                             Actions act = new Actions(Driver);
                             act.moveToElement(pageFactSJIX.ready).perform();
                             return null;
              }

              public String waitforbrtxt(WebDriver Driver) {

                             WebDriverWait wait = new WebDriverWait(Driver, 60);
                     wait.until(ExpectedConditions.elementToBeClickable(pageFactSJIX.BRtxt));
                             return null;
              }

              @BeforeTest
              public void beforeTest(WebDriver Driver) {
                             pageFact = new GenericFactory(Driver);
                             pageFactSJIX = new GenericFactorySJIX(Driver);
                             pageFactSJX = new GenericFactorySJX(Driver);
                             pageFactSJVIII = new GenericFactorySJVIII(Driver);
                             pageFactSJVI = new GenericFactorySJVI(Driver);
                             
              }

}
