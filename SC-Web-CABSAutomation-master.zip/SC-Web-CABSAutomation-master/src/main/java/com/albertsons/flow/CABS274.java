package com.albertsons.flow;

 
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-223
 * 
 * @author ssubr13
 *
 */

public class CABS274 extends ExtendBaseClass {

	WebDriver Driver;
 
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}

	@Test(priority = 1, enabled = true)
	public void CABS_274all() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-274 Execution started");

		PO.wait_forBlngbtn();
		PO.BillClick();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-274 Execution Completed");
		 
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 2 - CABS-274",
				"Verify MISC Action Bar");
		extentTest.log(LogStatus.INFO, "Browser Launched");
		// extentTest.log(LogStatus.INFO, "Navigated to CABS home page");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
