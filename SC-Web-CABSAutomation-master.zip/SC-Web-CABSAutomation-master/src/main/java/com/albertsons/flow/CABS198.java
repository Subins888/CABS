package com.albertsons.flow;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-198
 * 
 * @author AKUMA58
 *
 */
public class CABS198 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {
		PO.waitforelement();
		PO.Login();
	}

	// Verify user is able to see Create BR modal after clicking 'Create Billing
	// Record' button
	@Test(priority = 1, enabled = true)
	public void CABS_469() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-469 Execution started");
		PO.wait_forBlngbtn();
		// PO.billingDrpdwn();
		PO.createBRModal();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-469 Execution Completed");
	}

	// Verify user is able to choose Non Allowance billing type
	@Test(priority = 2, enabled = true)
	public void CABS_472() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS_472 Execution started");

		PO.NonAllowance();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS_472 Execution Completed");
	}

	// Verify Account Lookup Type values of Non Allowance billing type
	@Test(priority = 3, enabled = true)
	public void CABS_474() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS_474 Execution started");

		PO.AccountValue();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS_474 Execution Completed");

	}

	// Verify whether clicking 'X' closes the modal.

	@Test(priority = 4, enabled = true)
	public void CABS_490() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS_490 Execution started");
		PO.closebTn();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS_490 Execution Completed");
	}

	// Verify Account look up value is mandatory if Account look up type is
	// selected
	@Test(priority = 5, enabled = true)
	public void CABS_514() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS_514 Execution started");
		PO.AcntlukMand();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS_514 Execution Completed");
		Thread.sleep(3000);

	}

	// Verify whether clicking Submit button takes the user to create billing
	// main page
	@Test(priority = 6, enabled = true)
	public void CABS_498() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS_498 Execution started");

		PO.closebtnclk();
		// pageFact.creatBillng();
		// pageFact.blngrcrdDrp();
		// Thread.sleep(5000);
		// pageFact.nonAllwdrp();
		// pageFact.submitClk();

		PO.newBR();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS_498 Execution Completed");
		Thread.sleep(3000);

	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 1 - CABS-198", "Verify  ");
		extentTest
				.log(LogStatus.INFO, "Headless browser successfully launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
