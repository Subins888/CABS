package com.albertsons.flow;

 
import java.io.IOException;

 
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-223
 * 
 * @author akuma58
 *
 */
public class CABS223 extends ExtendBaseClass {

	WebDriver Driver;
	
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify whether valid error messages appearing when clicking Save button
	// without filling the mandatory information
	@Test(priority = 1, enabled = true)
	public void CABS_619() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-619 Execution started");

		PO.NonAlwnceBR();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-619 Execution Completed");
		 
	}

	// Verify all the fields for the billing record have valid values
	@Test(priority = 2, enabled = true)
	public void CABS_625() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-625 Execution started");

		PO.nonAlwnceBR();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-625 Execution Completed");
		 
	}

	// Offset Number validation, CABS-637,638 Handled here
	@Test(priority = 3, enabled = true)
	public void CABS_636() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-636 Execution started");

		PO.offsetnumErr();
		PO.offsetnumSucc();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-636 Execution Completed");

	}

	// Verify the Assign To drop down validation
	@Test(priority = 4, enabled = true)
	public void CABS_639() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-639 Execution started");

		PO.asingTotest();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-636 Execution Completed");

	}

	// Verify the BR status after clicking the Save button (CABS-642, also
	// handled)
	@Test(priority = 5, enabled = true)
	public void CABS_640() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-640 Execution started");

		PO.brStatuscChk();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-640 Execution Completed");
	}

	// Verify the Error/Success message on header after successful save of
	// Billing Record
	@Test(priority = 6, enabled = true)
	public void CABS_643() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-643 Execution started");

		PO.newBRsuccmsg();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-643 Execution Completed");
	}
	
	@Test(priority = 7, enabled = true)
	public void CABS_641() throws IOException, InterruptedException {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-641 Execution started");
		
		PO.getbilngRcrdId();
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-641 Execution Completed");
	}
	

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();
		extentTest = extent.startTest("Sprint 2 - CABS-223",
				"Billing Record header - Save( non-allowance )  ");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
