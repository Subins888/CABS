package com.albertsons.flow;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-278
 * 
 * @author akuma58
 *
 */

public class CABS278 extends ExtendBaseClass {

	WebDriver Driver;
 
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify whether the design is same as per the Invision
	@Test(priority = 1, enabled = true)
	public void CABS_707() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-707 Execution started");

		PO.newBrform();
		PO.income();
		PO.incmeRadio();
		// PO.incmDescr();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-707 Execution Completed");
	}

	// Verify whether the user can delete items from income section
	@Test(priority = 2, enabled = true)
	public void CABS_705() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-705 Execution started");

		PO.incmDescr();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-705 Execution Completed");
	}

	// Verify user with ‘Bill/Accrue bIlling record’ rights,can add misc income
	// under income section
	@Test(priority = 3, enabled = true)
	public void CABS_659() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-659 Execution started");

		PO.incmebTns();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-659 Execution Completed");
	}

	// Verify whether the system is calculating the sum of all the amount from
	// income section
	//NOT DONE
	@Test(priority = 4, enabled = true)
	public void CABS_706() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-706 Execution started");
		
		
		PO.incomeSum();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-706 Execution Completed");
	 
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {

		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 2 - CABS-278", "Verify  ");
		extentTest
				.log(LogStatus.INFO, "Headless browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
