package com.albertsons.flow;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import java.io.IOException;
import java.text.ParseException;

 
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-202
 * 
 * @author AKUMA58
 *
 */

public class CABS202 extends ExtendBaseClass {

	WebDriver Driver;

	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify whether the Billing Header Alignment and Layout as per the
	// Invision design
	@Test(priority = 1, enabled = true)
	public void CABS_649() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-649 Execution started");

		PO.newBR();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-649 Execution Completed");
	 
	}

	// Verify the 'BR Status' drop down field values in billing record header
	// for Non- Allowance
	@Test(priority = 2, enabled = true)
	public void CABS_652() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-652 Execution started");

		PO.newBRSave();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-652 Execution Completed");
	 
	}

	// Verify the 'Account Lookup Type' drop down field and the values for Misc
	@Test(priority = 3, enabled = true)
	public void CABS_654() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-654 Execution started");

		PO.acntlukup();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-654 Execution Completed");
	 
	}

	// Verify whether the 'Assign To' field list all the department users for
	// Allowance

	@Test(priority = 4, enabled = true)
	public void CABS_655() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-655 Execution started");

		PO.assignTodrp();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-655 Execution Completed");
		 
	}

	// Verify whether all the fields are available and all the values are
	// properly displaying for Non-Allowance BR
	@Test(priority = 5, enabled = true)
	public void CABS_658() throws IOException, InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-658 Execution started");

		PO.nonAlwnceBR();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-658 Execution Completed");
	 
	}

	// Verify whether all the fields are available and all the values are
	// properly displaying for Allowance BR
	@Test(priority = 6, enabled = false)
	public void CABS_657() throws IOException, InterruptedException,
			ParseException, BiffException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-658 Execution started");

		PO.AlwnceBR();
		Thread.sleep(5000);
		PO.nonAlwnceBR();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-658 Execution Completed");
	 
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {

		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 2 - CABS-202",
				"Billing Record header - layout  ");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
