package com.albertsons.flow;

import java.util.HashMap;
import java.util.Map;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CABS2685 {

	private WebDriver driver;

	private Map<String, Object> vars;
	JavascriptExecutor js;

	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				new File(System.getProperty("user.dir"), "chromedriverWin.exe")
						.getAbsolutePath());

		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		vars = new HashMap<String, Object>();
	}

	@AfterTest
	public void tearDown() {
		// driver.quit();
	}

	public String waitForSpinnerToBeGone() {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}

	@Test
	public void uATBugAPErrorIncomeSection() throws InterruptedException {
		driver.get("https://pabs-qa.safeway.com/pabs/static/home");
		driver.manage().window().maximize();

		WebDriverWait wait = new WebDriverWait(driver, 100);

		driver.findElement(By.id("inputUsername")).click();
		driver.findElement(By.id("inputUsername")).sendKeys("PAQ00BS");
		driver.findElement(By.id("inputPassword")).click();
		driver.findElement(By.id("inputPassword")).sendKeys("Pass@123");
		driver.findElement(By.name("LogIn")).click();

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		WebElement createBR = wait
				.until(ExpectedConditions.elementToBeClickable(By
						.xpath("//*[contains(text(), 'Create Billing Record')]")));
		createBR.click();
		// Thread.sleep(3000);

		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		
		waitForSpinnerToBeGone();		
		Thread.sleep(5000);
		driver.findElement(
				By.cssSelector("#billingRecordType .ng-arrow-wrapper")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.id("ta-billingRecordType-0")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		Thread.sleep(1000);
		driver.findElement(
				By.cssSelector("#accountLookupValue .ng-arrow-wrapper"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.id("ta-accountLookupValue-0")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector("#textvalue > #leadCIC")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector("#textvalue > #leadCIC")).sendKeys(
				"1010112");
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector(".col-3:nth-child(1) .fa")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(
				By.cssSelector(".ngb-dp-week:nth-child(2) > .ngb-dp-day:nth-child(2) > .btn-light"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector(".ng-untouched > .form-group .btn"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(
				By.cssSelector(".ngb-dp-week:nth-child(2) > .ngb-dp-day:nth-child(4) > .btn-light"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector(".post-dollar")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		WebElement headerFlatAmount = driver.findElement(By
				.cssSelector(".post-dollar"));
		headerFlatAmount.sendKeys("100");
		Thread.sleep(2000);
		driver.findElement(
				By.cssSelector("#flatCode > div > div > div.ng-input > input[type=text]"))
				.click();
		Thread.sleep(1000);
		driver.findElement(By.id("ta-flatCode-0")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector(".btn-action")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		Thread.sleep(25000);
		WebElement billingName = wait.until(ExpectedConditions
				.elementToBeClickable(By
						.cssSelector("#textvalue > #deductInvoiceNumber")));
		billingName.click();

		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));
		billingName.sendKeys("1234");
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		Thread.sleep(3000);
		driver.findElement(By.cssSelector(".btn-action")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));

		waitForSpinnerToBeGone();
		js.executeScript("window.scrollTo(0,0)");

		waitForSpinnerToBeGone();
		Thread.sleep(60000);
		driver.findElement(
				By.cssSelector("#allow-income-tab > .col-1 .feather")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		// js.executeScript("window.scrollTo(0,0)");

		waitForSpinnerToBeGone();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".smallFont > .checkmark")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		driver.findElement(By.cssSelector(".btn-warning-small:nth-child(2)"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		{
			WebElement element = driver.findElement(By
					.cssSelector(".income-btn > .btn"));
			Actions builder = new Actions(driver);
			builder.moveToElement(element).perform();
		}
		{
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(loadingImage));
			Thread.sleep(10000);
			WebElement element = driver.findElement(By
					.cssSelector(".cols-danger"));
			Actions builder = new Actions(driver);
			builder.moveToElement(element).perform();
		}
		{
			WebElement element = driver.findElement(By.tagName("body"));
			Actions builder = new Actions(driver);
			builder.moveToElement(element, 0, 0).perform();
		}
		driver.findElement(By.cssSelector(".cols-danger")).click();
		{
			WebElement element = driver.findElement(By
					.cssSelector(".btn-error-circle"));
			Actions builder = new Actions(driver);
			builder.moveToElement(element).perform();
		}
		{
			WebElement element = driver.findElement(By.tagName("body"));
			Actions builder = new Actions(driver);
			builder.moveToElement(element, 0, 0).perform();
		}
		driver.findElement(By.cssSelector("#textvalue > #deductInvoiceNumber"))
				.click();
		WebElement billingName2 = driver.findElement(By
				.cssSelector("#textvalue > #deductInvoiceNumber"));
		billingName2.clear();
		billingName2.sendKeys("793");
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));

		waitForSpinnerToBeGone();
		Thread.sleep(1000);
		waitForSpinnerToBeGone();
		driver.findElement(By.cssSelector(".col-12 > primary-button > .btn"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		Thread.sleep(3000);
		waitForSpinnerToBeGone();
		
		driver.findElement(By.cssSelector(".smallFont > .checkmark")).click();
		driver.findElement(By.cssSelector(".btn-warning-small:nth-child(2)"))
				.click();
		js.executeScript("window.scrollTo(0,0)");
		
		waitForSpinnerToBeGone();
		driver.findElement(
				By.cssSelector("#allowance-history-tab > .col-1 .feather"))
				.click();
		// check whether invoice has been created
		int size = driver
				.findElements(
						By.cssSelector("cabs-income-history-grid .datatable-body .datatable-row-center"))
				.size();
		Assert.assertEquals(size, 1);

	}
}
