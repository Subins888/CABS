package com.albertsons.flow;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import org.testng.annotations.BeforeTest;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.ITestResult;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

/**
 * User Story: CABS-194 Home Page and navigation
 * 
 * @author AKUMA58
 *
 */
public class CABS194 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}

	/**
	 * 
	 * @return
	 */
	public String placeHolder() {

		String txt = pageFact.home_bread.getText();
		if (txt.contains("Home")) {
			System.out.println("Placeholder displaying for main content");
			extentTest.log(LogStatus.INFO,
					"Placeholder displaying for main content");
		} else {
			System.out.println("Placeholder not displaying for main content");
			extentTest.log(LogStatus.FAIL,
					"Placeholder not displaying for main content");
			Assert.assertTrue(txt.contains("Home"));
		}
		return null;

	}

	/**
	 * Test Case: CABS-313 Verify whether user able to view the home page after
	 * successful login
	 * 
	 * @throws InterruptedException
	 */
	@Test(priority = 1, enabled = true)
	public void CABS_313() throws InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-313 Execution started");

		PO.wait_forHome();
		PO.home_page();
	}

	/**
	 * Test Case: CABS-314 Verify whether the Home page layout same as per the
	 * mockup design
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 2, enabled = true)
	public void CABS_314() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-314 Execution started");
		extentTest.log(LogStatus.INFO, "Screenshot of CABS application taken");
		// PO.wait_forHome();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-314 Execution completed");
		 
	}

	/**
	 * Test Case: CABS-325 Verify whether the Home page layout same as per the
	 * mockup design.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 3, enabled = true)
	public void CABS_325() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-325 Execution started");

		// PO.wait_forHome();
		PO.home_pageII();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-325 Execution completed");
	}

	/**
	 * Test Case: CABS-315 Verify whether the header portion of the home page
	 * has CABS logo and heading ‘Centralized Accounting Billing System’.
	 * 
	 * @throws InterruptedException
	 */
	@Test(priority = 4, enabled = true)
	public void CABS_315() throws InterruptedException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-315 Execution started");

		// PO.wait_forHome();
		PO.Title_Check();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-315 Execution completed");
	}

	/**
	 * Test Case: CABS-323 Verify the Top right side for hamburger menu with
	 * logout link.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 5, enabled = false)
	public void CABS_323() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-323 Execution started");

		// PO.wait_forHome();
		//PO.log_Out();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-323 Execution completed");

	}

	/**
	 * Test Case: CABS-324 Verify whether the left side of the page contains a
	 * side bar.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 6, enabled = true)
	public void CABS_324() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-324 Execution started");

		// PO.wait_forHome();
		PO.leftBtn();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-324 Execution completed");

	}

	/**
	 * Test Case: CABS-329 Verify whether the left side of the page contains a
	 * side bar.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 7, enabled = true)
	public void CABS_329() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-329 Execution started");

		// PO.wait_forHome();
		PO.placeHolder();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-329 Execution Completed");	
	}

	/**
	 * Test Case: CABS-328 Verify the tooltip with description of the Worklist
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 8, enabled = false)
	public void CABS_328() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-328 Execution started");

		// PO.wait_forHome();
		// PO.toolTip();

		Actions ToolTip1 = new Actions(Driver);
		WebElement googleLogo = Driver
				.findElement(By
						.xpath("//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[1]/span/img"));

		Thread.sleep(2000);
		ToolTip1.clickAndHold(googleLogo).perform();

		String ToolTipText = googleLogo.getAttribute("title");

		Assert.assertEquals(ToolTipText, "Google");

		Thread.sleep(2000);
		System.out.println("Tooltip value is: " + ToolTipText);

//		extentReportImage194_3 = System.getProperty("user.dir") + "\\picture"
//				+ "\\extentReportImage194_3.png";
//		File source = PO.aftermthd();
//
//		File destination = new File(extentReportImage194_3);
//		FileUtils.copyFile(source, destination);
//		extentTest.log(
//				LogStatus.INFO,
//				"Snapshot : "
//						+ extentTest.addScreenCapture(extentReportImage194_3));
	}

	/**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 */
	@BeforeTest
	public void b4Test() throws InterruptedException {

		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 0 - CABS-194",
				"Verify Home Page screen");
		extentTest
				.log(LogStatus.INFO, "Headless browser successfully launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
