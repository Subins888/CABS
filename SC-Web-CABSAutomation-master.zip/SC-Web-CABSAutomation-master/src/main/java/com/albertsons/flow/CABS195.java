package com.albertsons.flow;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-278
 * 
 * @author AKUMA58
 *
 */

public class CABS195 extends ExtendBaseClass {

	WebDriver Driver;

	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Check the UI location of the Department - Team drop down list
	@Test(priority = 1, enabled = true)
	public void CABS_400() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-400 Execution started");
		PO.dept();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-400 Execution Completed");
	}

	// Verify the department - team drop down list contains the description of
	// departments and teams the user has access to.
	@Test(priority = 2, enabled = true)
	public void CABS_401() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-401 Execution started");
		PO.deptContentDescr();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-401 Execution Completed");
	}

	// Verify which department/team selected by default in the drop down [if the
	// user has access to only one Department and Team]
	@Test(priority = 3, enabled = true)
	public void CABS_402() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-402 Execution started");
		PO.deptContent();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-402 Execution Completed");
	}

	// Verify whether user can associated with multiple department/team.
	@Test(priority = 4, enabled = true)
	public void CABS_403() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-403 Execution started");
		PO.multDept();
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-403 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();
		extentTest = extent.startTest("Sprint 1 - CABS-195", "Verify  ");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
