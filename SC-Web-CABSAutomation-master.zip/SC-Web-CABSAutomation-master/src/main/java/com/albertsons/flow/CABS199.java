package com.albertsons.flow;

import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

import org.testng.annotations.BeforeTest;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;

/**
 * User Story: CABS-199 Create Billing Record Modal - Retail allowance
 * 
 * @author JMAYA09
 *
 */
public class CABS199 extends ExtendBaseClass {

	WebDriver Driver;

	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {
		PO.waitforelement();
		PO.Login();
	}

	/**
	 * Test Case: CABS-464 Verify user is able to see Create BR modal after
	 * clicking 'Create Billing Record' button
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws AWTException
	 */

	@Test(priority = 1, enabled = true)
	public void cabs464() throws InterruptedException, IOException,
			AWTException {
		PO.wait_forHome();
		PO.wait_forBlngbtn();
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-464 Execution started");
		System.out.println("Test Case - CABS-464 Execution started");
		PO.createBRModal();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-464 Execution completed");
		System.out.println("Test Case - CABS-464 Execution completed");
	}

	/**
	 * Test Case: CABS-470 Verify user is able to choose Retail Allowance
	 * billing type
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 2, enabled = true)
	public void cabs470() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-470 Execution started");
		System.out.println("Test Case - CABS-470 Execution started");
		PO.bRTypeRetail();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-470 Execution completed");
		System.out.println("Test Case - CABS-470 Execution completed");
	}

	/**
	 * Test Case: CABS-475 Verify user gets error message if he doesn't enter
	 * all the mandatory fields
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	@Test(priority = 3, enabled = true)
	public void cabs475() throws InterruptedException, IOException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-475 Execution started");
		System.out.println("Test Case - CABS-475 Execution started");
		PO.bRTypeRetailMandFields();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-475 Execution completed");
		System.out.println("Test Case - CABS-475 Execution completed");
	}

	/**
	 * Test Case: CABS-476 Verify user gets error message if he doesn't enter
	 * any of the mandatory fields
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws BiffException 
	 */
	@Test(priority = 12, enabled = true)
	public void cabs476() throws InterruptedException, IOException,
			ParseException, BiffException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-476 Execution started");
		System.out.println("Test Case - CABS-476 Execution started");
		PO.bRTypeRetailAnyMandFields();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-476 Execution completed");
		System.out.println("Test Case - CABS-476 Execution completed");
	}

	/**
	 * Test Case: CABS-471 Verify Account Lookup Type,offer number, division,
	 * lead CIC ,and date fields of Retail Allowance billing type
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws BiffException 
	 */
	@Test(priority = 4, enabled = true)
	public void cabs471() throws InterruptedException, IOException,
			ParseException, BiffException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-471 Execution started");
		System.out.println("Test Case - CABS-471 Execution started");
		PO.bRTypeRetailFields();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-471 Execution completed");
		System.out.println("Test Case - CABS-471 Execution completed");
	}

	/**
	 * 
	 * Test Case: CABS-477 Verify header section of Retail Allowance billing
	 * type
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 5, enabled = true)
	public void cabs477() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-477 Execution started");
		System.out.println("Test Case - CABS-477 Execution started");
		PO.bRTypeRetailHeader();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-477 Execution completed");
		System.out.println("Test Case - CABS-477 Execution completed");
	}

	/**
	 * 
	 * Test Case: CABS-478 Verify itemized section of Retail Allowance billing
	 * type
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 6, enabled = true)
	public void cabs478() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-478 Execution started");
		System.out.println("Test Case - CABS-478 Execution started");
		PO.bRTypeRetailItemized();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-478 Execution completed");
		System.out.println("Test Case - CABS-478 Execution completed");
	}

	/**
	 * 
	 * Test Case: CABS-479 Verify Performance 1 & Performance 2 of Retail
	 * Allowance billing type for Allowance Type "T"
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 7, enabled = true)
	public void cabs479() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-479 Execution started");
		System.out.println("Test Case - CABS-479 Execution started");
		PO.allwTypeT();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-479 Execution completed");
		System.out.println("Test Case - CABS-479 Execution completed");
	}

	/**
	 * 
	 * Test Case: CABS-480 Verify Performance 1 & Performance 2 of Retail
	 * Allowance billing type for Allowance Type "S"
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 8, enabled = true)
	public void cabs480() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-480 Execution started");
		System.out.println("Test Case - CABS-480 Execution started");
		PO.allwTypeS();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-480 Execution completed");
		System.out.println("Test Case - CABS-480 Execution completed");
	}

	/**
	 * Test Case: CABS-481 Verify Performance 1 & Performance 2 of Retail
	 * Allowance billing type for Allowance Type "A"
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 9, enabled = true)
	public void cabs481() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-481 Execution started");
		System.out.println("Test Case - CABS-481 Execution started");
		PO.allwTypeA();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-481 Execution completed");
		System.out.println("Test Case - CABS-481 Execution completed");
	}

	/**
	 * 
	 * Test Case: CABS-482 Verify Performance 1 & Performance 2 of Retail
	 * Allowance billing type for Allowance Type "C"
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 10, enabled = true)
	public void cabs482() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-482 Execution started");
		System.out.println("Test Case - CABS-482 Execution started");
		PO.allwTypeC();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-482 Execution completed");
		System.out.println("Test Case - CABS-482 Execution completed");
	}

	/**
	 * Test Case: CABS-484 Verify "Clear" button clears all the entered value
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 11, enabled = true)
	public void cabs484() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-484 Execution started");
		System.out.println("Test Case - CABS-484 Execution started");
		PO.clear();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-484 Execution completed");
		System.out.println("Test Case - CABS-484 Execution completed");
	}

	/**
	 * Test Case: CABS-483 Verify "X" closes the BR modal pop up
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 */
	@Test(priority = 13, enabled = true)
	public void cabs483() throws InterruptedException, IOException,
			ParseException, AWTException {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-483 Execution started");
		System.out.println("Test Case - CABS-483 Execution started");
		PO.close();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-483 Execution completed");
		System.out.println("Test Case - CABS-483 Execution completed");
	}

	/**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 */
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 1 - CABS-199",
				"Create Billing Record Modal - Retail allowance");
		extentTest.log(LogStatus.INFO, "Browser Launched");
		// extentTest.log(LogStatus.INFO, "Navigated to CABS home page");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
