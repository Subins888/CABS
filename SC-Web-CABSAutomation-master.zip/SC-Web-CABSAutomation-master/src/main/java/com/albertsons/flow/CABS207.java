package com.albertsons.flow;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-207 CABS Smart Dropdowns
 * 
 * @author JMAYA09
 *
 */

public class CABS207 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {
		PO.waitforelement();
		PO.Login();
	}

	/**
	 * Test Case: CABS-312 Verify in CABS Smart Dropdowns, user can filter value
	 * based on the typed characters
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	@Test(priority = 1, enabled = true)
	public void CABS_312() throws InterruptedException, IOException {
		PO.wait_forHome();
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-312 Execution started");
		System.out.println("Test Case - CABS-312 Execution started");
		PO.smart_drpDwns();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-312 Execution completed");
		System.out.println("Test Case - CABS-312 Execution completed");
	}

	/**
	 * Test Case: CABS-317 Verify when the user filter in Smart
	 * Dropdowns,filtered values shown must be sorted in alphabetical order
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 2, enabled = true)
	public void CABS_317() throws InterruptedException, IOException {
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-317 Execution started");
		System.out.println("Test Case - CABS-317 Execution started");
		PO.smrt_drpDwn_Sort();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-317 Execution completed");
		System.out.println("Test Case - CABS-317 Execution completed");
	}

	/**
	 * Test Case: CABS-318 Verify when user refresh the page, typed character in
	 * the Smart Dropdown must be cleared
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 3, enabled = true)
	public void CABS_318() throws InterruptedException, IOException {
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-318 Execution started");
		System.out.println("Test Case - CABS-318 Execution started");
		PO.smrt_drpDwn_refresh();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-318 Execution completed");
		System.out.println("Test Case - CABS-318 Execution completed");
	}

	/**
	 * Test Case: CABS-319 Verify whether all the values are listing or not, if
	 * user clear the Search box filter
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Test(priority = 4, enabled = true)
	public void CABS_319() throws InterruptedException, IOException {
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-319 Execution started");
		System.out.println("Test Case - CABS-319 Execution started");
		PO.smrt_drpDwn_clear();
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-319 Execution completed");
		System.out.println("Test Case - CABS-319 Execution completed");
	}

	/**
	 * Test Case: CABS-320 Verify whether the user is able to scroll up and down
	 * the drop down to see values
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@Test(priority = 5, enabled = true)
	public void CABS_320() throws IOException, InterruptedException {
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-320 Execution started");
		System.out.println("Test Case - CABS-320 Execution started");
		PO.smrt_drpDwn_scroll();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-320 Execution completed");
		System.out.println("Test Case - CABS-320 Execution completed");
	}

	/**
	 * Test Case: CABS-321 Verify user is able to use up and down keys to go up
	 * and down listed values and select a value using 'Enter' key.
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@Test(priority = 6, enabled = true)
	public void CABS_321() throws IOException, InterruptedException {
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-321 Execution started");
		System.out.println("Test Case - CABS-321 Execution started");
		PO.smrt_drpDwn_key();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-321 Execution completed");
		System.out.println("Test Case - CABS-321 Execution completed");
	}

	/**
	 * Test Case: CABS-338 Verify in CABS Smart Dropdowns, user can paste the
	 * copied value and filter the result
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@Test(priority = 7, enabled = false)
	public void CABS_338() throws IOException, InterruptedException {
		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-338 Execution started");
		System.out.println("Test Case - CABS-338 Execution started");
		PO.smrt_drpDwn_CopyPaste();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-338 Execution completed");
		System.out.println("Test Case - CABS-338 Execution completed");
	}

	/**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 */
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		extentTest = extent.startTest("Sprint 0 - CABS-207",
				"Verify Smart Drop Down");
		extentTest.log(LogStatus.INFO, "Browser Launched");
		// extentTest.log(LogStatus.INFO, "Navigated to CABS home page");

	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
