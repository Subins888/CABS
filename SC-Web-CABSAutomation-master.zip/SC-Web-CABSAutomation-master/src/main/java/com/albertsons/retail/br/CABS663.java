package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS663 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	/**
	 * User Story: CABS-663 Add Items - Search by UPC( Retail )
	 * 
	 * @author akuma58
	 *
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	//Verify whether the item details are listed properly while entering the valid UPC
	@Test(priority = 1, enabled = true)
	public void CABS1280() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1280 Execution started");

		POIV.AlwnceBRIV(Driver);
		POV.UPC(Driver);
		POV.searchUPC(Driver);
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1280 Execution Completed");
	}
	
	//Verify whether the item details are not listing while entering the invalid UPC
	@Test(priority = 2, enabled = true)
	public void CABS1281() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1281 Execution started");

	 
		POV.invalidUPC(Driver);
		
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1281 Execution Completed");
	}
	
	//Verify the duplicate UPC/Item records is added for UPC
	@Test(priority = 3, enabled = true)
	public void CABS1282() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1282 Execution started");

	 
		POV.duplicateUPC(Driver);
		
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1282 Execution Completed");
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-663",
				"Add Items - Search by UPC( Retail )");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
