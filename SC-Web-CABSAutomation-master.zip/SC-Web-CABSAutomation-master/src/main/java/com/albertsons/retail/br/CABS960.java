package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import jxl.read.biff.BiffException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pageobjects.pageObjectsJSprint4;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS960 extends ExtendBaseClass {
	  WebDriver Driver;

	    PageObjects PO = new PageObjects(Driver);
	    PageObjectsIV POIV = new PageObjectsIV(Driver);
	    pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	    pageObjectsJSprint4 POS4 = new pageObjectsJSprint4(Driver);

	    GenericFactory pageFact = new GenericFactory(Driver);
	    ITestResult result;
	 /**
	    * Login Functionality
	    * 
	     * @throws Exception
	    */
	    @Test(priority = 0, enabled = true)
	    public void ABS_Login() throws Exception {

	    //           PO.waitforelement();
	                   PO.Login();

	    }
	    
	    /**
	     * Test Case: CABS-1047 Verify whether the Text box around cost in Item details will be removed or not	
	     * @throws InterruptedException
	     * @throws IOException
	     * @throws ParseException
	     * @throws AWTException
	     * @throws BiffException
	     */	     
	    
	     @Test(priority = 1, enabled = true)
	     public void CABS1047() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

	   
	                    extentTest.log(LogStatus.INFO, "Test Case - CABS-1047 Execution started");	                   
	                    PO.AlwnceBR();
	     
	                    POS3.wait_forBRPage(Driver);
	                    Thread.sleep(3000);
	                    POS4.itemizedChkBox(Driver);
	                    
	                    POS4.clickable(Driver);
	                    
	                    

	                    extentTest.log(LogStatus.INFO, "Test Case - CABS-1047 Execution completed");
	                  
	     }
	    
	    
	    @BeforeTest
	    public void beforeTest() throws InterruptedException, IOException {
	                   Driver = PO.beforeTest();
	                   POS4.beforeTest(Driver);
	                   POS3.beforeTest(Driver);
	                   POIV.beforeTest(Driver);
	                   extentTest = extent.startTest("Sprint 4 - CABS-960", "UI change - Remove text box around cost in Item details");
	                   extentTest.log(LogStatus.INFO, "Browser Launched");
	    }
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
