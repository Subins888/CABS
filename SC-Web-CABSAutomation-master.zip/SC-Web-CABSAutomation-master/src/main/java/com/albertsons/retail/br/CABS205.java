package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS205 extends ExtendBaseClass {
	
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	ITestResult result;
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify whether user is getting error message if AP/AR number entered is an invalid account number
		@Test(priority = 1, enabled = true)
		public void CABS1079() throws Exception {

			extentTest
			.log(LogStatus.INFO, "Test Case - CABS-1079 Execution started");			
			
			POIV.AlwnceBR2(Driver);
			POIV.deductInvoice(Driver);
			 			
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1079 Execution Completed");
		}
		
		//Verify billing name is auto-populated based on AP/AR number and vice versa
		@Test(priority = 2, enabled = true)
		public void CABS1081() throws Exception {

			extentTest
			.log(LogStatus.INFO, "Test Case - CABS-1081 Execution started");
			
			POIV.deductInvoiceValid(Driver);
			
			
 			
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1081 Execution Completed");
		}
	
	  @BeforeTest
	  public void beforeTest() throws InterruptedException {
		  Driver =  PO.beforeTest();
			 PO3.beforeTest(Driver);
			 POIV.beforeTest(Driver);
				extentTest = extent.startTest("Sprint 4 - CABS-205",
						"Billing Record header - AP, AR, Billing Name fields");
				extentTest.log(LogStatus.INFO, "Browser successfully launched");
	  }


 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
