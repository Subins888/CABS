package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS662 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	/**
	 * User Story: CABS-662 Add Items - Delete item row
	 * 
	 * @author akuma58
	 *
	 */
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Delete item row-The trash icon must be enabled for users with Create
	// Billing Record right
	// CABS1288 handled here
	@Test(priority = 1, enabled = true)
	public void CABS1287() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1287 Execution started");

		POIV.AlwnceBRIV(Driver);
		POV.trashDelete(Driver);
		POV.brSaveAllwnc(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1287 Execution Completed");
	}
	
	// Delete item row-The trash icon must be enabled for users with Edit Others
		// Billing Record right
		// CABS1295 handled here
		@Test(priority = 2, enabled = true)
		public void CABS1294() throws Exception {

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1294 Execution started");

			POV.teamChangeII(Driver);
			POV.trashDeleteII(Driver);
			POV.trashDelete(Driver);

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1294 Execution Completed");
		}
	// Delete item row- Click The trash icon
	@Test(priority = 3, enabled = true)
	public void CABS1296() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1296 Execution started");

		POV.trashDeleteClk(Driver);
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1296 Execution Completed");
	}

	

	// Delete item row- itemized income after deleting Items
	@Test(priority = 4, enabled = true)
	public void CABS1297() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1297 Execution started");

		POV.trashIncome(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1297 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-662",
				"Add Items - Delete item row");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
