package com.albertsons.retail.br;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS467  extends ExtendBaseClass{
	
	WebDriver Driver;
	String extentReportImage369_1;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify Allowance Income Section - Add income flat & Itemized section
	@Test(priority = 1, enabled = true)
	public void CABS1046() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1046 Execution started");
		
		POIV.AlwnceBRNoItemizd(Driver);	
		POIV.BRSave(Driver);
		POIV.BRSaveNewReady(Driver);
		
//		Thread.sleep(20000);
//		Driver.findElement(By.xpath("//*[@id='allow-tab']/div[1]/i-feather")).click();
 		 
//		POIV.dropSize(Driver);
		
		   
		POIV.incomeAddClk(Driver);
		Thread.sleep(3000);
	 	POIV.chckBox(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1046 Execution Completed");
	}
	
	//Verify Allowance Income Section - Add income flat & Itemized-Save and submit
	@Test(priority = 2, enabled = true)
	public void CABS1049() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1049 Execution started");
		
		POIV.itemQtyAmntII(Driver);	 
		POIV.incomeSave(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1049 Execution Completed");
	}
	
	//Verify Allowance Income Section - Add income flat & Itemized-Submit
	@Test(priority = 3, enabled = true)
	public void CABS1050() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1050 Execution started");
		
		POIV.incomeSubmit(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1050 Execution Completed");
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();
 
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 4 - CABS-467",
				"Offset # validation for Allowance BR");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
