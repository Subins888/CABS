package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pageobjects.pageObjectsJSprint4;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-453 Allowance Income Section - Add income flat only
 * 
 * @author U82703
 *
 */
public class CABS453 extends ExtendBaseClass {

	WebDriver Driver;

	PageObjects PO = new PageObjects(Driver);
	pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	pageObjectsJSprint4 POS4 = new pageObjectsJSprint4(Driver);

	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

	//	PO.waitforelement();
		PO.Login();

	}

	/**
	 * Test Case: CABS-1082 Allowance Income Section-Verify Header flat income checkbox with flat remaining>0
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 1, enabled = true)
	public void cabs1082() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

	//	PO.wait_forHome();
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1082 Execution started");
		System.out.println("Test Case - CABS-1082 Execution started");
		PO.AlwnceBR2();
	
		POS3.wait_forBRPage(Driver);
		Thread.sleep(1000);
		POS4.headrFlatChkBox(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1082 Execution completed");
		System.out.println("Test Case - CABS-1082 Execution completed");
	}
/**
 * 	Test Case: CABS-1083 Allowance Income Section-Verify Header flat income label 
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 2, enabled = false)
	public void cabs1083() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1083 Execution started");
		System.out.println("Test Case - CABS-1083 Execution started");
	
		POS4.headrFlatLabel(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1083 Execution completed");
		System.out.println("Test Case - CABS-1083 Execution completed");
	}
/**
 * 	Test Case: CABS-1084 Allowance Income Section-Verify Perf Date from, To in the header flat income must show the previously saved Perf Date from & To in allowance section by default
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 3, enabled = false)
	public void cabs1084() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1084 Execution started");
		System.out.println("Test Case - CABS-1084 Execution started");
	
		POS4.perfDtFrmTo(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1084 Execution completed");
		System.out.println("Test Case - CABS-1084 Execution completed");
	}
	
	/**
	 * Test Case: CABS-1085 Allowance Income Section-Verify field Flat remaining show the remaining amount that has not been billed		
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 4, enabled = false)
	public void cabs1085() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1085 Execution started");
		System.out.println("Test Case - CABS-1085 Execution started");
	
		POS4.flatRemain(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1085 Execution completed");
		System.out.println("Test Case - CABS-1085 Execution completed");
	}
/**
 * Test Case: CABS-1086 Allowance Income Section-Verify if Flat remaining is < 0,  should show $0 	
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 5, enabled = false)
	public void cabs1086() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1086 Execution started");
		System.out.println("Test Case - CABS-1086 Execution started");
	
		POS4.flatRemainLessZero(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1086 Execution completed");
		System.out.println("Test Case - CABS-1086 Execution completed");
	}
/**
 * 	Test Case: CABS-1087 Allowance Income Section-Verify Flat amount
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 6, enabled = false)
	public void cabs1087() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1087 Execution started");
		System.out.println("Test Case - CABS-1087 Execution started");
	
		POS4.flatAmt(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1087 Execution completed");
		System.out.println("Test Case - CABS-1087 Execution completed");
	}
/**
 * 	Test Case: CABS-1088 Allowance Income Section-Verify Use remaining balance checkbox
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 7, enabled = false)
	public void cabs1088() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1088 Execution started");
		System.out.println("Test Case - CABS-1088 Execution started");
		
		POS4.useRemBal(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1088 Execution completed");
		System.out.println("Test Case - CABS-1088 Execution completed");
	}
/**
 * Test Case: CABS-1089 Allowance Income Section-Verify Only if Header flat income checkbox or Itemized income checkbox or both is selected, the 3 buttons( Save, Submit, Cancel) will be enabled	
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 8, enabled = false)
	public void cabs1089() throws InterruptedException, IOException, ParseException, AWTException, BiffException {


		extentTest.log(LogStatus.INFO, "Test Case - CABS-1089 Execution started");
		System.out.println("Test Case - CABS-1089 Execution started");
		
		POS4.buttonsEnb(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1089 Execution completed");
		System.out.println("Test Case - CABS-1089 Execution completed");
	}
/**
 * 	Test Case: CABS-1090 Allowance Income Section-Verify Header Flat type of income -Save And Submit with Flat amount > Flat remaining
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 9, enabled = false)
	public void cabs1090() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1090 Execution started");
		System.out.println("Test Case - CABS-1090 Execution started");
		
		POS4.FlatAGRSaveSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1090 Execution completed");
		System.out.println("Test Case - CABS-1090 Execution completed");
	}
	/**
	 * Test Case: CABS-1091 Allowance Income Section-Verify Header Flat type of income -Submit with Flat amount > Flat remaining
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 10, enabled = false)
	public void cabs1091() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1091 Execution started");
		System.out.println("Test Case - CABS-1091 Execution started");
		
		POS4.FlatAGRSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1091 Execution completed");
		System.out.println("Test Case - CABS-1091 Execution completed");
	}
/**
 * 	Test Case: CABS-1092 Allowance Income Section-Verify Header Flat type of income -Submit with Flat amount < Flat remaining
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 11, enabled = false)
	public void cabs1092() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1092 Execution started");
		System.out.println("Test Case - CABS-1092 Execution started");
		
		POS4.FlatALRSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1092 Execution completed");
		System.out.println("Test Case - CABS-1092 Execution completed");
	}
/**
 * Test Case: CABS-1093 Allowance Income Section-Verify Header Flat type of income -Submit with Flat amount = Flat remaining	
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 12, enabled = false)
	public void cabs1093() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1093 Execution started");
		System.out.println("Test Case - CABS-1093 Execution started");
		
		POS4.FlatAERSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1093 Execution completed");
		System.out.println("Test Case - CABS-1093 Execution completed");
	}

	/**
	 * Test Case: CABS-1094 Allowance Income Section-Submit Bill type of Income
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 13, enabled = false)
	public void cabs1094() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1094 Execution started");
		System.out.println("Test Case - CABS-1094 Execution started");
		
		POS4.FlatARBillSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1094 Execution completed");
		System.out.println("Test Case - CABS-1094 Execution completed");
	}
/**
 * Test Case: CABS-1095 Allowance Income Section-Submit Accrue type of Income	
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 14, enabled = false)
	public void cabs1095() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1095 Execution started");
		System.out.println("Test Case - CABS-1095 Execution started");
		
		POS4.FlatARAccrueSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1095 Execution completed");
		System.out.println("Test Case - CABS-1095 Execution completed");
	}
/**
 * Test Case: CABS-1096 Allowance Income Section-Submit Bill and accrue type of Income	
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 15, enabled = false)
	public void cabs1096() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1096 Execution started");
		System.out.println("Test Case - CABS-1096 Execution started");
		
		POS4.FlatARBillAccrueSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1096 Execution completed");
		System.out.println("Test Case - CABS-1096 Execution completed");
	}
/**
 * Test Case: CABS-1097 Allowance Income Section-Verify Header flat income checkbox with flat remaining=0	
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 16, enabled = false)
	public void cabs1097() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
		
		PO.AlwnceBR();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1097 Execution started");
		System.out.println("Test Case - CABS-1097 Execution started");
		
		POS4.FlatRemZeroSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1097 Execution completed");
		System.out.println("Test Case - CABS-1097 Execution completed");
	}
	/**
	 * Test Case: CABS-1098 Allowance Income Section-Verify if Flat remaining =0 when total flat amount in allowance section equals Bill amount
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 17, enabled = false)
	public void cabs1098() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1098 Execution started");
		System.out.println("Test Case - CABS-1098 Execution started");
		
		POS4.TotFlatEqBill(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1098 Execution completed");
		System.out.println("Test Case - CABS-1098 Execution completed");
	}
	/**
	 * Test Case: CABS-1099 Allowance Income Section-Verify Header Flat type of income -Save And Submit with Flat amount =0
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 18, enabled = false)
	public void cabs1099() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1099 Execution started");
		System.out.println("Test Case - CABS-1099 Execution started");
		
		POS4.FlatAmtzeroSaveSub(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1099 Execution completed");
		System.out.println("Test Case - CABS-1099 Execution completed");
	}
/**
 * 	Test Case: CABS-1102 Allowance Income Section-Save and submit Bill type of Income
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 19, enabled = false)
	public void cabs1102() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1102 Execution started");
		System.out.println("Test Case - CABS-1102 Execution started");
		
		POS4.FlatARSaveSubBill(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1102 Execution completed");
		System.out.println("Test Case - CABS-1102 Execution completed");
	}

	/**
	 * Test Case: CABS-1103 Allowance Income Section-Save and Submit Accrue type of Income
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 20, enabled = false)
	public void cabs1103() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1103 Execution started");
		System.out.println("Test Case - CABS-1103 Execution started");
		
		POS4.FlatARSaveSubAccrue(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1103 Execution completed");
		System.out.println("Test Case - CABS-1103 Execution completed");
	}

	/**
	 * Test Case: CABS-1104 Allowance Income Section-Save and Submit Bill and accrue type of Income
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 21, enabled = false)
	public void cabs1104() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		PO.AlwnceBR2();
		POS3.wait_forBRPage(Driver);
		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1104 Execution started");
		System.out.println("Test Case - CABS-1104 Execution started");
		
		POS4.FlatARSaveSubBillAccrue(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1104 Execution completed");
		System.out.println("Test Case - CABS-1104 Execution completed");
	}
	/**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	@BeforeTest
	public void beforeTest() throws InterruptedException, IOException {
		Driver = PO.beforeTest();
		POS4.beforeTest(Driver);
		POS3.beforeTest(Driver);
	
		extentTest = extent.startTest("Sprint 4 - CABS-453", "Allowance Income Section - Add income flat only");
		extentTest.log(LogStatus.INFO, "Browser Launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 


}
