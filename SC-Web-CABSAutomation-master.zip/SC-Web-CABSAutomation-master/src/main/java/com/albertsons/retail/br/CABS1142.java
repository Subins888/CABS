package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.PageObjectsJIX;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-1142 Warn not saved info
 * 
 * @author JMAYA09
 *
 */

public class CABS1142 extends ExtendBaseClass {
	
	WebDriver Driver;
	String BillingId,BillingIdNxt;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsJIX POS10 = new PageObjectsJIX(Driver);
	pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	
	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}
	
	/**
	 * Test Case: CABS-2098 Verify the not saved warning message for Allowance BR
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 1, enabled = true)
    public void cabs2098() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
        PO.wait_forHome();
        extentTest.log(LogStatus.INFO, "Test Case - CABS-2098 Execution started");
        System.out.println("Test Case - CABS-2098 Execution started");
        PO.waitForSpinnerToBeGone();
        POS10.AlwnceBR(Driver);
        PO.waitForSpinnerToBeGone();
        Thread.sleep(15000);
        POS3.wait_forBRPage(Driver);
        Thread.sleep(3000);
        POS10.bRHeader(Driver);
        POS10.WarnMsg(Driver);
        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-2098 Execution completed");
        System.out.println("Test Case - CABS-2098 Execution completed");
  }


	/**
	 * Test Case: CABS-2099 Verify the not saved warning message for Non-Allowance BR
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 2, enabled = true)
	public void cabs2099() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
	       
        extentTest.log(LogStatus.INFO, "Test Case - CABS-2099 Execution started");
        System.out.println("Test Case - CABS-2099 Execution started");
        PO.waitForSpinnerToBeGone();
        POS10.nonAlwnceNew(Driver);
        PO.waitForSpinnerToBeGone();
        Thread.sleep(15000);
        POS3.wait_forBRPage(Driver);
        BillingId = POS10.brSavNonAlw(Driver);
        POS10.WarnMsg(Driver);
        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-2099 Execution completed");
        System.out.println("Test Case - CABS-2099 Execution completed");
  }
	 /**
 	 * Browser set up
 	 * 
 	 * @throws InterruptedException
 	 * @throws IOException 
 	 */
 	@BeforeTest
 	public void beforeTest() throws InterruptedException, IOException {
 		Driver = PO.beforeTest();
 		POS10.beforeTest(Driver);
 		POS3.beforeTest(Driver);
 		extentTest = extent.startTest("Sprint 10 - CABS-1142", "Warn not saved info");
 		extentTest.log(LogStatus.INFO, "Browser Launched");
 	}
 	
 	@AfterTest
	public void aftertest() {
		Driver.quit();
	}
}
