package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pageobjects.pageObjectsJSprint4;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

public class CABS466 extends ExtendBaseClass{
    WebDriver Driver;

    PageObjects PO = new PageObjects(Driver);
    PageObjectsIV POIV = new PageObjectsIV(Driver);
    pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
    pageObjectsJSprint4 POS4 = new pageObjectsJSprint4(Driver);

    GenericFactory pageFact = new GenericFactory(Driver);
    ITestResult result;

    /**
    * Login Functionality
    * 
     * @throws Exception
    */
    @Test(priority = 0, enabled = true)
    public void ABS_Login() throws Exception {

    //           PO.waitforelement();
                   PO.Login();

    }
    
    /**
    * Test Case: CABS-1042 Verify itemized income check box and label
    * @throws InterruptedException
    * @throws IOException
    * @throws ParseException
    * @throws AWTException
    * @throws BiffException
    */
    
   
    @Test(priority = 1, enabled = true)
    public void cabs1042() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

    //           PO.wait_forHome();
                   extentTest.log(LogStatus.INFO, "Test Case - CABS-1042 Execution started");
                   System.out.println("Test Case - CABS-1042 Execution started");
                   PO.AlwnceBR();
    
                   POS3.wait_forBRPage(Driver);
                   Thread.sleep(3000);
                   POS4.itemizedChkBox(Driver);

                   extentTest.log(LogStatus.INFO, "Test Case - CABS-1042 Execution completed");
                   System.out.println("Test Case - CABS-1042 Execution completed");
    }
    /**
    * Test Case: CABS-1051 Verify the fields of item listed in the item Detail section
    * @throws InterruptedException
    * @throws IOException
    * @throws ParseException
    * @throws AWTException
    * @throws BiffException
    */
    
    //Verify the fields of item listed in the item Detail section
    @Test(priority = 2, enabled = true)
    public void cabs1051() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

    
                   extentTest.log(LogStatus.INFO, "Test Case - CABS-1051 Execution started");
                   System.out.println("Test Case - CABS-1051 Execution started");
    
                   POS4.itemizedFields(Driver);

                   extentTest.log(LogStatus.INFO, "Test Case - CABS-1051 Execution completed");
                  System.out.println("Test Case - CABS-1051 Execution completed");
    }
/**
* Test Case: CABS-1052 Verify User is able to enter income against items listed in Item details section in the Itemized income table.
* @throws InterruptedException
* @throws IOException
* @throws ParseException
* @throws AWTException
* @throws BiffException
*/
    @Test(priority = 3, enabled = true)
    public void cabs1052() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

    
                   extentTest.log(LogStatus.INFO, "Test Case - CABS-1052 Execution started");
                   System.out.println("Test Case - CABS-1052 Execution started");
    
                  //  POS4.itemizedItemIncome(Driver);

                   extentTest.log(LogStatus.INFO, "Test Case - CABS-1052 Execution completed");
                   System.out.println("Test Case - CABS-1052 Execution completed");
    }
    
    
    
    //Verify Grand Total field in itemized income section
    @Test(priority=4, enabled = false)
    public void cabs1054() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1054 Execution started");
        System.out.println("Test Case - CABS-1054 Execution started");

         
        POS4.qtySum(Driver);
       
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1054 Execution completed");
        System.out.println("Test Case - CABS-1054 Execution completed");
}
    
    
    //Verify whether user is able to save itemized income section,
    //Bill type, with Qty >0, upon clicking "Save" button
    
    //1058, 1059, 1067, 1068 Also considered
    @Test(priority=5, enabled = true)
    public void cabs1056() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1056 Execution started");
        System.out.println("Test Case - CABS-1056 Execution started");
        Thread.sleep(3000);
        POS4.qtyfieldenter(Driver);
      //  POS4.fltAmntFieldenter(Driver);
        
        POIV.incomeSubmit2(Driver);
       
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1056 Execution completed");
        System.out.println("Test Case - CABS-1056 Execution completed");
}
    
    //Verify whether user is able to save itemized income section, 
    //bill type, with Qty =0 or blank, upon clicking "Save" button
    //1060, 1061,1062, 1066 handled here
    @Test(priority=6, enabled = true)
    public void cabs1057() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1057 Execution started");
        System.out.println("Test Case - CABS-1057 Execution started");
        Thread.sleep(2000);
        
        POS4.incomeClk(Driver);
        
       // POS4.BRSaveNew(Driver);
        Thread.sleep(2000);
        
        POS4.qtyfieldenter0(Driver);
        POIV.incomeSubmit3(Driver);
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1057 Execution completed");
        System.out.println("Test Case - CABS-1057 Execution completed");
}
    
    
    //Verify whether user is able to submit the income record , 
    //Accrue type ,which was previously saved with Qty >0
    @Test(priority=7, enabled = true)
    public void cabs1074() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1074 Execution started");
        System.out.println("Test Case - CABS-1074 Execution started");
        Thread.sleep(3000);
        
        
        
      //  POS4.BRSaveNew(Driver);
        POS4.incomeClk(Driver);
        Thread.sleep(2000);
        POS4.acrueClk(Driver);
     
        
        POS4.qtyfieldenter(Driver);
        POIV.incomeSubmit2(Driver);
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1074 Execution completed");
        System.out.println("Test Case - CABS-1074 Execution completed");
}
    
    @Test(priority=8, enabled = true)
    public void cabs1077() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1077 Execution started");
        System.out.println("Test Case - CABS-1077 Execution started");
        Thread.sleep(3000);
        
        POS4.incomeClk(Driver);
        Thread.sleep(2000);
        
        //POS4.BRSaveNew(Driver);
        POS4.acrueClk(Driver);
     
        
        POS4.qtyfieldenter0(Driver);
        POIV.incomeSubmit3(Driver);
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1077 Execution completed");
        System.out.println("Test Case - CABS-1077 Execution completed");
}
    
    
    @Test(priority=9, enabled = true)
    public void cabs1078() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1078 Execution started");
        System.out.println("Test Case - CABS-1078 Execution started");
        Thread.sleep(3000);
        POS4.incomeClk(Driver);
        Thread.sleep(2000);
        //POS4.BRSaveNew(Driver);
        POS4.BillacrueClk(Driver);
    
        POS4.qtyfieldenter0(Driver);
        POIV.incomeSubmit3(Driver);
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1078 Execution completed");
        System.out.println("Test Case - CABS-1078 Execution completed");
}
    

    /**
    * Browser set up
    * 
     * @throws InterruptedException
    * @throws IOException 
     */
    @BeforeTest
    public void beforeTest() throws InterruptedException, IOException {
                   Driver = PO.beforeTest();
                   POS4.beforeTest(Driver);
                   POS3.beforeTest(Driver);
                   POIV.beforeTest(Driver);
                   extentTest = extent.startTest("Sprint 4 - CABS-466", "Allowance Income Section - Add income Itemized only");
                   extentTest.log(LogStatus.INFO, "Browser Launched");
    }

   @AfterTest
	public void aftertest() {
		Driver.quit();
	} 


}

