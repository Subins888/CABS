package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS725 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	
	//Allowance-Income History-verify income history section
	@Test(priority = 1, enabled = true)
	public void CABS1504() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-1504 Execution started");
	
		POVI.waitforBlngbtn(Driver);
 
		POVI.AlwnceBR(Driver);
		
		POVI.brSaveAfterEdit(Driver);
		//Thread.sleep(25000);
		POVI.BrReady(Driver);
		//Thread.sleep(20000);
		POVI.incomeHistory(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1504 Execution Completed");
	}
	
	
	
	@Test(priority = 3, enabled = false)
	public void CABS1506() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-1506 Execution started");
	
		POVI.ascndingHistory(Driver);
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1506 Execution Completed");
	}
	
	
	@Test(priority = 2, enabled = true)
	public void CABS1505() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-1505 Execution started");
	 
		POVI.incomeHistoryBilNdAcrue(Driver);
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1505 Execution Completed");
	}
	
	
	@Test(priority = 4, enabled = false)
	public void CABS1507() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-1507 Execution started");
	 
		POVI.incomeHistoryAcrue(Driver);
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1507 Execution Completed");
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent
				.startTest("Sprint 6 - CABS-725",
						"Allowance - Income history( Submit a income record )");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
