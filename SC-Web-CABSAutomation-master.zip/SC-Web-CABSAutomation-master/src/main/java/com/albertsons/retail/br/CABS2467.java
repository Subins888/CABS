package com.albertsons.retail.br;

import org.testng.annotations.Test;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pageobjects.pageObjects11;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import org.testng.annotations.BeforeTest;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;

/**
 * User Story: CABS-2467 Auto-change item dates based on BR billing dates
 * 
 * @author akuma58
 *
 */

public class CABS2467 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	pageObjects11 PO11 = new pageObjects11(Driver);

	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}

	// Validate Item Bill Dates when BR billing dates match item billing dates
	@Test(priority = 1, enabled = true)
	public void CABS2600() throws Exception {

		extentTest.log(LogStatus.INFO, "Test Case - CABS-2600 Execution started");

		POVIII.AlwnceBRNoItemizd(Driver);

		PO11.dates(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-2600 Execution completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException, IOException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		PO11.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 12 - CABS-2467", "Auto-change item dates based on BR billing dates");
		extentTest.log(LogStatus.INFO, "Browser Launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	}

}
