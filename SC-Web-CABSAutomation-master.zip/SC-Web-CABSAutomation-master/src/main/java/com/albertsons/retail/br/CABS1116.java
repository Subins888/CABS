package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.PageObjectsJIX;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-1116 Dialog Worklist - List BRs in Dialog Worklist
 * 
 * @author JMAYA09
 *
 */

public class CABS1116 extends ExtendBaseClass {
WebDriver Driver;
String BillingId;
PageObjects PO = new PageObjects(Driver);
PageObjectsJIX POS10 = new PageObjectsJIX(Driver);
pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);

/**
 * Login Functionality
 * 
 * @throws Exception
 */
@Test(priority = 0, enabled = true)
public void ABS_Login() throws Exception {

	PO.waitforelement();
	PO.Login();

}

/**
 * Test Case: CABS-2478 Validate Dialog worklist with dialog status-Active/No active
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */

@Test(priority = 1, enabled = true)
public void cabs2478() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
	
	PO.wait_forHome();
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2478 Execution started");
	System.out.println("Test Case - CABS-2478 Execution started");
	PO.waitForSpinnerToBeGone();
	POS10.nonAlwnceNew(Driver);
	PO.waitForSpinnerToBeGone();
	Thread.sleep(2000);
	POS3.wait_forBRPage(Driver);
	BillingId = POS10.brSavNonAlw(Driver);

	POS10.addDialog(Driver);
	PO.waitForSpinnerToBeGone();
	Thread.sleep(40000);
	POS10.dialogWklst(Driver,"selected");
	
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2478 Execution completed");
	System.out.println("Test Case - CABS-2478 Execution completed");
}

/**
 * Test Case: CABS-2479 Validate Dialog worklist with selected user coming in Assign To or Notify fields
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
@Test(priority = 2, enabled = true)
public void cabs2479() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
	
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2479 Execution started");
	System.out.println("Test Case - CABS-2479 Execution started");
	
	POS10.dialogWklstwklstFrNotfdUsr(Driver);
	POS10.dialogWklst(Driver,"notified");
	
	POS10.dialogWklstwklstFrAsgUsr(Driver);
	POS10.dialogWklst(Driver,"assigned");
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2479 Execution completed");
	System.out.println("Test Case - CABS-2479 Execution completed");
}

/**
 * Test Case: CABS-2528 MISC-Dialog work list -Validate fields listed in the list view of the dialogs
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
@Test(priority = 3, enabled = true)
public void cabs2528() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
	
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2528 Execution started");
	System.out.println("Test Case - CABS-2528 Execution started");
	
	POS10.dialogWklstField(Driver,BillingId);
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2528 Execution completed");
	System.out.println("Test Case - CABS-2528 Execution completed");
}

/**
 * Test Case: CABS-2527 Retail/Cogs-Dialog work list -Validate fields listed in the list view of the dialogs
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
@Test(priority = 4, enabled = true)
public void cabs2527() throws InterruptedException, IOException, ParseException, AWTException, BiffException {
	
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2527 Execution started");
	System.out.println("Test Case - CABS-2527 Execution started");
	
	POS10.AlwnceBR(Driver);
	PO.waitForSpinnerToBeGone();
	Thread.sleep(15000);
	POS3.wait_forBRPage(Driver);
	Thread.sleep(3000);
	BillingId = POS10.bRHeader(Driver);
	
	POS10.addDialog(Driver);
	PO.waitForSpinnerToBeGone();
	Thread.sleep(40000);
	
	POS10.dialogWklstFieldRtl(Driver,BillingId);
	
	extentTest.log(LogStatus.INFO, "Test Case - CABS-2527 Execution completed");
	System.out.println("Test Case - CABS-2527 Execution completed");
}

/**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	@BeforeTest
	public void beforeTest() throws InterruptedException, IOException {
		Driver = PO.beforeTest();
		POS10.beforeTest(Driver);
		POS3.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 12 - CABS-1116", "Dialog Worklist - List BRs in Dialog Worklist");
		extentTest.log(LogStatus.INFO, "Browser Launched");
	}
	
	@AfterTest
public void aftertest() {
	Driver.quit();
}
}
