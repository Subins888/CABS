package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1155 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify the fields labels type as per the design(Title Case)
	@Test(priority = 1, enabled = true)
	public void CABS1304() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1304 Execution started");

		POIV.AlwnceBRIV(Driver);
		POV.labelChck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1304 Execution Completed");
	}

	// Verify whether the BR status bar getting cleared when user starts editing
	// the billing record
	@Test(priority = 2, enabled = true)
	public void CABS1303() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1303 Execution started");

		POIV.BRSave(Driver);
		POV.succMsgClear(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1303 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-1155",
				"Billing Record - clear status message");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
