package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS647 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Add Items -Verify whether the item details are grouped by CIC
	@Test(priority = 1, enabled = true)
	public void CABS1472() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1472 Execution started");

		POIV.AlwnceBRIV(Driver);
		POV.waitforbrtxt(Driver);
		Thread.sleep(5000);
		POV.CICDetails(Driver);

		POVI.ascndingUPC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1472 Execution Completed");
	}

	// Add Items -verify group update items under a CIC
	@Test(priority = 2, enabled = true)
	public void CABS1473() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1473 Execution started");

		POVI.colapseData(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1473 Execution Completed");
	}

	// Add Items -verify individual update on UPC row under a CIC
	@Test(priority = 3, enabled = true)
	public void CABS1474() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1474 Execution started");

		POVI.editNextRow(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1474 Execution Completed");
	}

	// Add Items -verify if user able collapse the CIC when user has updated one
	// or more individual UPC rows and data on any of 3 fields( date from, date
	// to, Allowance Amount) on any of the item rows for the CIC is same
	@Test(priority = 4, enabled = true)
	public void CABS1477() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1477 Execution started");

		POVI.colapsEnable(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1477 Execution Completed");
	}

	// Add Items -verify if user able collapse the CIC when user has updated one
	// or more individual UPC rows and data on any of 3 fields( date from, date
	// to, Allowance Amount) on any of the item rows for the CIC is different
	@Test(priority = 5, enabled = true)
	public void CABS1476() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1476 Execution started");

		POVI.noColaps(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1476 Execution Completed");
	}

	// Add Items - verify if CIC/UPC add or edit on any row and clicking save BR
	// saves the details in back end and history
	@Test(priority = 6, enabled = true)
	public void CABS1478() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1478 Execution started");

		POVI.brSaveAfterEdit(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1478 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 6 - CABS-647",
				"Add Items - Listing Items, group/individual update");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
