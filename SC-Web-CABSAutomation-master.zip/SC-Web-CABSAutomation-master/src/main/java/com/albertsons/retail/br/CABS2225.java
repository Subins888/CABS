package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pageobjects.pageObjects11;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS2225 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	pageObjects11 PO11 = new pageObjects11(Driver);

	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Validate AP number with AP nbr status in Lawson-Retail/COGS
	// CABS- 2352,
	@Test(priority = 1, enabled = true)
	public void CABS2351() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2351 Execution started");

		POVIII.AlwnceBRNoItemizd(Driver);
		PO11.BRSave(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2351 Execution completed");
	}

	// Validate AP number with vendor group validation -Retail/COGS
	@Test(priority = 2, enabled = true)
	public void CABS2353() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2353 Execution started");

		PO11.invalidAPAR(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2353 Execution completed");
	}

	// Validate AR number with AR nbr status in Lawson-Retail/COGS
	// CABS-2355
	@Test(priority = 3, enabled = true)
	public void CABS2352() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2352 Execution started");

		PO11.AR(Driver);
		PO11.invalidAPAR(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2352 Execution completed");
	}

	// Validate AP number with AP nbr status in Lawson-MISC
	//CABS=2357, 2358, 2360
	@Test(priority = 4, enabled = true)
	public void CABS2356() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2352 Execution started");

 
		POVIII.searchBtn(Driver);
		Thread.sleep(1500);
		
		PO11.warningYesClk(Driver);
		PO.nonAlwnceNew();
		PO11.brSaveMisc(Driver);
		PO11.invalidAPAR(Driver);
		PO11.ARMisc(Driver);
		PO11.invalidAPAR(Driver);
		
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2352 Execution completed");
	}
	
	

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		PO11.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 11 - CABS-2225", "Validate AP/AR Number against Lawson");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		 Driver.quit();
	} 
}
