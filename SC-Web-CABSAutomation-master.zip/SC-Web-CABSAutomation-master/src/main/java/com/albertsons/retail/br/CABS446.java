package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.PageObjectsJSSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;


public class CABS446 extends ExtendBaseClass  {
	
	WebDriver Driver;
    String extentReportImage446_1; 
    String extentReportImage880_1; 
    String extentReportImage879_1;
    PageObjects PO = new PageObjects(Driver);
    GenericFactory pageFact = new GenericFactory(Driver);
    ITestResult result;
    PageObjectsJSSprint3 POJS3 = new PageObjectsJSSprint3(Driver);      

	
    @Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
    
    /**
     * Test Case: CABS-880 Verify the action bar area and buttons displaying in the Billing Record action bar for Allowance.
     * @throws InterruptedException
     * @throws IOException
     */
@Test(priority = 1, enabled = true)
public void CABS_879() throws Exception {
        extentTest.log(LogStatus.INFO, "Test Case - CABS-879 Execution started");
  
  PO.wait_forHome();
  PO.AlwnceBR();
  POJS3.wait_forSave(Driver);
  POJS3.ChckAlwactionBr(Driver);               
  extentTest.log(LogStatus.INFO, "Test Case - CABS-879 Execution Completed");       
}
@Test(priority = 2, enabled = true)
public void CABS_880() throws Exception {

     extentTest.log(LogStatus.INFO, "Test Case - CABS-880 Execution started");
  
     POJS3.AlwactionBr(Driver);               
     extentTest.log(LogStatus.INFO, "Test Case - CABS-880 Execution Completed");    
}

    @BeforeTest
    public void beforeTest() throws InterruptedException {
    Driver  =   PO.beforeTest();
    POJS3.beforeTest(Driver);
    extentTest = extent.startTest("Sprint 3 - CABS-446", "Verify ALW Action Bar");
    extentTest.log(LogStatus.INFO, "Browser Launched");                    
}


@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
