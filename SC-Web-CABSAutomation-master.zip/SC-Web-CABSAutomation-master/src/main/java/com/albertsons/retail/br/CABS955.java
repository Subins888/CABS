package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-451
 * 
 * @author akuma58
 *
 */

public class CABS955 extends ExtendBaseClass {

	WebDriver Driver;
	String extentReportImage369_1;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	// Validate Offset# and the proper error message is displaying while all 3
	// parts or the first 2
	// parts of offset # is not associated with the team based on the lookup and
	// Value
	@Test(priority = 1, enabled = false)
	public void CABS1045() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1045 Execution started");
		
		
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1045 Execution Completed");
	}

	// Validate Offset# and the proper error message is displaying when the
	// derived Section ID is not associated with the Account and
	// Facility for the team, lookup type and Val combo( in
	// GL_Team_Acct_Sect_Ctrl)
	@Test(priority = 2, enabled = true)
	public void CABS1048() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1048 Execution started");
		
		PO3.AlwnceBRUpdt(Driver);	 
		PO3.errCaseSectionID(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1048 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();
		PO3.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 4 - CABS-955",
				"Offset # validation for Allowance BR");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
