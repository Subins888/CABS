package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS525 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	/**
	 * User Story: CABS-525 Save button functionality for a previously saved
	 * Allowance BR
	 * 
	 * @author akuma58
	 *
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	

	// Save button functionality for a previously saved Allowance BR- with user
	// editing mandatory information
	@Test(priority = 1, enabled = true)
	public void CABS1298() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1298 Execution started");

		POIV.AlwnceBRIV(Driver);
		POV.brSaveAllwnc(Driver);		
		POV.SearchII(Driver);
		POV.waitforbrtxt(Driver);
		POV.editII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1298 Execution Completed");
	}
	
	// Save button functionality for a previously saved Allowance BR- with user
		// entering invalid data for mandatory information
		@Test(priority = 2, enabled = true)
		public void CABS1299() throws Exception {

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1299 Execution started");

		 	POV.editInvalidII(Driver);

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1299 Execution Completed");
		}
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-525",
				"Save button functionality for a previously saved");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
