package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import com.albertsons.pageobjects.GenericFactoryJSprint3;
import com.albertsons.pageobjects.pageObjectsJSprint3;
//import com.cabs.pages.ExtendBaseClass;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-353 Verify Allowance BR has Allowance information section
 * 
 * @author U82703
 *
 */
public class CABS353 extends ExtendBaseClass {

	WebDriver Driver;
		
	PageObjects PO = new PageObjects(Driver);
	pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	
	GenericFactory pageFact = new GenericFactory(Driver);
	ITestResult result;
	


	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}

	/**
	 * Test Case: CABS-856 Verify Allowance BR has Allowance information section
	 * based on the typed characters
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException 
	 * @throws AWTException 
	 * @throws BiffException 
	 */

	@Test(priority = 1, enabled = true)
	public void cabs856() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

             PO.wait_forHome();
             extentTest.log(LogStatus.INFO, "Test Case - CABS-856 Execution started");
             System.out.println("Test Case - CABS-856 Execution started");
             PO.AlwnceBR();
             PO.waitForSpinnerToBeGone();
             
             POS3.wait_forBRPage(Driver);
             
             Thread.sleep(20000);
             POS3.allwInfoSect(Driver);

             extentTest.log(LogStatus.INFO, "Test Case - CABS-856 Execution completed");
             System.out.println("Test Case - CABS-856 Execution completed");
       }

/**
 * Test Case: CABS-857 Verify the fields in allowance information section
 * @throws IOException
 * @throws InterruptedException
 * @throws ParseException
 */
	@Test(priority = 2, enabled = true)
	public void cabs857() throws IOException, InterruptedException, ParseException  {

             
             extentTest.log(LogStatus.INFO, "Test Case - CABS-857 Execution started");
             System.out.println("Test Case - CABS-857 Execution started");
             PO.waitForSpinnerToBeGone();
             POS3.allwInfoSectFields(Driver);

             extentTest.log(LogStatus.INFO, "Test Case - CABS-857 Execution completed");
             System.out.println("Test Case - CABS-857 Execution completed");
       }

	
	/**
	 * Test Case: CABS-858 Verify user is getting warning when both header and itemized input are not given	

	 * @throws IOException
	 * @throws ParseException 
	 * @throws InterruptedException 
	 * @throws BiffException 
	 */
	@Test(priority = 3, enabled = false)
	public void cabs858() throws IOException, InterruptedException, ParseException, BiffException  {

             
             extentTest.log(LogStatus.INFO, "Test Case - CABS-858 Execution started");
             System.out.println("Test Case - CABS-858 Execution started");
             
             PO.AlwnceBR2();
             PO.waitForSpinnerToBeGone();
             Thread.sleep(15000);
             POS3.wait_forBRPage(Driver);
             PO.waitForSpinnerToBeGone();
             Thread.sleep(10000);
             POS3.NoHeadItem(Driver);

             extentTest.log(LogStatus.INFO, "Test Case - CABS-858 Execution completed");
             System.out.println("Test Case - CABS-858 Execution completed");
       }


	/**
	 * Test Case: CABS-859 Verify flat code is mandatory if flat amount > 0
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ParseException
	 */

	@Test(priority = 4, enabled = false)
	public void cabs859() throws IOException, InterruptedException, ParseException  {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-859 Execution started");
		System.out.println("Test Case - CABS-859 Execution started");
		
		POS3.FltAmtCode(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-859 Execution completed");
		System.out.println("Test Case - CABS-859 Execution completed");
	}
/**
 * Test Case: CABS-861 Verify Performance code 1 is required if Allowance type is selected
 * @throws IOException
 * @throws InterruptedException
 * @throws ParseException
 */
	@Test(priority = 5, enabled = false)
	public void cabs861() throws IOException, InterruptedException, ParseException  {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-861 Execution started");
		System.out.println("Test Case - CABS-861 Execution started");
		
		POS3.AlwPerf1(Driver);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-861 Execution completed");
		System.out.println("Test Case - CABS-861 Execution completed");
	}
	

	/**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	@BeforeTest
	public void beforeTest() throws InterruptedException, IOException {
		Driver = PO.beforeTest();
		POS3.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 3 - CABS-353", "Create Billing Record - View/update allowance info");
		extentTest.log(LogStatus.INFO, "Browser Launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
