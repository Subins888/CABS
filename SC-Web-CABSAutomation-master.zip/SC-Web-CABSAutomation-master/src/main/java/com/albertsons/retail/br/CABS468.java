package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS468 extends ExtendBaseClass {
	
	WebDriver Driver;
	String extentReportImage369_1;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify the Cancellation of allowance income section details- without save -Click Ok
	@Test(priority = 1, enabled = true)
	public void CABS1105() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-1105 Execution started");
		
		POIV.AlwnceBRNoItemizd(Driver);
//		PO.wait_forbrtxt();
//		PO3.BRSaveNew(Driver);
//		PO3.BRSaveNewReady(Driver);
//		PO3.incomeAddClk(Driver);
//		Thread.sleep(3500);
		
		POIV.BRSave(Driver);
		POIV.BRSaveNewReady(Driver);		   
		POIV.incomeAddClk(Driver);
		Thread.sleep(3000);
		PO3.incomeRetCancelOk(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1105 Execution Completed");
	}
	
	
	//Verify the Cancellation of allowance income section details for a previously saved income record- Click OK
	@Test(priority = 2, enabled = true)
	public void CABS1106() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-1106 Execution started");
		
		PO3.incmSave(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1106 Execution Completed");
	}
	
	//Verify the Cancellation of allowance income section details- without save- Click Cancel
	@Test(priority = 3, enabled = true)
	public void CABS1107() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-1107 Execution started");
		
		PO3.itemRetCancelCan(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1107 Execution Completed");
	}
	
	//Verify the Cancellation of allowance income section details for a previously saved income record- Click Cancel
	@Test(priority = 4, enabled = true)
	public void CABS1108() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-1108 Execution started");
		
		 
		PO3.incmSaveCancelCan(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1108 Execution Completed");
	}
	
	
	  @BeforeTest
	  public void beforeTest() throws InterruptedException {
		  Driver =  PO.beforeTest();
			 PO3.beforeTest(Driver);
			 POIV.beforeTest(Driver);
				extentTest = extent.startTest("Sprint 4 - CABS-468",
						"Allowance Income Section - Cancel Button");
				extentTest.log(LogStatus.INFO, "Browser successfully launched");
	  }


 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
