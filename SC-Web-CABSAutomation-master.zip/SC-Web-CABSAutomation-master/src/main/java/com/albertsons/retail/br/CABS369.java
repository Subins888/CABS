package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-369
 * 
 * @author akuma58
 *
 */

public class CABS369 extends ExtendBaseClass {
	
	WebDriver Driver;
	String extentReportImage369_1;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify the Section ID field in Offset number
	@Test(priority = 1, enabled = true)
	public void CABS_871() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-871 Execution started");
		
		PO.AlwnceBR();
	 	//Thread.sleep(10000);
		PO3.sectionId(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-871 Execution Completed");
	}
	
	
  
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	 Driver =  PO.beforeTest();
	 PO3.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 3 - CABS-369",
				"Verify the Section ID field in Offset number  ");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
  }

 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
