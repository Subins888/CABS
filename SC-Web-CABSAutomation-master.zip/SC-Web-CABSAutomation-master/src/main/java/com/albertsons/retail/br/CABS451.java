package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-451
 * 
 * @author akuma58
 *
 */

public class CABS451 extends ExtendBaseClass{
	

	WebDriver Driver;
	String extentReportImage369_1;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify for user with bill/Accrue my billing record rights, income section is collapsed by default when billing page is loaded
	@Test(priority = 1, enabled = true)
	public void CABS_845() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-845 Execution started");
		
	 PO.AlwnceBR();
	 PO.wait_forbrtxt();
	 PO3.incmSavebutton(Driver);
	 	
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-845 Execution Completed");
	}
	
	//CABS-849 also included with this
	//Verify for users with 'Bill/Accrue my billing record' rights ,the 'Add Income' button and all controls in Income section must be disabled for my billing record with status not 'Ready for Income',
		@Test(priority = 2, enabled = true)
		public void CABS_855() throws Exception {

			extentTest
			.log(LogStatus.INFO, "Test Case - CABS-855 Execution started");
			
	 
		 PO3.BRSaveNew(Driver);
			
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-855 Execution Completed");
		}
		
		//CABS-851 also included with this
	//Verify when user with 'Bill/Accrue my billing record' rights create and save the billing record ,the 'Add Income' button and all controls in Income section must be enabled
	@Test(priority = 3, enabled = true)
	public void CABS_847() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-847 Execution started");
		
	 PO3.BRSaveNewReady(Driver);
	 
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-847 Execution Completed");
	}
	
	
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	  Driver =  PO.beforeTest();
		 PO3.beforeTest(Driver);
			extentTest = extent.startTest("Sprint 3 - CABS-451",
					"Allowance Income Section - Role based access ");
			extentTest.log(LogStatus.INFO, "Browser successfully launched");
  }

 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
