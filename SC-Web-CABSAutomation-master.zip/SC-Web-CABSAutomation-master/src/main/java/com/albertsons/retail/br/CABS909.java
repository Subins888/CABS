package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.PageObjectsJIX;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-909 Overlaps - Re-calc Overlaps
 * 
 * @author JMAYA09
 *
 */

public class CABS909 extends ExtendBaseClass{
	
	WebDriver Driver;
	String BillingId;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsJIX POS10 = new PageObjectsJIX(Driver);
	pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	
	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}

	/**
	 * Test Case: CABS-1995 Verify Overlap re-calc must happen while changing the 'Item Bill Date'
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */

	@Test(priority = 1, enabled = true)
	public void cabs1995() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        PO.wait_forHome();
        
        extentTest.log(LogStatus.INFO, "Test Case - CABS-1995 Execution started");
        System.out.println("Test Case - CABS-1995 Execution started");
        PO.waitForSpinnerToBeGone();
        POS10.AlwnceBR(Driver);
        PO.waitForSpinnerToBeGone();
        Thread.sleep(15000);
        POS3.wait_forBRPage(Driver);
        Thread.sleep(3000);
        BillingId = POS10.bRHeader(Driver);
        System.out.println(BillingId);
        
        
        POS10.AlwnceBR(Driver);
        PO.waitForSpinnerToBeGone();
        Thread.sleep(15000);
        POS3.wait_forBRPage(Driver);
        Thread.sleep(3000);
        POS10.bRHeader(Driver);
        
        
        POS10.OvrlapItemBillDt(Driver,BillingId);

        extentTest.log(LogStatus.INFO, "Test Case - CABS-1995 Execution completed");
        System.out.println("Test Case - CABS-1995 Execution completed");
  }
  
/**
 * 	Test Case: CABS-2000 Verify Overlap re-calc must happen while updating Allowance Type/Perf codes
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 2, enabled = true)
	public void cabs2000() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-2000 Execution started");
		System.out.println("Test Case - CABS-2000 Execution started");
		
		POS10.AllwTypChange(Driver,BillingId);
		

		extentTest.log(LogStatus.INFO, "Test Case - CABS-2000 Execution completed");
		System.out.println("Test Case - CABS-2000 Execution completed");
	}
	
	/**
	 * Test Case: CABS-1996 Verify Overlap re-calc must happen while changing the 'Perf Date'	 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	
	@Test(priority = 3, enabled = true)
	public void cabs1996() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1996 Execution started");
		System.out.println("Test Case - CABS-1996 Execution started");
		
		POS10.PerfChange(Driver,BillingId);
		

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1996 Execution completed");
		System.out.println("Test Case - CABS-1996 Execution completed");
	}
	
	/**
	 * Test Case: CABS-1997 Verify Overlap re-calc must happen while deleting items (UPC)	 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	
	@Test(priority = 4, enabled = true)
	public void cabs1997() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1997 Execution started");
		System.out.println("Test Case - CABS-1997 Execution started");
		
		POS10.itemDel(Driver,BillingId);
		

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1997 Execution completed");
		System.out.println("Test Case - CABS-1997 Execution completed");
	}
	
	/**
	 * Test Case: CABS-1999 Verify Overlap re-calc must happen while Adding items (UPC\CIC)	 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	
	@Test(priority = 5, enabled = true)
	public void cabs1999() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1999 Execution started");
		System.out.println("Test Case - CABS-1999 Execution started");
		
		POS10.itemAdd(Driver,BillingId);
		

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1999 Execution completed");
		System.out.println("Test Case - CABS-1999 Execution completed");
	}
	
/**
 * Test Case: CABS-1998	Verify Overlap re-calc must happen while deleting items (CIC) 
 * @throws InterruptedException
 * @throws IOException
 * @throws ParseException
 * @throws AWTException
 * @throws BiffException
 */
	@Test(priority = 6, enabled = true)
	public void cabs1998() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-1998 Execution started");
		System.out.println("Test Case - CABS-1998 Execution started");
		
		POS10.itemDelCIC(Driver,BillingId);
		

		extentTest.log(LogStatus.INFO, "Test Case - CABS-1998 Execution completed");
		System.out.println("Test Case - CABS-1998 Execution completed");
	}

	/**
	 * Test Case: CABS-2002 Verify there is no billing for BR status 'Ended'
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */
	@Test(priority = 7, enabled = true)
	public void cabs2002() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-cabs2002 Execution started");
		System.out.println("Test Case - CABS-cabs2002 Execution started");
		
		POS10.BrEnd(Driver,BillingId);
		

		extentTest.log(LogStatus.INFO, "Test Case - CABS-cabs2002 Execution completed");
		System.out.println("Test Case - CABS-cabs2002 Execution completed");
	}
	
  /**
	 * Browser set up
	 * 
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	@BeforeTest
	public void beforeTest() throws InterruptedException, IOException {
		Driver = PO.beforeTest();
		POS10.beforeTest(Driver);
		POS3.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 9 - CABS-909", "Overlaps - Re-calc Overlaps");
		extentTest.log(LogStatus.INFO, "Browser Launched");
	}
	
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
