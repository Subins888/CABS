package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySJX;
import com.albertsons.pageobjects.PageObjectsSJIX;
import com.albertsons.pageobjects.PageObjectsSJX;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1353 extends ExtendBaseClass{
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySJX pageFact10 = new GenericFactorySJX(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsSJIX POJS9 = new PageObjectsSJIX(Driver);
	PageObjectsSJX POJS10 = new PageObjectsSJX(Driver);
	ITestResult result;
	String Type;
	/**
	 * User Story: CABS-1353 BR Cancel button
	 * 
	 * 
	 * @author jmann89
	 *
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Validate BR cancel button while creating billing record
		@Test(priority = 1, enabled = true)
		public void CABS2206() throws Exception{
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2206 Execution started");
			POVIII.AlwnceBRNoItemizd(Driver);
			Thread.sleep(3000);
			POJS10.waitforbrtxt(Driver)	;
			Thread.sleep(3000);				
			System.out.println("Created BR and now validating cancel BR");
			extentTest.log(LogStatus.INFO,
					"Created BR and now validating cancel BR ");			
			Thread.sleep(3000);	
			Type="Create";
			POJS10.BRCancel(Driver,Type);		
			Thread.sleep(2000);		
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2206 Execution Completed");
			Thread.sleep(3000);	
			
		}
		
	//Verify the cancel button on billing record header is enabled only when user has made any edits to 
	//any of Billing record related fields( header/allowance/item details)
	@Test(priority = 2, enabled = true)
	public void CABS2205() throws Exception{
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2205 Execution started");
		POVIII.AlwnceBRNoItemizd(Driver);		
		POJS10.AllwncBRSaveforFlat(Driver);
		Thread.sleep(32000);
		System.out.println("Created and saved BR and now validating cancel BR");
		extentTest.log(LogStatus.INFO,
				"Created and saved BR and now validating cancel BR ");
		POJS10.brCanclVal(Driver);
		Thread.sleep(3000);
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2205 Execution Completed");
		
	}
	
	//Validate BR cancel button while editing billing record
		@Test(priority = 3, enabled = true)
		public void CABS2207() throws Exception{
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2207 Execution started");
			Thread.sleep(2000);
			POJS10.EnterBRVal(Driver);			
			Thread.sleep(3000);
			System.out.println("Searched and retreived the BR and now validating cancel BR");
			extentTest.log(LogStatus.INFO,
					"Searched and retreived the BR and now validating cancel BR");	
			Thread.sleep(5000);	
			POJS10.CancelEdit(Driver);
			Type="Edit";
			POJS10.BRCancel(Driver, Type);						
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2207 Execution Completed");
			
		}
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();
		POJS9.beforeTest(Driver);
		POJS10.beforeTest(Driver);
		POVIII.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 10 - CABS-1353",
				"BR Cancel button ");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public void aftertest(){
		
		Driver.quit();
	}
	
}
