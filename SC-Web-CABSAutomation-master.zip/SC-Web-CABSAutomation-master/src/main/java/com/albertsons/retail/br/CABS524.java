package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS524 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// View/Edit BR - Allowance-Only users "View billing record" rights, can
	// view billing record
	// CABS1248, CABS1253, CABS1257 Handled here
	@Test(priority = 1, enabled = true)
	public void CABS1246() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1246 Execution started");

		POV.AlwnceBR2(Driver);

		POIV.BRSave(Driver);
		POV.BRSaveNewReady(Driver);

		POV.srchBilRecord(Driver);
		POV.editAllw(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1246 Execution Completed");
	}

	// View/Edit BR - Allowance -EDIT BR with BR Status change
	@Test(priority = 2, enabled = true)
	public void CABS1259() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1259 Execution started");

		POV.brStatusDrppChng(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1259 Execution Completed");
	}

	// View/Edit BR - Allowance-Edit BR with valid CIC having more than 1 row
	// (if data on any of 3 fields( date from, date to, Allowance Amount) on any
	// of the item rows for the CIC is different)
	@Test(priority = 3, enabled = true)
	public void CABS1256() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1256 Execution started");

		POV.cicExpand(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1256 Execution Completed");
	}

	// View/Edit BR - Allowance-BR assigned to Logged in User with Edit My
	// Billing Record right
	@Test(priority = 4, enabled = true)
	public void CABS1251() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1255 Execution started");

		POV.editAllw2(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1255 Execution Completed");
	}

	// View/Edit BR - Allowance-BR assigned to User other than logged in user
	// and with Edit My Billing Record right
	// CABS1255 Also handled here
	@Test(priority = 5, enabled = true)
	public void CABS1249() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1249 Execution started");

		POV.asignToChange(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1249 Execution Completed");
	}

	// View/Edit BR - Allowance -Offset Account # Validation for saved offset #
	// for the team, CABS1269 also handled
	@Test(priority = 6, enabled = true)
	public void CABS1260() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1260 Execution started");

		POV.ofsetNum(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1260 Execution Completed");
	}

	// View/Edit BR - Allowance -Offset Account # Validation when offset #
	// cannot be derived with lookup and Value which is not associated with any
	// GL account #,Facility ID,Section ID
	@Test(priority = 7, enabled = true)
	public void CABS1272() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1272 Execution started");

		
		POV.AlwnceBR3(Driver);
		POV.BRSaveRet(Driver);
	//	POV.BRSaveNewReady(Driver);
		POV.ofSetError(Driver);
	//	POV.errCaseSectionID(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1272 Execution Completed");
	}

	// View/Edit BR - Allowance -Offset Account # Validation when offset #
	// cannot be derived when the derived Section ID is not associated with the
	// Account and Facility for the team, lookup type and Val combo( in
	// GL_Team_Acct_Sect_Ctrl)
	@Test(priority = 8, enabled = true)
	public void CABS1273() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1273 Execution started");

		POV.AlwnceBR3(Driver);
		POV.BRSaveRet(Driver);
		//POV.BRSaveNewReady(Driver);
		POV.ofSetErrorII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1273 Execution Completed");
	}

	// View/Edit BR - Allowance -Offset Account # Validation for saved offset #
	// for the team
	@Test(priority = 7, enabled = true)
	public void CABS1270() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1270 Execution started");
		
		POV.AlwnceBR2(Driver);
		
		POIV.BRSave(Driver);
		POV.BRSaveNewReady(Driver);
		
		POV.incmeValidation(Driver);
		POV.srchBilRecord(Driver);
		 
	 
		POV.editAllwIncm(Driver);
		 
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1270 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-524",
				"View/Edit BR - Allowance");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
