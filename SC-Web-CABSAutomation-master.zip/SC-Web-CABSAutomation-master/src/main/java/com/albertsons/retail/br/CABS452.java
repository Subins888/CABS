package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import jxl.read.biff.BiffException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pageobjects.pageObjectsJSprint4;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS452 extends ExtendBaseClass{
	
	
	  WebDriver Driver;

	    PageObjects PO = new PageObjects(Driver);
	    PageObjectsIV POIV = new PageObjectsIV(Driver);
	    pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	    pageObjectsJSprint4 POS4 = new pageObjectsJSprint4(Driver);

	    GenericFactory pageFact = new GenericFactory(Driver);
	    ITestResult result;
	 /**
	    * Login Functionality
	    * 
	     * @throws Exception
	    */
	    @Test(priority = 0, enabled = true)
	    public void ABS_Login() throws Exception {

	    //           PO.waitforelement();
	                   PO.Login();

	    }
	    
	    
	    
	    
	    /**
	     * Test Case: CABS-1055 Verify header and itemized section fields
	     * @throws InterruptedException
	     * @throws IOException
	     * @throws ParseException
	     * @throws AWTException
	     * @throws BiffException
	     */	     
	    
	     @Test(priority = 1, enabled = true)
	     public void cabs1055() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

	   
	                    extentTest.log(LogStatus.INFO, "Test Case - CABS-1055 Execution started");	                   
	                    PO.AlwnceBR2();
	     
	                    POS3.wait_forBRPage(Driver);
	                    Thread.sleep(3000);
	                    POS4.headrFlatChkBox(Driver);
	                    POS4.buttonsEnb(Driver);
                  //  POS4.itemizedChkBox(Driver);
	                    
	                   // POS4.incomeClk(Driver);

	                    extentTest.log(LogStatus.INFO, "Test Case - CABS-1055 Execution completed");
	                  
	     }
	     
	     /**
		     * Test Case: CABS-1053 Verify if User must be able to select type of allowance income and enter notes
		     * @throws InterruptedException
		     * @throws IOException
		     * @throws ParseException
		     * @throws AWTException
		     * @throws BiffException
		     */	 
	     @Test(priority = 2, enabled = true)
	     public void cabs1053() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

	   
	                    extentTest.log(LogStatus.INFO, "Test Case - CABS-1055 Execution started");	                   
	                      
	                    POS4.acrueClk(Driver);
	                    POS4.BillacrueClk(Driver);
	                    POS4.qtyfieldenter(Driver);
	                    
	                    extentTest.log(LogStatus.INFO, "Test Case - CABS-1055 Execution completed");
	                  
	     }

  @BeforeTest
  public void beforeTest() throws InterruptedException, IOException {
                 Driver = PO.beforeTest();
                 POS4.beforeTest(Driver);
                 POS3.beforeTest(Driver);
                 POIV.beforeTest(Driver);
                 extentTest = extent.startTest("Sprint 4 - CABS-452", "Allowance Income Section - User inputs");
                 extentTest.log(LogStatus.INFO, "Browser Launched");
  }
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
