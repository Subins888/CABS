package com.albertsons.retail.br;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.PageObjectsJIX;
import com.albertsons.pageobjects.pageObjectsJSprint3;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import jxl.read.biff.BiffException;

/**
 * User Story: CABS-943 Overlaps - Overlap Detail Modal
 * 
 * @author JMAYA09
 *
 */

public class CABS943 extends ExtendBaseClass{
	
	WebDriver Driver;
	String BillingId,BillingIdNxt;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsJIX POS10 = new PageObjectsJIX(Driver);
	pageObjectsJSprint3 POS3 = new pageObjectsJSprint3(Driver);
	
	/**
	 * Login Functionality
	 * 
	 * @throws Exception
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();

	}
	

	/**
	 * Test Case: CABS-2166 Verify clicking on hyperlink on item count row on overlap, open up the Overlap Detail modal
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */

	@Test(priority = 1, enabled = true)
	public void cabs2166() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

        PO.wait_forHome();
        extentTest.log(LogStatus.INFO, "Test Case - CABS-2166 Execution started");
        System.out.println("Test Case - CABS-2166 Execution started");
        PO.waitForSpinnerToBeGone();
        POS10.AlwnceBR(Driver);
        PO.waitForSpinnerToBeGone();
        Thread.sleep(15000);
        POS3.wait_forBRPage(Driver);
        Thread.sleep(3000);
        BillingId = POS10.bRHeader(Driver);
        System.out.println(BillingId);
        
        Thread.sleep(2000);
        POS10.AlwnceBR(Driver);
        PO.waitForSpinnerToBeGone();
        Thread.sleep(15000);
        POS3.wait_forBRPage(Driver);
        Thread.sleep(1000);
        BillingIdNxt=POS10.bRHeader(Driver);
        
        POS10.OvrlapDtlModal(Driver,BillingId);

        extentTest.log(LogStatus.INFO, "Test Case - CABS-2166 Execution completed");
        System.out.println("Test Case - CABS-2166 Execution completed");
  }
  
	/**
	 * Test Case: CABS-2167 Validate Overlap detail modal header
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */

	@Test(priority = 2, enabled = true)
	public void cabs2167() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-2167 Execution started");
		System.out.println("Test Case - CABS-2167 Execution started");
			
		POS10.OvrlapDtlModalHdr(Driver,BillingId,BillingIdNxt);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-2167 Execution completed");
		System.out.println("Test Case - CABS-2167 Execution completed");
	}
  
	
	/**
	 * Test Case: CABS-2168 Validate Overlap detail modal table body
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */

	@Test(priority = 3, enabled = true)
	public void cabs2168() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-2168 Execution started");
		System.out.println("Test Case - CABS-2168 Execution started");
			
		POS10.OvrlapDtlModalBody(Driver,BillingId);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-2168 Execution completed");
		System.out.println("Test Case - CABS-2168 Execution completed");
	}
  

	/**
	 * Test Case: CABS-2170 Validate Overlap Detail modal bottom section
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ParseException
	 * @throws AWTException
	 * @throws BiffException
	 */

	@Test(priority = 4, enabled = true)
	public void cabs2170() throws InterruptedException, IOException, ParseException, AWTException, BiffException {

		
		extentTest.log(LogStatus.INFO, "Test Case - CABS-2170 Execution started");
		System.out.println("Test Case - CABS-2170 Execution started");
			
		POS10.OvrlapDtlModalBottm(Driver,BillingId);

		extentTest.log(LogStatus.INFO, "Test Case - CABS-2170 Execution completed");
		System.out.println("Test Case - CABS-2170 Execution completed");
	}
  
  /**
 	 * Browser set up
 	 * 
 	 * @throws InterruptedException
 	 * @throws IOException 
 	 */
 	@BeforeTest
 	public void beforeTest() throws InterruptedException, IOException {
 		Driver = PO.beforeTest();
 		POS10.beforeTest(Driver);
 		POS3.beforeTest(Driver);
 		extentTest = extent.startTest("Sprint 10 - CABS-943", "Overlaps - Overlap Detail Modal");
 		extentTest.log(LogStatus.INFO, "Browser Launched");
 	}

 	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
