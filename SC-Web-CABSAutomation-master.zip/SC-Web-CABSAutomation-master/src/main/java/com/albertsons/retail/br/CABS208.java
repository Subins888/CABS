package com.albertsons.retail.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsJSSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS208 extends ExtendBaseClass {

      WebDriver Driver;
    PageObjects PO = new PageObjects(Driver);
    GenericFactorySprint3 pageFactAS3;
    GenericFactory pageFact = new GenericFactory(Driver);
    ITestResult result;
    PageObjectsJSSprint3 POJS3 = new PageObjectsJSSprint3(Driver);   

      
    @Test(priority = 0, enabled = true)
      public void ABS_Login() throws Exception {

            PO.waitforelement();
            PO.Login();
      }
    /**
     * Test Case: CABS-880 Verify the action bar area and buttons displaying in the Billing Record action bar for Allowance.
     * @throws InterruptedException
     * @throws IOException
     */
    
 
    //Verify the Assign To dropdown field if the user has not selected any user-team in Assign To
    @Test(priority = 1, enabled = true)
   public void CABS_887 () throws Exception {
      extentTest.log(LogStatus.INFO, "Test Case - CABS-887 Execution started");
       
      PO.AlwnceBR2();  
      
      POJS3.waitforbrtxt(Driver);
      
      POJS3.VerifyAssignedToValue(Driver);
      Thread.sleep(3000);
      extentTest.log(LogStatus.INFO, "Test Case - CABS-887 Execution Completed"); 
  }
    
    //Click on Save button without filling any of the mandatory information
    @Test(priority = 2, enabled = true)
    public void CABS_885 () throws Exception {
      extentTest.log(LogStatus.INFO, "Test Case - CABS-885 Execution started");
   
      POJS3.ChkRtSaveMsg(Driver);  
      POJS3.ChkRtSaveMsgVal(Driver);
      Thread.sleep(3000);
      
      extentTest.log(LogStatus.INFO, "Test Case - CABS-885 Execution Completed"); 
  }
    
    
    //Validate Offset# , If only first 2 parts can be derived and the Section ID derived from Teradata is 
    //not associated with the Account and Facility for the team, lookup type and Val combo
    @Test(priority = 3, enabled = false)
    public void CABS_886 () throws Exception {
      extentTest.log(LogStatus.INFO, "Test Case - CABS-886 Execution started");
   
      POJS3.sectNummbr(Driver);
      
      extentTest.log(LogStatus.INFO, "Test Case - CABS-886 Execution Completed"); 
  }
    

    //Verify if the user has explicitly selected a user-team combo in Assign To
    @Test(priority = 4, enabled = true)
    public void CABS_888 () throws Exception {
      extentTest.log(LogStatus.INFO, "Test Case - CABS-888 Execution started");
            
      
      POJS3.assignToCheck(Driver);
      
//      POJS3.RtSaveAssign(Driver);
//        Thread.sleep(3000);
//        POJS3.SelectAssign(Driver);
//        Thread.sleep(3000);
//        pageFactAS3.txtAreaa(Driver);
//        Thread.sleep(3000);
//        POJS3.itemDetailsAmnt2(Driver);
//        Thread.sleep(5000);
//     // pageFact.brStatusdrpclk();
//        // pageFactAS3.brStatusdropp(Driver);
//        Thread.sleep(3000);
//        POJS3.RtDVrAssignedToValue(Driver);
//        Thread.sleep(3000);
//        POJS3.ChkRtSaveMsg(Driver);        
//        Thread.sleep(5000);
      extentTest.log(LogStatus.INFO, "Test Case - CABS-888 Execution Completed"); 
  }
    
    
    //Verify the 3 parts - Account Number, Facility ID & Section ID
    //of the offset number field and check the table where it goes updated while saving the BR
    @Test(priority = 5, enabled = true)
    public void CABS_889 () throws Exception {
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-889 Execution started");
    	
    	  
    	  POJS3.ofsetNum(Driver);
    	  
    	  
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-889 Execution Completed"); 
    	
    }
    
    
    //Verify the BR Status after clicking the Save button
    @Test(priority = 6, enabled = true)
    public void CABS_890 () throws Exception {
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-889 Execution started");
    	
    	  
    	  POJS3.brStatusChk(Driver);
    	  
    	  
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-889 Execution Completed"); 
    	
    }
    
    //Check whether the new Billing Record ID shown in the billing header and also check whether 
    //the new Billing Record ID generated successfuly saved in the back end
    @Test(priority = 7, enabled = true)
    public void CABS_893 () throws Exception {
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-893 Execution started");
    	
    	  
    	  POJS3.getbilngRcrdId(Driver);
    	  
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-893 Execution Completed"); 
    	
    }
    
    //Click on Save button after filling all the mandatory information and check the Error/Success message
    @Test(priority = 8, enabled = true)
    public void CABS_894 () throws Exception {
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-894 Execution started");
    	
    	  
    	  POJS3.succMsg(Driver);
    	  
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-894 Execution Completed"); 
    	
    }
    
    //Validate Offset# , if all 3 parts cannot be derived for this team for the lookup and Value
    @Test(priority = 9, enabled = false)
    public void CABS_930 () throws Exception {
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-930 Execution started");
    	
    	  
    	 
    	  
    	  extentTest.log(LogStatus.INFO, "Test Case - CABS-930 Execution Completed"); 
    	
    }

    @BeforeTest
    public void beforeTest() throws InterruptedException {
        Driver  =   PO.beforeTest();
        POJS3.beforeTest(Driver);
        pageFactAS3=new GenericFactorySprint3(Driver); 
        extentTest = extent.startTest("Sprint 3 - CABS-208", "Save Allowance BR");
        extentTest.log(LogStatus.INFO, "Browser Launched");                    
    }

 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
