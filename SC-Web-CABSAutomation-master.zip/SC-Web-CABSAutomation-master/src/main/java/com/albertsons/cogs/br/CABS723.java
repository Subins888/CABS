package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS723 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//OT Worklist-Verfiy The Over Tolerance Worklist menu for Retail BRs
	@Test(priority = 1, enabled = true)
	public void CABS1495() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1495 Execution started");

		POVI.AlwnceBRII(Driver);
		POVI.brSaveAfterEdit(Driver);
		Thread.sleep(15000);
		POV.BRSaveNewReady(Driver);
		POVI.waitforIncomeBtn(Driver);
		Thread.sleep(2500);
		POIV.incomeAddClk(Driver);
		Thread.sleep(2500);
		POVI.ot(Driver);
	 	POVI.otWorklist(Driver);


		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1495 Execution Completed");
	}
	
	//OT Worklist-Verify The Over Tolerance Worklist menu for MISC BRs
	@Test(priority = 2, enabled = false)
	public void CABS1496() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1496 Execution started");
		
	 PO.nonAlwnceNew();
	 POV.brSavNonAlw(Driver);
	 POVI.MiscincomeAddClk(Driver);
	 Thread.sleep(2500);
	 POVI.otMiscII(Driver);
	 
	 
	 
	 POVI.otWorklistMisc(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1496 Execution Completed");
	}
	
	
	//OT Worklist-Verfiy OT worklist data for Retail BRs
	//CABS1502 Also handled here
	@Test(priority = 3, enabled = false)
	public void CABS1497() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1497 Execution started");
		
		POVI.searchBtnClk(Driver);
		Thread.sleep(2500);
		POVI.OTWorklistLeftClk(Driver);
		Thread.sleep(2500);
		POVI.OTDatacheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1497 Execution Completed");
	}
	
	//Check all user's Over Tolerance Worklist menu
	@Test(priority = 4, enabled = false)
	public void CABS1503() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1503 Execution started");
		POVI.diffUserOT(Driver);
	 

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1503 Execution Completed");
	}
	
	
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 6 - CABS-723",
				"OT Worklist - List BRs for the selected user");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
