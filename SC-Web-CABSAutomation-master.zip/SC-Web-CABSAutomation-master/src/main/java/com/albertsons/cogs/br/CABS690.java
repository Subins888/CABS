package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS690 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify the OT validation of "Bill" type income for Allowance billing,when
	// total income >= OT limit for the Acct Lookup Val and Type for the team
	// CABS1452 also handled here
	@Test(priority = 1, enabled = true)
	public void CABS1430() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1430 Execution started");

		POVIII.AlwnceBRNoItemizd(Driver);
		POVI.brSaveAfterEdit(Driver);
		POV.BRSaveNewReady(Driver);
		POVI.waitforIncomeBtn(Driver);
		Thread.sleep(45000);
		POIV.incomeAddClk(Driver);
		POVI.ot(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1430 Execution Completed");
	}

	// Verify the OT validation of "Accrue" type income for Allowance
	// billing,when total income >= OT limit for the Acct Lookup Val and Type
	// for the team
	@Test(priority = 2, enabled = true)
	public void CABS1431() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1431 Execution started");

		Thread.sleep(45000);
		POVI.acrueClk(Driver);
		Thread.sleep(2500);
		POIV.incomeAddClk(Driver);
		POVI.ot(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1431 Execution Completed");
	}

	// Verify the OT validation of "Bill & Accrue" type income for Allowance
	// billing,when total income >= OT limit for the Acct Lookup Val and Type
	// for the team
	@Test(priority = 3, enabled = true)
	public void CABS1439() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1439 Execution started");

		Thread.sleep(45000);
		POVI.bilNdacruClk(Driver);
		Thread.sleep(2500);
		POIV.incomeAddClk(Driver);
		POVI.ot(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1439 Execution Completed");
	}

	// Verify the OT validation of "Bill" type income for Allowance billing,when
	// total income < OT limit for the Acct Lookup Val and Type for the team and
	// total income >= trainee OT limit for the user
	@Test(priority = 4, enabled = true)
	public void CABS1432() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1432 Execution started");

		Thread.sleep(45000);
		POIV.incomeAddClk(Driver);
		POVI.otII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1432 Execution Completed");
	}

	// Verify the OT validation of "Accrue" type income for Allowance
	// billing,when total income < OT limit for the Acct Lookup Val and Type for
	// the team and total income >= trainee OT limit for the user

	@Test(priority = 5, enabled = true)
	public void CABS1433() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1433 Execution started");

		Thread.sleep(45000);
		POVI.acrueClk(Driver);
		Thread.sleep(2500);
		POIV.incomeAddClk(Driver);
		Thread.sleep(3600);
		POVI.otII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1433 Execution Completed");
	}

	// Verify the OT validation of "Bill" type income for Misc billing,when
	// total income >= OT limit for the Acct Lookup Val and Type for the team

	@Test(priority = 6, enabled = false)
	public void CABS1434() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1434 Execution started");

		POVI.searchBtnClk(Driver);
		Thread.sleep(2500);
		
		
		PO.nonAlwnceNew();
		POV.brSavNonAlw(Driver);
		POVI.waitforMiscIncomeBtn(Driver);
		POVI.MiscincomeAddClk(Driver);
		POVI.otMisc(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1434 Execution Completed");
	}

	// Verify the OT validation of "Accrue" type income for Misc billing,when
	// total income >= OT limit for the Acct Lookup Val and Type for the team
	@Test(priority = 7, enabled = false)
	public void CABS1438() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1438 Execution started");

		Thread.sleep(2500);
		POVI.acrueClkMisc(Driver);
		Thread.sleep(2500);
		POVI.addIncomeCollapseCase(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1438 Execution Completed");
	}

	// Verify the OT validation of "Bill &Accrue" type income for Misc
	// billing,when total income >= OT limit for the Acct Lookup Val and Type
	// for the team
	// CABS1441 also handled here
	@Test(priority = 8, enabled = false)
	public void CABS1440() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1440 Execution started");

		Thread.sleep(2500);
		POVI.BilacrueClkMisc(Driver);
		Thread.sleep(2500);
		POVI.addIncomeCollapseCase(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1440 Execution Completed");
	}

	// Verify the OT validation of "Bill" type income for Misc billing which is
	// not associated with acct Lkup type & val,when total income >= Misc. OT
	// limit for the user
	@Test(priority = 9, enabled = false)
	public void CABS1442() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1442 Execution started");

		POVI.searchBtnClk(Driver);
		Thread.sleep(2500);
		POVII.nonAlwnceNoRetailType(Driver);
		Thread.sleep(5000);
		POVII.ofsetValidationMisc(Driver);
		Thread.sleep(5000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(3000);
		POVI.otMiscII(Driver);
		Thread.sleep(3000);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1442 Execution Completed");
	}

	// Verify the OT validation of "Accrue" type income for Misc billing which
	// is not associated with acct Lkup type & val,when total income >= Misc. OT
	// limit for the user
	@Test(priority = 10, enabled = false)
	public void CABS1443() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1443 Execution started");

		POVI.acrueClkMisc(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheckAcru(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1443 Execution Completed");
	}

	// Verify the OT validation of "Bill & Accrue" type income for Misc billing
	// which is not associated with acct Lkup type & val,when total income >=
	// Misc. OT limit for the user
	@Test(priority = 11, enabled = false)
	public void CABS1444() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1444 Execution started");

		POVI.BilacrueClkMisc(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheckBilNdAcru(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1444 Execution Completed");
	}

	// Verify the OT validation of "Bill" type income for Misc billing,when
	// total income < OT limit for the Acct Lookup Val and Type for the team and
	// total income on the income record >= trainee OT limit for the user
	@Test(priority = 12, enabled = false)
	public void CABS1445() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1445 Execution started");

		POVI.searchBtnClk(Driver);
		Thread.sleep(2500);
		POVII.nonAlwnceType(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1445 Execution Completed");
	}

	// Verify the OT validation of "Accrue" type income for Misc billing,when
	// total income < OT limit for the Acct Lookup Val and Type for the team and
	// total income on the income record >= trainee OT limit for the user
	@Test(priority = 13, enabled = false)
	public void CABS1446() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1446 Execution started");

		POVI.acrueClkMisc(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheckAcru(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1446 Execution Completed");
	}

	// Verify the OT validation of "Bill & Accrue" type income for Misc
	// billing,when total income < OT limit for the Acct Lookup Val and Type for
	// the team and total income on the income record >= trainee OT limit for
	// the user
	@Test(priority = 14, enabled = false)
	public void CABS1448() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1448 Execution started");

		POVI.BilacrueClkMisc(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheckBilNdAcru(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1448 Execution Completed");
	}

	// Verify the OT validation of "Bill" type income for Misc billing which is
	// not associated with acct Lkup type & val,when total income <Misc. OT
	// limit for the user and the total income on the income record >= trainee
	// OT limit for the user

	@Test(priority = 15, enabled = false)
	public void CABS1449() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1449 Execution started");

		POVI.searchBtnClk(Driver);
		Thread.sleep(2500);
		POVII.nonAlwnceType(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVII.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1449 Execution Completed");
	}

	// Verify the OT validation of "Accrue" type income for Misc billing which
	// is not associated with acct Lkup type & val,when total income <Misc. OT
	// limit for the user and the total income on the income record >= trainee
	// OT limit for the user
	@Test(priority = 16, enabled = false)
	public void CABS1450() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1450 Execution started");

		POVI.acrueClkMisc(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheckAcru(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1450 Execution Completed");
	}

	// Verify the OT validation of "Bill & Accrue" type income for Misc billing
	// which is not associated with acct Lkup type & val,when total income
	// <Misc. OT limit for the user and the total income on the income record >=
	// trainee OT limit for the user
	@Test(priority = 17, enabled = false)
	public void CABS1451() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1451 Execution started");

		POVI.BilacrueClkMisc(Driver);
		Thread.sleep(2000);
		POVII.miscIncmeBtnClk(Driver);
		Thread.sleep(2000);
		POVI.otMiscII(Driver);
		Thread.sleep(2000);
		POVII.pendingOTCheckBilNdAcru(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1451 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POVII.beforeTest(Driver);
		
		POVIII.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 6 - CABS-690",
				"Over Tolerance - Check if income exceeded OT limit");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
