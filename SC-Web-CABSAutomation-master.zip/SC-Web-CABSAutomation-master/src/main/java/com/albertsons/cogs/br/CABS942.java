package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS942 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Invalid CIC with Lead CIC Ie, CIC start and end date after BR start and
	// end Date
	@Test(priority = 1, enabled = true)
	public void CABS1462() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1462 Execution started");

		POVI.COGSAlwnceBRinvalid(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1462 Execution Completed");
	}

	// Valid CIC with Lead CIC start date before BR start date and CIC end date
	// after BR start date.
	// CABS1464 also handled here
	@Test(priority = 2, enabled = true)
	public void CABS1463() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1463 Execution started");

//		POVI.searchBtnClk(Driver);
//		Thread.sleep(5000);
		PO.AlwnceBR();
		POVI.newBRpage(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1463 Execution Completed");
	}

	// Valid CIC with multiple ROG's and that have at least some range of its
	// effective dates overlapping with the billing date range
	@Test(priority = 3, enabled = false)
	public void CABS1465() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1465 Execution started");

		POVI.searchBtnClk(Driver);
		Thread.sleep(3000);
		POVI.waitforBlngbtn(Driver);
		Thread.sleep(3000);
		POVI.AlwnceBR(Driver);
		POVI.newBRpage(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1465 Execution Completed");
	}

	//Invalid CIC with Lead CIC start and end date before BR start and end date
	@Test(priority = 4, enabled = true)
	public void CABS1467() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1467 Execution started");

		POVI.searchBtnClk(Driver);
		Thread.sleep(3000);
		POVI.waitforBlngbtn(Driver);
		Thread.sleep(3000);
		POVI.AlwnceBRinvalid(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1467 Execution Completed");
	}
	
	
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 6 - CABS-942",
				"Items - Map NOPA Division to ROGs for fetching item data");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
