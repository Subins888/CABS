package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;

import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1743 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);

	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify whether the header income input field values is cleared and
	// disabled while uncheck Header check box
	@Test(priority = 1, enabled = false)
	public void CABS2025Data() throws Exception {

		String tcName = "CABS-2025";
		String inputVal = POIX.readExcel(Driver, tcName);
		System.out.println("inn " + inputVal);
		if (inputVal != null) {
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2025 Execution started");
			System.out.println("Test Case - CABS-2025 Execution started");

			if (POIX.SearchData(Driver, inputVal) == false) {
				String status = "PASS";
				POIX.writeExcel(Driver, status, tcName);
			} else {

				String status = "FAIL";
				POIX.writeExcel(Driver, status, tcName);
			}

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2025 Execution completed");
			System.out.println("Test Case - CABS-2025 Execution completed");

		} else {
			extentTest
					.log(LogStatus.INFO, "Test Case - CABS-2025 NOT Executed");
			System.out.println("Test Case - CABS-2025 NOT Executed");
		}

		Thread.sleep(25000);
		POIX.headerCheck(Driver);

	}

	// Verify whether the header income input field values is cleared and
	// disabled while uncheck Header check box
	@Test(priority = 1, enabled = true)
	public void CABS2025() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2025 Execution started");

		POVIII.waitForSpinnerToBeGone(Driver);

		// Thread.sleep(20000);

		Thread.sleep(2000);

		POVIII.AlwnceBRNoItemizd(Driver);

		// POIX.Search(Driver);
		// Thread.sleep(3000);
		//
		// POIX.SearchFirstItemClk(Driver);
		// POIX.waitforbrtxt(Driver);
		//
		// Thread.sleep(15000);

		POIX.waitforbrtxt(Driver);
		// Thread.sleep(20000);
		POVIII.waitForSpinnerToBeGone(Driver);

		POVIII.BRSave(Driver);

		POVIII.waitForSpinnerToBeGone(Driver);
		Thread.sleep(25000);

		POIX.headerCheck(Driver);
		Thread.sleep(3000);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2025 Execution Completed");
	}

	// Verify whether the itemized income input field values is cleared and
	// disabled while uncheck Itemized check box
	@Test(priority = 2, enabled = true)
	public void CABS2026() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2026 Execution started");

		POIX.itemizedCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2026 Execution Completed");
	}

	// Verify whether the Save and Submit is disabled while uncheck Header and
	// Itemized check box
	@Test(priority = 3, enabled = true)
	public void CABS2027() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2027 Execution started");

		POIX.buttonEnabledCheck(Driver);
		Thread.sleep(20000);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2027 Execution Completed");
	}

	// Verify whether the Income 'itemized section' is disabled while flat code
	// saved on the BR and no itemized allowance code
	@Test(priority = 4, enabled = false)
	public void CABS2028() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2028 Execution started");

		POVIII.searchBtn(Driver);
		Thread.sleep(1500);
		POIX.WarningYES(Driver);

		Thread.sleep(7000);

		POVIII.AlwnceBRNoItemizd(Driver);
		POVIII.BRSave(Driver);
		POVIII.waitforReadyBtn(Driver);
		Thread.sleep(2500);
		POVIII.readyBtnClk(Driver);
		Thread.sleep(3000);
		POIX.headerCheckII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2028 Execution Completed");
	}

	// Verify whether the Income 'header section' is disabled while Itemized
	// allowance code saved on the BR and no flat code
	@Test(priority = 5, enabled = false)
	public void CABS2029() throws Exception {

		String tcName = "CABS-2029";
		String inputVal = POIX.readExcel(Driver, tcName);
		System.out.println("inn " + inputVal);
		if (inputVal != null) {
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2029 Execution started");
			System.out.println("Test Case - CABS-2029 Execution started");

			Thread.sleep(1500);
			POIX.WarningYES(Driver);

			Thread.sleep(7000);

			if (POIX.SearchData(Driver, inputVal) == false) {
				String status = "PASS";
				POIX.writeExcel(Driver, status, tcName);
			} else {

				String status = "FAIL";
				POIX.writeExcel(Driver, status, tcName);
			}

			// extentTest.log(LogStatus.INFO,
			// "Test Case - CABS-2029 Execution completed");
			// System.out.println("Test Case - CABS-2029 Execution completed");

		} else {
			extentTest
					.log(LogStatus.INFO, "Test Case - CABS-2029 NOT Executed");
			System.out.println("Test Case - CABS-2029 NOT Executed");
		}

		Thread.sleep(3000);
		POIX.headerCheckIII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2029 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		POVIII.beforeTest(Driver);
		POIX.beforeTest(Driver);
	 

		extentTest = extent
				.startTest("Sprint 9 - CABS-1743",
						"Allowance Income - Disable & Clear unselected allowance income section");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
