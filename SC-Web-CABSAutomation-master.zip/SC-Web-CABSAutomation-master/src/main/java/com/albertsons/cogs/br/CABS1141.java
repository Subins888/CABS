package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1141 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify Ready button is enabled while creating the BR for allowance for
	// user with 'Create Billing Record' rights
	//CABS-1684
	@Test(priority = 1, enabled = true)
	public void CABS1682() throws Exception {

		String tcName = "CABS-1682";
		String inputVal = POIX.readExcel(Driver, tcName);
		if (inputVal != null) {
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1682 Execution started");
			System.out.println("Test Case - CABS-1682 Execution started");

			POX.COGSAlwnceBR(Driver, inputVal);

			if (POX.brSubmit(Driver, inputVal) == true) {
				String status = "PASS";
				POIX.writeExcel(Driver, status, tcName);
			} else {

				String status = "FAIL";
				POIX.writeExcel(Driver, status, tcName);
			}

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1682 Execution completed");
			System.out.println("Test Case - CABS-1682 Execution completed");

		} else {
			extentTest
					.log(LogStatus.INFO, "Test Case - CABS-1682 NOT Executed");
			System.out.println("Test Case - CABS-1682 NOT Executed");
		}

	}

	// Verify income section, when Ready button is enabled while creating the BR
	// for allowance for user with only 'Create Billing Record' rights
	@Test(priority = 2, enabled = true)
	public void CABS1683() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1683 Execution started");
		System.out.println("Test Case - CABS-1683 Execution started");

		POX.incomeBtn(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1683 Execution completed");
		System.out.println("Test Case - CABS-1683 Execution completed");

	}
	
	@Test(priority = 3, enabled = true)
	public void CABS1685() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1685 Execution started");
		System.out.println("Test Case - CABS-1685 Execution started");

		POX.readyOtherRights(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1685 Execution completed");
		System.out.println("Test Case - CABS-1685 Execution completed");

	}
	

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 10 - CABS-1141",
				"Ready for Income status - follow-up story");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest(){
		
		Driver.quit();
	}
}
