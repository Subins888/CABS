package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1907 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify the 'Account Lookup Type' drop down field and the values for COGS
	// Allowance
	@Test(priority = 1, enabled = true)
	public void CABS2196() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2196 Execution started");

		POX.COGSAlwnceBRLukupVal(Driver);
		POX.COGSDrpValue(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2196 Execution Completed");
	}

	// Verify whether the given offset number field is valid or not for COGS
	// facility name
	@Test(priority = 2, enabled = true)
	public void CABS2197() throws Exception {

		String tcName = "CABS-2197";
		String inputVal = POIX.readExcel(Driver, tcName);
		if (inputVal != null) {
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2197 Execution started");
			System.out.println("Test Case - CABS-2197 Execution started");

			POX.COGSAlwnceBRInvalid(Driver, inputVal);

			if (POX.brSubmitInvalidCOGS(Driver) == true) {
				String status = "PASS";
				POIX.writeExcel(Driver, status, tcName);
			} else {

				String status = "FAIL";
				POIX.writeExcel(Driver, status, tcName);
			}

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2197 Execution completed");
			System.out.println("Test Case - CABS-2197 Execution completed");

		} else {
			extentTest
					.log(LogStatus.INFO, "Test Case - CABS-2197 NOT Executed");
			System.out.println("Test Case - CABS-2197 NOT Executed");
		}
	}

	// Section ID validation for COGS
	@Test(priority = 3, enabled = true)
	public void CABS2198() throws Exception {

		String tcName = "CABS-2198";
		String inputVal = POIX.readExcel(Driver, tcName);
		if (inputVal != null) {
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2198 Execution started");
			System.out.println("Test Case - CABS-2198 Execution started");

			if (POX.sectionIDValidation(Driver, inputVal) == true) {
				String status = "PASS";
				POIX.writeExcel(Driver, status, tcName);
			} else {

				String status = "FAIL";
				POIX.writeExcel(Driver, status, tcName);
			}

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-2198 Execution completed");
			System.out.println("Test Case - CABS-2198 Execution completed");

		} else {
			extentTest
					.log(LogStatus.INFO, "Test Case - CABS-2198 NOT Executed");
			System.out.println("Test Case - CABS-2198 NOT Executed");
		}
	}

	// Verify Income Save and Submit for COGS
	// CABS-2214
	@Test(priority = 4, enabled = true)
	public void CABS2199() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2199 Execution started");
		System.out.println("Test Case - CABS-2199 Execution started");

		POX.BRSave(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2199 Execution completed");
		System.out.println("Test Case - CABS-2199 Execution completed");

	}

	// Offset# - Verify the three parts of Auto derived Offset Number field-COGS
	// CABS-2209, CABS-2210, CABS-2211,CABS-2216, CABS-2213, CABS-2223
	@Test(priority = 5, enabled = true)
	public void CABS2208() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2208 Execution started");
		System.out.println("Test Case - CABS-2208 Execution started");

		POX.offsetValidation(Driver);
		POX.CICValidation(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2208 Execution completed");
		System.out.println("Test Case - CABS-2208 Execution completed");

	}

	// CIC - Invalid CIC with Lead CIC start and end date before BR start and
	// end date - COGS
	// CABS-2222
	@Test(priority = 6, enabled = true)
	public void CABS2219() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2219 Execution started");
		System.out.println("Test Case - CABS-2219 Execution started");

		
		POX.searchBtn(Driver);
		Thread.sleep(2500);
		
		POX.WarningYES(Driver);
		Thread.sleep(4500);
		
		POX.COGSAlwnceBRNoItemized(Driver);
		Thread.sleep(7500);

		POX.invalidCOGSCIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2219 Execution completed");
		System.out.println("Test Case - CABS-2219 Execution completed");

	}

	// Verify the Offset Number field when the user has only 'View-only' role
	// for the team - COGS
	@Test(priority = 7, enabled = true)
	public void CABS2212() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2212 Execution started");
		System.out.println("Test Case - CABS-2212 Execution started");

		POX.otherUser(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2212 Execution completed");
		System.out.println("Test Case - CABS-2212 Execution completed");

	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent
				.startTest("Sprint 10 - CABS-1907",
						"COGs - Change Acct Lkup Type name to match NOPA facility name");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	
	@AfterTest
	public void aftertest(){
		
		Driver.quit();
	}

}
