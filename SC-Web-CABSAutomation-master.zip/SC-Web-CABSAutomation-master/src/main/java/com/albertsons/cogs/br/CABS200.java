package com.albertsons.cogs.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS200 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// CIC - Invalid CIC with Lead CIC Ie, CIC start and end date after BR start
	// and end Date - COGS
	@Test(priority = 1, enabled = true)
	public void CABS838() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-838 Execution started");

		POVI.COGSAlwnceBRinvalid(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-838 Execution Completed");
	}

	// ALT - Verify the 'Account Lookup Type' drop down field and the values for
	// COGS Allowance
	@Test(priority = 2, enabled = true)
	public void CABS687() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-687 Execution started");

		POVI.COGSAlwnceBR(Driver);
		POVI.cogsChck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-687 Execution Completed");
	}

	// Offset# - Verify the three parts of Auto derived Offset Number field-COGS
	// CABS-940 also handled here
	@Test(priority = 3, enabled = true)
	public void CABS937() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-937 Execution started");

		POVI.ofsetNum(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-937 Execution Completed");
	}

	// Offset# - Verify whether the given offset number field is valid or not
	// [For COGS]
	@Test(priority = 4, enabled = true)
	public void CABS914() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-914 Execution started");

		POVI.ofsetInvalid(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-914 Execution Completed");
	}

	// Offset# - Verify the Offset Number field When the team has setup Forced
	// Section ID/Default Section ID - COGS
	//FALSE
	@Test(priority = 5, enabled = false)
	public void CABS938() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-938 Execution started");

		POVI.ofsetTeraDbcase(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-938 Execution Completed");
	}

	// Offset# - Verify the Offset Number field when the user has only
	// 'View-only' role for the team - COGS
	@Test(priority = 6, enabled = false)
	public void CABS941() throws Exception {

		extentTest
				.log(LogStatus.INFO, "Test Case - CABS-941 Execution started");

		POVI.teamXternal(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-941 Execution Completed");
	}

	// ALW T, Perf - Verify Performance 1 & Performance 2 of COGS billing type
	// for Allowance Type "C"
	@Test(priority = 7, enabled = false)
	public void CABS1480() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1480 Execution started");

		POVI.bRTypeCOGSItemized(Driver);
		POVI.allwTypeC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1480 Execution Completed");
	}

	// ALW T, Perf - Verify Performance 1 & Performance 2 of COGS billing type
	// for Allowance Type "A"
	@Test(priority = 8, enabled = false)
	public void CABS1479() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1479 Execution started");

		POVI.allwTypeA(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1479 Execution Completed");
	}

	// CIC - Valid CIC with Lead CIC start date before BR start date and CIC end
	// date after BR start date- COGS
	@Test(priority = 9, enabled = false)
	public void CABS1481() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1481 Execution started");

 
		POVI.COGSAlwnceBRnoOfsetIII(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1481 Execution Completed");
	}
	
	//CIC - Invalid CIC with Lead CIC start and end date before BR start and end date - COGS
	@Test(priority = 10, enabled = false)
	public void CABS1484() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1484 Execution started");

		POVI.COGSAlwnceBRnoOfsetIV(Driver);
	 
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1484 Execution Completed");
	}
	
	//CIC - Valid CIC with Lead CIC start date before BR start date and CIC end date Before BR end date -COGS
	//CABS-
	@Test(priority = 11, enabled = false)
	public void CABS1486() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1486 Execution started");

		POVI.COGSAlwnceBRnoOfsetV(Driver); 
	 
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1486 Execution Completed");
	}
	
	//Item Details - Check Allowance Header Table and Allowance Detail Table after successful save of BR- COGS
		@Test(priority = 12, enabled = false)
		public void CABS1489() throws Exception {

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1489 Execution started");

			POVI.brSaveAfterEdit(Driver);
		 
			
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1489 Execution Completed");
		}
	 

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 6 - CABS-200",
				"CABS - COGS allowance support");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
