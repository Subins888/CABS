package com.albertsons.search;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1135 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify Basic Filtering in Search Billing Record Page for BR# filtering
	@Test(priority = 1, enabled = true)
	public void CABS1762() throws Exception {

        String tcName = "CABS-1762";
        String inputVal =readExcel(tcName);
              if (inputVal != null) {
                     extentTest.log(LogStatus.INFO, "Test Case - CABS-1762 Execution started");
                     System.out.println("Test Case - CABS-1762 Execution started");

                     if(POVIII.SearchData(Driver,inputVal)== true) {
                           String status = "PASS";
                           writeExcel(status,tcName);
                     }
                     else {
                           
                            String status = "FAIL";
                           writeExcel(status,tcName);
                     }
	
                     extentTest.log(LogStatus.INFO, "Test Case - CABS-1762 Execution completed");
                     System.out.println("Test Case - CABS-1762 Execution completed");
                     
              }
              else {
                     extentTest.log(LogStatus.INFO, "Test Case - CABS-1762 NOT Executed");
                     System.out.println("Test Case - CABS-1762 NOT Executed");
              }


	}

	// Verify Basic Filter in Search Billing Record Page for Billing Name
	// filtering
	@Test(priority = 2, enabled = true)
	public void CABS1763() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1763 Execution started");

		POVIII.searchNameFiltering(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1763 Execution Completed");
	}

	// Verify Basic Filtering in Search Billing Record Page for BR Status
	// filtering
	// CABS1767 Handled here
	@Test(priority = 3, enabled = true)
	public void CABS1764() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1764 Execution started");

		POVIII.brStatusValidation(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1764 Execution Completed");
	}

	// Verify Basic Filter in Search Billing Record Page for Assign To filtering
	// CABS1767 Handled here
	@Test(priority = 4, enabled = true)
	public void CABS1765() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1765 Execution started");

		POVIII.assignToDrpValidation(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1765 Execution Completed");
	}

	// Search Basic filter-Verify if user able to select one or more filter
	// options
	@Test(priority = 5, enabled = true)
	public void CABS1768() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1768 Execution started");

		POVIII.multipleFilters(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1768 Execution Completed");
	}

	public String readExcel(String tcName) throws IOException {
		String xlfile = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fis = new FileInputStream(xlfile);

		HSSFWorkbook CABS_TestRslt = null;

		CABS_TestRslt = new HSSFWorkbook(fis);

		HSSFSheet s = CABS_TestRslt.getSheet("TestExecutionMetrics");

		int Norows = s.getLastRowNum();

		for (int i = 1; i <= Norows; i++) {

			String s1 = s.getRow(i).getCell(0).toString();

			String s2 = s.getRow(i).getCell(1).toString();
			String s3 = s.getRow(i).getCell(2).toString();

			// System.out.println("s1" + s1);
			// System.out.println("s2" + s2);
			// System.out.println("s3" + s3);
			// System.out.println(tcName);

			if (s1.contentEquals(tcName)) {
				if (s2.contentEquals("Y")) {
					return s3;
				} else {
					return null;
				}
			}
		}
		return null;
	}

	public String writeExcel(String status, String tcName) throws IOException {
		String xlfile = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();

		FileInputStream fis = new FileInputStream(xlfile);

		HSSFWorkbook CABS_TestRslt = null;

		CABS_TestRslt = new HSSFWorkbook(fis);

		HSSFSheet s = CABS_TestRslt.getSheet("TestExecutionMetrics");

		int Norows = s.getLastRowNum();

		for (int i = 1; i <= Norows; i++) {

			String s1 = s.getRow(i).getCell(0).toString();

			String s2 = s.getRow(i).getCell(1).toString();
			String s3 = s.getRow(i).getCell(2).toString();

			// System.out.println("s1" + s1);
			// System.out.println("s2" + s2);
			// System.out.println("s3" + s3);

			if (s1.contentEquals(tcName)) {
				if (s2.contentEquals("Y")) {
					Row row = s.getRow(i);

					String[] valueToWrite = { status };

					int j = 3;

					Cell cell = row.createCell(j);
					System.out.println("Cell Created");

					cell.setCellValue(valueToWrite[0]);

					System.out.println("value written");

					fis.close();

					FileOutputStream fos = new FileOutputStream(xlfile);
					CABS_TestRslt.write(fos);
					fos.close();
					return null;

				}
			}

		}
		return null;
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		POVIII.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 8 - CABS-1135",
				"Search Basic filter");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
