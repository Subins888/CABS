package com.albertsons.search;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSJX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1136 extends ExtendBaseClass {
              WebDriver Driver;
              PageObjects PO = new PageObjects(Driver);
              GenericFactory pageFact = new GenericFactory(Driver);
              GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
              PageObjectsSJX POJS10 = new PageObjectsSJX(Driver);
              ITestResult result;
              
              @Test(priority = 0, enabled = true)
              public void ABS_Login() throws Exception {

                             PO.waitforelement();
                             PO.Login();
              }
              //Verify More filter options in Search Billing Record Page for Account Lookup Type & Val for Account Lookup Type & Val
              @Test(priority = 1, enabled = true)
              public void CABS2368() throws Exception {
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2368 Execution started");
                             
                             POJS10.AdvSearchAcct(Driver);
                             POJS10.ValResultArea(Driver);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2368 Execution Completed");
                             
              }
              
              //Verify More filter options in Search Billing Record Page for Section
              @Test(priority = 2, enabled = true)
              public void CABS2369() throws Exception {
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2369 Execution started");
                             POJS10.AdvSearchSection(Driver);
                             Thread.sleep(3000);
                             POJS10.ValResultSection(Driver);                                                       
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2369 Execution Completed");
              }
              //Verify More filter options in Search Billing Record Page for Allowance Type filtering
              @Test(priority = 3, enabled = true)
              public void CABS2370() throws Exception {
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2370 Execution started");
                             POJS10.AdvSearchAlwnc(Driver);
                             Thread.sleep(3000);
                             POJS10.ValResultAlwnc(Driver);
                             
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2370 Execution Completed");
                             
              }
              //Verify More filter options in Search Billing Record Page for Flat Amount filtering
              @Test(priority = 4, enabled = true)
              public void CABS2371() throws Exception {
                             extentTest.log(LogStatus.INFO,
                                                         "Test Case - CABS-2371 Execution started");
                             POJS10.AdvSearchFlatAmt(Driver);
                             POJS10.ValResulFlatAmt(Driver);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2371 Execution Completed");
                             
              }
              //Search More filter options filter-Verify if user able to select one or more filter options
              @Test(priority = 5, enabled = true)
              public void CABS2372() throws Exception {
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2372 Execution started");
                             POJS10.AdvSearchMultipleFilter(Driver);                            
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2372 Execution Completed");
                             
              }
              
              //Handled user story 2265-Search filter options - Dialog filter
              //Search filter options - Dialog filter for retail/cogs
              @Test(priority = 6, enabled = true)
              public void CABS2529() throws Exception {
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2372 Execution started");
                             POJS10.dialogFilter(Driver);                      
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2372 Execution Completed");
                             
              }
              
              //Handled user story 2265-Search filter options - Dialog filter
                             //Search filter options - Dialog filter for misc
                             @Test(priority = 7, enabled = true)
                             public void CABS2530() throws Exception {
                                           extentTest.log(LogStatus.INFO,
                                                                        "Test Case - CABS-2372 Execution started");
                                           POJS10.dialogFilterMisc(Driver);              
                                           extentTest.log(LogStatus.INFO,
                                                                        "Test Case - CABS-2372 Execution Completed");
                                           
                             }
              
              
              
  @BeforeTest
  public void beforeTest() throws InterruptedException {
                Driver = PO.beforeTest();
      POJS10.beforeTest(Driver);
      extentTest = extent.startTest("Sprint 11 - CABS-1136",
                                   "Search - More filter options ");
      extentTest.log(LogStatus.INFO, "Browser successfully launched");
  }

  @AfterTest
  public void afterTest() {
	  
	  Driver.quit();
  }

}
