package com.albertsons.search;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pageobjects.pageObjects11;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS2394 Browser Back button support for search
 * 
 * @author akuma58
 *
 */

public class CABS2394 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	pageObjects11 PO11 = new pageObjects11(Driver);

	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify whether the Browser back button is working for BR detail page
	// CABS2665, 2666, 2667
	@Test(priority = 1, enabled = true)
	public void CABS2664() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2664 Execution started");

		PO11.backButtonClick(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2664 Execution completed");
	}

	// CORRECTIONS FROM UAT TESTING - CABS2434
	@Test(priority = 2, enabled = true)
	public void CABS2564() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2664 Execution started");

		PO11.dollar(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2664 Execution completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		PO11.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 13 - CABS-2394 ",
				"Browser Back button support for search");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public void afterTest() {
		Driver.quit();
	}

}
