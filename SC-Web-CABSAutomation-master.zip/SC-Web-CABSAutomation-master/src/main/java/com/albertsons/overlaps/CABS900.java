package com.albertsons.overlaps;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS900 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify the BR if overlaps are identified and are unresolved, when user
	// view/save the BR
	@Test(priority = 1, enabled = true)
	public void CABS1843() throws Exception {

		String tcName = "CABS-1843";
		String inputVal = POIX.readExcel(Driver, tcName);
		System.out.println("inn " + inputVal);
		if (inputVal != null) {
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-1843 Execution started");
			System.out.println("Test Case - CABS-1843 Execution started");

			if (POIX.SearchData(Driver, inputVal) == true) {
				String status = "PASS";
				POIX.writeExcel(Driver, status, tcName);
			} else {

				String status = "FAIL";
				POIX.writeExcel(Driver, status, tcName);
			}

			System.out
					.println("Test Case - CABS-CABS-1843 Execution completed");

		} else {

			System.out.println("Test Case - CABS-1843 NOT Executed");
			extentTest
					.log(LogStatus.INFO, "Test Case - CABS-1843 NOT Executed");

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS-CABS-1843 Execution completed");
		}

		Thread.sleep(5000);
		POIX.overlapWarning(Driver);

	}

	// Verify the overlap dropdown list every BR that overlaps with current BR
	@Test(priority = 2, enabled = true)
	public void CABS1844() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1844 Execution started");
		System.out.println("Test Case - CABS-1844 Execution started");

		Thread.sleep(5000);
		POIX.overlapValidation(Driver);

		System.out.println("Test Case - CABS-CABS-1844 Execution completed");
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-CABS-1844 Execution completed");
	}

	// Verify the expanded view of the accordion is showing current and
	// overlapping BR ID along with Overlaps
	@Test(priority = 3, enabled = true)
	public void CABS1845() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1845 Execution started");
		System.out.println("Test Case - CABS-1845 Execution started");

		POIX.overlapValidationII(Driver);

		System.out.println("Test Case - CABS-CABS-1845 Execution completed");
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-CABS-1845 Execution completed");
	}

	// Verify the row information listed for Current vs Overlap BR for Date
	// Compare Method 'B'
	// Hyperlink from above testcase and stores count calculated here
	// CABS1847,1848 handled here, the functionality of the values covered in
	// CABS899 userstory
	@Test(priority = 4, enabled = true)
	public void CABS1846() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1846 Execution started");
		System.out.println("Test Case - CABS-1846 Execution started");

		POIX.hyperlinkStoresCount(Driver);

		System.out.println("Test Case - CABS-CABS-1846 Execution completed");
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-CABS-1846 Execution completed");
	}

	// Verify within the expanded view for each overlap against the current BR,
	// there is a "Intentional overlap" checkbox
	@Test(priority = 5, enabled = true)
	public void CABS1849() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1849 Execution started");
		System.out.println("Test Case - CABS-1849 Execution started");

		 POIX.waitforbrtxt(Driver);
		 Thread.sleep(7000);
		POIX.intentionalOverlap(Driver);
		
		
		System.out.println("Test Case - CABS-CABS-1849 Execution completed");
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-CABS-1849 Execution completed");
	}
	
	//Verify when all overlaps associated with BR are resolved, user can add income
	@Test(priority = 6, enabled = true)
	public void CABS1850() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1849 Execution started");
		System.out.println("Test Case - CABS-1850 Execution started");

	 
		POIX.intentionalIncome(Driver);
		
		System.out.println("Test Case - CABS-CABS-1850 Execution completed");
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-CABS-1849 Execution completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		POVIII.beforeTest(Driver);
		POIX.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 8 - CABS-900",
				"Overlaps - Overlap dropdown");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
