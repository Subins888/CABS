package com.albertsons.overlaps;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS899 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify the Overlaps rule : Scan- Scan -B -U
	@Test(priority = 1, enabled = true)
	public void CABS1869() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1869 Execution started");

		POVIII.AlwnceBRRetailOverlap(Driver);
		POVIII.BRSaveItemDetails(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlaps(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1869 Execution Completed");
	}

	// Verify the Overlaps rule : Scan- S2S -Perf -U
	@Test(priority = 2, enabled = true)
	public void CABS1870() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1870 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		POVIII.AlwnceBRRetailOverlapIII(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlaps(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1870 Execution Completed");
	}

	// Verify the Overlaps rule : Scan- Case -Perf -U
	@Test(priority = 3, enabled = true)
	public void CABS1871() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1871 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		POVIII.AlwnceBRRetailOverlapC51(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1871 Execution Completed");
	}

	// Verify the Overlaps rule : S2S- S2S -B -C
	@Test(priority = 4, enabled = true)
	public void CABS1872() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1872 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		POVIII.AlwnceBRRetailOverlapS06(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1872 Execution Completed");
	}

	// Verify the Overlaps rule : S2S- Scan -Perf -U
	@Test(priority = 5, enabled = true)
	public void CABS1873() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1873 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapS06(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsS06(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1873 Execution Completed");
	}

	// Verify the Overlaps rule : S2S- Case -Perf -C
	@Test(priority = 6, enabled = true)
	public void CABS1874() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1874 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapC51(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsS06(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1874 Execution Completed");
	}

	// Verify the Overlaps rule : Case- Case -B -C
	@Test(priority = 7, enabled = true)
	public void CABS1875() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1875 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.COGSAlwnceBR(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);
		
		POVIII.overlapsCOGS(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1875 Execution Completed");
	}

	// Verify the Overlaps rule : Case- Scan -Perf -U
	@Test(priority = 8, enabled = true)
	public void CABS1876() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1876 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapT05(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsC51(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1876 Execution Completed");
	}

	// Verify the Overlaps rule : Case -S2S-Perf -C
	@Test(priority = 9, enabled = true)
	public void CABS1877() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1877 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapS06(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsC51CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1877 Execution Completed");
	}

	// Verify the Overlaps rule : Coupon- Coupon -B -U
	@Test(priority = 10, enabled = true)
	public void CABS1878() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1878 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapT20(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsT20CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1878 Execution Completed");
	}

	// Verify the Overlaps rule : J4U- J4U -B -U
	@Test(priority = 11, enabled = true)
	public void CABS1879() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1879 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapT20(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsT20CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1879 Execution Completed");
	}

	// Verify the Overlaps rule : Liquor- Liquor -B -U
	@Test(priority = 12, enabled = true)
	public void CABS1880() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1880 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapT38(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsT38CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1880 Execution Completed");
	}

	// Verify the Overlaps rule : Placement- Placement -N -C
	@Test(priority = 13, enabled = true)
	public void CABS1881() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1881 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapA04(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsA04CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1881 Execution Completed");
	}

	// Verify the Overlaps rule : ItemFlat- ItemFlat -B -C
	@Test(priority = 14, enabled = true)
	public void CABS1882() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1882 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapA08(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsA08CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1882 Execution Completed");
	}
	
	
	//Verify the Overlaps rule : Fuel- Fuel -B -U
	@Test(priority = 15, enabled = true)
	public void CABS1883() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1883 Execution started");

		POVIII.waitforBlngbtn(Driver);
		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POVIII.AlwnceBRRetailOverlapT2077(Driver);
		POVIII.BRSave(Driver);
		Thread.sleep(5000);
		POVIII.getBillingRecordId(Driver);

		POVIII.overlapsT2077CIC(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1883 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		POVIII.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 8 - CABS-899",
				"Overlaps - Identify Overlaps");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
