 

 package com.albertsons.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Base64;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

//import com.relevantcodes.extentreports.LogStatus;

//import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.Wait;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 * 
 * 
 * @author akuma58
 *
 */
public class PageObjects extends ExtendBaseClass {

	WebDriver Driver;
	GenericFactory pageFact;
	Properties prop;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	HSSFCell cell;
	String extentReportImage198PO_0, extentReportImage198PO_01,
			extentReportImage198PO_02, extentReportImage203PO_0,
			extentReportImage202PO_09, extentReportImage198PO_03,
			extentReportImage223PO_3, extentReportImage198PO_04,
			extentReportImage198PO_05, extentReportImage204PO_0,
			extentReportImage202PO_06, extentReportImage278PO_0,
			extentReportImage278PO_1, extentReportImage278PO_2,
			extentReportImage278PO_3, extentReportImage202PO_08,
			extentReportImage278PO_4, extentReportImage278PO_5,
			extentReportImage278PO_6, extentReportImage202PO_04,
			extentReportImage202PO_07, extentReportImage205PO_0,
			extentReportImage223PO_0, extentReportImage223PO_1,
			extentReportImage223PO_2, extentReportImage202PO_0,
			extentReportImage206PO_0, extentReportImage202PO_02;

	String extentReportImage194_2PO1, extentReportImage199PO_0,
			extentReportImage199PO_1, extentReportImage199PO_2,
			extentReportImage199PO_3, extentReportImage199PO_4,
			extentReportImage199PO_5, extentReportImage199PO_6,
			extentReportImage199PO_7, extentReportImage199PO_8,
			extentReportImage199PO_9, extentReportImage199PO_10,
			extentReportImage199PO_11, extentReportImage199PO_12,
			extentReportImage199PO_13, extentReportImage199PO_14,
			extentReportImage199PO_15, extentReportImage199PO_16,
			extentReportImage199PO_17, extentReportImage199PO_18,
			extentReportImage199PO_19, extentReportImage199PO_20,
			extentReportImage199PO_21, extentReportImage199PO_22,
			extentReportImage199PO_23, extentReportImage199PO_24,
			extentReportImage199PO_25, extentReportImage199PO_26,
			extentReportImage199PO_27, extentReportImage199PO_28,
			extentReportImage199PO_29, extentReportImage199PO_30,
			extentReportImage199PO_31, extentReportImage202PO_01,
			extentReportImage202PO_03, extentReportImage202PO_05;

	public static String offer, lead, dtFrm, dtTo, ftAmt, ftCode, allwTyp,
			perf1, perf2;

	// public static ExtentReports extent;
	// public static ExtentTest extentTest;

	public PageObjects(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	// CABS-186
	@Test(description = "Read test data")
	public String Login() throws Exception {

		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();

		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		String xlfile = new File(System.getProperty("user.dir"), "TestData.xls")
				.getAbsolutePath();
		FileInputStream fi = new FileInputStream(xlfile);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(0);

		try {
			for (int i = 1; i < s.getRows(); i++) {
				// Read data from excel sheet
				String s1 = s.getCell(1, i).getContents();
				String s2 = s.getCell(2, i).getContents();

				Thread.sleep(5000);

				Driver.findElement(By.id(prop.getProperty("usrNameId")))
						.sendKeys(s1);
				Driver.findElement(By.name(prop.getProperty("usrPwdId")))
						.sendKeys(s2);

				Driver.findElement(By.name(prop.getProperty("logClk"))).click();

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		wait_forHome();

		String txt = pageFact.home_bread.getText();

		if (txt.contains("Home")) {
			System.out.println("Login Success");
			extentTest.log(LogStatus.INFO, "Login Success");
		} else {
			System.out.println("Login Failed");
			extentTest.log(LogStatus.FAIL, "Login Failed");
			Assert.assertTrue(txt.contains("Home"));
		}
		return null;
	}

	// public String Login() {
	//
	// // Creation of file object
	// // File file = new
	// //
	// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");
	//
	// String file = new File(System.getProperty("user.dir"),
	// "properties_File").getAbsolutePath();
	//
	// // Creation of properties object
	// Properties prop = new Properties();
	//
	// // Creation of InputStream object to read data
	// FileInputStream objInput = null;
	// try {
	// objInput = new FileInputStream(file);
	// // Reading properties key/values in file
	// prop.load(objInput);
	// // Closing the input stream
	// // objInput.close();
	// } catch (FileNotFoundException e) {
	// System.out.println(e.getMessage());
	// } catch (IOException e) {
	// System.out.println(e.getMessage());
	// }
	//
	// Driver.findElement(By.id(prop.getProperty("usrNameId"))).sendKeys(
	// prop.getProperty("tempUsr"));
	// Driver.findElement(By.id(prop.getProperty("usrPwdId"))).sendKeys(
	// prop.getProperty("tempPwd"));
	//
	// Driver.findElement(By.id(prop.getProperty("logClk"))).click();
	//
	// wait_forHome();
	//
	// String txt = pageFact.home_bread.getText();
	//
	// if (txt.contains("Home")) {
	// System.out.println("Login Success");
	// extentTest.log(LogStatus.INFO, "Login Success");
	// } else {
	// System.out.println("Login Failed");
	// extentTest.log(LogStatus.FAIL, "Login Failed");
	// Assert.assertTrue(txt.contains("Home"));
	// }
	//
	// return null;
	// }

	/**
	 * 
	 * @return
	 */
	public String placeHolder() {

		String txt = pageFact.home_bread.getText();
		if (txt.contains("Home")) {
			System.out.println("Placeholder displaying for main content");
			extentTest.log(LogStatus.INFO,
					"Placeholder displaying for main content");
		} else {
			System.out.println("Placeholder not displaying for main content");
			extentTest.log(LogStatus.FAIL,
					"Placeholder not displaying for main content");
			Assert.assertTrue(txt.contains("Home"));
		}
		return null;

	}

	// Login button visibility
	public String waitforelement() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.login_ClkII));
		return null;
	}

	public String wait_forHome() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.home_bread));
		return null;
	}

	public String wait_forLogOut() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.log_Out));
		return null;
	}

	public String wait_forBlngbtn() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFact.createBillrcrd));
		return null;
	}

	public String waitforbillType() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFact.blngRcrdType0));
		return null;
	}

	@Test
	public String title() throws IOException {

		String title = Driver.getTitle();
		System.out.println("Title is: " + title);

		if (title.contains("CABS - Centralized Accounting Billing System")) {
			System.out.println("PASS:  CABS Home page displayed");

			// extentTest.log(LogStatus.INFO, "Title Matches");
		} else {
			System.out.println("FAIL:  CABS Home page not displayed");

			// extentTest.log(LogStatus.INFO, "Title not Matches");
			Assert.assertTrue(title.contains("Gmails"));

		}
		return title;

	}

	public String aftermthd() throws IOException {

             TakesScreenshot ts = (TakesScreenshot) Driver;
       //     File source = ts.getScreenshotAs(OutputType.FILE);
             String source1= ts.getScreenshotAs(OutputType.BASE64);
             return source1;
       }


	public String home_page() {

		if (pageFact.srchBillingrcrd().contains("SEARCH BILLING RECORD")) {
			System.out
					.println("PASS:  HOME Page successully displayed without any error");
			System.out.println("Test Case - CABS-313 Passed");
			extentTest.log(LogStatus.INFO,
					"Home page successfully displayed without any error");
			extentTest.log(LogStatus.INFO,
					"CABS-313 TestCase execution completed");
		} else {
			System.out.println("FAIL:  Home page not displayed");

		}
		return null;
	}

	public String home_pageII() {

		if (pageFact.srchBillingrcrd().contains("SEARCH BILLING RECORD")) {
			System.out
					.println("PASS:  Search Billing Record displaying in the Left Panel ");
			extentTest.log(LogStatus.INFO,
					"Search Billing Record menu displaying in the side panel");
		} else {
			System.out
					.println("FAIL:   SEARCH BILLING RECORD not displaying in the Left Panel");
			extentTest
					.log(LogStatus.FAIL,
							"Search Billing Record menu NOT displaying in the side panel");
		}

		if (pageFact.analysisWrklst().contains("ANALYSIS WORKLIST")) {
			System.out
					.println("PASS:  Analysis Worklist menu displaying in the side panel");
			extentTest.log(LogStatus.INFO,
					"Analysis Worklist menu displaying in the side panel");
			// Assert.assertEquals(Driver.findElement(By.xpath("//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[1]")).getText(),
			// "ANALYSIS1 WORKLIST1");
		} else {
			System.out
					.println("FAIL:  Analysis Worklist menu NOT displaying in the side panel");
			extentTest.log(LogStatus.FAIL,
					"Analysis Worklist menu NOT displaying in the side panel");

		}

		if (pageFact.incmeWrklist().contains("INCOME WORKLIST")) {
			System.out
					.println("PASS:  Income Worklist menu displaying in the side panel");
			extentTest.log(LogStatus.INFO,
					"Income Worklist menu displaying in the side panel");
		} else {
			System.out
					.println("FAIL:  Income Worklist menu NOT displaying in the side panel");
			extentTest.log(LogStatus.FAIL,
					"Income Worklist menu NOT displaying in the side panel");
		}

		if (pageFact.ovrTolrnceWrklst().contains("OVER TOLERANCE WORKLIST")) {
			System.out
					.println("PASS:  Over Tolerance Worklist menu displaying in the side panel");
			extentTest
					.log(LogStatus.INFO,
							"Over Tolerance Worklist menu displaying in the side panel");
		} else {
			System.out
					.println("FAIL:  Over Tolerance Worklist menu NOT displaying in the side panel");
			extentTest
					.log(LogStatus.FAIL,
							"Over Tolerance Worklist menu NOT displaying in the side panel");
		}

		if (pageFact.dialogWrklst().contains("DIALOG WORKLIST")) {
			System.out
					.println("PASS:  Dialog Worklist menu displaying in the side panel");
			extentTest.log(LogStatus.INFO,
					"Dialog Worklist menu displaying in the side panel");
		} else {
			System.out
					.println("FAIL:  Dialog Worklist menu NOT displaying in the side panel");
			extentTest.log(LogStatus.FAIL,
					"Dialog Worklist menu NOT displaying in the side panel");
		}

		if (pageFact.paybckWrklst().contains("PAYBACK WORKLIST")) {
			System.out
					.println("PASS:  Payback Worklist menu displaying in the side panel");
			extentTest.log(LogStatus.INFO,
					"Payback Worklist menu displaying in the side panel");
		} else {
			System.out
					.println("FAIL:  Payback Worklist menu NOT displaying in the side panel");
			extentTest.log(LogStatus.FAIL,
					"Payback Worklist menu NOT displaying in the side panel");
		}

		return null;
	}

	public String Title_Check() {

		String title = Driver.getTitle();
		extentTest.log(LogStatus.INFO, "Got the WebSite title");
		System.out.println("Title is: " + title);
		extentTest.log(LogStatus.INFO, "Actual title is: " + title);

		try {

			if (title.contains("CABS")) {
				System.out.println("PASS:  CABS Home page displayed");
				extentTest.log(LogStatus.INFO, "Title Matches");
			} else {
				System.out.println("FAIL:  Title Mismatch");
				extentTest.log(LogStatus.INFO, "Title not Matches");
				Assert.assertTrue(title.contains("CABS"));

			}

		} catch (Exception e) {

			System.out.println(e);
			extentTest.log(LogStatus.FAIL, "Exception");
		}

		return null;

	}

//	public String log_Out() throws InterruptedException {
//
//		pageFact.hamBurg();
//		System.out.println("Clicked on Hamburger Menu");
//		extentTest.log(LogStatus.INFO, "Clicked on Hamburger Menu");
//
//		wait_forLogOut();
//		if (pageFact.logOut().contains("Logout")) {
//			System.out.println("PASS:  Log Out button displayed");
//			extentTest.log(LogStatus.INFO, "Log Out button displayed");
//			System.out.println("Test Case - CABS-323 Passed");
//		} else {
//			System.out.println("FAIL:  Log Out button not displayed");
//			extentTest.log(LogStatus.FAIL, "Log Out button not displayed");
//
//		}
//		return null;
//	}

	public String leftBtn() throws InterruptedException {

		wait_forBlngbtn();

		if (pageFact.createBilRcrd().equals("Create Billing Record")) {
			System.out.println("PASS:  Create billing record button displayed");
			extentTest.log(LogStatus.INFO,
					"Create billing record button displayed");
		} else {
			System.out
					.println("FAIL:  Create billing record button not displayed");
			extentTest.log(LogStatus.FAIL,
					"Create billing record button not displayed");
		}

		if (pageFact.upLoadBtn().equals("Upload Miscellaneous File")) {
			System.out
					.println("PASS:  Upload miscellaneous file button displayed");
			extentTest.log(LogStatus.INFO,
					"Upload miscellaneous file button displayed");
		} else {
			System.out
					.println("FAIL:  Upload miscellaneous file button not displayed");
			extentTest.log(LogStatus.FAIL,
					"Upload miscellaneous file button not displayed");
		}

		if (pageFact.searchBill().equals("SEARCH BILLING RECORD")) {
			System.out.println("PASS:  Search billing record button displayed");
			extentTest.log(LogStatus.INFO,
					"Search billing record button displayed");
		} else {
			System.out
					.println("FAIL:  Search billing record button not displayed");
			extentTest.log(LogStatus.FAIL,
					"Search billing record button not displayed");
		}
		Thread.sleep(5000);
		// Driver.findElement(By.id("dropdownManual")).sendKeys("David");
		pageFact.smartDrp();

		System.out.println("Search for keywords in Smart Dropdown");
		extentTest.log(LogStatus.INFO, "Search for keywords in Smart Dropdown");
		System.out.println("Test Case - CABS-324 Passed");

		return null;
	}

	public String toolTip() {

		String expectdTool = "Billing records that require analysis";

		String tool = pageFact.tool_tip1
				.getAttribute("Billing records that require analysis");
		System.out.println("Actual Title of Tool Tip" + tool);

		if (tool.equals(expectdTool)) {
			System.out.println("Test Case Passed");
		}

		return null;
	}

	public String billingDrpdwn() throws InterruptedException {

		pageFact.createBillrcrd.click();
		wait_forBlngbtn();
		pageFact.blngRcrdDrpdown.click();

		Thread.sleep(5000);

		pageFact.blngRcrdType0.click();
		System.out.println("First Dropdown value is " + pageFact.blngRcrdTxt());
		pageFact.blngRcrdDrpdown.click();
		Thread.sleep(2500);
		pageFact.blngRcrdType1.click();
		System.out
				.println("Second Dropdown value is " + pageFact.blngRcrdTxt());

		return null;
	}

	public String NonAllowance() throws InterruptedException, IOException,
			AWTException {

		try {

			// pageFact.blngRcrdTyp.click();
			// Thread.sleep(2500);
			pageFact.nonAllwTyp.click();

			String acnttxt = pageFact.AcntlukText();

			if (acnttxt.contains("Account Lookup Type")) {
				System.out.println("Account Lookup Type label displayed");
				extentTest.log(LogStatus.INFO,
						"Account Lookup Type label displayed");
			} else {
				System.out.println("Account Lookup Type label not displayed");

				// extentReportImage198PO_0 = System.getProperty("user.dir")
				// + "\\picture" + "\\extentReportImage198PO_0.png";
				extentReportImage198PO_0 = System
						.setProperty(
								"url",
								"/appl/chje/jenkins_home/workspace/pabs-/pabs-git-master-/cabs_ui_testing/picture/extentReportImage198PO_0.png");
				// extentReportImage198PO_0 = System.getProperty("user.dir")
				// + "\\picture" + "\\extentReportImage198PO_0.png";

				extentTest
						.log(LogStatus.FAIL,
								"Label displayed is wrong");
			}

			if (pageFact.acntLukupTypVal() == true) {
				System.out
						.println("User able to see Account Lookup Type drop down with Retail and COGS values");
				extentTest
						.log(LogStatus.INFO,
								"User able to see Account Lookup Type drop down with Retail and COGS values");
			} else {
				System.out
						.println("User not able to see Account Lookup Type drop down with Retail and COGS values");
				// extentTest.log(LogStatus.FAIL,
				// "User is not able to see BR modal pop up with billing record types");
				extentReportImage198PO_01 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage198PO_01.png";
			
				extentTest
						.log(LogStatus.FAIL,
								"User not able to see Account Lookup Type drop down with Retail and COGS values");

			}
		} catch (Exception e) {

			System.out
					.println("User have no privilage to see Account Lookup Type drop down with Retail and COGS values");
			extentTest
					.log(LogStatus.INFO,
							"User have no privilage to see Account Lookup Type drop down with Retail and COGS values");

		}

		return null;
	}

	public String AccountValue() throws InterruptedException, IOException {

		try {

			Thread.sleep(4000);
			pageFact.AcntlukRet.click();
			Thread.sleep(3000);

			pageFact.AcntlukVal.click();

			if (pageFact.AcntlukVal1.isDisplayed()) {
				System.out
						.println("Able to see Account Lookup Type values based on Retail Div selection");
				extentTest
						.log(LogStatus.INFO,
								"Able to see Account Lookup Type values based on Retail Div selection");
			} else {
				System.out
						.println("Not able to see Account Lookup Type values based on Retail Div selection");
				extentReportImage198PO_02 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage198PO_02.png";
				 
				extentTest
						.log(LogStatus.FAIL,
								"User Not able to see Account Lookup Type values based on Retail Div selection");

			}

			pageFact.AcntlukDrp.click();
			pageFact.AcntlukCog.click();
			Thread.sleep(3000);

			pageFact.AcntlukVal.click();
			if (pageFact.AcntlukVal1.isDisplayed()) {
				System.out
						.println("Able to see Account Lookup Type values based on COGS Facilities selection");
				extentTest
						.log(LogStatus.INFO,
								"Able to see Account Lookup Type values based on COGS Facilities selection");
			} else {
				System.out
						.println("Not able to see Account Lookup Type values based on COGS Facilities selection");
				extentReportImage198PO_03 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage198PO_03.png";
				 
				extentTest
						.log(LogStatus.FAIL,
								"Not able to see Account Lookup Type values based on COGS Facilities selection");

			}
		} catch (Exception e) {

			System.out
					.println("User have no privilage to see Account Lookup Type values in the COGS Facilities selection");
			extentTest
					.log(LogStatus.INFO,
							"User have no privilage to see Account Lookup Type drop down with Retail and COGS values");

		}

		return null;
	}

		public String AcntlukMand() throws InterruptedException, IOException {

		try{
		pageFact.createBillrcrd.click();
		pageFact.bRType.click();
		Thread.sleep(3000);
		pageFact.nonAllwTyp.click();
		Thread.sleep(1500);
		pageFact.AcntlukDrp.click();
		pageFact.AcntlukRet.click();
		pageFact.creatBrSbmt.click();

		String ErrMesag = pageFact.errMsg.getText();

		if (pageFact.errMsg.isDisplayed()) {
			System.out.println("Error message displayed is: " + ErrMesag);
			extentTest.log(LogStatus.INFO, "Error message displayed is: "
					+ ErrMesag);
		} else {
			System.out.println("Error message not displayed");

			extentReportImage198PO_05 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage198PO_05.png";
			String source = aftermthd();
			File destination = new File(extentReportImage198PO_05);
		//	//FileUtils.copyFile(source, destination);

			extentTest.log(LogStatus.FAIL, "Close button not working"
					+ extentTest.addScreenCapture(extentReportImage198PO_05));
		}}
		catch(Exception e){
			
			System.out.println("Error message not displayed");
			extentTest.log(LogStatus.INFO, "Error message not displayed");
		}
		return null;
	}

	public String closebTn() throws IOException {

		// pageFact.createBillrcrd.click();
		// wait_forBlngbtn();
		// Driver.findElement(By.xpath("/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span/i-feather/svg/line[1]")).click();
		pageFact.closeBtn.click();

		String txt = pageFact.home_bread.getText();
		if (txt.contains("Home")) {
			System.out.println("Pop up successfully closed");
			extentTest.log(LogStatus.INFO, "Pop up successfully closed");
		} else {
			System.out.println("Close button not working");

			extentReportImage198PO_04 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage198PO_04.png";
			String source = aftermthd();
			File destination = new File(extentReportImage198PO_04);
			////FileUtils.copyFile(source, destination);

			extentTest.log(LogStatus.FAIL, "Close button not working"
					+ extentTest.addScreenCapture(extentReportImage198PO_04));

		}

		return null;
	}

	public String newBrform() throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		wait_forBlngbtn();
		
		pageFact.waitForSpinnerToBeGone();		
		Thread.sleep(3000);
		
		pageFact.creatBillng();
		
		pageFact.waitForSpinnerToBeGone();	
		Thread.sleep(3000);
		pageFact.blngrcrdDrp();
		Thread.sleep(4500);

		pageFact.nonAllwdrp();
		Thread.sleep(4500);
		pageFact.submitClk();

		pageFact.waitForSpinnerToBeGone();	
		Thread.sleep(3000);
		wait_forbrtxt();
		Thread.sleep(2000);
		pageFact.newBracnclk();
		Thread.sleep(2000);
		pageFact.newRetclk();
		Thread.sleep(3000);

		pageFact.accntretNeww();
		Thread.sleep(3000);
		 pageFact.newRetval();
		//pageFact.newRetval2();

		pageFact.elmntIntract();
		Thread.sleep(2500);
		pageFact.blngname();
		pageFact.blngnamevalu();
		pageFact.txtAreaa();
		Thread.sleep(5000);
		pageFact.newBRSave();
		Thread.sleep(5000);
		return null;
	}

		public String income() throws IOException, InterruptedException {

		// JavascriptExecutor js = (JavascriptExecutor)Driver;
		// js.executeScript("scroll(0,250)");

		Actions action = new Actions(Driver);
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
	//	Thread.sleep(15000);
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);
		
		pageFact.incmbtnclk();
		System.out.println("Clicked on Add Income Button");
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);
		
		try {
		if (pageFact.incmdsave.isDisplayed()) {
			System.out
					.println("The Income Section expanded on clicking 'Add Income' button");
			extentTest
					.log(LogStatus.INFO,
							"The Income Section expanded on clicking 'Add Income' button");
		} else {
			System.out
					.println("The Income Section not expanded on clicking 'Add Income' button");
			extentReportImage278PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_0.png";
			 
			extentTest
					.log(LogStatus.FAIL,
							"The Income Section not expanded on clicking 'Add Income' button");
		}}catch (Exception e) {
			
			System.out
			.println("The Income Section disabled for the logged in user");
	extentTest
			.log(LogStatus.INFO,
					"The Income Section disabled for the logged in user");
		}

		return null;
	}

	public String incmeLables() throws IOException {

		if (pageFact.billLab().equals("Bill")) {
			if (pageFact.accruLab().equals("Accrue")) {
				if (pageFact.billndAcclab().equals("Bill & Accruee")) {
					System.out
							.println("All Radio button labels displaying is correct");
					extentTest.log(LogStatus.INFO,
							"All Radio button labels displaying is correct");
				}
			}
		} else {
			System.out.println("Radio button labels are wrong");
			extentReportImage278PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_1.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_1);
		//	//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Radio button labels are wrong"
					+ extentTest.addScreenCapture(extentReportImage278PO_1));
		}

		return null;
	}

	public String incmeRadio() throws IOException {

		if (pageFact.billLab().equals("Bill")) {
			System.out.println("Bill radio button selected");
			extentTest.log(LogStatus.INFO, "Bill radio button selected");

		} else {
			System.out.println("Bill radio button not selected");
			extentReportImage278PO_2 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_2.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_2);
			////FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Bill radio button not selected"
					+ extentTest.addScreenCapture(extentReportImage278PO_2));
		}
		return null;

	}

	public String incmDescr() throws InterruptedException, IOException {

		// pageFact.txtAreaa();
		pageFact.txtDee();
		pageFact.amntsend();
		pageFact.AddRow();
		Thread.sleep(5000);

		// pageFact.delete();
		pageFact.deltinteract();
		Thread.sleep(2000);
		if (pageFact.deleteBtn.isDisplayed()) {
			System.out.println("Delete not working properly");
			
			extentTest.log(LogStatus.FAIL, "Delete not working properly");

		} else {
			System.out.println("The added row successfully deleted");
			extentTest
					.log(LogStatus.INFO, "The added row successfully deleted");
		}
		return null;
	}

	public String incmebTns() throws IOException {

		if (pageFact.AddRowbTN.isDisplayed()) {
			System.out.println("Add Row button displayed");
			extentTest.log(LogStatus.INFO, "Add Row button displayed");
		} else {
			System.out.println("Add Row button not displayed");
			extentReportImage278PO_4 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_4.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_4);
		//	//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Add Row button not displayed"
					+ extentTest.addScreenCapture(extentReportImage278PO_4));
		}

		if (pageFact.txtDescr.isDisplayed()) {
			System.out.println("Description text area displayed");
			extentTest.log(LogStatus.INFO, "Description text area displayed");
		} else {
			System.out.println("Description text area not displayed");
			extentReportImage278PO_5 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_5.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_5);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Description text area not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage278PO_5));
		}

		if (pageFact.amnt.isDisplayed()) {
			System.out.println("The amount field displayed");
			extentTest.log(LogStatus.INFO, "The amount field displayed");
		} else {
			System.out.println("The amount field not displayed");
			extentReportImage278PO_6 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_6.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_6);
		//	//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "The amount field not displayed"
					+ extentTest.addScreenCapture(extentReportImage278PO_6));
		}

		try {
		if (pageFact.incmdsave.isDisplayed()) {
			System.out.println("Save button displayed");
			extentTest.log(LogStatus.INFO, "Save button displayed");
		} else {
			System.out.println("Save button not displayed");
			extentReportImage278PO_6 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_6.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_6);
			////FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Save button not displayed"
					+ extentTest.addScreenCapture(extentReportImage278PO_6));
		}}
		catch(Exception e) {
			
			System.out.println("Save button disabled for the logged'n user");
			extentTest.log(LogStatus.INFO, "Save button disabled for the logged'n user");
		}

		if (pageFact.incmCancel.isDisplayed()) {
			System.out.println("Cancel button displayed");
			extentTest.log(LogStatus.INFO, "Cancel button displayed");
		} else {
			System.out.println("Cancel button not displayed");
			extentReportImage278PO_6 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_6.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_6);
		//	//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Cancel button not displayed"
					+ extentTest.addScreenCapture(extentReportImage278PO_6));
		}

		if (pageFact.incmSubmt.isDisplayed()) {
			System.out.println("Submit button displayed");
			extentTest.log(LogStatus.INFO, "Submit button displayed");
		} else {
			System.out.println("Submit button not displayed");
			extentReportImage278PO_6 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage278PO_6.png";
			String source = aftermthd();
			File destination = new File(extentReportImage278PO_6);
			////FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Submit button not displayed"
					+ extentTest.addScreenCapture(extentReportImage278PO_6));
		}

		return null;

	}

	// CABS-195 Methods
	public String dept() {

		if (pageFact.deptTextCapt().contains("Department - Team")) {
			System.out.println("Label name displaying is - Department - Team");
			extentTest.log(LogStatus.INFO,
					"Label name displaying is - Department - Team");
		} else {
			System.out.println("Label name displaying is wrong");
			extentTest.log(LogStatus.INFO, "Label name displaying is wrong");

			if (pageFact.deptDrpDwn.isDisplayed()) {
				System.out.println("Department team dropdown is displaying");
				extentTest.log(LogStatus.INFO,
						"Department team dropdown is displaying");
			} else {
				System.out.println("Department team dropdown not displaying");
				extentTest.log(LogStatus.INFO,
						"Department team dropdown not displaying");
			}
		}

		return null;
	}

	public String deptContent() {

		if (pageFact.deptDrpdownTxt().equals("Allowance - Billing")) {
			System.out.println("Department - Team displaying is "
					+ pageFact.deptDrpdownTxt());
			extentTest.log(LogStatus.INFO, "Department - Team displaying is "
					+ pageFact.deptDrpdownTxt());
		} else if (pageFact.deptDrpdownTxt().equals(
				"Allowance Billing - Post-Audit")) {
			System.out.println("Department - Team displaying is "
					+ pageFact.deptDrpdownTxt());
			extentTest.log(LogStatus.INFO, "Department - Team displaying is "
					+ pageFact.deptDrpdownTxt());
		} else {
			System.out
					.println("Department team not displaying in the dropdown");
			extentTest.log(LogStatus.FAIL,
					"Department team not displaying in the dropdown");
		}

		return null;
	}

	public String deptContentDescr() {

		if (pageFact.deptDrpdownTxt().equals("Allowance - Billing")) {
			System.out
					.println("Description of Department, Team displaying in the dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Description of Department, Team displaying in the dropdown");
		} else if (pageFact.deptDrpdownTxt().equals(
				"Allowance Billing - Post-Audit")) {
			System.out
					.println("Description of Department, Team displaying in the dropdown");
			extentTest
					.log(LogStatus.INFO,
							"Description of Department, Team displaying in the dropdown");
		} else {
			System.out
					.println("Description of Department, Team not displaying in the dropdown");
			extentTest
					.log(LogStatus.FAIL,
							"Description of Department, Team not displaying in the dropdown");
		}

		return null;
	}

	public String multDept() throws InterruptedException {

		try {

			Thread.sleep(55000);
			pageFact.deptDrpdownbtn();

			if (pageFact.deptDrpdwnval1.isDisplayed()) {
				System.out.println("First Department associated with the user is " + pageFact.deptDrpdownvalclk());
				extentTest.log(LogStatus.INFO,
						"First Department associated with the user is " + pageFact.deptDrpdownvalclk());
			} else {
				System.out.println("Department-Team drop down is empty");
				extentTest.log(LogStatus.FAIL, "Department-Team drop down is empty");
			}

			if (pageFact.deptDrpdwnval1.isDisplayed()) {
				System.out.println("Second Department associated with the user is " + pageFact.deptDrpdownvalclk2());
				extentTest.log(LogStatus.INFO,
						"Second Department associated with the user is " + pageFact.deptDrpdownvalclk2());
			} else {
				System.out.println("Department-Team drop down is empty");
				extentTest.log(LogStatus.FAIL, "Department-Team drop down is empty");
			}

		} catch (Exception e) {
			System.out.println("Unable to view Department-Team drop down as the user doesn't have much privilege");
			extentTest.log(LogStatus.INFO,
					"Unable to view Department-Team drop down as the user doesn't have much privilege");

		}

		return null;
	}

	public String closebtnclk() throws InterruptedException {
		try{
		pageFact.closclk();
		}catch(Exception e){
			
			System.out.println("Close button not interactable");
			extentTest.log(LogStatus.INFO, "Close button not interactable");
		}
		return null;
	}

	public String newBR() throws InterruptedException {

		try{
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		wait_forBlngbtn();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.creatBillng();
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);
		pageFact.blngRcrdTyp.click();
		Thread.sleep(4500);
		pageFact.nonAllwdrp();
		Thread.sleep(4500);
		pageFact.submitClk();
		wait_forbrtxt();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2000);
		if (pageFact.brgetxt().contains("New BR")) {
			System.out.println("New BR page displayed");
			extentTest.log(LogStatus.INFO, "New BR page displayed");
		} else {
			System.out.println("New BR page not displayed");
			extentTest.log(LogStatus.FAIL, "New BR page not displayed");
		}}
		catch(Exception e){
			System.out.println("User do not have proper privlege to view the BR page");
			extentTest.log(LogStatus.INFO, "User do not have proper privlege to view the BR page");
			
		}
		return null;
	}

	public String wait_forbrtxt() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.BRtxt));
		return null;
	}

	public String newBRSave() throws InterruptedException, IOException {

		Thread.sleep(3000);
		pageFact.newBracnclk();
		System.out.println("Account Lookup Type dropdown clicked");
		Thread.sleep(3000);
		pageFact.newRetclk();
		System.out.println("Selected Retail Div");
		Thread.sleep(5000);
		pageFact.accntretNeww();
		System.out.println("Account Lookup Type value dropdown clicked");
		pageFact.newRetval();
		// pageFact.newRetval2();
		System.out.println("Selected Account lookup type value");
		pageFact.elmntIntract();
		System.out.println("Entered Deduct/Invoice amount");
		Thread.sleep(2500);
		pageFact.blngname();
		System.out.println("Clicked on Billing Name dropdown");
		pageFact.blngnamevalu();
		System.out.println("Selected Billing name value");
		pageFact.txtDee();
		System.out.println("Entered Internal Notes");
		pageFact.brsaveBtnn();
		System.out.println("Clicked on Save button");

		Thread.sleep(55000);
		pageFact.brStatuclk();
		Thread.sleep(5000);
		if (pageFact.brStatustxt().contains("Ready for Income")) {
			System.out
					.println("BR Status enabled with Status Ready For Income");
			extentTest.log(LogStatus.INFO,
					"BR Status enabled with Status Ready For Income");
		} else {
			System.out
					.println("BR Status not enabled or status showing is wrong");

			extentReportImage202PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_0.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_0);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"BR Status not enabled or status showing is wrong"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_0));
		}
		return null;
	}

	public String acntlukup() throws IOException, InterruptedException {

		try {
			pageFact.waitForSpinnerToBeGone();
			Thread.sleep(2000);
			pageFact.newBracnclk();
			Thread.sleep(2000);

			if (pageFact.newRettxt().contains("Retail Div")) {
				System.out.println("Account lookup type dropdown displayed");
				extentTest.log(LogStatus.INFO,
						"Account lookup type dropdown displayed");
			} else {
				System.out
						.println("Account lookup type dropdown not displayed");

				extentReportImage203PO_0 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage203PO_0.png";
			 
				extentTest
						.log(LogStatus.FAIL,
								"Account lookup type dropdown not displayed");
			}

			pageFact.newRetclk();
			Thread.sleep(2000);
			pageFact.accntretNeww();

			if (pageFact.newRetvalTxt2().contains("17")) {
				System.out
						.println("Account lookup type value dropdown displayed");
				extentTest.log(LogStatus.INFO,
						"Account lookup type value dropdown displayed");
			} else {
				System.out
						.println("Account lookup type dropdown value not displayed");

				extentReportImage203PO_0 = System.getProperty("user.dir")
						+ "\\picture" + "\\extentReportImage203PO_0.png";
			 
				extentTest
						.log(LogStatus.FAIL,
								"Account lookup type dropdown value not displayed");
			}

		} catch (Exception e) {

			System.out
					.println("Account lookup type value dropdown displayed, but unable to click because of privilege issue/unexpected error");
			extentTest
					.log(LogStatus.INFO,
							"Account lookup type value dropdown displayed, but unable to click because of privilege issue/unexpected error");

		}
		return null;
	}

	public String assignTodrp() throws IOException, InterruptedException {

		Driver.findElement(By.xpath("//*[@id='assignTo']/div/span")).click();
		Thread.sleep(2000);
		String asign = pageFact.assignToo();

		System.out
				.println("Assign To Contains username and department like: -  "
						+ asign);
		extentTest.log(LogStatus.INFO,
				"Assign To Contains username and department of the user "
						+ asign);

		// if (pageFact.assignToow().contains("Ajith")) {
		// System.out
		// .println("Assign To Contains username and department like: -  "
		// + asign);
		// extentTest.log(LogStatus.INFO,
		// "Assign To Contains username and department of the user "
		// + asign);
		// } else {
		// System.out.println("Assign To drop down values are wrong" +asign);
		//
		// extentReportImage203PO_0 = System.getProperty("user.dir")
		// + "\\picture" + "\\extentReportImage203PO_0.png";
		// String source = aftermthd();
		// File destination = new File(extentReportImage203PO_0);
		// //FileUtils.copyFile(source, destination);
		// extentTest
		// .log(LogStatus.FAIL,
		// "Assign To drop down values are wrong" +asign
		// + extentTest
		// .addScreenCapture(extentReportImage203PO_0));
		// }
		// List<WebElement> we = Driver.findElements(By.id("assignTo"));
		// System.out.println("*****  " +we.size() );
		// for (int i=1;i<we.size();i++){
		// System.out.println("the values are : " + we.get(i).getText());
		// }
		return null;
	}

		public String nonAlwnceBR() throws IOException, InterruptedException {

		wait_forbrtxt();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		if (pageFact.blngRcrdidLab().equals("Billing Record ID")) {
			System.out
					.println("Billing Record ID field displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Billing Record ID field displaying properly in the UI");
		} else {
			System.out
					.println("Billing Record ID field not displaying properly in the UI");

			extentReportImage204PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage204PO_0.png";
			String source = aftermthd();
			File destination = new File(extentReportImage204PO_0);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account lookup type dropdown value not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage204PO_0));
		}

		if (pageFact.lastDatLabelTx().equals("Last Update Date")) {
			System.out
					.println("Last Update Date field displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Last Update Date field displaying properly in the UI");
		} else {
			System.out
					.println("Last Update Date field not displaying properly in the UI");

			extentReportImage205PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage205PO_0.png";
			String source = aftermthd();
			File destination = new File(extentReportImage205PO_0);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account lookup type dropdown value not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage205PO_0));
		}

		if (pageFact.brStatusdrp.isDisplayed()) {
			System.out
					.println("BR Status dropdown displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"BR Status dropdown displaying properly in the UI");
		} else {
			System.out
					.println("BR Status dropdown not displaying properly in the UI");

			extentReportImage206PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage206PO_0.png";
			String source = aftermthd();
			File destination = new File(extentReportImage206PO_0);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"BR Status dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage206PO_0));
		}

		if (pageFact.assignTodrp.isDisplayed()) {
			System.out
					.println("Assign To dropdown displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Assign To dropdown displaying properly in the UI");
		} else {
			System.out
					.println("Assign To dropdown not displaying properly in the UI");

			extentReportImage202PO_01 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_01.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_01);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Assign To dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_01));
		}

		if (pageFact.newBracntlukup.isDisplayed()) {
			System.out
					.println("Account Lookup Type dropdown displaying properly in the UI");
			extentTest
					.log(LogStatus.INFO,
							"Account Lookup Type dropdown displaying properly in the UI");
		} else {
			System.out
					.println("Account Lookup Type dropdown not displaying properly in the UI");

			extentReportImage202PO_02 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_02.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_02);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account Lookup Type dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_02));
		}

		if (pageFact.accntRetnew.isDisplayed()) {
			System.out
					.println("Account Lookup Type Value dropdown displaying properly in the UI");
			extentTest
					.log(LogStatus.INFO,
							"Account Lookup Type Value dropdown displaying properly in the UI");
		} else {
			System.out
					.println("Account Lookup Type Value dropdown not displaying properly in the UI");

			extentReportImage202PO_03 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_03.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_03);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account Lookup Type Value dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_03));
		}

		if (pageFact.offsetNumlab.isDisplayed()) {
			System.out
					.println("Offset Number field displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Offset Number field displaying properly in the UI");
		} else {
			System.out
					.println("Offset Number field not displaying properly in the UI");

			extentReportImage202PO_04 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_04.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_04);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Offset Number field not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_04));
		}

		if (pageFact.deductnum.isDisplayed()) {
			System.out
					.println("Deduct/Invoice Textbox displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Deduct/Invoice Textbox displaying properly in the UI");
		} else {
			System.out
					.println("Deduct/Invoice Textbox not displaying properly in the UI");

			extentReportImage202PO_05 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_05.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_05);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Deduct/Invoice Textbox not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_05));
		}

		if (pageFact.APaRRadio.isDisplayed()) {
			System.out
					.println("AP/AR Radio button displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"AP/AR Radio button displaying properly in the UI");
		} else {
			System.out
					.println("AP/AR Radio button not displaying properly in the UI");

			extentReportImage202PO_06 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_06.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_06);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"AP/AR Radio button not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_06));
		}

		if (pageFact.blngNam.isDisplayed()) {
			System.out
					.println("Billing Name dropdown displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Billing Name dropdown displaying properly in the UI");
		} else {
			System.out
					.println("Billing Name dropdown not displaying properly in the UI");

			extentReportImage202PO_07 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_07.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_07);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Billing Name dropdown not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_07));
		}

		if (pageFact.createAlert.isDisplayed()) {
			System.out
					.println("Create Alert checkbox displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Create Alert checkbox displaying properly in the UI");
		} else {
			System.out
					.println("Create Alert checkbox not displaying properly in the UI");

			extentReportImage202PO_08 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_08.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_08);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Create Alert checkbox not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_08));
		}

		if (pageFact.txtDescr.isDisplayed()) {
			System.out
					.println("Internal Notes Text Area displaying properly in the UI");
			extentTest.log(LogStatus.INFO,
					"Internal Notes Text Area displaying properly in the UI");
		} else {
			System.out
					.println("Internal Notes Text Area not displaying properly in the UI");

			extentReportImage202PO_09 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage202PO_09.png";
			String source = aftermthd();
			File destination = new File(extentReportImage202PO_09);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Internal Notes Text Area not displaying properly in the UI"
									+ extentTest
											.addScreenCapture(extentReportImage202PO_09));
		}

		return null;
	}

	public String waitForSpinnerToBeGone() {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	
	public String AlwnceBR() throws IOException, InterruptedException,
			ParseException, BiffException {

//		pageFact.searchBtn.click();
//		Thread.sleep(5500);
//		// Newly made popup click
//		pageFact.warningYes.click();

		wait_forBlngbtn();
		waitForSpinnerToBeGone();
		Thread.sleep(4500);
		pageFact.creatBillng();

		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		 

		pageFact.retailalw();
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldOffNo();
		Thread.sleep(3500);
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		Thread.sleep(3500);
		pageFact.itemAlwType();
		Thread.sleep(3500);
		pageFact.allwtype();
		Thread.sleep(3500);
		pageFact.allwTP1P2();
		Thread.sleep(3500);
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		// offer= pageFact.offnum.getAttribute("value");
		offer = pageFact.offrno.getAttribute("value");
		lead = pageFact.LCIC.getAttribute("value");
		dtFrm = pageFact.billDateFrom.getAttribute("value");
		dtTo = pageFact.billDateTo.getAttribute("value");
		ftAmt = pageFact.amtTxtBox1.getAttribute("value");
		ftCode = pageFact.flatCodeBox.findElement(
				By.className("ng-value-label")).getText();
		allwTyp = Driver.findElement(By.xpath("//*[@id=\"allowanceType\"]"))
				.getText();
		perf1 = Driver.findElement(By.xpath("//*[@id=\"performanceCode1\"]"))
				.getText();
		perf2 = Driver.findElement(By.xpath("//*[@id=\"performanceCode2\"]"))
				.getText();

		System.out.println(offer + lead + dtFrm + dtTo + ftAmt + ftCode);
		System.out.println("Allw type" + allwTyp);
		System.out.println("P1" + perf1);
		System.out.println("P2" + perf2);

		pageFact.brSubmit.click();

		return null;

	}
	
		public String AlwnceBRnew() throws IOException, InterruptedException,
			ParseException, BiffException {

	//	Thread.sleep(15000);
		pageFact.waitForSpinnerToBeGone();
		wait_forBlngbtn();
		pageFact.searchBtn.click();
		//Driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		
		pageFact.waitForSpinnerToBeGone();
		wait_forBlngbtn();
	//	Driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.blngrcrdDrp();
		Thread.sleep(3500);
		// WRITE REVERSE PROXY CODE

		pageFact.retailalw();
		Thread.sleep(7500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldOffNo();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();
		pageFact.headerFlatAmtGrtZero();
		pageFact.itemAlwType();
		pageFact.allwtype();
		pageFact.allwTP1P2();
		pageFact.p2AlwT0.click();
		Thread.sleep(2500);

		// offer= pageFact.offnum.getAttribute("value");
		offer = pageFact.offrno.getAttribute("value");
		lead = pageFact.LCIC.getAttribute("value");
		dtFrm = pageFact.billDateFrom.getAttribute("value");
		dtTo = pageFact.billDateTo.getAttribute("value");
		ftAmt = pageFact.amtTxtBox1.getAttribute("value");
		ftCode = pageFact.flatCodeBox.findElement(
				By.className("ng-value-label")).getText();
		allwTyp = Driver.findElement(By.xpath("//*[@id=\"allowanceType\"]"))
				.getText();
		perf1 = Driver.findElement(By.xpath("//*[@id=\"performanceCode1\"]"))
				.getText();
		perf2 = Driver.findElement(By.xpath("//*[@id=\"performanceCode2\"]"))
				.getText();

		System.out.println(offer + lead + dtFrm + dtTo + ftAmt + ftCode);
		System.out.println("Allw type" + allwTyp);
		System.out.println("P1" + perf1);
		System.out.println("P2" + perf2);

		pageFact.brSubmit.click();

		return null;

	}

	public String AlwnceBR2() throws IOException, InterruptedException,
			ParseException, BiffException {
				
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		wait_forBlngbtn();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.analysis_wrklist.click();
//		pageFact.waitForSpinnerToBeGone();
//		Thread.sleep(2500);
		Thread.sleep(55000);
		pageFact.creatBillng();
		Thread.sleep(4500);
		pageFact.blngrcrdDrp();
		Thread.sleep(4500);
		pageFact.retailalw();
		Thread.sleep(4500);

		pageFact.bRTypeRetailFieldAccValue();
		pageFact.bRTypeRetailFieldLeadCIC();
		pageFact.bRTypeRetailFieldStartDt();
		pageFact.bRTypeRetailFieldEndDt();

		Thread.sleep(2000);
		pageFact.billDateTo.sendKeys(Keys.TAB, "1");

		Thread.sleep(3000);
		WebElement FC = Driver.findElement(By
				.xpath("//*[@id=\"flatCode\"]/div/div/div[2]/input"));

		FC.click();
		Thread.sleep(3000);
		pageFact.flatCode1.click();
		pageFact.brSubmit.click();

		return null;
	}

	// CABS223 CODE

	public String wait_newBRSav() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(pageFact.newBRSav));
		return null;
	}

	public String wait_Errmsg() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(pageFact.newBRErrmsg));
		return null;
	}

	public String wait_Errmsg2() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(pageFact.invalidOfseterr));
		return null;
	}

	public String NonAlwnceBR() throws InterruptedException, IOException {

		wait_forBlngbtn();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);

		pageFact.creatBillng();
		Thread.sleep(5500);
		pageFact.blngrcrdDrp();
		Thread.sleep(4500);

		pageFact.nonAllwdrp();
		Thread.sleep(4500);
		pageFact.submitClk();
		
		wait_newBRSav();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		pageFact.newBRSave();
		wait_Errmsg();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		
		String ErrMsg = pageFact.newBRErrmsge();
		if (pageFact
				.newBRErrmsge()
				.contains(
						"Offset Number,Deduct/Invoice Number,Billing Name is not entered")) {
			System.out
					.println("Error message displaying properly, Error message showing is - "
							+ ErrMsg);
			extentTest.log(LogStatus.INFO,
					"Error message displaying properly, Error message showing is - "
							+ ErrMsg);
		} else {
				System.out.println("Error message showing is wrong");

			extentReportImage223PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage223PO_0.png";
			 
			extentTest.log(LogStatus.FAIL, "Error message showing is wrong");
		}

		return null;
	}

	public String offsetnumErr() throws InterruptedException, IOException {

		pageFact.newBracnclk();
		pageFact.newRetclk();
		
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(7500);
		pageFact.accntretNeww();
		Thread.sleep(2500);
		pageFact.newRetval1();
		Thread.sleep(2500);
		pageFact.offsetnumfi();
		Thread.sleep(2500);
		pageFact.elmntIntract();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		pageFact.blngname();
		pageFact.blngnamevalu();
		pageFact.txtDee();
		pageFact.brsaveBtnn();

		wait_Errmsg2();
		String invErrMsg = pageFact.invalidOfseterro();
		if (pageFact.invalidOfseterro().contains("Invalid Offset")) {
			System.out
					.println("Invalid Offset Case:  Error message displaying properly, Error message showing is - "
							+ invErrMsg);
			extentTest
					.log(LogStatus.INFO,
							"Invalid Offset Case:  Error message displaying properly, Error message showing is - "
									+ invErrMsg);
		} else {
				System.out.println("Error message showing is wrong");

			extentReportImage223PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage223PO_1.png";
			 
			extentTest.log(LogStatus.FAIL, "Error message showing is wrong");
		}

		return null;
	}

	public String offsetnumSucc() throws InterruptedException, IOException {

		pageFact.newBracnclk();
		pageFact.newRetclk();
		Thread.sleep(2500);
		pageFact.accntretNeww();
		
		//Changes made after Sprint 10 re-work
		 pageFact.newRetval();
	
		//pageFact.newRetval2();
//		pageFact.elmntIntract();
//		Thread.sleep(2500);
//		pageFact.blngname();
//		Thread.sleep(3000);
//		pageFact.blngnamevalu();
		Thread.sleep(3000);
		pageFact.txtDee();
		Thread.sleep(3000);
		pageFact.brsaveBtnn();
		Thread.sleep(5000);
		wait_Errmsg2();
		Thread.sleep(2000);
		String SuccErrMsg = pageFact.invalidOfseterro();
		if (pageFact.invalidOfseterro().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Offset number successfully saved, Success message showing is - "
							+ SuccErrMsg);
			extentTest.log(LogStatus.INFO,
					"Offset number successfully saved, Success message showing is - "
							+ SuccErrMsg);
		} else {
			System.out.println("Offset number validation failed");			 
			extentTest.log(LogStatus.FAIL, "Offset number validation failed");
		}

		return null;
	}
	
	public String offsetnumSuccII() throws InterruptedException, IOException {

		pageFact.newBracnclk();
		pageFact.newRetclk();
		Thread.sleep(2500);
		pageFact.accntretNeww();

		pageFact.newRetval();
		// pageFact.newRetval2();
		  pageFact.elmntIntract();
		  
		// pageFact.blngname();
		// Thread.sleep(3000);
		// pageFact.blngnamevalu();
		Thread.sleep(3000);
		pageFact.txtDee();
		Thread.sleep(3000);
		pageFact.brsaveBtnn();
		Thread.sleep(5000);
		wait_Errmsg2();
		Thread.sleep(2000);
		String SuccErrMsg = pageFact.invalidOfseterro();
		if (pageFact.invalidOfseterro().contains(
				"Billing Record has been saved")) {
			System.out
					.println("Offset number successfully saved, Success message showing is - "
							+ SuccErrMsg);
			extentTest.log(LogStatus.INFO,
					"Offset number successfully saved, Success message showing is - "
							+ SuccErrMsg);
		} else {
			System.out.println("Offset number validation failed"); 
			extentTest.log(LogStatus.FAIL, "Offset number validation failed");
		}

		return null;
	}

	public String asingTotest() throws InterruptedException {

		Thread.sleep(55000);
		pageFact.assignTodrpclk();
		Thread.sleep(5000);
		String asigntouser = pageFact.asignToo();
		System.out.println("Assign to user is - " + asigntouser);
		extentTest
				.log(LogStatus.INFO,
						"Logged in user name showing properly in Assign To Dropdown.  Assign to user is - "
								+ asigntouser);

		return null;
	}

	public String brStatuscChk() throws IOException, InterruptedException {

		Thread.sleep(55000);
		pageFact.brStatusdrpclk();
		Thread.sleep(3000);
		String brstatususr = pageFact.brStatustxt();

		if (pageFact.brStatustxt().contains("Ready for Income")) {
			System.out
					.println("BR Status displaying after successful save is - "
							+ brstatususr);
			extentTest.log(LogStatus.INFO,
					"BR Status displaying after successful save is - "
							+ brstatususr);
		} else {
			System.out.println("BR Status displaying is wrong " + brstatususr);

			extentReportImage223PO_3 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage223PO_3.png";
			String source = aftermthd();
			File destination = new File(extentReportImage223PO_3);
			//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Offset number validation failed"
					+ extentTest.addScreenCapture(extentReportImage223PO_3));
		}
		return null;
	}

	public String newBRsuccmsg() throws IOException, InterruptedException {

		Thread.sleep(3600);
		String invErrMsg = pageFact.invalidOfseterro();
		if (pageFact.invalidOfseterro().contains(
				"Billing Record has been saved")) {
			System.out
					.println("After successful save error/success message showing is - "
							+ invErrMsg);
			extentTest.log(LogStatus.INFO,
					"After successful save error/success message showing is - "
							+ invErrMsg);
		} else {
			System.out.println("Error/Success message showing is wrong");

			extentReportImage223PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage223PO_1.png";
			String source = aftermthd();
			File destination = new File(extentReportImage223PO_1);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Error/Success message showing is wrong"
									+ extentTest
											.addScreenCapture(extentReportImage223PO_1));
		}

		return null;
	}

	public String getbilngRcrdId() {

		String testelem = pageFact.blngRcrdidd();
		System.out.println("BR ID displaying after successful save is - "
				+ testelem);
		extentTest.log(LogStatus.INFO,
				"BR ID displaying after successful save is - " + testelem);

		return null;
	}

	/**
	 * 
	 * 
	 * @author jmaya09
	 * @throws IOException 
	 *
	 */
	public String smart_drpDwns() throws InterruptedException, IOException {

		// Creation of file object
		// File file = new
		// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");

		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();
		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		if (pageFact.smart_dropdown(prop.getProperty("CABS_207_var")).contains(
				prop.getProperty("CABS_207_var"))) {
			System.out
					.println("In Smart drop downs, the area where the selected value shows is clickable");
			System.out
					.println("Listed value is filtered with user typed character");
			System.out.println("User typed character is selected");
			extentTest
					.log(LogStatus.INFO,
							"In Smart drop downs, the area where the selected value shows is clickable");
			extentTest.log(LogStatus.INFO,
					"Listed value is filtered with user typed character");
			extentTest.log(LogStatus.INFO, "User typed character is selected");
		} else {
            System.out.println("User typed character is not selected");
            String source =aftermthd();
            
     

            extentTest.log(LogStatus.FAIL, "User typed character is not selected" + 
            extentTest.addScreenCapture("data:image/png;base64,"+source));
	
		}
		return null;
	}

	public String smrt_drpDwn_Sort() throws InterruptedException {

		// Creation of file object
		// File file = new
		// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");

		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();
		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		if (pageFact.dropDownListSortedOrNot(prop.getProperty("CABS_207_var2")) == true) {
			System.out.println("Drop down list is in sorted order");
			extentTest.log(LogStatus.INFO, "Drop down list is in sorted order");
		} else {
			System.out.println("Drop down list is not in sorted order");
			extentTest.log(LogStatus.FAIL,
					"Drop down list is not in sorted order");
		}
		return null;
	}

	public String smrt_drpDwn_refresh() throws InterruptedException {
		// Creation of file object
		// File file = new
		// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");
		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();
		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		if (pageFact.DropDwn_Refresh(prop.getProperty("CABS_207_var3")) == true) {
			System.out
					.println("Filter criteria is cleared when page is refreshed");
			extentTest.log(LogStatus.INFO,
					"Filter criteria is cleared when page is refreshed");
		} else {
			System.out
					.println("Filter criteria is not cleared when page is refreshed");
			extentTest.log(LogStatus.FAIL,
					"Filter criteria is not cleared when page is refreshed");
		}
		return null;
	}

	public String smrt_drpDwn_clear() throws InterruptedException {
		// Creation of file object
		// File file = new
		// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");
		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();
		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		if (pageFact.DropDwn_Clear(prop.getProperty("CABS_207_var4")) == true) {
			System.out
					.println("All values are showing in drop down when filter criteria is cleared");
			extentTest
					.log(LogStatus.INFO,
							"All values are showing in drop down when filter criteria is cleared");
		} else {
			System.out
					.println("All values are not showing in drop down when filter criteria is cleared");
			extentTest
					.log(LogStatus.FAIL,
							"All values are not showing in drop down when filter criteria is cleared");
		}
		return null;
	}

	public String smrt_drpDwn_scroll() throws InterruptedException {
		// Creation of file object
		// File file = new
		// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");
		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();
		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		// if (pageFact.DropDwn_Scroll() == true) {
		// System.out.println("User is able to scroll the drop down");
		// extentTest.log(LogStatus.INFO,
		// "User is able to scroll the drop down");
		// } else {
		// System.out.println("User is not able to scroll the drop down");
		// extentTest.log(LogStatus.FAIL,
		// "User is not able to scroll the drop down");
		// }
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		if (pageFact.DropDwn_Scroll_Filter(prop.getProperty("CABS_207_var5")) == true) {
			System.out
					.println("User is able to scroll the drop down after filter");
			extentTest.log(LogStatus.INFO,
					"User is able to scroll the drop down after filter");
		} else {
			System.out
					.println("User is not able to scroll the drop down after filter");
			extentTest.log(LogStatus.FAIL,
					"User is not able to scroll the drop down after filter");
		}
		return null;
	}

	public String smrt_drpDwn_key() throws InterruptedException {
		if (pageFact.DropDwn_Key() == true) {
			System.out
					.println("User is able to use up and down key and select a value");
			extentTest.log(LogStatus.INFO,
					"User is able to use up and down key and select a value");
		} else {
			System.out
					.println("User is not able to use up and down key and select a value");
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to use up and down key and select a value");
		}
		return null;
	}

	public String smrt_drpDwn_CopyPaste() throws InterruptedException {
		if (pageFact.DropDwn_CopyPaste() == true) {
			System.out
					.println("User is able to paste the copied value and filter the result");
			extentTest
					.log(LogStatus.INFO,
							"User is able to paste the copied value and filter the result");
		} else {
			System.out
					.println("User is not able to paste the copied value and filter the result");
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to paste the copied value and filter the result");
		}
		return null;
	}

	public String createBRModal() throws InterruptedException, IOException,
			AWTException {
	
		waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		if (pageFact.createBRModalPopUp() == true) {
			System.out
					.println("User is able to see BR modal pop up with billing record types");
			extentTest
					.log(LogStatus.INFO,
							"User is able to see BR modal pop up with billing record types");
		} else {
			System.out
					.println("User is not able to see BR modal pop up with billing record types");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_0 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_0.png";
			//File source = aftermthd();
			//File destination = new File(extentReportImage199PO_0);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to see BR modal pop up with billing record types"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_0));

		}
		return null;
	}

	public String bRTypeRetail() throws InterruptedException, IOException {
		if (pageFact.bRTypeRetailSel() == true) {
			System.out
					.println("User is able to choose Retail Allowance as Billing Record type");
			extentTest
					.log(LogStatus.INFO,
							"User is able to choose Retail Allowance as Billing Record type");
		} else {
			System.out
					.println("User is not able to choose Retail Allowance as Billing Record type");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_1.png";
			String source= aftermthd();
			File destination = new File(extentReportImage199PO_1);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to choose Retail Allowance as Billing Record type"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_0));

		}
		return null;
	}

	public String bRTypeRetailFields() throws InterruptedException,
			IOException, ParseException, BiffException {

		if (pageFact.bRTypeRetailAccType().equals("Account Lookup Type")) {
			System.out.println("Account Lookup Type Label is displayed");
			extentTest.log(LogStatus.INFO,
					"Account Lookup Type Label is displayed");
		} else {
			System.out.println("Account Lookup Type label is not displayed");
			extentReportImage199PO_1 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_1.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_1);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account Lookup Type label is not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_1));

		}

		if (pageFact.bRTypeRetailOffno().equals("Offer Number")) {
			System.out.println("Offer number label is displayed");
			extentTest.log(LogStatus.INFO, "Offer number label is displayed");
		} else {
			System.out.println("Offer number label is not displayed");
			extentReportImage199PO_2 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_2.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_2);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Offer number label is not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_2));

		}

		if (pageFact.bRTypeRetailleadCIC().equals("Lead CIC")) {
			System.out.println("Lead CIC label is displayed");
			extentTest.log(LogStatus.INFO, "Lead CIC label is displayed");
		} else {
			System.out.println("Lead CIC label is not displayed");
			extentReportImage199PO_3 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_3.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_3);
			//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "Lead CIC label is not displayed"
					+ extentTest.addScreenCapture(extentReportImage199PO_3));

		}

		if (pageFact.bRTypeRetaildateFrom().equals("Bill Date From")) {
			System.out.println("Bill Date from label is displayed");
			extentTest.log(LogStatus.INFO, "Bill Date from label is displayed");
		} else {
			System.out.println("Bill Date from label is not displayed");
			extentReportImage199PO_4 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_4.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_4);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Bill Date from label is not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_4));

		}

		if (pageFact.bRTypeRetaildateTo().equals("Bill Date To")) {
			System.out.println("Bill Date to label is displayed");
			extentTest.log(LogStatus.INFO, "Bill Date to label is displayed");
		} else {
			System.out.println("Bill Date to label is not displayed");
			extentReportImage199PO_5 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_5.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_5);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Bill Date to label is not displayed"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_5));

		}

		if (pageFact.bRTypeRetailFieldAccType() == true) {
			System.out
					.println("Account look up type field is having value Retail div");
			extentTest.log(LogStatus.INFO,
					"Account look up type field is having value Retail div");
		} else {
			System.out.println("Account look up type field is not as expected");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_6 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_6.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_6);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account look up type field is not as expected"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_6));

		}

		if (pageFact.bRTypeRetailFieldAccValue() == true) {
			System.out
					.println("User can select Account look up value from drop down for Retail division");
			extentTest
					.log(LogStatus.INFO,
							"User can select Account look up value from drop down for Retail division");
		} else {
			System.out
					.println("Account look up value drop down is not showing values for Retail division");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_7 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_7.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_7);
			//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Account look up value drop down is not showing values for Retail division"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_7));
		}

		if (pageFact.bRTypeRetailFieldOffNo() == true) {
			System.out.println("User is able to enter offer number");
			extentTest
					.log(LogStatus.INFO, "User is able to enter offer number");
		} else {
			System.out.println("User is not able to enter offer number");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_8 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_8.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_8);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to enter offer number"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_8));
		}

		if (pageFact.bRTypeRetailFieldLeadCIC() == true) {
			System.out.println("User is able to enter Lead CIC");
			extentTest.log(LogStatus.INFO, "User is able to enter Lead CIC");
		} else {
			System.out.println("User is not able to enter Lead CIC");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_9 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_9.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_9);
			//FileUtils.copyFile(source, destination);
			extentTest.log(LogStatus.FAIL, "User is not able to enter Lead CIC"
					+ extentTest.addScreenCapture(extentReportImage199PO_9));
		}

		if (pageFact.bRTypeRetailFieldStartDt() == true) {
			System.out
					.println("User is able to pick a start date using a date picker");
			extentTest.log(LogStatus.INFO,
					"User is able to pick a start date using a date picker");
		} else {
			System.out
					.println("User is not able to pick a start date using a date picker");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_10 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_10.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_10);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to pick a start date using a date picker"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_10));
		}

		if (pageFact.bRTypeRetailFieldEndDt() == true) {
			System.out
					.println("User is able to pick an end date using a date picker");
			extentTest.log(LogStatus.INFO,
					"User is able to pick an end date using a date picker");
		} else {
			System.out
					.println("User is not able to pick an end date using a date picker");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_11 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_11.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_11);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not able to pick an end date using a date picker"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_11));
		}
		return null;
	}

	public String bRTypeRetailMandFields() throws InterruptedException,
			IOException {

		if (pageFact.bRTypeRetailMand() == true) {
			System.out
					.println("User is getting error message when all the mandatory fields are not entered");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when all the mandatory fields are not entered");
		} else {
			System.out
					.println("Error message showing is not proper when all the mandatory fields are not entered");
			
			
			
			//Jenkins IMAGE PATH				
			//extentReportImage199PO_12 = System.getProperty("url","/appl/chje/jenkins_home/workspace/pabs-/pabs-git-master-/cabs_ui_testing/picture/extentReportImage199PO_12.png");
				 
			//String source = aftermthd();
			//File destination = new File(extentReportImage199PO_12);
			////FileUtils.copyFile(source, destination);
			//extentTest
					//.log(LogStatus.FAIL,
							//"Error message showing is not proper when all the mandatory fields are not entered"
									//+ extentTest
										//	.addScreenCapture(extentReportImage199PO_12));
			//extent = new ExtentReports(System.getProperty("url"),true);
			
			//File source =aftermthd();
//byte[] fileContent = FileUtils.readFileToByteArray(source);
  //String Base64StringofScreenshot = "data:image/png;base64,"+Base64.getEncoder().encodeToString(fileContent);
        
            //extentTest.log(LogStatus.FAIL, "User is not able to see BR modal pop up with billing record types"+ extentTest.addScreenCapture(Base64StringofScreenshot));



		}
		return null;
	}

	public String bRTypeRetailAnyMandFields() throws InterruptedException,
			IOException, ParseException, BiffException {

		if (pageFact.bRTypeRetailAnyMandAccVal() == true) {
			System.out
					.println("User is getting error message when Account look up value field is not entered");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when Account look up value field is not entered");
		} else {
			System.out
					.println("User is not getting error message when Account look up value field is not entered");
			extentReportImage199PO_13 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_13.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_13);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not getting error message when Account look up value field is not entered"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_13));
		}

		if (pageFact.bRTypeRetailAnyMandLeadCIC() == true) {
			System.out
					.println("User is getting error message when Lead CIC field is not entered");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when Lead CIC field is not entered");
		} else {
			System.out
					.println("User is not getting error message when Lead CIC field is not entered");
			extentReportImage199PO_14 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_14.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_14);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not getting error message when Lead CIC field is not entered"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_14));
		}

		if (pageFact.bRTypeRetailAnyMandStDate() == true) {
			System.out
					.println("User is getting error message when Bill Date from field is not entered");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when Bill Date from field is not entered");
		} else {
			System.out
					.println("User is not getting error message when Bill Date from field is not entered");
			extentReportImage199PO_15 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_15.png";
			String source= aftermthd();
			File destination = new File(extentReportImage199PO_15);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not getting error message when Bill Date from field is not entered"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_15));
		}

		if (pageFact.bRTypeRetailAnyMandEndDate() == true) {
			System.out
					.println("User is getting error message when Bill Date to field is not entered");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when Bill Date to field is not entered");
		} else {
			System.out
					.println("User is not getting error message when Bill Date to field is not entered");
			extentReportImage199PO_16 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_16.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_16);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not getting error message when Bill Date to field is not entered"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_16));
		}

		if (pageFact.bRTypeRetailAnyMandFlatCode() == true) {
			System.out
					.println("User is getting error message when Flat code is not entered for Flat amount");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when Flat code is not entered for Flat amount");
		} else {
			System.out
					.println("User is not getting error message when Flat code is not entered for Flat amount");
			extentReportImage199PO_28 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_28.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_28);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not getting error message when Flat code is not entered for Flat amount"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_28));
		}

		if (pageFact.bRTypeRetailAnyMandPerf1() == true) {
			System.out
					.println("User is getting error message when performance code1 is not entered for Allowance Type");
			extentTest
					.log(LogStatus.INFO,
							"User is getting error message when performance code1 is not entered for Allowance Type");
		} else {
			System.out
					.println("User is not getting error message when performance code1 is not entered for Allowance Type");
			extentReportImage199PO_29 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_29.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_29);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"User is not getting error message when performance code1 is not entered for Allowance Type"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_29));
		}
		return null;
	}

	public String bRTypeRetailHeader() throws InterruptedException,
			IOException, AWTException {
		if (pageFact.headerFlat().contains("Flat Amount")) {
			System.out
					.println("Flat Amount label is displayed under HEADER section");
			extentTest.log(LogStatus.INFO,
					"Flat Amount label is displayed under HEADER section");
		} else {
			System.out
					.println("Flat Amount label is  not displayed under HEADER section");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_17 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_17.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_17);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Flat Amount label is not displayed under HEADER section"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_17));

		}

		if (pageFact.headerFlatCode().equals("Flat Code")) {
			System.out
					.println("Flat Code label is displayed under HEADER section");
			extentTest.log(LogStatus.INFO,
					"Flat Code label is displayed under HEADER section");
		} else {
			System.out
					.println("Flat Code label is  not displayed under HEADER section");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_18 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_18.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_18);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Flat Code label is not displayed under HEADER section"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_18));

		}

		if (pageFact.headerFlatAmtGrtZero() == true) {
			System.out
					.println("For Flat Amount greater than 0, valid values are shown in Flat code drop down");
			extentTest
					.log(LogStatus.INFO,
							"For Flat Amount greater than 0, valid values are shown in Flat code drop down");
		} else {
			System.out
					.println("For Flat Amount greater than 0, valid values are not shown in Flat code drop down");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_20 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_20.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_20);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"For Flat Amount greater than 0, valid values are not shown in Flat code drop down"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_20));

		}
		return null;
	}

	public String bRTypeRetailItemized() throws InterruptedException,
			IOException, AWTException {
		if (pageFact.itemAlwType().equals("Allowance Type")) {
			System.out
					.println("Allowance type label is displayed under ITEMIZED section");
			extentTest.log(LogStatus.INFO,
					"Allowance type label is displayed under ITEMIZED section");
		} else {
			System.out
					.println("Allowance type label is not displayed under ITEMIZED section");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_18 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_18.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_18);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Allowance type label is not displayed under ITEMIZED section"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_18));

		}

		if (pageFact.itemPerf1().equals("Performance 1")) {
			System.out
					.println("Performance 1 label is displayed under ITEMIZED section");
			extentTest.log(LogStatus.INFO,
					"Performance 1 label is displayed under ITEMIZED section");
		} else {
			System.out
					.println("Performance 1 label is not displayed under ITEMIZED section");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_19 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_19.png";
			String source= aftermthd();
			File destination = new File(extentReportImage199PO_19);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Performance 1 label is not displayed under ITEMIZED section"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_19));

		}

		if (pageFact.itemPerf2().equals("Performance 2")) {
			System.out
					.println("Performance 2 label is displayed under ITEMIZED section");
			extentTest.log(LogStatus.INFO,
					"Performance 2 label is displayed under ITEMIZED section");
		} else {
			System.out
					.println("Performance 2 label is not displayed under ITEMIZED section");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_20 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_20.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_20);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Performance 2 label is not displayed under ITEMIZED section"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_20));

		}

		if (pageFact.allwtype() == true) {
			System.out
					.println("Allowance Type drop down under ITEMIZED section is showing valid values");
			extentTest
					.log(LogStatus.INFO,
							"Allowance Type drop down under ITEMIZED section is showing valid values");
		} else {
			System.out
					.println("Allowance Type drop down under ITEMIZED section is not showing valid values");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_21 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_21.png";
			String source= aftermthd();
			File destination = new File(extentReportImage199PO_21);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Allowance Type drop down under ITEMIZED section is not showing valid values"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_21));

		}
		return null;
	}

	public Boolean allwTypeT() throws InterruptedException, IOException,
			AWTException {
		if (pageFact.allwTP1P2() == true) {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"T\" is having valid values");
			extentTest
					.log(LogStatus.INFO,
							"Performance 1 & Performance 2 for Allowance Type \"T\" is having valid values");
		} else {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"T\" is not having valid values");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_22 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_22.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_22);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Performance 1 & Performance 2 for Allowance Type \"T\" is not having valid values"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_22));
		}
		return null;
	}

	public Boolean allwTypeS() throws InterruptedException, IOException,
			AWTException {
		if (pageFact.allwSP1P2() == true) {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"S\" is having valid values");
			extentTest
					.log(LogStatus.INFO,
							"Performance 1 & Performance 2 for Allowance Type \"S\" is having valid values");
		} else {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"S\" is not having valid values");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_23 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_23.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_23);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Performance 1 & Performance 2 for Allowance Type \"S\" is not having valid values"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_23));
		}
		return null;
	}

	public Boolean allwTypeA() throws InterruptedException, IOException,
			AWTException {
		if (pageFact.allwAP1P2() == true) {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"A\" is having valid values");
			extentTest
					.log(LogStatus.INFO,
							"Performance 1 & Performance 2 for Allowance Type \"A\" is having valid values");
		} else {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"A\" is not having valid values");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_24 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_24.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_24);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Performance 1 & Performance 2 for Allowance Type \"A\" is not having valid values"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_24));
		}
		return null;
	}

	public Boolean allwTypeC() throws InterruptedException, IOException,
			AWTException {
		if (pageFact.allwCP1P2() == true) {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"C\" is having valid values");
			extentTest
					.log(LogStatus.INFO,
							"Performance 1 & Performance 2 for Allowance Type \"C\" is having valid values");
		} else {
			System.out
					.println("Performance 1 & Performance 2 for Allowance Type \"C\" is not having valid values");
			
		//	File source =aftermthd();
//byte[] fileContent = FileUtils.readFileToByteArray(source);
  //String Base64StringofScreenshot = "data:image/png;base64,"+Base64.getEncoder().encodeToString(fileContent);
        
        //    extentTest.log(LogStatus.FAIL, "User is not able to see BR modal pop up with billing record types"+ extentTest.addScreenCapture(Base64StringofScreenshot));


			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
		//Jenkins IMAGE PATH		
			
			//	extentReportImage199PO_25 = System.getProperty("url","/appl/chje/jenkins_home/workspace/pabs-/pabs-git-master-/cabs_ui_testing/extentReportImage199PO_25.png");
		//	extentReportImage199PO_25 = System.getProperty("url","/appl/chje/jenkins_home/workspace/pabs-/pabs-git-master-/cabs_ui_testing/picture/extentReportImage199PO_25.png");
				 
			//String source = aftermthd();
			//File destination = new File(extentReportImage199PO_25);
			////FileUtils.copyFile(source, destination);
			//extentTest
			//		.log(LogStatus.FAIL,
							//"Performance 1 & Performance 2 for Allowance Type \"C\" is not having valid values"
								//	+ extentTest
										//	.addScreenCapture(extentReportImage199PO_25));
				//extent = new ExtentReports(System.getProperty("url"),true);
			
			//extentReportImage199PO_25 = System.getProperty("user.dir")
			//		+ "\\picture" + "\\extentReportImage199PO_25.png";
			//String source = aftermthd();
			//File destination = new File(extentReportImage199PO_25);
			////FileUtils.copyFile(source, destination);
			//extentTest
				//	.log(LogStatus.FAIL,
					//		"Performance 1 & Performance 2 for Allowance Type \"C\" is not having valid values"
								//	+ extentTest
									//		.addScreenCapture(extentReportImage199PO_25));
		}
		return null;
	}

	public Boolean clear() throws InterruptedException, IOException,
			AWTException {
		if (pageFact.RetClear() == true) {
			System.out.println("Clear button clears all the field values");
			extentTest.log(LogStatus.INFO,
					"Clear button clears all the field values");
		} else {
			System.out
					.println("Clear button is not clearing all the field values");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_26 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_26.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_26);
		//	//FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Clear button is not clearing all the field values"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_26));
		}
		return null;
	}

	public Boolean close() throws InterruptedException, IOException,
			AWTException {
		if (pageFact.RetClose() == true) {
			System.out.println("Close button close the BR modal pop up");
			extentTest.log(LogStatus.INFO,
					"Close button close the BR modal pop up");
		} else {
			System.out
					.println("Close button is not closing the BR modal pop up");
			// extentTest.log(LogStatus.FAIL, "User is not able to see BR modal
			// pop up with
			// billing record types");
			extentReportImage199PO_27 = System.getProperty("user.dir")
					+ "\\picture" + "\\extentReportImage199PO_27.png";
			String source = aftermthd();
			File destination = new File(extentReportImage199PO_27);
			////FileUtils.copyFile(source, destination);
			extentTest
					.log(LogStatus.FAIL,
							"Close button is not closing the BR modal pop up"
									+ extentTest
											.addScreenCapture(extentReportImage199PO_27));
		}
		return null;
	}

	/**
	 * 
	 * Author: ssubr13
	 */
	public String waitforcreate() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.elementToBeClickable(pageFact.createbilling));
		return null;
	}

	public String ClickCreatbill() throws InterruptedException {

		waitforcreate();
		pageFact.CreateClick();

		return null;
	}

	public String BillingType() throws InterruptedException {

		waitforcreate();
		pageFact.BillClick();

		return null;
	}

	public String BillClick() throws InterruptedException {

		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		pageFact.createBillrcrd.click();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(3000);
		
		pageFact.BrTyp();
		Thread.sleep(4500);
		pageFact.BrSel();
		Thread.sleep(3000);
		pageFact.alt1();
		Thread.sleep(2500);
		pageFact.alt2();
		Thread.sleep(2500);
		pageFact.alt3();
		Thread.sleep(2500);
		pageFact.alt4();
		Thread.sleep(2500);
		pageFact.Firstsub();
		Thread.sleep(2500);
		
		if (pageFact.Savebtntxt().equals("Save")) {
			System.out.println("PASS:  Save button displayed");
			extentTest.log(LogStatus.INFO, "Save button displayed");
		} else {
			System.out.println("FAIL:  Save button not displayed");
			extentTest.log(LogStatus.FAIL, "Save button not displayed");
		}
		Thread.sleep(2500);

		if (pageFact.Cancelbtntxt().equals("Cancel")) {
			System.out.println("PASS:  Cancel button displayed");
			extentTest.log(LogStatus.INFO, "Cancel button displayed");
		} else {
			System.out.println("FAIL:  Cancel button not displayed");
			extentTest.log(LogStatus.FAIL, "Cancel button not displayed");
		}
		return null;
	}
	
	 

	public String nonAlwnceNew() throws InterruptedException {

		wait_forBlngbtn();
	 pageFact.waitForSpinnerToBeGone();
	 Thread.sleep(2500);
		//Thread.sleep(20000);
		pageFact.creatBillng();
		pageFact.waitForSpinnerToBeGone();
		Thread.sleep(5000);
	 
		pageFact.BrTyp();
		Thread.sleep(4500);
		waitforbillType();
		Thread.sleep(2000);
		pageFact.nonAllwdrp();		
		Thread.sleep(4500);
		pageFact.submitClk();
		wait_forbrtxt();
	 
		return null;
	}
	
	public String incomeSum() throws InterruptedException {

		Thread.sleep(2000);
		pageFact.AddRow();
		Thread.sleep(2000);

		pageFact.firstIncAmount.sendKeys("1");
		pageFact.secondIncAmount.sendKeys("1");
		Thread.sleep(2000);
		
		String sum = pageFact.sumTxt();
		
		System.out.println("SUM IS"  +sum);
		
		if(pageFact.sumTxt().equals("2.00")){
			
			System.out.println("PASS:  Sum of added Income amount showing in the Grand Total field properly");
			extentTest.log(LogStatus.INFO, "Sum of added Income amount showing in the Grand Total field properly");
			
		}else{
			System.out.println("FAIL:  Sum showing is wrong");
			extentTest.log(LogStatus.FAIL, "Sum showing in the Grand Total field is wrong");
			
		}

		return null;
	}

	@BeforeTest
	public WebDriver beforeTest() throws InterruptedException {

		// Creation of file object
		// File file = new
		// File("D:\\U82703\\Eclipse_Selenium\\ABS_CABS\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");

		String file = new File(System.getProperty("user.dir"),
				"properties_File").getAbsolutePath();

		// Creation of properties object
		Properties prop = new Properties();

		// Creation of InputStream object to read data
		FileInputStream objInput = null;
		try {
			objInput = new FileInputStream(file);
			// Reading properties key/values in file
			prop.load(objInput);
			// Closing the input stream
			// objInput.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		// Linux path
		 System.setProperty("webdriver.chrome.driver","/appl/chje/jenkins/chromedriver/chromedriver");

		// Windows Chromedriver
//		System.setProperty("webdriver.chrome.driver",
//				new File(System.getProperty("user.dir"), "chromedriverWin.exe")
//						.getAbsolutePath());
		
		
		
		//Old Linux Chromedriver
		// new File(System.getProperty("user.dir"),
		// "chromedriver").getAbsolutePath());
		ChromeOptions chromeOptions = new ChromeOptions();

		// chromeOptions.addArguments("--headless");
		 chromeOptions.addArguments("--proxy-server=http://172.20.119.16:8080");

		Driver = new ChromeDriver(chromeOptions);
		Driver.manage().window().maximize();

		// String url1 = Driver.getCurrentUrl();
		// Assert.assertEquals(url1, "http://40.117.78.82:31862/#");

		Driver.get(prop.getProperty("url"));
		Thread.sleep(5000);
		pageFact = new GenericFactory(Driver);

		// -- Code for by passing Proxy
		// pageFact.wait_forprox();
		// String expPageTitle = "CABS - Centralized Accounting Billing System";

		// if (Driver.getTitle().equalsIgnoreCase(expPageTitle)) {
		// System.out.println("Yeah... Page title matched");
		// }
		// pageFact.prox_click();

		return Driver;
	}

	@AfterTest
	public void afterTest() {

	}

}
