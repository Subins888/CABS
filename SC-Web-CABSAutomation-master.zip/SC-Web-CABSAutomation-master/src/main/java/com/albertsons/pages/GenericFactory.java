package com.albertsons.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class GenericFactory {

	WebDriver Driver;
	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	
	   public WebElement offnum, LCIC; 
	   
	   
	   
	@FindBy(id = "inputUsername")
	WebElement usr_Name;

	@FindBy(id = "inputPassword")
	WebElement pass_Wrd;

	@FindBy(id = "submitButton")
	WebElement login_Clk;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[2]/div/action-button/button")
	WebElement homepage_name;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[2]/div/action-button/button")
	WebElement createBillbtn;
	
	@FindBy(name="LogIn")
	WebElement login_ClkII;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
	public  WebElement createBillrcrd;

	@FindBy(xpath = "/html/body/div/div/form/table[2]/tbody/tr/td/table[1]/tbody/tr[4]/td/table/tbody/tr/td[1]/input[2]")
	WebElement proxy;

	// @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[1]")
	@FindBy(xpath = "//*[@id='search']/li/a")
	WebElement Search_billing_rcrd;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[1]/a")
	// @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[2]")
	WebElement analysis_wrklist;

	// @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[3]")
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[2]/a")
	WebElement incme_wrklist;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[3]/a")
	// @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[4]")
	WebElement ovr_tolerance_wrklist;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[4]/a")
	// @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[5]")
	WebElement dialog_wrklist;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[5]/a")
	// @FindBy(xpath="//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[6]")
	WebElement paybck_wrklist;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/app-create-br/cabs-modal/div[3]/div/div/div/action-button/button")
	WebElement submit_Btn;

	@FindBy(xpath = "//*[@id='ngb-panel-0-header']/div/button")
	WebElement income_Txt;

	@FindBy(xpath = "//*[@id='upload']/input")
	public WebElement upLoad;

	@FindBy(xpath = "//*[@id='hamburger-dropdown']/span/a/img")
	public WebElement hamBurger;

	@FindBy(xpath = "//*[@id='hamburger-dropdown']/div/button/div")
	public WebElement log_Out;

	@FindBy(xpath = "//*[@id='dropdownManual']/input")
	public WebElement smart_Drp;

	@FindBy(id = "upload")
	public WebElement upload_btn;

	@FindBy(xpath = "//*[@id='search']/li/a")
	public WebElement search_Bill;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/worklist-menu/div/ul/li[1]/span/img")
	public WebElement tool_tip1;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-home/div/div/nav/ol/li")
	public WebElement home_bread;

	// @FindBy(xpath="//*[@id='billingRecordType']/div/div/div[2]")
	@FindBy(id = "billingRecordType")
	public WebElement blngRcrdDrpdown;

	@FindBy(id = "ae259512ba6b-0")
	public WebElement drpFirst;

	@FindBy(xpath = "//*[@id='flatCode']/div/div/div[3]/input")
	public WebElement flatcodeDrpdwn;

	@FindBy(xpath = "//*[@id='flatAmount']")
	public WebElement flatAmnt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[2]/div/div/div[1]/action-button/button")
	public WebElement subMitBtn;

	@FindBy(xpath = "//*[@id='flatCode']/div/span")
	public WebElement flatCodeDrpVal;

	@FindBy(xpath = "//*[@id='ta-billingRecordType-0']")
	public WebElement blngRcrdType0;

	@FindBy(xpath = "//*[@id='ta-billingRecordType-1']")
	public WebElement blngRcrdType1;

	@FindBy(xpath = "//*[@id='billingRecordType']/div/span")
	public WebElement blngRcrdTyp;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div/div[1]/div/label")
	public WebElement AcntlukTxt;

	@FindBy(xpath = "//*[@id='accountLookupType']/div/span")
	public WebElement AcntlukDrp;

	@FindBy(xpath = "//*[@id='accountLookupType']/div/div/div[3]")
	public WebElement AcntlukDrp1;

	@FindBy(id = "ta-accountLookupType-0")
	public WebElement AcntlukRet;

	@FindBy(id = "ta-accountLookupType-1")
	public WebElement AcntlukCog;

	@FindBy(id = "accountLookupValue")
	public WebElement AcntlukVal;

	@FindBy(id = "ta-accountLookupValue-0")
	public WebElement AcntlukVal1;

	// @FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span/i-feather/svg")
	// @FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span/i-feather/svg/line[1]")
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span")
	public WebElement closeBtn;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[2]/div/div/div/action-button/button")
	public WebElement creatBrSbmt;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/h4/span[2]")
	public WebElement errMsg;

	@FindBy(xpath = "//*[@id='accLookUpType']/div/span")
	public WebElement newBracntlukup;

	@FindBy(id = "ta-accLookUpType-0")
	public WebElement accntRet;

	@FindBy(id = "accLookUpValue")
	public WebElement accntRetnew;

	@FindBy(id = "ta-accLookUpValue-1")
	public WebElement accntRetval;
	
	@FindBy(id = "ta-accLookUpValue-2")
	public WebElement accntRetval2;

	@FindBy(id = "ta-accLookUpValue-0")
	public WebElement accntRetval1;

	@FindBy(id = "deductInvoiceNumber")
	public WebElement deductnum;

	@FindBy(id = "billingName")
	public WebElement blngNam;

	@FindBy(id = "ta-billingName-0")
	public WebElement blngNamval;

	@FindBy(id = "textarea")
	public WebElement txtArea;

	@FindBy(xpath = "//*[@id='undefined']")
	public WebElement txtDescr;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	public WebElement newBRSav;

	@FindBy(xpath = "//*[@id='income-tab']/div[4]/button")
	public WebElement incombtn;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/button")
	public WebElement incmdsave;

	@FindBy(xpath = "//*[@id='income-tab']/div[3]/div[1]/label")
	public WebElement billLbl;

	@FindBy(xpath = "//*[@id='income-tab']/div[3]/div[2]/label")
	public WebElement acrueLbl;

	@FindBy(xpath = "//*[@id='income-tab']/div[3]/div[3]/label")
	public WebElement blAcrLbl;

	// @FindBy(id="amount")
	// public WebElement amnt;

	@FindBy(id = "amountId0")
	public WebElement amnt;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/plain-button/button")
	public WebElement incmCancel;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[2]/div[2]/div/action-button/button")
	public WebElement incmSubmt;

	@FindBy(xpath = "//*[@id='incomeCollapse']/div/div/div[3]/div[1]/div[1]/div/button")
	public WebElement AddRowbTN;

	// @FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[2]/div[2]/div[3]/div/i-feather/svg")
	// @FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[2]/div[2]/div[3]/div/i-feather/svg/path")
	//@FindBy(name = "Trash2")
	@FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[2]/div[1]/div[3]/div/i-feather")
	public WebElement deleteBtn;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/span")
	public WebElement deptTxt;

	@FindBy(xpath = "//*[@id='teamDropdown']/span[2]/fa")
	public WebElement deptDrpDwn;

	@FindBy(xpath = "//*[@id='teamDropdown']/span[1]")
	public WebElement deptDrpDwnFirst;

	@FindBy(id = "teamDropdown")
	public WebElement teamDrp;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[1]/a")
	public WebElement deptDrpdwnval1;

	@FindBy(xpath = "//*[@id='maincontainer']/div[1]/div/cabs-navbar/nav/div/department-selector/div/div/div/button[2]/a")
	public WebElement deptDrpdwnval2;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[1]/nav/ol/li")
	public WebElement BRtxt;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	public WebElement brSaveBtn;

	@FindBy(xpath = "//*[@id='brStatus']/div/div/div[3]/input")
	public WebElement brStatus;

	@FindBy(xpath = "//*[@id='brStatus']/div/span")
	public WebElement brStatusdrp;

	@FindBy(id = "ta-brStatus-0")
	public WebElement rdyforinc;

	@FindBy(id = "label")
	public WebElement blngRcrdidLabel;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[1]/div[1]/div/div[2]/div/label")
	public WebElement lastDatLabel;

	@FindBy(id = "assignTo")
	public WebElement assignTodrp;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[1]/div/div[3]/label")
	public WebElement offsetNumlab;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[2]/div[3]/div/div[1]/div")
	public WebElement APaRRadio;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[3]/div[3]/div/div/div/cabs-checkbox/label/span")
	public WebElement createAlert;

	@FindBy(id = "ta-assignTo-5")
	public WebElement assignTo;
	
	@FindBy(id = "ta-assignTo-0")
	public WebElement assignTow;
	

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span/span")
	public WebElement newBRErrmsg;

	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/br-details/div/cabs-header/div/form/div/div[2]/div/div/span")
	public WebElement invalidOfseterr;

	@FindBy(id = "offsetSectionNumber")
	public WebElement offSetnum5;

	@FindBy(id = "ta-assignTo-18")
	public WebElement asignTo;

	@FindBy(id = "billingRecordId")
	public WebElement blngRcrdid;

	/**
	 * 
	 * 
	 * @author jmaya09
	 *
	 */
	// @FindBy(xpath = "//*[@id=\"dropdownManual\"]/input")
	//@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/div[3]/div/ng-select/div/div/div[2]/input")
	@FindBy(xpath="//*[@id='worklist']/div/div/div[3]/input")
	public WebElement smart_drop_down;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/div[3]/div/ng-select")
	public WebElement smart_drop_down_val;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/div[3]/div/ng-select/div/div/div[3]/input")
	public WebElement smart_drop_down1;

	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[2]/cabs-home/div/div/nav/ol/li")
	public WebElement smart_drp_copy;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/h4/span")
	public WebElement bRPopup;

	@FindBy(xpath = "//*[@id=\"billingRecordType\"]")
	public WebElement bRType;

	@FindBy(xpath = "//*[@id=\"ta-billingRecordType-0\"]")
	public WebElement retailAllwTyp;
	
	

	@FindBy(xpath = "//*[@id=\"ta-billingRecordType-1\"]")
	public WebElement cogsAllwTyp;

	@FindBy(xpath = "//*[@id=\"ta-billingRecordType-2\"]")
	public WebElement nonAllwTyp;

	@FindBy(xpath = "//*[@id=\"billingRecordType\"]/div/span")
	public WebElement bRDropdwn;

	@FindBy(xpath = "//*[@id=\"billingRecordType\"]/span[1]")
	public WebElement bRTypeDropDown;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]")
	public WebElement bROut;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[1]/div[1]/div/label")
	public WebElement accLkpType;

//	@FindBy(xpath = "//*[@id=\"offerNumber\"]")
//	public WebElement offrno;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[1]/div[3]/cabs-textbox/div/input")
	public WebElement offrno;
	
	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[1]/div[3]/cabs-textbox/div/label")
	public WebElement offrnoLabel;
	
	@FindBy(xpath = "//*[@id=\"leadCIC\"]")
	public WebElement leadCIC;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker")
	public WebElement dateFrom;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker")
	public WebElement dateTo;

	@FindBy(xpath = "//*[@id=\"accountLookupType\"]")
	public WebElement accLkUpType;

	@FindBy(xpath = "//*[@id=\"accountLookupValue\"]")
	public WebElement accLkUpVal;

	@FindBy(xpath = "//*[@id=\"accountLookupType\"]/div/div/div[3]")
	public WebElement accLkUpTypebox;

	@FindBy(xpath = "//*[@id=\"ta-accountLookupValue-0\"]")
	public WebElement selAccLkUpVal;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement fromCal;

	// @FindBy(xpath =
	// "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[5]/div[4]/div")
	// public WebElement fromCalopen;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[3]/div[5]/div")
	public WebElement fromCalopen;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[1]/cabs-datepicker/form/div/div/input")
	public WebElement billDateFrom;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/div/fa/i")
	public WebElement toCal;

	// @FindBy(xpath =
	// "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[6]/div[5]/div")
	// public WebElement toCalOpen;

	@FindBy(xpath = "/html/body/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[5]/div[4]/div")
	public WebElement toCalOpen;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[1]/div[2]/cabs-datepicker/form/div/div/input")
	public WebElement billDateTo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[2]/div/div/div[1]/action-button/button")
	public WebElement brSubmit;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/h4/span[2]")
	public WebElement brError;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[2]/div[1]/div/div/span")
	public WebElement headerLabel;

	@FindBy(xpath = "//*[@id=\"flatAmount\"]")
	public WebElement flatAmtLabel;

	@FindBy(xpath = "//*[@id=\"flatAmount\"]/input")
	public WebElement amtTxtBox1;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[2]/div[2]/div[2]/div/label")
	public WebElement flatCodeLabel;

	@FindBy(xpath = "//*[@id=\"flatCode\"]")
	public WebElement flatCodeBox;

	@FindBy(xpath = "//*[@id=\"ta-flatCode-0\"]")
	public WebElement flatCode0;

	@FindBy(xpath = "//*[@id=\"ta-flatCode-1\"]")
	public WebElement flatCode1;

	@FindBy(xpath = "//*[@id=\"ta-flatCode-2\"]")
	public WebElement flatCode2;

	@FindBy(xpath = "//*[@id=\"ta-flatCode-3\"]")
	public WebElement flatCode3;

	@FindBy(xpath = "//*[@id=\"ta-flatCode-4\"]")
	public WebElement flatCode4;
	@FindBy(xpath = "//*[@id=\"ta-flatCode-5\"]")
	public WebElement flatCode5;
	@FindBy(xpath = "//*[@id=\"ta-flatCode-6\"]")
	public WebElement flatCode6;
	@FindBy(xpath = "//*[@id=\"ta-flatCode-7\"]")
	public WebElement flatCode7;

	@FindBy(xpath = "//*[@id=\"ta-flatCode-8\"]")
	public WebElement flatCode8;
	@FindBy(xpath = "//*[@id=\"ta-flatCode-9\"]")
	public WebElement flatCode9;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[3]/div[1]/div/div/span")
	public WebElement itemizedLabel;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/label")
	public WebElement allwTypeLabel;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[3]/div[2]/div[2]/div/label")
	public WebElement perf1Label;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[1]/div[2]/div[2]/div[3]/div[2]/div[3]/div/label")
	public WebElement perf2Label;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-0\"]")
	public WebElement allwType0;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-1\"]")
	public WebElement allwType1;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-2\"]")
	public WebElement allwType2;

	@FindBy(xpath = "//*[@id=\"ta-allowanceType-3\"]")
	public WebElement allwType3;

	@FindBy(xpath = "//*[@id=\"allowanceType\"]/div/div/div[2]/input")
	public WebElement allwTypeBox;

	@FindBy(xpath = "//*[@id=\"allowanceType\"]/div/div/div[3]/input")
	public WebElement allwTypeBoxAfterSel;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[2]/input")
	public WebElement perf1Box;

	@FindBy(xpath = "//*[@id=\"performanceCode1\"]/div/div/div[3]/input")
	public WebElement perf1BoxAfterSel;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-0\"]")
	public WebElement p1AlwT0;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-1\"]")
	public WebElement p1AlwT1;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-2\"]")
	public WebElement p1AlwT2;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode1-3\"]")
	public WebElement p1AlwT3;

	@FindBy(xpath = "//*[@id=\"performanceCode2\"]")
       public WebElement perf2Box1;

	
	
	@FindBy(xpath ="//*[@id=\"performanceCode2\"]/div/div/div[2]/input")
	//@FindBy(xpath = "//*[@id=\"performanceCode2\"]")
	public WebElement perf2Box;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-0\"]")
	public WebElement p2AlwT0;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-1\"]")
	public WebElement p2AlwT1;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-2\"]")
	public WebElement p2AlwT2;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-3\"]")
	public WebElement p2AlwT3;

	@FindBy(xpath = "//*[@id=\"ta-performanceCode2-4\"]")
	public WebElement p2AlwT4;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[2]/div/div/div[1]/plain-button/button")
	public WebElement retClear;

	@FindBy(xpath ="/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button/span/i-feather")
	//@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/div/button")
	public WebElement retClose;
	/**
	 * 
	 * 
	 * @author ssubr13
	 *
	 */
	@FindBy(xpath = "//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/div[1]/button/span")
	public WebElement createbilling;

	@FindBy(xpath = "//*[@id=\"billingRecordType\"]/span[1]")
	public WebElement BilltypeClick;

	@FindBy(xpath = "//*[@id='billingRecordType']/div/span")
	// @FindBy(xpath = "//*[@id=\'billingRecordType\']/div/span")
	public WebElement Brtypeclick;

	// *[@id="ta-billingRecordType-2"]
	@FindBy(xpath = "//*[@id=\'ta-billingRecordType-2\']")
	public WebElement Brtypeslct;

	@FindBy(xpath = "//*[@id=\'accountLookupType\']")
	public WebElement Altclk;

	@FindBy(xpath = "//*[@id=\'ta-accountLookupType-0\']")
	public WebElement Altone;

	@FindBy(xpath = "//*[@id=\'accountLookupValue\']/div/span")
	public WebElement Alnclk;

	@FindBy(xpath = "//*[@id=\'ta-accountLookupValue-3\']")
	public WebElement Alttwo;

	@FindBy(xpath = "/html/body/ngb-modal-window/div/div/cabs-create-br/cabs-modal/form/div[2]/div/div/div/action-button/button")
	public WebElement Btsubmit;

	@FindBy(xpath = "//*[@id=\'maincontainer\']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/action-button/button")
	public WebElement Savebtn;

	@FindBy(xpath = "//*[@id=\'maincontainer\']/div[2]/div[2]/br-details/div/cabs-header/div/form/cabs-action-bar/div/div/div/plain-button/button")
	public WebElement Cancelbtn;
	
	@FindBy(xpath="/html/body/ngb-modal-window/div/div/cabs-confirm-dialog/div[3]/primary-button/button")
	public WebElement warningYes;
	
	@FindBy(xpath="//*[@id='search']/li/a")
	public WebElement searchBtn;
	
	//newly added xpaths
	@FindBy(xpath="//*[@id='amountId0']/input")
	public WebElement firstIncAmount;
	
	@FindBy(xpath="//*[@id='amountId1']/input")
	public WebElement secondIncAmount;
	
	@FindBy(xpath="//*[@id='incomeCollapse']/div/div/div[3]/div[1]/div[3]/div/input")
	public WebElement sum;
	
	@FindBy(xpath = "//*[@id='assignToPanel']/div/div/div[2]/input")
	public WebElement assignTodrpSearch;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[1]/form/div[2]/div[2]/action-button/button")
	public WebElement searchApply;
	
	@FindBy(xpath = "//*[@id='maincontainer']/div[2]/div[2]/cabs-search-br/div/div/div[2]/div[2]/cabs-worklist-table/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span")
	public WebElement searchFirstItem;
	
	@FindBy(xpath="//*[@id=\"performanceCode1\"]/div/div/div[2]/span[2]")
   	 public WebElement perf1A;

	public GenericFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	/**
	 * 
	 * 
	 * @author akuma58
	 *
	 */
	public String getHomePageName() {
		return homepage_name.getText();
	}
	
	public String waitForSpinnerToBeGone() {

		By loadingImage = By
				.xpath("//*[@id=\"maincontainer\"]/cabs-spinner/ngx-spinner");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	
	public String sumTxt() {
		//return sum.getText();
		return sum.getAttribute("value");
	}

	public String createBilRcrd() {
		return createBillrcrd.getText();
	}

	public String upLoadBtn() {
		return upload_btn.getText();
	}

	public String srchBillingrcrd() {
		return Search_billing_rcrd.getText();
	}

	public String analysisWrklst() {
		return analysis_wrklist.getText();
	}
	
	public String analysisWrklstt(WebDriver Driver) {
		  analysis_wrklist.click();
		  return null;
	}
	

	public String incmeWrklist() {
		return incme_wrklist.getText();
	}

	public String ovrTolrnceWrklst() {
		return ovr_tolerance_wrklist.getText();
	}

	public String dialogWrklst() {
		return dialog_wrklist.getText();
	}

	public String paybckWrklst() {
		return paybck_wrklist.getText();
	}

	public String submitText() {
		return submit_Btn.getText();
	}

	public String incomeTxt() {
		return income_Txt.getText();
	}

	public String searchBill() {
		return search_Bill.getText();
	}

	@Test
	public String submitClick() {
		submit_Btn.click();
		return null;
	}

	public String hamBurg() {
		hamBurger.click();
		return null;
	}

	public String creatBillng() {
		createBillrcrd.click();
		return null;

	}

	public String blngrcrdDrp() {
		bRType.click();
		return null;
	}

	public String nonAllwdrp() {
		nonAllwTyp.click();
		return null;
	}

	public String submitClk() {
		creatBrSbmt.click();
		return null;
	}

	public String newBracnclk() {
		newBracntlukup.click();
		return null;
	}

	public String newRetclk() {
		accntRet.click();
		return null;
	}

	public String newRettxt() {
		return accntRet.getText();
	}

	public String newRetval() {
		accntRetval.click();
		return null;
	}
	
	public String newRetval2() {
		accntRetval2.click();
		return null;
	}
	

	public String newRetval1() {
		accntRetval1.click();
		return null;
	}

	public String newRetvalTxt() {
		return accntRetval.getText();
	}

	public String newRetvalTxt2() {
		return accntRetval2.getText();
	}

	// public String deduct(){
	// deductnum.sendKeys("1");
	// return null;
	// }

	public String offsetnumfi() {
		offSetnum5.sendKeys("123");
		return null;
	}

	public String elmntIntract() {
		deductnum.findElement(By.className("form-control")).sendKeys("510");
		return null;
	}

	public String deltinteract() {
		//deleteBtn.findElement(By.className("blackfeather")).click();
		deleteBtn.click();
		return null;
	}

	public String blngname() {
		blngNam.click();
		return null;
	}

	public String blngnamevalu() {
		blngNamval.click();
		return null;
	}

	public String txtAreaa() {
		// txtArea.sendKeys("Test Automation");
		txtDescr.sendKeys("Test Automation");
		return null;
	}

	public String txtComnt() {
		// txtArea.findElement(By.className("form-control")).sendKeys("Test Automation Comment");
		txtArea.findElement(
				By.cssSelector(".form-control.solid-border.multiple-lines.ng-pristine.ng-valid.ng-touched"))
				.sendKeys("Test Automation Comment");

		return null;
	}

	public String txtDee() {
		txtDescr.sendKeys("Test Automation - Description");
		return null;
	}

	public String amntsend() {
		amnt.findElement(By.className("form-control")).sendKeys("100");
		return null;
	}

	public String newBRSave() {
		newBRSav.click();
		return null;
	}

	public String accntretNeww() {
		accntRetnew.click();
		return null;
	}

	public String incmbtnclk() {
		incombtn.click();
		return null;
	}

	public String AddRow() {
		AddRowbTN.click();
		return null;
	}

	public String billLab() {
		return billLbl.getText();
	}

	public String accruLab() {
		return acrueLbl.getText();
	}

	public String billndAcclab() {
		return blAcrLbl.getText();
	}

	public String logOut() {
		return log_Out.getText();
	}

	public String delete() {
		deleteBtn.click();
		return null;
	}

	@Test
	public String prox() {
		return proxy.getText();
	}

	@Test
	public String prox_click() {
		proxy.click();
		return null;
	}

	@Test
	public String buttonClick() {
		createBillbtn.click();
		return null;
	}

	public String smartDrp() {

		// smart_Drp.sendKeys("David");
		smart_drop_down.sendKeys("Ajith");
		return null;
	}

	public String wait_forelement() {
		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(homepage_name)).getText();
		return null;
	}

	public String wait_forelement2() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(submit_Btn)).getText();
		return null;
	}

	public String wait_forelement3() {
		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(log_Out)).isEnabled();
		return null;
	}

	public String wait_forprox() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(proxy)).getText();
		return null;
	}

	public String firstVal() {
		return drpFirst.getText();
	}

	public String blngRcrdTxt() {
		return blngRcrdDrpdown.getText();
	}

	public String AcntlukText() {
		return AcntlukTxt.getText();
	}

	public String wait_createBRbtn() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.visibilityOf(subMitBtn)).isEnabled();
		return null;
	}

	public boolean acntLukupTypVal() throws InterruptedException, AWTException {

		AcntlukDrp.click();
		Thread.sleep(7000);

		if (AcntlukRet.getText().equals("Retail Div")) {
			Thread.sleep(2000);
			if (AcntlukCog.getText().equals("COGS Facilities")) {

				return true;
			}
			return false;

		}
		return false;
	}

	public String deptTextCapt() {

		return deptTxt.getText();
	}

	public String deptDrpdownTxt() {

		return deptDrpDwnFirst.getText();
	}

	public String deptDrpdownbtn() {

		teamDrp.click();
		return null;
	}

	public String deptDrpdownvalclk() {

		return deptDrpdwnval1.getText();

	}

	public String deptDrpdownvalclk2() {

		return deptDrpdwnval2.getText();

	}

	public String brgetxt() {

		return BRtxt.getText();
	}

	public String brsaveBtnn() {

		brSaveBtn.click();
		return null;
	}

	public String brStatuclk() {

		brStatus.click();
		return null;
	}

	public String brStatustxt() {

		return rdyforinc.getText();
	}

	public String blngRcrdidLab() {

		return blngRcrdidLabel.getText();
	}

	public String blngRcrdidclk() {

		blngRcrdidLabel.click();
		return null;
	}

	public String lastDatLabelTx() {

		return lastDatLabel.getText();
	}

	public String retailalw() {

		retailAllwTyp.click();
		return null;
	}

	public String closclk() {

		closeBtn.click();
		return null;
	}

	public String assignToo() {

		return assignTo.getText();
	}
	public String assignToow() {

		return assignTow.getText();
	}
	
	public String newBRErrmsge() {

		return newBRErrmsg.getText();
	}

	public String invalidOfseterro() {

		return invalidOfseterr.getText();
	}

	public String asignToo() {

		return asignTo.getText();
	}

	public String assignTodrpclk() {

		assignTodrp.click();
		return null;
	}

	public String brStatusdrpclk() {

		brStatusdrp.click();
		return null;
	}

	
	public String blngRcrdidd() {

	//	return blngRcrdid.getText();		
	//	return blngRcrdid.getAttribute("value");		
		WebElement elem = blngRcrdid.findElement(By.className("form-control"));		
		return	elem.getAttribute("value");	
		//return blngRcrdid.getAttribute("value");
	}

	/**
	 * 
	 * 
	 * @author jmaya09
	 *
	 */
	public String smart_dropdown(String val) throws InterruptedException {
		Thread.sleep(55000);
		smart_drop_down.click();
		smart_drop_down.sendKeys(val, Keys.ENTER);

		System.out.println("Value is: " + smart_drop_down_val.getText());

		// return smart_drop_down_val.getAttribute("value");
		return smart_drop_down_val.getText();
	}

	public boolean dropDownListSortedOrNot(String val)
			throws InterruptedException {

		smart_drop_down1.sendKeys(val);

		List<WebElement> dropDownvalues = smart_drop_down_val.findElements(By
				.className("ng-dropdown-panel"));

		ArrayList<String> listValues = new ArrayList<String>();
		for (WebElement value : dropDownvalues) {

			listValues.add(value.getText());

		}

		ArrayList<String> SortlistValues = new ArrayList<String>();
		for (String s : listValues) {

			SortlistValues.add(s);

		}

		Collections.sort(SortlistValues);

		System.out.println("Values obtained from UI are " + listValues);
		System.out.println("After Sorting the values obtained are "
				+ SortlistValues);

		if (SortlistValues.equals(listValues)) {
			return true;
		} else {
			return false;
		}

	}

	public boolean DropDwn_Refresh(String val) throws InterruptedException {
		smart_drop_down1.clear();
		// smart_drop_down.click();
		smart_drop_down1.sendKeys(val);
		System.out.println("Before Refresh, value is "
				+ smart_drop_down_val.getText());
		Driver.navigate().refresh();
		Thread.sleep(55000);
		System.out.println("After Refresh, value is "
				+ smart_drop_down_val.getText());

		if (smart_drop_down_val.getText() == val) {
			return false;
		} else {
			return true;
		}

	}

	public boolean DropDwn_Clear(String val) throws InterruptedException {
		
		waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		smart_drop_down.click();
		Thread.sleep(3000);
		smart_drop_down.sendKeys(val);

		List<WebElement> dropDownvalues = smart_drop_down_val.findElements(By
				.className("ng-dropdown-panel"));

		ArrayList<String> listValues = new ArrayList<String>();
		for (WebElement value : dropDownvalues) {
			listValues.add(value.getText());
		}

		System.out.println("Filtered value is" + listValues);

		home_bread.click();
		// Thread.sleep(2500);

		smart_drop_down.click();

		List<WebElement> dropDownvalues_clear = smart_drop_down_val
				.findElements(By.className("ng-dropdown-panel"));

		ArrayList<String> listValuesClear = new ArrayList<String>();
		for (WebElement value : dropDownvalues_clear) {
			listValuesClear.add(value.getText());
		}

		System.out.println("Drop Down value after clear is" + listValuesClear);

		if (listValues.equals(listValuesClear)) {
			return false;
		} else {
			return true;
		}

	}

	// public boolean DropDwn_Scroll() throws InterruptedException {
	// // smart_drop_down.clear();
	// smart_drop_down.click();
	//
	// //WebElement element =
	// Driver.findElement(By.xpath("//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/cabs-selector/div/div/div[2]/button[8]"));
	//
	// // WebElement element = Driver.findElement(By.xpath(
	// //
	// "//*[@id=\"maincontainer\"]/div[2]/div[1]/cabs-sidebar/div/div[3]/cabs-selector/div/div/div[2]/button[8]"));
	//
	// //WebElement element =
	// Driver.findElement(By.xpath("//*[@id=\"a19871150377-4\"]/div"));
	//
	// List<WebElement> dropDownvalues =
	// smart_drop_down_val.findElements(By.className("ng-dropdown-panel"));
	//
	// //ArrayList<String> listValues = new ArrayList<String>();
	// int i=0;
	// WebElement element = null;
	// for (WebElement value : dropDownvalues) {
	// System.out.println(value.getText());
	// if(i==7) {
	// element = Driver.findElement(By.linkText(value.getText()));
	// System.out.println(element);
	// Actions actions = new Actions(Driver);
	// actions.moveToElement(element);
	// actions.perform();
	// }
	// i++;
	// }
	//
	//
	// // if (element.isEnabled()) {
	// //
	// // return true;
	// // } else {
	// //
	// // return false;
	// // }
	// return false;
	// }

	public boolean DropDwn_Scroll_Filter(String val)
			throws InterruptedException {

		smart_drop_down.sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN,
				Keys.ARROW_DOWN, Keys.ENTER);
		
		waitForSpinnerToBeGone();
		Thread.sleep(2500);
		
		smart_drop_down_val.click();

		if (smart_drop_down1.getText().isEmpty()) {

			return true;
		} else {

			return false;
		}
	}

	public boolean DropDwn_Key() throws InterruptedException {

		// smart_drop_down.clear();
		smart_drop_down1.sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);

		if (smart_drop_down_val.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public boolean DropDwn_CopyPaste() throws InterruptedException {

		waitForSpinnerToBeGone();
		Thread.sleep(2500);
		//Thread.sleep(15000);
		// smart_drop_down_val.clear();
		smart_drop_down_val.click();
		Thread.sleep(3000);
		smart_drop_down1.sendKeys("Ajith");

		Actions act = new Actions(Driver);
		// Home copy paste
		// act.moveToElement(smart_drp_copy).doubleClick().sendKeys(Keys.chord(Keys.CONTROL,"c")).build().perform();

		// David Copy paste
		act.moveToElement(smart_drop_down1).doubleClick()
				.sendKeys(Keys.chord(Keys.CONTROL, "c")).build().perform();
		home_bread.click();

		smart_drop_down1.sendKeys(Keys.chord(Keys.CONTROL, "v"));

		if (smart_drop_down_val.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}

	}
	
	
	public String waitForBrPopup() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(bRPopup));
		return null;
	}

	public boolean createBRModalPopUp() throws InterruptedException,
			AWTException {

		createBillrcrd.click();

		waitForBrPopup();
		Thread.sleep(3000);

		if (bRPopup.getText().equals("CREATE BR")) {

			bRType.click();
			Thread.sleep(3000);

			if (retailAllwTyp.getText().equals("Retail Allowance")) {
				if (cogsAllwTyp.getText().equals("COGS Allowance")) {
					if (nonAllwTyp.getText().equals("Non Allowance")) {
						return true;
					}
				}

			}
			return false;

		}
		return false;
	}

	public boolean bRTypeRetailSel() throws InterruptedException {

		retailAllwTyp.click();

		if (bRType.getText().contains("Retail Allowance")) {
			return true;
		} else {
			return false;
		}
	}

	public String bRTypeRetailAccType() throws InterruptedException {
		RetClear();
		return accLkpType.getText();
	}

	public String bRTypeRetailOffno() {
		return offrnoLabel.getText();
	}

	public String bRTypeRetailleadCIC() {
		return leadCIC.getText();
	}

	public String bRTypeRetaildateFrom() {
		return dateFrom.getText();
	}

	public String bRTypeRetaildateTo() {
		return dateTo.getText();
	}

	public boolean bRTypeRetailFieldAccType() {

		if (accLkUpType.getText().equals("Retail Div")) {

			return true;

		}
		return false;
	}

	public boolean bRTypeRetailFieldAccValue() throws InterruptedException {

		accLkUpVal.click();
		Thread.sleep(2000);
		selAccLkUpVal.click();

		if (accLkUpVal.getText().isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public boolean bRTypeRetailFieldOffNo() {

		// offnum = offrno.findElement(By.className("form-control"));

		offrno.click();
		offrno.sendKeys("1234");
		// offnum.click();
		// offnum.sendKeys("1234");

		if (offrno.getAttribute("value").equals("1234")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean bRTypeRetailFieldLeadCIC() throws BiffException, IOException {
		LCIC = leadCIC.findElement(By.className("form-control"));
        LCIC.click();
        String file = new File(System.getProperty("user.dir"),"TestData.xls").getAbsolutePath();
//      FileInputStream fi = new
//                   FileInputStream("D:\\U82703\\Eclipse_Selenium\\SC-Web-CABSAutomation\\TestData.xls");
        
        FileInputStream fi = new FileInputStream(file);
                     
                      Workbook w = Workbook.getWorkbook(fi);
                            Sheet s = w.getSheet(1);
                            String s1 = null;
                            try {
                            for (int i = 2; i < s.getRows(); i++) {
                            // Read data from excel sheet
                            s1 = s.getCell(3, i).getContents();
                            
                            Thread.sleep(3000);
                            
                             LCIC.sendKeys(s1);
                                                             
                             
                            
        if (LCIC.getAttribute("value").equals(s1)) {
               return true;
        } else {
               return false;
        }
                            } } catch (Exception e) {
                                  System.out.println(e);
                                  }
                            return false;

	}

	public boolean bRTypeRetailFieldStartDt() throws ParseException {

		fromCal.click();

		fromCalopen.click();

		if (billDateFrom.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailFieldEndDt() {

		toCal.click();
		toCalOpen.click();

		if (billDateTo.getAttribute("value").isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public boolean bRTypeRetailMand() throws InterruptedException {
		
        waitForSpinnerToBeGone();
		Thread.sleep(3000);
		brSubmit.click();
		Thread.sleep(2000);
		System.out.println(brError.getText());
		if (brError
				.getText()
				.contains(
						"Following fields is/are not valid  : Account Lookup Value,Lead CIC,Bill Date From,Bill Date To")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean bRTypeRetailAnyMandAccVal() throws ParseException,
			InterruptedException, BiffException, IOException {

		if (RetClear() == true) {

			if (bRTypeRetailFieldOffNo() == true
					&& bRTypeRetailFieldLeadCIC() == true
					&& bRTypeRetailFieldStartDt() == true
					&& bRTypeRetailFieldEndDt() == true
					&& headerFlatAmtGrtZero() == true
					&& itemAlwType().equals("Allowance Type")
					&& allwtype() == true && allwTP1P2() == true) {

				// accLkUpVal.clear();
				brSubmit.click();
				brSubmit.click();
				Thread.sleep(1000);
				if (brError
						.getText()
						.contentEquals(
								"Following fields is/are not valid  : Account Lookup Value ")) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
		System.out.println("All fields are not clear initially");
		return false;
	}

	public boolean bRTypeRetailAnyMandLeadCIC() throws InterruptedException,
			ParseException {

		if (RetClear() == true) {

			if (bRTypeRetailFieldOffNo() == true
					&& bRTypeRetailFieldAccValue() == true
					&& bRTypeRetailFieldStartDt() == true
					&& bRTypeRetailFieldEndDt() == true
					&& headerFlatAmtGrtZero() == true
					&& itemAlwType().equals("Allowance Type")
					&& allwtype() == true && allwTP1P2() == true) {
				// WebElement LCIC =
				// leadCIC.findElement(By.className("form-control"));
				// LCIC.clear();
				brSubmit.click();
				Thread.sleep(1000);
				if (brError.getText().contentEquals(
						"Following fields is/are not valid  : Lead CIC ")) {
					return true;
				} else {
					return false;
				}
			}
			return false;

		}
		System.out.println("All fields are not clear initially");
		return false;
	}

	public boolean bRTypeRetailAnyMandStDate() throws InterruptedException,
			BiffException, IOException {

		if (RetClear() == true) {
			if (bRTypeRetailFieldOffNo() == true
					&& bRTypeRetailFieldAccValue() == true
					&& bRTypeRetailFieldLeadCIC() == true
					&& bRTypeRetailFieldEndDt() == true
					&& headerFlatAmtGrtZero() == true
					&& itemAlwType().equals("Allowance Type")
					&& allwtype() == true && allwTP1P2() == true) {
				// billDateFrom.clear();
				brSubmit.click();
				Thread.sleep(1000);
				if (brError.getText().contentEquals(
						"Following fields is/are not valid  : Bill Date From ")) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
		System.out.println("All fields are not clear initially");
		return false;
	}

	public boolean bRTypeRetailAnyMandEndDate() throws InterruptedException,
			ParseException, BiffException, IOException {

		if (RetClear() == true) {

			if (bRTypeRetailFieldOffNo() == true
					&& bRTypeRetailFieldAccValue() == true
					&& bRTypeRetailFieldLeadCIC() == true
					&& bRTypeRetailFieldStartDt() == true
					&& headerFlatAmtGrtZero() == true
					&& itemAlwType().equals("Allowance Type")
					&& allwtype() == true && allwTP1P2() == true) {
				// billDateTo.clear();
				brSubmit.click();
				Thread.sleep(1000);
				if (brError.getText().contentEquals(
						"Following fields is/are not valid  : Bill Date To ")) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
		System.out.println("All fields are not clear initially");
		return false;
	}

	public boolean bRTypeRetailAnyMandFlatCode() throws InterruptedException,
			ParseException, BiffException, IOException {
		if (RetClear() == true) {

			if (bRTypeRetailFieldOffNo() == true
					&& bRTypeRetailFieldAccValue() == true
					&& bRTypeRetailFieldLeadCIC() == true
					&& bRTypeRetailFieldStartDt() == true
					&& bRTypeRetailFieldEndDt() == true
					&& headerFlatAmtGrtZero() == true && allwtype() == true
					&& allwTP1P2() == true) {
				// flatCodeBox.clear();
				brSubmit.click();
				Thread.sleep(1000);
				if (brError.getText().contentEquals(
						"All required fields have to be filled  : Flat Code")) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
		System.out.println("All fields are not clear initially");
		return false;
	}

	public boolean bRTypeRetailAnyMandPerf1() throws InterruptedException,
			ParseException, BiffException, IOException {
		if (RetClear() == true) {

			if (bRTypeRetailFieldOffNo() == true
					&& bRTypeRetailFieldAccValue() == true
					&& bRTypeRetailFieldLeadCIC() == true
					&& bRTypeRetailFieldStartDt() == true
					&& bRTypeRetailFieldEndDt() == true
					&& headerFlatAmtGrtZero() == true
					&& itemAlwType().equals("Allowance Type")
					&& allwtype() == true) {
				// perf1Box.clear();
				allwType0.click();
				Thread.sleep(4500);
				brSubmit.click();
				Thread.sleep(4500);
				if (brError
						.getText()
						.contentEquals(
								"All required fields have to be filled  : Performance 1")) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
		System.out.println("All fields are not clear initially");
		return false;
	}

	public String headerFlat() {

		if (headerLabel.getText().equals("HEADER")) {

			return flatAmtLabel.getText();
		} else {
			return null;
		}
	}

	public String headerFlatCode() {
		if (headerLabel.getText().equals("HEADER")) {
			return flatCodeLabel.getText();
		} else {
			return null;
		}
	}

	public boolean headerFlatAmtGrtZero() throws InterruptedException {
		// WebElement amtTxtBox =
		// flatAmtLabel.findElement(By.className("input-group"));
		// WebElement amtTxtBox1 =
		// amtTxtBox.findElement(By.className("form-control"));
		amtTxtBox1.clear();
		amtTxtBox1.sendKeys("1");
		Thread.sleep(3000);
		flatCodeBox.click();
		Thread.sleep(2500);

		if (flatCode0.getText().equals("03")
				&& flatCode1.getText().equals("08")
				&& flatCode2.getText().equals("20")
				&& flatCode3.getText().equals("30")
				&& flatCode4.getText().equals("32")
				&& flatCode5.getText().equals("52")
				&& flatCode6.getText().equals("77")
				&& flatCode7.getText().equals("88")
				&& flatCode8.getText().equals("92")
				&& flatCode9.getText().equals("99")) {
			return true;
		} else {
			return false;
		}
	}

	public String itemAlwType() throws InterruptedException {

		flatCode1.click();

		if (itemizedLabel.getText().equals("ITEMIZED")) {

			return allwTypeLabel.getText();
		}
		return null;

	}

	public String itemPerf1() throws InterruptedException {

		if (itemizedLabel.getText().equals("ITEMIZED")) {

			return perf1Label.getText();
		}
		return null;

	}

	public String itemPerf2() throws InterruptedException {

		if (itemizedLabel.getText().equals("ITEMIZED")) {

			return perf2Label.getText();
		}
		return null;

	}

	public Boolean allwtype() throws InterruptedException {

		allwTypeBox.click();

		if (allwType0.getText().equals("T") && allwType1.getText().equals("S")
				&& allwType2.getText().equals("C")
				&& allwType3.getText().equals("A")) {
			return true;
		} else {
			return false;
		}

	}

	public Boolean allwTP1P2() throws InterruptedException {

        allwType0.click();
        Thread.sleep(7000);
        perf1Box.click();

        if (p1AlwT0.getText().equals("05") && p1AlwT1.getText().equals("20")
                     && p1AlwT2.getText().equals("30")
                     && p1AlwT3.getText().equals("38")) {
               p1AlwT0.click();
               Thread.sleep(3000);
               perf2Box.click();
               if (p2AlwT0.getText().equals("01")
                            && p2AlwT1.getText().equals("88")) {

                     perf1BoxAfterSel.click();
                     p1AlwT1.click();
                     Thread.sleep(3000);
                     perf2Box.click();

                     if (p2AlwT0.getText().equals("52")
                                  && p2AlwT1.getText().equals("75")
                                  && p2AlwT2.getText().equals("77")) {
                            perf1BoxAfterSel.click();
                            p1AlwT2.click();
                            Thread.sleep(2000);
                            perf2Box.click();
//                          WebElement element = perf2Box.findElement(By
//                                       .className("ng-dropdown-panel"));

        //                  if (element.getText().equals("No items found")) {

                            if (p2AlwT0.getText().equals("01")
                                         && p2AlwT1.getText().equals("88")) {
                                  
                                  perf1BoxAfterSel.click();
                                  p1AlwT3.click();
                                  Thread.sleep(3000);
                                  perf2Box.click();
                                  if (p2AlwT0.getText().equals("88")) {
                                         return true;
                                  }
                            }
                     }
               }
        }
        return false;

	}

	public Boolean allwSP1P2() throws InterruptedException {

		allwTypeBoxAfterSel.click();
		allwType1.click();
		Thread.sleep(4000);
		perf1Box.click();

		if (p1AlwT0.getText().equals("06") && p1AlwT1.getText().equals("30")) {
			p1AlwT0.click();
			Thread.sleep(2000);
			perf2Box.click();
			if (p2AlwT0.getText().equals("01")
					&& p2AlwT1.getText().equals("88")) {

				perf1BoxAfterSel.click();
				p1AlwT1.click();
				Thread.sleep(2000);
				perf2Box.click();

				if (p2AlwT0.getText().equals("01")
						&& p2AlwT1.getText().equals("88")) {
					return true;
				}

			}
		}
		return false;
	}

	public Boolean allwAP1P2() throws InterruptedException {

		allwTypeBoxAfterSel.click();
		allwType3.click();
		Thread.sleep(4000);
	//	perf1Box.click();

        if (perf1A.getText().equals("A")) {
			//p1AlwT0.click();
			Thread.sleep(2000);
			perf2Box.click();
			if (p2AlwT0.getText().equals("04")
					&& p2AlwT1.getText().equals("08")
					&& p2AlwT2.getText().equals("88")
					&& p2AlwT3.getText().equals("96")
					&& p2AlwT4.getText().equals("99")) {

				return true;
			}

		}
		return false;
	}

	public Boolean allwCP1P2() throws InterruptedException {

		allwTypeBoxAfterSel.click();
		allwType2.click();
		Thread.sleep(4000);
		//perf1Box.click();

		// OLD
		// if (p1AlwT0.getText().equals("01") && p1AlwT1.getText().equals("48")
		// && p1AlwT2.getText().equals("51")) {
		// p1AlwT0.click();
		// Thread.sleep(2000);
		// perf2Box.click();
		// if (p2AlwT0.getText().equals("01")) {
		//
		// perf1BoxAfterSel.click();
		// p1AlwT2.click();
		// Thread.sleep(2000);
		// perf2Box.click();
		//
		// WebElement element = perf2Box.findElement(By
		// .className("ng-dropdown-panel"));
		//
		// if (element.getText().equals("No items found")) {
		// perf1BoxAfterSel.click();
		// p1AlwT1.click();
		// Thread.sleep(2000);
		// perf2Box.click();
		//
		// if (p2AlwT0.getText().equals("85")
		// && p2AlwT1.getText().equals("88")) {
		//
		// return true;
		// }
		//
		// }
		// }
		//
		// }
		// return false;

	//	if (p1AlwT0.getText().equals("51")) {
		if (perf1A.getText().equals("51")) {
		//	p1AlwT0.click();
			Thread.sleep(2000);
			perf2Box.click();

			WebElement element = perf2Box1.findElement(By
					.className("ng-dropdown-panel"));

			if (element.getText().equals("No items found")) {

				return true;
			} else {
				return false;

			}
		}

		return false;
	}

	public Boolean RetClear() throws InterruptedException {

		// p2AlwT0.click();
		retClear.click();

		WebElement amtTxtBox = flatAmtLabel.findElement(By
				.className("input-group"));
		WebElement amtTxtBox1 = amtTxtBox.findElement(By
				.className("form-control"));
		// WebElement offnum = offrno.findElement(By.className("form-control"));

		WebElement LCIC = leadCIC.findElement(By.className("form-control"));

		if (accLkUpVal.getText().equals("Select")
				&& offrno.getAttribute("value").isEmpty()
				&& LCIC.getAttribute("value").isEmpty()
				&& billDateFrom.getAttribute("value").isEmpty()
				&& billDateTo.getAttribute("value").isEmpty()
				&& amtTxtBox1.getText().isEmpty()
				&& allwTypeBox.getText().isEmpty()) {
			return true;
		}

		return false;
	}

	public Boolean RetClose() throws InterruptedException {

		retClose.click();
		if (home_bread.isDisplayed()) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * 
	 * @author ssubr13
	 *
	 */
	public String CreateClick() {

		createbilling.click();
		return null;
	}

	public String BillClick() {

		createbilling.click();
		return null;
	}

	public String BrTyp() {

		Brtypeclick.click();

		return null;
	}

	public String BrSel() {

		Brtypeslct.click();
		return null;
	}

	public String alt1() {

		Altclk.click();
		return null;
	}

	public String alt2() {

		Altone.click();
		return null;
	}

	public String alt3() {

		Alnclk.click();
		return null;
	}

	public String alt4() {

		Alttwo.click();
		return null;
	}

	public String Firstsub() {

		Btsubmit.click();
		return null;
	}

	public String Savebtntxt() {

		return Savebtn.getText();

	}

	public String Cancelbtntxt() {

		return Cancelbtn.getText();

	}

}
