package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS268 extends ExtendBaseClass {
	
	WebDriver Driver;
	String extentReportImage369_1;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	/**
	 * User Story: CABS-369
	 * 
	 * @author akuma58
	 *
	 */
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify the manually entered Invalid Offset number validation for Misc BR
	@Test(priority = 1, enabled = true)
	public void CABS832() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-832 Execution started");
		
	  PO.NonAlwnceBR();
	  PO.offsetnumErr();
	  PO3.offsetmanualInvalid(Driver);
	  
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-832 Execution Completed");
		
	}
	
	
	//Verify the manually entered valid Offset number validation for Misc BR
	@Test(priority = 2, enabled = true)
	public void CABS833() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-833 Execution started");
		
	  PO3.manualOfsetvalid(Driver);
	  
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-833 Execution Completed");
		
	}
	
	
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	  Driver =  PO.beforeTest();
		 PO3.beforeTest(Driver);
			extentTest = extent.startTest("Sprint 3 - CABS-268",
					"Billing Record header - Validate manually entered Offset # for misc BR  ");
			extentTest.log(LogStatus.INFO, "Browser successfully launched");
  }

 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
