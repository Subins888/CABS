package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS341 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	String BType;
	Integer Time;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// verify income history section.
	// Covers the test case 667 in user story 281 also.
	// @Test(priority=1, invocationCount = 5)
	@Test(priority = 1, enabled = true)
	public void CABS1437() throws Exception {
		BType = "BnA";
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1437 Execution started");
		PO.nonAlwnceNew();
		POV.brSavNonAlw(Driver);
		Time = 1;
		POJS6.brSbmtNonAlw(Driver, BType, Time);
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1437 Execution Completed");

	}

	// misc-Income History-verify fields in income history section for Bill and
	// Accrual income type
	@Test(priority = 2, enabled = true)
	public void CABS1436() throws Exception {
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1436 Execution started");
		POJS6.NonAlwFieldsVal(Driver);
		// POJS6.NonAlwCancelButtonVal(Driver);
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1436 Execution Completed");

	}

	// misc-Income History-verify fields in income history section for Bill
	// income type
	@Test(priority = 3, enabled = true)
	public void CABS1455() throws Exception {
		BType = "B";
		Time = 2;
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1455 Execution started");
		POJS6.brSbmtNonAlw(Driver, BType, Time);
		// POJS6.NonAlwCancelButtonVal(Driver);
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1455 Execution Completed");

	}

	// misc-Income History-verify fields in income history section for Accrual
	// income type
	@Test(priority = 4, enabled = true)
	public void CABS1471() throws Exception {
		BType = "A";
		Time = 3;
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1471 Execution started");
		POJS6.brSbmtNonAlw(Driver, BType, Time);
		// POJS6.NonAlwCancelButtonVal(Driver);
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1471 Execution Completed");

	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 6 - CABS-341",
				"Misc - Income history( Submit a income record )");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	}

}
