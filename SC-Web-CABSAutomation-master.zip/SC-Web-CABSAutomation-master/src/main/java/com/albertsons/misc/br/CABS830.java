package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS830 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

// Verify user with "Initiate Payback request" rights can see "Payback"
	// button next to the Bill type income in Income History Section, which is
	// in 'Sent to Vendor' status

	// TYPE 1: Non allowance > New BR check
	@Test(priority = 1, enabled = false)
	public void CABS1583() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1583 Execution started");

		PO.nonAlwnceNew();
		POV.brSavNonAlw(Driver);
		Thread.sleep(5000);
		POVII.miscIncmeBtnClk(Driver);
		POVII.otMiscIII(Driver);
		// POVII.miscHistoryPlus(Driver);
		POV.Search(Driver);
		POVII.waitforbrtxt(Driver);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(3000);
		// Following methods depends on 'Send to Vendor (payback)' status
		POVII.payback(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1583 Execution Completed");
	}

	// Verify user with "Initiate Payback request" rights can see "Payback"
	// button next to the Bill type income in Income History Section, which is
	// in 'Sent to Vendor' status

	// TYPE 2: SEARCH AND CHECK
	// CABS-1588 also handled here
	@Test(priority = 1, enabled = false)
	public void CABS1583_2() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1583 Execution started");
		// write search code once implemented

		// GET TEST DATA FROM EXCEL

		// write search code once implemented
		// POV.Search(Driver);
		POVII.waitforbrtxt(Driver);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(3000);
		// Following methods depends on 'Send to Vendor (payback)' status
		POVII.paybackValidation(Driver);
		POVII.payback(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1583 Execution Completed");
	}

	// Verify Payback modal popup
	@Test(priority = 1, enabled = true)
	public void CABS1584() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1584 Execution started");

		POV.Search(Driver);

		POVII.waitforHistory(Driver);
		Thread.sleep(3000);
		// POVII.AddIncmMisc(Driver);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(3000);
		// Following methods depends on 'Send to Vendor (payback)' status
		POVII.paybackValidation(Driver);

		// POVII.payback(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1584 Execution Completed");
	}

	// Verify Payback Approver in the payback modal pop up
	@Test(priority = 2, enabled = true)
	public void CABS1585() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1585 Execution started");
	
		POVII.dropDownListSortedOrNot(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1585 Execution Completed");
	}

	// Verify Reasons in the payback modal pop up

	@Test(priority = 3, enabled = true)
	public void CABS1586() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1586 Execution started");
	

		POVII.reasonCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1586 Execution Completed");
	}

	// Verify Responsible users in the payback modal pop up
	@Test(priority = 4, enabled = true)
	public void CABS1587() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1587 Execution started");
	

		POVII.UserCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1587 Execution Completed");
	}

	// Verify 'X' on the payback modal should leave the income record as is
	@Test(priority = 4, enabled = false)
	public void CABS1589() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1589 Execution started");
		

		POVII.close(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1589 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 7 - CABS-830",
				"Payback - Initiate payback");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
