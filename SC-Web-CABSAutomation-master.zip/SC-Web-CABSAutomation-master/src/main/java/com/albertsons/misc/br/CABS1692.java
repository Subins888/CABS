package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSJVII;
import com.albertsons.pageobjects.PageObjectsSJVIII;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1692 extends ExtendBaseClass{
              WebDriver Driver;
              PageObjects PO = new PageObjects(Driver);
              PageObjectsIV POIV = new PageObjectsIV(Driver);
              PageObjectsV POV = new PageObjectsV(Driver);
              GenericFactory pageFact = new GenericFactory(Driver);
              GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
              PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
              PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
              PageObjectsSJVII POJS7 = new PageObjectsSJVII(Driver);
              PageObjectsSJVIII POJS8 = new PageObjectsSJVIII(Driver);
              ITestResult result;
              String BType;
              Integer Time;
              @Test(priority = 0, enabled = true)
              public void ABS_Login() throws Exception {

                             PO.waitforelement();
                             PO.Login();
              }
              
              //Verify all incomes in Income History section is sorted by submitted date & time in descending order
              @Test(priority = 1, enabled = true)
              public void CABS1865() throws Exception{

                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-1865 Execution started");
                             PO.nonAlwnceNew();
                             POV.brSavNonAlw(Driver);                        
                             POJS8.waitforAddIncome(Driver);
                             Thread.sleep(8000);
                             BType="B";
                             Time=1;
                             POJS6.brSbmtNonAlw(Driver,BType,Time);//Submit Bill Income
                             Thread.sleep(2000);       
                             BType="B";
                             Time=2;
                             POJS6.brSbmtNonAlw(Driver,BType,Time);//Submit Bill Income
                             Thread.sleep(2000);
                             BType="B";
                             Time=3;
                             POJS6.brSbmtNonAlw(Driver,BType,Time);//Submit Bill Income
                             Thread.sleep(2000);
                             System.out.println("Bill Income submitted three times.Now validating the Income sorting order");
                             extentTest.log(LogStatus.INFO,
                                                          "Bill Income submitted three times.Now validating the Income sorting order");
                             POJS8.SortIncomeVal(Driver);
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-1865 Execution Completed");

              }
              
              
              //Verify If Bill & Accrue type of income is submitted at same time, 
              //the accrual record must be shown on top, in the income history section
              @Test(priority = 2, enabled = true)
              public void CABS1866() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-1866 Execution started");
                             
                             POJS8.SearchBRClick(Driver);
                             POJS8.wait_forBlngbtn(Driver);
                             PO.nonAlwnceNew();
                             POV.brSavNonAlw(Driver);                        
                             //POJS8.waitforAddIncome(Driver);
                             Thread.sleep(3000);
                             BType="BnA";
                             Time=1;                                           
                             POJS6.brSbmtNonAlw(Driver,BType,Time);
                             POJS8.BillnAccrueVal(Driver);
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-1866 Execution Completed");

              }
              //Verify If Payback is associated with a bill income, it is shown below the bill income in the income history section
              @Test(priority = 3, enabled = true)
              public void CABS1867() throws Exception{           
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-1867 Execution started");
                             POJS8.SearchBRClick(Driver);
                             POJS8.EnterBRValue(Driver);

                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-1867 Execution Completed");

              }
             
  @BeforeTest
  public void beforeTest() throws InterruptedException{
                             Driver = PO.beforeTest();
                             POV.beforeTest(Driver);
                             POIV.beforeTest(Driver);
                             POJS6.beforeTest(Driver);
                             POJS7.beforeTest(Driver);
                             POJS8.beforeTest(Driver);
                             extentTest = extent.startTest("Sprint 8 - CABS-1692",
                                                          "Income History - sorting )");
                             extentTest.log(LogStatus.INFO, "Browser successfully launched");
  }

	@AfterTest
	public void aftertest(){
		
		Driver.quit();
	}
}
