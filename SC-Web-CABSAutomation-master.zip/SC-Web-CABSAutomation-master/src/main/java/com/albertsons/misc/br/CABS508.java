package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS508 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify Only users with "View billing record" rights, can view billing
	// record
	// CABS1263 Also handled
	@Test(priority = 1, enabled = true)
	public void CABS1261() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1261 Execution started");

		PO.nonAlwnceNew();
		POV.brSavNonAlw(Driver);
		//POV.srchBilRecord(Driver);
		
		POVIII.Search(Driver);
		POVIII.searchFirstItemClk(Driver);
		
		 POV.getbilngRcrdId(Driver);
		 
		POV.brtxtcondition(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1261 Execution Completed");
	}

	// Verify the user with Edit My Billing Record right can edit his billing
	// record when the BR is
	// assigned to me in the selected team
	// CABS1265, CABS1267 also handled
	@Test(priority = 2, enabled = true)
	public void CABS1264() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1264 Execution started");

		POV.edit(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1264 Execution Completed");
	}

	// Verify when user with edit permission, view the previously saved BR whose
	// offset
	// account # was saved for the team, then show the saved offset # for the
	// team

	@Test(priority = 3, enabled = true)
	public void CABS1275() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1275 Execution started");

		POV.ofsetNum(Driver);
		

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1275 Execution Completed");
	}

	// Verify when user with edit permission, view the previously saved BR that
	// has no previously saved Offset # for the team,then show the first 2
	// parts of offset # auto-derived by the app corresponding to previously
	// saved lookup type and value
	@Test(priority = 4, enabled = true)
	public void CABS1277() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1277 Execution started");

		POVIII.searchBtn(Driver);
		Thread.sleep(3000);
		POV.ofsetSectionValidation(Driver);
		
		POVIII.SearchII(Driver);
		POVIII.searchFirstItemClk(Driver);
		
		POV.ofsetSectionValidationII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1277 Execution Completed");
	}

	// Verify when user with edit permission, view the previously saved BR that
	// has no previously saved Offset # for the team,then all 3 parts of offset
	// # is editable if the app is unable to auto-derive based on lookup type
	// and value selected
	@Test(priority = 5, enabled = false)
	public void CABS1278() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1278 Execution started");

		POV.ofsetValidation(Driver);
		POVIII.SearchII(Driver);
		POVIII.searchFirstItemClk(Driver);
		
	 

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1278 Execution Completed");
	}

	// Verify when user with edit permission, view the previously saved BR that
	// has no previously saved Offset # for the team,then all 3 parts of offset
	// # is editable if lookup type and value was not saved on the BR previously
	@Test(priority = 6, enabled = false)
	public void CABS1279() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1279 Execution started");

		POV.teamChange(Driver);
		PO.nonAlwnceNew();
		POV.brSavNonAlw2(Driver);
		
		
		
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1279 Execution Completed");
	}
	

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-508",
				"View/Edit BR - Misc");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
