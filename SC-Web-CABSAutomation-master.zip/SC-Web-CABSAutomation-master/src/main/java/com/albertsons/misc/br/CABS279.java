package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

/**
 * User Story: CABS-279
 * 
 * @author akuma58
 *
 */

public class CABS279 extends ExtendBaseClass{
	
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;
	
	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}
	
	//Verify If the user has not entered any value in required field then the system is showing alert
	@Test(priority = 1, enabled = true)
	public void CABS834() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-834 Execution started");
		
		PO.NonAlwnceBR();
		PO.offsetnumSuccII();
		PO.income();
	//	PO3.incSavClk(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-834 Execution Completed");
		
	}
	
	//Verify If user has entered valid value in all the required field then system should proceed to save in back-end
	@Test(priority = 2, enabled = true)
	public void CABS835() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-835 Execution started");
		
	 PO3.incSaveBtn();

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-835 Execution Completed");
		
	}
	
	//Verify If user entered amount is to be validated
	@Test(priority = 3, enabled = true)
	public void CABS836() throws Exception {

		extentTest
		.log(LogStatus.INFO, "Test Case - CABS-836 Execution started");
		
	  PO3.incmAmtErrCheck(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-836 Execution Completed");
		
	}
	
	 @BeforeTest
	  public void beforeTest() throws InterruptedException {
		  Driver =  PO.beforeTest();
			 PO3.beforeTest(Driver);
				extentTest = extent.startTest("Sprint 3 - CABS-279",
						"Misc Income Section - Validate inputs");
				extentTest.log(LogStatus.INFO, "Browser successfully launched");
	  }

 @AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
