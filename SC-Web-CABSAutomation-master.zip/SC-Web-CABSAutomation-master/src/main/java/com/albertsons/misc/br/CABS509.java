package com.albertsons.misc.br;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS509 extends ExtendBaseClass {
	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify all required fields for the billing record have valid values, when
	// user edit and save my billing record
	@Test(priority = 1, enabled = true)
	public void CABS1284() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1284 Execution started");

		PO.nonAlwnceNew();
		POV.brSavNonAlw(Driver);
		POV.srchBilRecord(Driver);
		POV.edit(Driver);
	//	POV.editInvalid(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1284 Execution Completed");
	}

	// Verify all required fields for the billing record have valid values, when
	// user edit and save others billing record, 
	//CABS1286 Also handled here
	@Test(priority = 2, enabled = true)
	public void CABS1285() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1285 Execution started");

		POV.teamChangeV(Driver);
		POV.srchBilRecord(Driver);
		POV.editIII(Driver);
	//	POV.editInvalid(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1285 Execution Completed");
	}

	// Verify if the user manually typed any part of Offset # for the team, BR
	// history is saved
	@Test(priority = 3, enabled = true)
	public void CABS1289() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1289 Execution started");

		POV.teamChange(Driver);
		POV.ofsetSectionValidation(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1289 Execution Completed");
	}

	// Verify Add Income button is disabled until there is a valid offset
	// account # saved for the BR for the team
	@Test(priority = 4, enabled = true)
	public void CABS1290() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1290 Execution started");

		POV.AddIncome(Driver);
		
		//POIV.BRSaveNewReady(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1290 Execution Completed");
	}
	
	// Verify all required fields for the billing record have valid values, when
		// user edit and save my billing record
		@Test(priority = 5, enabled = true)
		public void CABS1284Edit_Invalid() throws Exception {

			extentTest.log(LogStatus.INFO,
					"Test Case - CABS1284_Edit_Invalid Execution started");

			POV.editInvalid(Driver);
			
			extentTest.log(LogStatus.INFO,
					"Test Case - CABS1284_Edit_Invalid  Execution Completed");
		}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 5 - CABS-509",
				"Save button functionality for a previously saved Misc BR");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
