package com.albertsons.worklist;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS860 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify user with "Initiate Payback request" rights can see "Payback"
	// button next to the Bill type income in Income History Section, which is
	// in 'Sent to Vendor' status

	@Test(priority = 1, enabled = true)
	public void CABS1644() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1644 Execution started");

		POVII.waitforBlngbtn(Driver);
		POVII.paybackWorklistLeft(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1644 Execution Completed");
	}

	// Verify In the income history, the income that has payback initiated and
	// waiting for current user's approval should show 'View PB' button next to
	// the income
	@Test(priority = 2, enabled = true)
	public void CABS1645() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1645 Execution started");

		POVII.viewPb(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1645 Execution Completed");
	}

	// Verify 'View PB' button shows up for all users with right to approve
	// payback/role Payback Approver in the team
	@Test(priority = 3, enabled = true)
	public void CABS1646() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1646 Execution started");

		POVII.worklistForUserChange(Driver);
		POVII.paybackWorklistLeftII(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1646 Execution Completed");
	}

	// Verify when user click on the "View PB" button, payback approve modal is
	// show up
	@Test(priority = 4, enabled = false)
	public void CABS1647() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1647 Execution started");

		POVII.worklistForUserChangeII(Driver);
		Thread.sleep(5000);
		POVII.paybackWorklistLeftII(Driver);
		Thread.sleep(5000);
		POVII.viewPbbClick(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1647 Execution Completed");
	}

	// Verify Approver field in the Payback Approver Modal
	@Test(priority = 5, enabled = false)
	public void CABS1648() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1648 Execution started");

		POVII.approver(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1648 Execution Completed");
	}

	// Verify initially, Reason & Responsible user field values are same given
	// in initiate payback modal
	@Test(priority = 6, enabled = false)
	public void CABS1649() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1649 Execution started");

		POVII.reason(Driver);
		POVII.users(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1649 Execution Completed");
	}

	// Verify approver can change the Reason ans Responsible Users field value
	// on Payback Approver modal
	@Test(priority = 7, enabled = false)
	public void CABS1651() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1651 Execution started");

		POVII.reasonClick(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1651 Execution Completed");
	}

	// Validate Reason field value changed by the approver
	@Test(priority = 8, enabled = false)
	public void CABS1652() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1652 Execution started");

		POVII.reasonRemove(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1652 Execution Completed");
	}

	// Validate Responsible User field value changed by the approver
	@Test(priority = 9, enabled = false)
	public void CABS1653() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1653 Execution started");

		POVII.userRemove(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1653 Execution Completed");
	}

	// Verify if user changes reasons or responsible users or both, old entries
	// in back-end should be removed and the latest reasons/responsible users
	// must be saved for the payback
	//cabs1657,1658,1659 also handled here
	@Test(priority = 10, enabled = false)
	public void CABS1656() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1656 Execution started");
		
		
		POVII.paybackApprove(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1656 Execution Completed");
	}
	

	// Verify income and invoice when user clicks reject in Payback approve
	// modal
	@Test(priority = 11, enabled = false)
	public void CABS1660() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1660 Execution started");

		POVII.rejectClick(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1660 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 7 - CABS-860",
				"Payback - Approve/Reject");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
