package com.albertsons.worklist;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS927 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	//Verify ANALYSIS WORKLIST menu
	@Test(priority = 1, enabled = true)
	public void CABS2174() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2174 Execution started");

		POVIII.AlwnceBRRetailOverlap(Driver);
		POX.BRSaveII(Driver);

		POX.analysisWorklistNew(Driver);		 
	 	POX.analysisWorklistLater(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2174 Execution Completed");
	}
	
	//Verify ANALYSIS WORKLIST fields for Retail/COGS
	@Test(priority = 2, enabled = false)
	public void CABS2175() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2174 Execution started");

 
		POX.COGSAlwnceBRNoItemized(Driver);
		POX.BRSaveIII(Driver);
		
		POX.analysisWorklistNew(Driver);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2174 Execution Completed");
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent
				.startTest("Sprint 10 - CABS-927",
						"Analysis Worklist - List BR in Analysis worklist");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	
	@AfterTest
	public void aftertest(){
		
		Driver.quit();
	}

}
