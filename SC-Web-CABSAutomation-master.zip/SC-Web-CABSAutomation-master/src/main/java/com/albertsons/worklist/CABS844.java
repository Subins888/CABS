package com.albertsons.worklist;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSJVII;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

import org.openqa.selenium.WebDriver;

import org.testng.ITestResult;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;

import com.albertsons.pageobjects.PageObjectsIV;

import com.albertsons.pageobjects.PageObjectsSJVI;

import com.albertsons.pageobjects.PageObjectsSJVII;

import com.albertsons.pageobjects.PageObjectsSprint3;

import com.albertsons.pageobjects.PageObjectsV;

import com.albertsons.pages.GenericFactory;

import com.albertsons.pages.PageObjects;

import com.albertsons.reportGeneration.ExtendBaseClass;

import com.relevantcodes.extentreports.LogStatus;

public class CABS844 extends ExtendBaseClass {

	WebDriver Driver;

	PageObjects PO = new PageObjects(Driver);

	PageObjectsIV POIV = new PageObjectsIV(Driver);

	PageObjectsV POV = new PageObjectsV(Driver);

	GenericFactory pageFact = new GenericFactory(Driver);

	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);

	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);

	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);

	PageObjectsSJVII POJS7 = new PageObjectsSJVII(Driver);

	ITestResult result;

	@Test(priority = 0, enabled = true)

	public void ABS_Login() throws Exception {

		PO.waitforelement();

		PO.Login();

	}

	// Verify Payback worklist list the billing records with income

	// records that are waiting for selected user's approval in selected team

	@Test(priority = 1, enabled = true)

	public void CABS1638() throws Exception {

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1638 Execution started");

		POJS7.paybackWorkListMenuClick(Driver);

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1638 Execution Completed");

	}

	// Verify the 'PAYBACK WORKLIST' menu on side bar shows the count of income
	// records waiting in the

	// Payback work list for the approval of selected user in 'Worklist for' drop
	// down

	@Test(priority = 2, enabled = true)

	public void CABS1639() throws Exception {

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1639 Execution started");

		POJS7.paybackWorkListIncmCount(Driver);

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1639 Execution Completed");

	}

	// Verify the PayBack Worklist fields

	@Test(priority = 3, enabled = true)

	public void CABS1640() throws Exception {

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1640 Execution started");

		POJS7.PaybackWorkListFields(Driver);

		POJS7.PaybackWorkListFieldsVal(Driver);

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1640 Execution Completed");

	}

	// Verify Payback Worklist sort is by Billing record ID, Invoice Nbr - ascending
	// order, by default

	@Test(priority = 4, enabled = true)

	public void CABS1641() throws Exception {

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1641 Execution started");

		POJS7.ascndingBR(Driver);

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1641 Execution Completed");

	}

	// Verify if multiple payback income records are associated with a BR, then the
	// BR is listed more than one time

	@Test(priority = 5, enabled = true)

	public void CABS1642() throws Exception {

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1642 Execution started");

		POJS7.PaybackMultipleIncomeVal(Driver);

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1642 Execution Completed");

	}

	// Verify if the logged-in user has at least view-only role in the selected
	// team, user must be taken to billing record page for the billing record ID by
	// clicking on Billing record ID hyperlink

	@Test(priority = 6, enabled = true)

	public void CABS1643() throws Exception {

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1643 Execution started");

		POJS7.BRClick(Driver);

		extentTest.log(LogStatus.INFO,

				"Test Case - CABS-1643 Execution Completed");

	}

	@BeforeTest

	public void beforeTest() throws InterruptedException {

		Driver = PO.beforeTest();

		POV.beforeTest(Driver);

		POIV.beforeTest(Driver);

		POJS6.beforeTest(Driver);

		POJS7.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 7 - CABS-844",

				"Payback Worklist - List BRs for the selected user )");

		extentTest.log(LogStatus.INFO, "Browser successfully launched");

	}

	@AfterTest
	public void aftertest() {
		Driver.quit();
	}
}
