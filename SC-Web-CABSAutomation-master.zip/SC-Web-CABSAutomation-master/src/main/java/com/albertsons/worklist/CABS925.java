package com.albertsons.worklist;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS925 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify user with Cancel MY Invoice rights, should be shown 'Cancel'
	// button next to the income record for the billing record assigned to
	// current user in Income History section, when income is in 'Submitted'
	// status
	@Test(priority = 1, enabled = true)
	public void CABS1672() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1672 Execution started");
		
		POVII.nonAlwnceType(Driver);
		Thread.sleep(5000);
		POVII.AddIncmMiscII(Driver);
		POVII.otMiscIII(Driver);
		Thread.sleep(2500);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(5000);
		
		POVII.cancel(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1672 Execution Completed");
	}

	// Verify user with Cancel other invoices rights, should be shown 'Cancel'
	// button next to the income record for the billing record assigned to other
	// user in Income History section, when income is in 'Submitted' status
	@Test(priority = 2, enabled = true)
	public void CABS1673() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1673 Execution started");

		POVII.waitforBlngbtn(Driver);
		//POVII.userChange(Driver);	
		POVII.SearchNew(Driver);
		Thread.sleep(5000);
		//POVII.readyBtnClk(Driver);
		POVIII.searchFirstItemClk(Driver);
		Thread.sleep(3000);
		POVII.AddIncmMiscII(Driver);
		Thread.sleep(3000);
		POVII.scroldown(Driver);
		Thread.sleep(3000);
		POVII.otMiscIII(Driver);
		Thread.sleep(2500);
		POVII.miscHistoryPlus(Driver);
		Thread.sleep(5000);
		
		POVII.cancel(Driver);
 	

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1673 Execution Completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		POVIII.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 7 - CABS-925",
				"Income History - Cancel submitted income");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
