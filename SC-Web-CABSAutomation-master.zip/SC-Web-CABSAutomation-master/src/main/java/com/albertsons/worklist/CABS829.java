package com.albertsons.worklist;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSJX;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS829  extends ExtendBaseClass{
      
      WebDriver Driver;
      PageObjects PO = new PageObjects(Driver);
      GenericFactory pageFact = new GenericFactory(Driver);
      GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
      PageObjectsSJX POJS10 = new PageObjectsSJX(Driver);
      PageObjectsV POV = new PageObjectsV(Driver);
      PageObjectsIV POIV = new PageObjectsIV(Driver);
      PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
      ITestResult result;
      Integer Time;
      String BType;

      @Test(priority = 0, enabled = true)
      public void ABS_Login() throws Exception {

            PO.waitforelement();
            PO.Login();
      }
      //Verify Income worklist menu on side bar shows the count of billing records that needs 
      //to be billed and that are assigned to selected user in 'View as' dropdown and selected team.
      @Test(priority = 1, enabled = true)
      public void CABS2531() throws Exception {
            extentTest.log(LogStatus.INFO,
                        "Test Case - CABS-2531 Execution started");
            POJS10.WorkListForDropDown(Driver);
            POJS10.IncomeWorkListMenuClick(Driver);
            extentTest.log(LogStatus.INFO,
                        "Test Case - CABS-2531 Execution Completed");
            
      }
      //Verify Income worklist layout
      @Test(priority = 2, enabled = true)
      public void CABS2550() throws Exception {
            extentTest.log(LogStatus.INFO,
                        "Test Case - CABS-2550 Execution started");
            POJS10.IncomeWorkListFields(Driver);
            extentTest.log(LogStatus.INFO,
                        "Test Case - CABS-2550 Execution Completed");
            
      }
      //Verify the billing records with status other than 'Ready for Income' should not be shown in income worklist
      @Test(priority = 3, enabled = true)
      public void CABS2549() throws Exception {
            extentTest.log(LogStatus.INFO,
                        "Test Case - CABS-2549 Execution started");
            PO.nonAlwnceNew();
            POV.brSavNonAlw(Driver);      
            POJS10.brIncomeSave(Driver);
            POJS10.miscBRVal(Driver);
            
            extentTest.log(LogStatus.INFO,
                        "Test Case - CABS-2549 Execution Completed");
            
      }
  
      @BeforeTest
        public void beforeTest() throws InterruptedException {
              Driver = PO.beforeTest();
            POJS10.beforeTest(Driver);
                  POV.beforeTest(Driver);
                  POIV.beforeTest(Driver);
                  POJS6.beforeTest(Driver);
            
            extentTest = extent.startTest("Sprint 12 - CABS-829",
                                         "Income worklist( Basic ) ");
            extentTest.log(LogStatus.INFO, "Browser successfully launched");
        }
      
      @AfterTest
      public void afterTest() {
    	  
    	  Driver.quit();
      }

}
