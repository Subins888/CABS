package com.albertsons.worklist;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS724 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify logged in user who has the right 'Approve Over Tolerance' in the
	// team ,the over tolerance worklist should list the billing records needing
	// the logged-in user's approval in that team
	@Test(priority = 1, enabled = true)
	public void CABS1570() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1570 Execution started");

		POVII.OTLeft(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1570 Execution Completed");
	}

	// Verify logged in user who has the right 'Approve Over Tolerance' in the
	// team ,the over tolerance worklist should not list the billing records
	// doesn't need the logged-in user's approval in that team
	@Test(priority = 2, enabled = true)
	public void CABS1573() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1573 Execution started");

		POVII.userChangeOT(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1573 Execution Completed");
	}

	// Verify the user assigned to approve the OT on the income record in the
	// team should be shown 'View OT' button in income history
	@Test(priority = 3, enabled = true)
	public void CABS1574() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1574 Execution started");

		POVII.viewOTbtn(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1574 Execution Completed");
	}

	// Verify user who has the right 'Approve Over Tolerance' in the team ,
	// should be shown 'View OT' button
	@Test(priority = 4, enabled = true)
	public void CABS1575() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1575 Execution started");

		POVII.viewOTbtnLogdnUser(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1575 Execution Completed");
	}

	// Verify clicking on 'X' close the popup during which time, the income
	// record status should not change
	@Test(priority = 7, enabled = true)
	public void CABS1579() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1579 Execution started");

		POVII.closePopup(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1579 Execution Completed");

	}

	// Verify OT approver can approve the OT income records from income history
	// section
	@Test(priority = 5, enabled = true)
	public void CABS1577() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1577 Execution started");

		POVII.AddIncome(Driver);
		POVII.approveOT(Driver);
		Thread.sleep(5000);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1577 Execution Completed");

	}

	// Verify OT approver can reject the OT income records from income history
	// section

	@Test(priority = 6, enabled = true)
	public void CABS1578() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1578 Execution started");

		POVII.AddIncome(Driver);
		POVII.rejectOT(Driver);
		Thread.sleep(5000);
		
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-1578 Execution Completed");

	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);

		extentTest = extent.startTest("Sprint 7 - CABS-724",
				"OT Income - Approve/Reject");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
}
