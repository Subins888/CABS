package com.albertsons.brHistory;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pageobjects.PageObjectsX;
import com.albertsons.pageobjects.pageObjects11;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1111 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsX POX = new PageObjectsX(Driver);
	pageObjects11 PO11 = new pageObjects11(Driver);

	ITestResult result;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}


	// Verify the Dialog Trail Front view - Allowance
	// CABS- 2346, 2347, CABS-1112, CABS-1114, CABS-1113
	@Test(priority = 1, enabled = true)
	public void CABS2345() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2345 Execution started");

		POVIII.AlwnceBRNoItemizd(Driver);
		POVIII.BRSave(Driver);

		PO11.dialog(Driver);
		PO11.DialogDrpValue(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2345 Execution completed");
	}

	// Verify the Dialog Trail Front view - Non Allowance
	// CABS-2349, 2350, CABS-1112, CABS-1114, CABS-1113
	@Test(priority = 2, enabled = true)
	public void CABS2348() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2348 Execution started");

		POVIII.searchBtn(Driver);
		Thread.sleep(1500);
		PO11.warningYesClk(Driver);
		Thread.sleep(2500);

		POVII.nonAlwnceNoRetailType(Driver);
		 PO11.brSaveMisc(Driver);
		 
		 PO11.dialogMisc(Driver);
	//	 PO11.DialogDrpValueMisc(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2348 Execution completed");
	}

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVIII.beforeTest(Driver);
		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POX.beforeTest(Driver);
		PO11.beforeTest(Driver);
		POIV.beforeTest(Driver);
		extentTest = extent.startTest("Sprint 11 - CABS-1111", "Dialog");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 

}
