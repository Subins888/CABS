package com.albertsons.brHistory;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.albertsons.pageobjects.GenericFactorySprint3;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsIX;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSprint3;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVI;
import com.albertsons.pageobjects.PageObjectsVII;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1133 extends ExtendBaseClass {

	WebDriver Driver;
	PageObjects PO = new PageObjects(Driver);
	PageObjectsIV POIV = new PageObjectsIV(Driver);
	PageObjectsV POV = new PageObjectsV(Driver);
	PageObjectsVI POVI = new PageObjectsVI(Driver);
	PageObjectsVII POVII = new PageObjectsVII(Driver);
	PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
	PageObjectsIX POIX = new PageObjectsIX(Driver);
	GenericFactory pageFact = new GenericFactory(Driver);
	GenericFactorySprint3 pageFact3 = new GenericFactorySprint3(Driver);
	PageObjectsSprint3 PO3 = new PageObjectsSprint3(Driver);
	PageObjectsSJVI POJS6 = new PageObjectsSJVI(Driver);
	ITestResult result;
	String BType;

	@Test(priority = 0, enabled = true)
	public void ABS_Login() throws Exception {

		PO.waitforelement();
		PO.Login();
	}

	// Verify the last update date field on the Billing record header section
	// shows the date & time and edit history text, of the all the times when
	// the billing record has had edits or income was submitted.

	@Test(priority = 1, enabled = true)
	public void CABS2010() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2010 Execution started");

		POVIII.waitforBlngbtn(Driver);
		Thread.sleep(3000);
		POVII.nonAlwnceType(Driver);
		Thread.sleep(3000);
		POIX.lastUpdateView(Driver);

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2010 Execution Completed");
	}

	// Verify billing page section(s) is loaded with data, that the billing
	// record had during that save,When user selects any listing from the
	// history dropdown.
	@Test(priority = 2, enabled = true)
	public void CABS2011() throws Exception {

		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2011 Execution started");

		Thread.sleep(2500);
		POIX.modifyBR(Driver);
		Thread.sleep(5000);
		POIX.lastUpdateViewDisabled(Driver);
	 	
		extentTest.log(LogStatus.INFO,
				"Test Case - CABS-2011 Execution Completed");
	}
	

	@BeforeTest
	public void beforeTest() throws InterruptedException {
		Driver = PO.beforeTest();

		POVII.beforeTest(Driver);
		POVI.beforeTest(Driver);
		POV.beforeTest(Driver);
		POIV.beforeTest(Driver);
		POJS6.beforeTest(Driver);
		POVIII.beforeTest(Driver);
		POIX.beforeTest(Driver);

		extentTest = extent
				.startTest("Sprint 9 - CABS-1133", "BR History View");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}
	@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
	
}
