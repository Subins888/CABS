package com.albertsons.brHistory;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.albertsons.pageobjects.GenericFactorySJX;
import com.albertsons.pageobjects.PageObjectsIV;
import com.albertsons.pageobjects.PageObjectsSJVI;
import com.albertsons.pageobjects.PageObjectsSJVII;
import com.albertsons.pageobjects.PageObjectsSJVIII;
import com.albertsons.pageobjects.PageObjectsSJIX;
import com.albertsons.pageobjects.PageObjectsSJX;
import com.albertsons.pageobjects.PageObjectsV;
import com.albertsons.pageobjects.PageObjectsVIII;
import com.albertsons.pages.GenericFactory;
import com.albertsons.pages.PageObjects;
import com.albertsons.reportGeneration.ExtendBaseClass;
import com.relevantcodes.extentreports.LogStatus;

public class CABS1132 extends ExtendBaseClass {
              WebDriver Driver;
              PageObjects PO = new PageObjects(Driver);
              PageObjectsV POV = new PageObjectsV(Driver);
              GenericFactory pageFact = new GenericFactory(Driver);
              GenericFactorySJX pageFactSJX = new GenericFactorySJX(Driver);
              PageObjectsVIII POVIII = new PageObjectsVIII(Driver);
              PageObjectsSJIX POJS9 = new PageObjectsSJIX(Driver);
              PageObjectsSJX POJS10 = new PageObjectsSJX(Driver);
              ITestResult result;
              String BType;
              String EditType;
              
              /**
              * User Story: CABS-1132 BR history Save
              * 
               * 
               * @author jmann89
              *
              */
              
              @Test(priority = 0, enabled = true)
              public void ABS_Login() throws Exception {

                             PO.waitforelement();
                             PO.Login();
              }
              //Verify the historical view of BR shows the data "Billing record created" after creating BR
              @Test(priority = 1, enabled = true)
              public void CABS2003() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2003 Execution started");
                             POVIII.AlwnceBRNoItemizd(Driver);                      
                             //POJS9.AllwncBRSave(Driver);
                             POJS10.AllwncBRSaveforFlat(Driver);
                             Thread.sleep(2000);       
                             EditType="Billing";
                             POJS9.BRCreateHistVal(Driver,EditType);
                             POJS9.BRCreateHistClick(Driver);
                             Thread.sleep(2000);
                             POJS9.BRCreateHistClickFieldsVal(Driver);
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2003 Execution Completed");
                             
              }
              //Verify the historical view of BR shows the data "Allowance Information updated" if only Allowance Information section of the BR was updated
              @Test(priority = 2, enabled = true)
              public void CABS2004() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                         "Test Case - CABS-2004 Execution started");
                             POJS9.EditAllowInfo(Driver);
                             EditType="Allowance";
                             System.out.println("Checking BR history");
                             POJS9.BRCreateHistVal(Driver,EditType);
                             POJS9.BRCreateHistClick(Driver);
                             Thread.sleep(2000);
                             POJS9.BRCreateHistFieldsValwithAllowFields(Driver);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2004 Execution Completed");
              }
              //Verify the historical view of BR shows the data "Item details updated" if only Item Details section of the BR was updated        
              @Test(priority = 6, enabled = false)
              public void CABS2005() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2005 Execution started");
                             Thread.sleep(5000);
                             POJS9.EditItem(Driver);
                             Thread.sleep(3500);
                             EditType="ItemDetails";
                             POJS9.BRCreateHistVal(Driver,EditType);
                             POJS9.BRCreateHistClick(Driver);
                             POJS9.BRCreateHistFieldsValwithAllowFields(Driver);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2005 Execution Completed");
                             
              
              }
              //Verify the historical view of BR shows the data "Billing record header updated" if only header of the BR was updated
              @Test(priority = 3, enabled = true)
              public void CABS2006() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2006 Execution started");
                             POJS9.scrollDownReady(Driver);
                             POJS9.EditHeader(Driver);
                             EditType="Header";
                             POJS9.scrollUp(Driver);
                             POJS9.BRCreateHistVal(Driver,EditType);
                             POJS9.BRCreateHistClick(Driver);
                             POJS9.BRCreateHistClickFieldsValwithHeader(Driver);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2006 Execution Completed");
                             
              
              }
  //Verify the historical view of BR shows the data "Multiple updates" if multiple sections of BR were updated
              @Test(priority = 5, enabled = false)
              public void CABS2007() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2007 Execution started");
                             POJS9.MultipleUpdates(Driver);
                             Thread.sleep(3000);
                             EditType="Multiple";
                             POJS9.BRCreateHistVal(Driver,EditType);
                             POJS9.BRCreateHistClick(Driver);
                             Thread.sleep(8000);
                             POJS9.BRCreateHistClickFieldsValwithMulipleUpd(Driver);
                             Thread.sleep(3000);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2007 Execution Completed");                   
              }             
              
//Verify the historical view of BR shows the data Income type + " submitted" for every income record submitted         
//Handled testcase CABS-2009 also in the below testcase
              @Test(priority = 4, enabled = false)
              public void CABS2008() throws Exception{
                             extentTest.log(LogStatus.INFO,
                                                         "Test Case - CABS-2008 Execution started");
                             POJS9.scrollDownReady(Driver);
                             Thread.sleep(2000);
                             POJS9.AddAllowIncome(Driver);
                             EditType="Income";
                             POJS9.BRCreateHistVal(Driver,EditType);
                             POJS9.BRCreateHistClick(Driver);
                             POJS9.BRCreateHistClickFieldsValwithMulipleUpd(Driver);
                             
                             extentTest.log(LogStatus.INFO,
                                                          "Test Case - CABS-2008 Execution Completed");                   
              }
              
              
              
              
  @BeforeTest
  public void beforeTest() throws InterruptedException{
                             Driver = PO.beforeTest();
                             POJS9.beforeTest(Driver);
                             POJS10.beforeTest(Driver);
                             POVIII.beforeTest(Driver);
                             extentTest = extent.startTest("Sprint 9 - CABS-1132",
                                                          "BR History Save ");
                             extentTest.log(LogStatus.INFO, "Browser successfully launched");
}

@AfterTest
	public void aftertest() {
		Driver.quit();
	} 
	
}
