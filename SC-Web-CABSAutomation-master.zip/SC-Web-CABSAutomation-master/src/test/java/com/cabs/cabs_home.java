package com.cabs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.util.Properties;

//import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Assert;
import org.testng.annotations.AfterTest;
import com.cabs.pages.GenericFactory_bckup;

public class cabs_home {
	
	WebDriver Driver;
	GenericFactory_bckup pageFact;

	 
  @Test(priority=0, enabled = true)
  public void home_page_TestCase_001() throws InterruptedException {
	  
  
	  
  }
    
  @Test(priority=1, enabled = true)
  public void side_panel_TestCase_002() throws InterruptedException {
	  
	 
  }
  
  @Test(priority=2, enabled = true)
  public void side_worklist() throws InterruptedException {
	  
	  
	  
  }
  
  @Test(priority=3, enabled = true)
  public void create_billing() throws InterruptedException {
	  
	  
	  
  }
  
  @Test(priority=4, enabled = true)
  public void upload_income() throws InterruptedException {
	  
	  
	  
  }
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	 
	}

      // Driver.switchTo().alert().dismiss();

  @AfterTest
  public void afterTest() {
	//  Driver.quit();
  }

}
