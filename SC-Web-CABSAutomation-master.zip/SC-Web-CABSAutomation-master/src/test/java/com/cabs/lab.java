package com.cabs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class lab {
	
	WebDriver driver;
	
  @Test
  public void f() throws BiffException, IOException {
	     driver.get("https://pabs-qa.safeway.com/pabs/static/#/home");
	   
	     String file = new File(System.getProperty("user.dir"), "properties_File").getAbsolutePath();

	       // Creation of properties object
	       Properties prop = new Properties();

	       // Creation of InputStream object to read data
	       FileInputStream objInput = null;
	       try {
	              objInput = new FileInputStream(file);
	              // Reading properties key/values in file
	              prop.load(objInput);
	              // Closing the input stream
	              // objInput.close();
	       } catch (FileNotFoundException e) {
	              System.out.println(e.getMessage());
	       } catch (IOException e) {
	              System.out.println(e.getMessage());
	       }

	    
	        FileInputStream fi = new FileInputStream("C:\\Users\\u61282\\workspace\\ABS_CABS\\TestData.xls");
	         Workbook w = Workbook.getWorkbook(fi);
	         Sheet s = w.getSheet(0);
	     
	     try {
	      for (int i = 1; i < s.getRows(); i++) {
	       // Read data from excel sheet
	       String s1 = s.getCell(1, i).getContents();
	       String s2 = s.getCell(2, i).getContents();
	       
	     Thread.sleep(10000);
//	       driver.findElement(By.id("userNameInput")).sendKeys(s1);
//	         driver.findElement(By.id("passwordInput")).sendKeys(s2);
	         
	         driver.findElement(By.id(prop.getProperty("usrNameId"))).sendKeys(s1);
	           driver.findElement(By.id(prop.getProperty("usrPwdId"))).sendKeys(s2);
	           
	           //driver.findElement(By.id(prop.getProperty("submitButton"))).click();
	           driver.findElement(By.id("submitButton")).click();
	      }
	     } catch (Exception e) {
	      System.out.println(e);
	     }

  }
  @BeforeTest
  public void beforeTest() {
	  
	  System.setProperty("webdriver.chrome.driver",
				new File(System.getProperty("user.dir"), "chromedriver.exe").getAbsolutePath());
	  driver= new ChromeDriver();
	  
	  

  }

  @AfterTest
  public void afterTest() {
  }

}
