package com.cabs.pages;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.io.IOException;
 
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class ExtendBaseClass_bckup {
	
    
     public static ExtentReports extent;
     public static ExtentTest extentTest;   
     WebDriver Driver;
     
     @BeforeSuite
     public void setup() throws IOException {
            
     String extentReportFile = System.getProperty("user.dir")+ "\\extentReportFile.html";
     extent = new ExtentReports(extentReportFile,true);

     }
     
     
     @AfterMethod
     public void getResult(ITestResult result) throws IOException
     {
   
         if(result.getStatus() == ITestResult.FAILURE)
         {       
            extentTest.log(LogStatus.FAIL," Test case FAILED ");
            System.out.println("Fail");
         }
         else if(result.getStatus() == ITestResult.SUCCESS)
         {
            extentTest.log(LogStatus.PASS, " Test Case PASSED");
         }
         else
         {
            extentTest.log(LogStatus.SKIP, " Test Case SKIPPED");  
         }
                 
     }
     
     @AfterSuite
     public void tearDown(){
     extent.flush();
         
        }
}
