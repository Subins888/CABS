package com.cabs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
 
import org.testng.annotations.AfterTest;

public class headless {
	
	String  actualTitle, actualTitle2;
	
	
  @Test
  public void headless_automation() throws InterruptedException, AWTException {
	 
	  //  chromeOptions.setBinary("/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary");
    //  chromeOptions.addArguments("--headless");
//      WebDriverWait waitForUsername = new WebDriverWait(Driver, 5000);
//      waitForUsername.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
	  ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--headless");
	  WebDriver Driver = new ChromeDriver(chromeOptions);
	     // chromeOptions.addArguments("--headless");
		      Driver.navigate().to("https://www.google.com");
		System.out.println("Navigated to Google Site");
      Thread.sleep(2500);
      Driver.findElement(By.name("q")).sendKeys("ajith");
      actualTitle = Driver.getTitle();
      System.out.println("Title is " + actualTitle);
    
      Robot robot = new Robot();
      robot.keyPress(KeyEvent.VK_ENTER);	

    
       Thread.sleep(5000);
       Driver.findElement(By.id("rso")).click();
       Thread.sleep(5000);
       System.out.println("New Title is " + actualTitle2);
     
//      waitForError.until(ExpectedConditions.visibilityOfElementLocated(By.id("flash")));
//
//      Assert.assertTrue(Driver.findElement(By.id("flash")).getText().contains("Your password is invalid!"));
//     
  }
  @Test
  public void headless_automationII(){
	  
	  
  }
  
  
  @BeforeTest
  public void beforeTest() {
	  //  chromeOptions.setBinary("/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary");
	  
		
  }

  @AfterTest
  public void afterTest() {
  }

}
