package com.cabs;

import org.testng.annotations.Test;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.apache.commons.io.FileUtils; 

public class lab1    {
	
	static ExtentReports extent;
    static ExtentTest extentTest;
    String extentReportImage;
	
	WebDriver Driver;	
	
  @Test
  public void lab_method() throws IOException {
	  
	  
	  TakesScreenshot ts = (TakesScreenshot)Driver;
	   	 File source = ts.getScreenshotAs(OutputType.FILE);
	   	 File destination = new File(extentReportImage);
	   		
	   	 FileUtils.copyFile(source, destination);  
	   		
	   		extentTest.log(LogStatus.INFO,"Snapshot : "+ extentTest.addScreenCapture(extentReportImage));
	   		System.out.println("Screen capture"); 
  }
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
