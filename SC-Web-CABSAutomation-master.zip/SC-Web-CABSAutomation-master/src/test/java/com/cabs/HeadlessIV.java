package com.cabs;


import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.awt.AWTException;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;



public class HeadlessIV {
       
 
  String getTitle;
  WebDriver driver;
  
  @Test
  public void Test() throws AWTException, InterruptedException {
         
        
      
      
      getTitle = driver.getTitle();
      System.out.println("Site name is "+ getTitle);
      
      
      Thread.sleep(2500);
      driver.findElement(By.name("q")).sendKeys("Test");
      driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
                
      Thread.sleep(5000);

      WebElement text1 = driver.findElement(By.id
                ("resultStats"));
       System.out.println("Text is "+ text1.getText());

  }
  
  @BeforeTest
  public void beforetest() throws InterruptedException {
         
         System.setProperty("webdriver.chrome.driver", new File(System.getProperty("user.dir"), "chromedriver.exe").getAbsolutePath()); 
         
                ChromeOptions chromeOptions = new ChromeOptions(); 
               // chromeOptions.addArguments("headless");
                
                  driver = new ChromeDriver(chromeOptions);
                
                
                
             driver.navigate().to("https://www.google.com");
             Thread.sleep(10000);
             driver.findElement(By.xpath("/html/body/div/div/form/table[2]/tbody/tr/td/table[1]/tbody/tr[4]/td/table/tbody/tr/td[1]/input[2]")).click();
             System.out.println("Navigated to Google Site");
  }

  @AfterTest
  public void afterTest() {
         
         
  }

}

