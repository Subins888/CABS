package com.cabs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import java.awt.AWTException;
//import java.awt.Robot;
//import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
 
public class headlessII {
	
	String  actualTitle, actualTitle2;
	ChromeOptions chromeOptions = new ChromeOptions();
	WebDriver Driver = new ChromeDriver(chromeOptions);
	
  @Test
  public void headless_automation() throws InterruptedException, AWTException {
	  
      chromeOptions.addArguments("--headless");


      Thread.sleep(5000);
      Driver.findElement(By.id("user-message")).sendKeys("ajith");      
      actualTitle = Driver.getTitle();
      System.out.println("Title is " + actualTitle);
    
//      Robot robot = new Robot();
//      robot.keyPress(KeyEvent.VK_ENTER);	

     
       Driver.findElement(By.id("get-input")).click();
       Thread.sleep(2500);
       
       System.out.println("New Title is " + actualTitle2);
  }
  
  @Test
  public void headless_sample() {
	  
  }
  
  @BeforeTest
  public void beforeTest() {
	  chromeOptions.addArguments("--headless");
      Driver.navigate().to("https://www.seleniumeasy.com/test/basic-first-form-demo.html");
      System.out.println("Navigated to Demo Web Site");	  
  }

  @AfterTest
  public void afterTest() {
	  
	  Driver.quit();
  }

}
