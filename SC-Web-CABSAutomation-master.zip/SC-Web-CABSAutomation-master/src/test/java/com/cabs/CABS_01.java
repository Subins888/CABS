package com.cabs;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.albertsons.pages.PageObjects;
import com.cabs.pages.GenericFactory_bckup;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;


//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class CABS_01 {
	
	
	GenericFactory_bckup pageFact;
	PageObjects pageObj;
	WebDriver Driver;
	
	 String extentReportFile = System.getProperty("user.dir")
             + "\\extentReportFile.html";


     // Create object of extent report and specify the report file path.
     ExtentReports extent = new ExtentReports(extentReportFile, true);
     
     // Start the test using the ExtentTest class object.
     ExtentTest extentTest = extent.startTest("CABS_01",
             "Verify Home Page and Other Actions");
	 
  @Test (priority = 0, enabled = true)
  public void TestCase_001() throws InterruptedException {
	  
	   pageFact.wait_forelement();
	   //Thread.sleep(5000);
	   
		  try{
			  if(pageFact.getHomePageName().contains("Create billing record")){
				  System.out.println("PASS:  CABS Home page displayed");			  
				  //extentTest.log(LogStatus.INFO, "Browser Launched");
			  }		  
		  }catch(Exception e){
		      Assert.assertEquals(pageFact.getHomePageName(), "Create billing record");	  
			  System.out.println("FAIL:  CABS Home page not displayed");
		  }  
		  
		  // close report.
	        extent.endTest(extentTest);
	        // writing everything to document.
	        extent.flush();
	  }
  

@Test (priority = 2, enabled = true)
  public void TestCase_003() {
 
	pageFact = new GenericFactory_bckup(Driver);
	pageFact.buttonClick();

	 pageFact.wait_forelement2();
		
	  if(pageFact.submitText().contains("Submit")){
		  System.out.println("PASS:  Navigated to Create Billing Record page");
		  extentTest.log(LogStatus.PASS, "Navigated to Create Billing Record page");
	  } else	{System.out.println("FAIL:  NOT Navigated to Create Billing Record page");
	  extentTest.log(LogStatus.FAIL, "NOT Navigated to Create Billing Record page");}
	
	 // close report.
    extent.endTest(extentTest);
    // writing everything to document.
    extent.flush();
	  
  }
  

  @Test (priority = 1, enabled = true)
  public void TestCase_002() {
	  
//	  pageObj = new page_Objects(Driver);
//	  pageObj.TC_001();
	 
	  if(pageFact.srchBillingrcrd().contains("SEARCH BILLING RECORD")){
		  System.out.println("PASS:  Search Billing Record menu displaying in the side panel");			
		  extentTest.log(LogStatus.PASS, "Search Billing Record menu displaying in the side panel");
	  }		else	{  System.out.println("FAIL:  Search Billing Record menu NOT displaying in the side panel");	
	  extentTest.log(LogStatus.FAIL, "Search Billing Record menu NOT displaying in the side panel");
	  }
  
		  if(pageFact.analysisWrklst().contains("ANALYSIS1 WORKLIST1")){
			  System.out.println("PASS:  Analysis Worklist menu displaying in the side panel");		
			  extentTest.log(LogStatus.PASS, "Analysis Worklist menu displaying in the side panel");
			//  Assert.assertEquals(Driver.findElement(By.xpath("//*[@id='maincontainer']/div[2]/div[1]/cabs-sidebar/div/div[1]/div[2]/worklist-menu/div/a[1]")).getText(), "ANALYSIS1 WORKLIST1");
		  }		else { System.out.println("FAIL:  Analysis Worklist menu NOT displaying in the side panel");  
		  extentTest.log(LogStatus.FAIL, "Analysis Worklist menu NOT displaying in the side panel"); 
		  
		  }
	 
		  if(pageFact.incmeWrklist().contains("INCOME WORKLIST")){
			  System.out.println("PASS:  Income Worklist menu displaying in the side panel");
			  extentTest.log(LogStatus.PASS, "Income Worklist menu displaying in the side panel");
		  }	else	{  System.out.println("FAIL:  Income Worklist menu NOT displaying in the side panel");
		              extentTest.log(LogStatus.FAIL, "Income Worklist menu NOT displaying in the side panel");}

		  if(pageFact.ovrTolrnceWrklst().contains("OVER TOLERANCE WORKLIST")){
			  System.out.println("PASS:  Over Tolerance Worklist menu displaying in the side panel");
			  extentTest.log(LogStatus.PASS, "Over Tolerance Worklist menu displaying in the side panel");
		  }	else	{  System.out.println("FAIL:  Over Tolerance Worklist menu NOT displaying in the side panel");
		  extentTest.log(LogStatus.FAIL, "Over Tolerance Worklist menu NOT displaying in the side panel");}
   
		   
	 
		  if(pageFact.dialogWrklst().contains("DIALOG WORKLIST")){
			  System.out.println("PASS:  Dialog Worklist menu displaying in the side panel");
			  extentTest.log(LogStatus.PASS, "Dialog Worklist menu displaying in the side panel");
		  } else	{System.out.println("FAIL:  Dialog Worklist menu NOT displaying in the side panel");
		  extentTest.log(LogStatus.FAIL, "Dialog Worklist menu NOT displaying in the side panel");}
 
	  	   
		  if(pageFact.paybckWrklst().contains("PAYBACK WORKLIST")){
			  System.out.println("PASS:  Payback Worklist menu displaying in the side panel");	
			  extentTest.log(LogStatus.PASS, "Payback Worklist menu displaying in the side panel");
		  }	else { System.out.println("FAIL:  Payback Worklist menu NOT displaying in the side panel");
		  extentTest.log(LogStatus.FAIL, "Payback Worklist menu NOT displaying in the side panel");}
 			  
	  // close report.
      extent.endTest(extentTest);
      // writing everything to document.
      extent.flush();  	  
  }
 
  @BeforeTest
  public void beforeTest() {
	  
	//Creation of file object
	  File file = new File("C:\\Users\\u61282\\workspace\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");	  
	 //Creation of properties object
	  Properties prop = new Properties();
	  
	  //Creation of InputStream object to read data
	  FileInputStream objInput = null;
	  try{
		  objInput = new FileInputStream(file);
		  //Reading properties key/values in file
		  prop.load(objInput);
		  //Closing the input stream
		//  objInput.close();
	  }catch(FileNotFoundException e){
		  System.out.println(e.getMessage());
	  }catch(IOException e){
		  System.out.println(e.getMessage());
	  }
	  System.setProperty("webdriver.chrome.driver", new File(System.getProperty("user.dir"), "chromedriver.exe").getAbsolutePath());      
      ChromeOptions chromeOptions = new ChromeOptions(); 
    
     chromeOptions.addArguments("--headless");         
      Driver = new ChromeDriver(chromeOptions); 
      extentTest.log(LogStatus.PASS, "Browser Launched");
      Driver.manage().window().maximize();
      extentTest.log(LogStatus.PASS, "Browser Maximized");
      
//      String url1 = Driver.getCurrentUrl();
//      Assert.assertEquals(url1, "http://40.117.78.82:31862/#");
      
      Driver.get(prop.getProperty("url"));    
      pageFact = new GenericFactory_bckup(Driver);
      pageObj = new PageObjects(Driver);
      pageFact.wait_forprox();
    
		String expPageTitle = "CABS - Centralized Accounting Billing System";
		
		if (Driver.getTitle().equalsIgnoreCase(expPageTitle)) {			  
			System.out.println("Yeah... Page title matched");
		}	
		pageFact.prox_click();
		
		 // close report.
        extent.endTest(extentTest);
        // writing everything to document.
        extent.flush();
	}

  @AfterTest
  public void afterTest() {
	  
  }

}
