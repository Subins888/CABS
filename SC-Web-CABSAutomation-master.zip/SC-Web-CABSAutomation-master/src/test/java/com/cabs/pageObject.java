package com.cabs;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import com.cabs.pages.GenericFactory_bckup;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class pageObject  {
  
	  WebDriver Driver;
	GenericFactory_bckup pageFact;
	String extentReportImage1;
	String extentReportImage2;
//	
//	 String extentReportFile = System.getProperty("user.dir")
//             + "\\extentReportFile3.html";
//
//
//     // Create object of extent report and specify the report file path.
//     ExtentReports extent = new ExtentReports(extentReportFile, false);
//     
//     // Start the test using the ExtentTest class object.
//     ExtentTest extentTest = extent.startTest("CABS Validation",
//             "Verify Login and Other Actions");
//     
     
String extentReportFile = System.getProperty("user.dir")+ "\\extentReportFile.html";
   String extentReportImage = System.getProperty("user.dir")+ "\\extentReportImage.png";
     
ExtentReports extent = new ExtentReports(extentReportFile, false);
     
ExtentReports img = new ExtentReports(extentReportImage, false);
     ExtentTest extentTest = extent.startTest("CABS Home Page","Verify Home Page Screen UI");

     
	public pageObject(WebDriver Driver){
		
		this.Driver = Driver;	
		PageFactory.initElements(Driver, this);
		}
	
  @Test
  public void Login() {
	  
	  
  }
  public void screenShot() throws IOException {
      System.out.println("Method2");
      TakesScreenshot ts = (TakesScreenshot)Driver;
   File source = ts.getScreenshotAs(OutputType.FILE);
    File destination = new File(extentReportImage);
    
           FileUtils.copyFile(source, destination);  
    
     extentTest.log(LogStatus.INFO,"Snapshot : "+ extentTest.addScreenCapture(extentReportImage));
     System.out.println("Screen capture");
}

  public String Title_Check(){
	  
      
      String title = Driver.getTitle();
      extentTest.log(LogStatus.INFO, "Got the WebSite title");
      System.out.println("Title is: "+title);
      extentTest.log(LogStatus.INFO, "Actual title is"+title);
      
      try{

               if(title.contains("Dark Theme")){
                      System.out.println("PASS:  CABS Home page displayed");      
                      extentTest.log(LogStatus.INFO, "Title Matches");
               }           
               else {
                      System.out.println("FAIL:  CABS Home page not displayed");
                      extentTest.log(LogStatus.INFO, "Title not Matches");
                      Assert.assertTrue(title.contains("Gmails"));
                    
                      }
        
        }catch(Exception e){
            
               System.out.println(e);
               extentTest.log(LogStatus.FAIL, "Exception");
      }   
      
      return null;

  }
  
  
  
  public void after() throws IOException{
	  
	  TakesScreenshot ts = (TakesScreenshot)Driver;
	     File source = ts.getScreenshotAs(OutputType.FILE);
	       File destination = new File(extentReportImage1);
	       FileUtils.copyFile(source, destination);  
	        extentTest.log(LogStatus.INFO,"Snapshot : "+ extentTest.addScreenCapture(extentReportImage1));
	       System.out.println("Screen capture"); 
  }
  
 
  @BeforeTest
  public String beforeTest() {
	  
	  
	  
	//Creation of file object
	  File file = new File("C:\\Users\\u61282\\workspace\\ABS_CABS\\src\\test\\java\\com\\cabs\\pages\\properties_File");	  
	 //Creation of properties object
	  Properties prop = new Properties();
	  
	  //Creation of InputStream object to read data
	  FileInputStream objInput = null;
	  try{
		  objInput = new FileInputStream(file);
		  //Reading properties key/values in file
		  prop.load(objInput);
		  //Closing the input stream
		//  objInput.close();
	  }catch(FileNotFoundException e){
		  System.out.println(e.getMessage());
	  }catch(IOException e){
		  System.out.println(e.getMessage());
	  }
	  System.setProperty("webdriver.chrome.driver", new File(System.getProperty("user.dir"), "chromedriverWin.exe").getAbsolutePath());      
      ChromeOptions chromeOptions = new ChromeOptions(); 
      
    
     chromeOptions.addArguments("--headless");         
      Driver = new ChromeDriver(chromeOptions); 
      extentTest.log(LogStatus.PASS, "Browser Launched");
      Driver.manage().window().maximize();
      extentTest.log(LogStatus.PASS, "Browser Maximized");
      
//      String url1 = Driver.getCurrentUrl();
//      Assert.assertEquals(url1, "http://40.117.78.82:31862/#");
      
      Driver.get(prop.getProperty("url"));    
      pageFact = new GenericFactory_bckup(Driver);
   
      pageFact.wait_forprox();
    
		String expPageTitle = "CABS - Centralized Accounting Billing System";
		
		if (Driver.getTitle().equalsIgnoreCase(expPageTitle)) {			  
			System.out.println("Yeah... Page title matched");
		}	
		pageFact.prox_click();
		
	  return null;
	  
  }

  @AfterTest
  public void afterTest() {
	  
	  Driver.quit();
      extent.flush();
  }

}
